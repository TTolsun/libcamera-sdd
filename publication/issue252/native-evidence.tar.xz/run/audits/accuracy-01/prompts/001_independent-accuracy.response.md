{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "제출에서 완료까지; 준비 대기와 재진입을 좁히기; UVC의 장치 제출과 완료를 추적하기",
      "diagnosis_values": "queued 호출의 실행 여부, waitingRequests_ 선두, prepared_, notifiers_, 300ms 타이머, queuedRequests_ 크기와 한도 및 선두 상태를 확인합니다.",
      "next_branch": "준비가 끝나지 않았다면 fence 알림과 timeout을 확인하고, 준비가 끝났다면 취소 여부와 UVC 제출 및 DQBUF 경로를 확인합니다.",
      "change_validation": "동기 준비와 timeout 취소에서 재귀 호출 전에 선두를 pop하고 중복 처리와 순서가 유지되는지 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1308-1383",
        "src/libcamera/pipeline_handler.cpp:428-620",
        "src/libcamera/request.cpp:139-312",
        "src/libcamera/v4l2_videodevice.cpp:1814-1987"
      ],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "UVC의 장치 제출과 완료를 추적하기",
      "diagnosis_values": "findBuffer 결과, 개별 processControl 결과, setControls 반환값과 error_idx, queueBuffer 및 VIDIOC_QBUF 반환값, sequence_를 확인합니다.",
      "next_branch": "버퍼 부재 또는 음수 제출 결과는 공통 취소 경로로 이어집니다. 개별 변환 오류는 무시될 수 있으며 제어 설정 뒤 QBUF가 실패할 수 있습니다.",
      "change_validation": "개별 변환 오류, 부분 제어 실패와 제어 설정 후 QBUF 실패를 각각 주입하고 취소와 부작용을 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:327-470",
        "src/libcamera/v4l2_device.cpp:309-430",
        "src/libcamera/v4l2_videodevice.cpp:1648-1814",
        "src/libcamera/pipeline_handler.cpp:483-501"
      ],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "제출에서 완료까지; UVC의 장치 제출과 완료를 추적하기; 버퍼 알림과 요청 반환의 내부 경계",
      "diagnosis_values": "bufferCompleted 시점의 pending_, 버퍼 metadata.status, 요청 cancelled_와 status, queuedRequests_ 선두를 확인합니다.",
      "next_branch": "DQBUF 실패나 예상하지 못한 인덱스면 bufferReady가 없고, 버퍼를 받으면 UVC가 completeBuffer와 completeRequest를 차례로 호출합니다. 선두가 pending이면 요청 통지가 대기합니다.",
      "change_validation": "FrameError와 RequestComplete의 조합, 버퍼별 단일 완료, pending이 없는 요청 완료 및 제출 순서를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/v4l2_videodevice.cpp:1814-1987",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:893-905",
        "src/libcamera/request.cpp:84-137",
        "src/libcamera/pipeline_handler.cpp:547-607"
      ],
      "missing": [
        "콜백 순서 그림은 선두 검사보다 camera 통지를 먼저 배치합니다."
      ]
    },
    {
      "id": "Q4",
      "answer_location": "요청·버퍼·fence의 수명; 버퍼 알림과 요청 반환의 내부 경계; 콜백의 스레드와 재진입을 구분하기",
      "diagnosis_values": "요청과 버퍼의 소유자, pending_과 버퍼의 request 연결, 남은 fence, 지연된 콜백의 포인터 수명을 확인합니다.",
      "next_branch": "fence가 남았다면 releaseFence로 회수하고, 요청 완료 및 모든 지연 수신자의 수명 조건을 확인한 뒤 재사용을 판단합니다.",
      "change_validation": "직접 버퍼 콜백 중에는 내부 bookkeeping이 끝나지 않았음을 확인하고, queued 수신자가 사용할 때까지 전달된 포인터가 유효한지 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/request.cpp:103-163,326-338,376-475",
        "src/libcamera/pipeline_handler.cpp:547-620",
        "src/libcamera/framebuffer.cpp: request() 및 releaseFence()",
        "src/libcamera/base/signal.cpp:73-113",
        "src/libcamera/base/object.cpp: invokeMethod 계약"
      ],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "정지와 연결 해제를 구분하기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "CameraStopping, 분리된 waitingRequests_, streamOff 반환값, state_, queuedBuffers_, cache_, releaseBuffers 결과와 ASSERT 도달 여부를 확인합니다.",
      "next_branch": "STREAMOFF 성공이면 버퍼 취소와 알림을 추적하고, 실패면 조기 반환 후 UVC의 releaseBuffers 호출과 남은 큐 및 알림 상태를 조사합니다.",
      "change_validation": "대기 및 장치 요청이 섞인 경우와 STREAMOFF 및 releaseBuffers 실패를 각각 주입해 완료 횟수, 순서, 잔존 큐와 재투입을 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1431-1475",
        "src/libcamera/pipeline_handler.cpp:359-414",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320-327,893-905",
        "src/libcamera/v4l2_videodevice.cpp:1616-1629,2023-2059"
      ],
      "missing": [
        "기존 stopDevice 관찰 그림의 ‘구현 미검토’ 표기는 같은 문서의 UVC 구현 분석과 충돌합니다."
      ]
    },
    {
      "id": "Q6",
      "answer_location": "콜백의 스레드와 재진입을 구분하기; 정지와 연결 해제를 구분하기; 공개 가상 카메라의 콜백 관찰",
      "diagnosis_values": "수신자의 Object 여부, 연결 종류, 현재 및 수신 스레드, 이벤트 루프 진행과 콜백 진입·복귀 표식을 확인합니다.",
      "next_branch": "Auto는 스레드가 같으면 Direct이고 다르면 Queued입니다. Blocking은 같은 스레드면 Direct이고 그 밖에는 호출 완료 신호를 기다립니다.",
      "change_validation": "직접 호출의 중첩 진입, 지연 콜백의 포인터 수명, 호출자 동기화와 별도 콜백 drain을 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/base/bound_method.cpp:22-108",
        "include/libcamera/base/bound_method.h: BoundMethodArgs, BoundMethodMember, BoundMethodStatic",
        "src/libcamera/base/object.cpp: postMessage 및 invokeMethod 계약",
        "Documentation/thread-safety.dox:1-46",
        "src/libcamera/camera.cpp:769-784,1431-1475"
      ],
      "missing": []
    },
    {
      "id": "Q7",
      "answer_location": "준비 대기와 재진입을 좁히기; UVC 정지의 정상 경로와 실패 경계; 변경 검토와 실행 확인",
      "diagnosis_values": "pop 순서, 버퍼별 완료 횟수, pending_, 요청 접근 시점, 큐와 sequence_, 정지 후 재투입 여부를 확인합니다.",
      "next_branch": "준비 취소, 제어 및 QBUF 실패, DQBUF 실패 또는 예상 밖 인덱스, FrameError, STREAMOFF 실패를 각각 추적합니다.",
      "change_validation": "각 실패 주입마다 예상 분기와 완료 횟수, 제출 순서, 잔존 상태 및 수명 조건을 대조해야 합니다.",
      "answerable": false,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp:359-414,483-620",
        "src/libcamera/request.cpp:84-163,192-312",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320-470,893-905",
        "src/libcamera/v4l2_videodevice.cpp:1648-1987,2023-2059"
      ],
      "missing": [
        "변경 검토 절에는 필수 실패 주입별 예상 분기와 검증 조건을 연결한 매트릭스가 없습니다.",
        "각 버퍼를 정확히 한 번 완료해야 한다는 조건이 변경 검증 항목으로 명시되지 않습니다."
      ]
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q3",
      "claim": "callback-order-flow 그림은 completeRequest가 camera에 완료를 알린 뒤 queuedRequests_ 선두의 RequestPending 여부를 검사하는 순서로 표시합니다.",
      "counterevidence": "src/libcamera/pipeline_handler.cpp:571-607에서 completeRequest는 먼저 현재 요청의 complete()를 호출하고, 큐 선두가 RequestPending이면 중단합니다. 그 밖의 경우에만 pending 버퍼를 검사하고 pop_front한 뒤 camera->requestComplete(req)를 호출합니다.",
      "fix": "현재 요청의 상태 갱신, 선두 검사, pending 검사와 pop, camera 통지의 순서로 그림을 수정합니다."
    },
    {
      "blocking": true,
      "question": "Q7",
      "claim": "변경 검토는 일부 관찰 계획을 제시하지만 실패 주입별 예상 분기와 단일 버퍼 완료 조건을 하나의 검증 경로로 연결하지 않습니다.",
      "counterevidence": "src/libcamera/request.cpp:84-137은 각 버퍼를 정확히 한 번 완료하고 요청 완료 전에 pending이 없어야 한다고 명시합니다. pipeline_handler.cpp:483-620과 v4l2_videodevice.cpp:1814-1987,2023-2059는 각각 제출 실패, DQBUF 오류와 STREAMOFF 실패에서 서로 다른 분기를 실행합니다.",
      "fix": "준비 취소, 제어 실패, QBUF 실패, DQBUF 오류·예상 밖 인덱스, FrameError 및 STREAMOFF 실패를 구분하고 각 경우의 예상 분기, 완료 횟수, 순서, 잔존 상태와 수명 검사 조건을 제시합니다."
    },
    {
      "blocking": false,
      "question": "Q5",
      "claim": "stop-device-observation-plan 그림은 실제 stopDevice 구현을 ‘구현 미검토’라고 표시합니다.",
      "counterevidence": "같은 문서의 UVC 정지 절은 src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320-327과 v4l2_videodevice.cpp:2023-2059를 근거로 선택한 UVC 구현과 STREAMOFF 실패 분기를 분석합니다.",
      "fix": "해당 표기를 선택한 UVC 구현의 정적 분석과 미실행 관찰 계획으로 갱신하고, 다른 구현을 미검토 범위로 구분합니다."
    }
  ],
  "items": [
    {
      "anchor": "제출에서 완료까지",
      "question": "제출과 준비, 장치 처리 및 완료는 어떻게 연결됩니까?",
      "visual_status": "보완 필요",
      "reason": "질문별 흐름도는 있지만 callback-order-flow의 camera 통지 순서가 소스와 다릅니다."
    },
    {
      "anchor": "준비 대기와 재진입을 좁히기",
      "question": "준비 완료와 재귀 전달은 어떻게 연결됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "fence, timeout, prepared와 선두 pop을 연결하는 그림이 있습니다."
    },
    {
      "anchor": "UVC의 장치 제출과 완료를 추적하기",
      "question": "제출 실패와 버퍼 완료 경로는 어떻게 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "제출 실패의 취소와 버퍼 알림 후 명시적 완료를 구분합니다."
    },
    {
      "anchor": "요청·버퍼·fence의 수명",
      "question": "누가 자원을 유지하고 fence를 회수합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "소유권, timeout 후 회수 및 ReuseBuffers의 범위를 각각 표시합니다."
    },
    {
      "anchor": "버퍼 알림과 요청 반환의 내부 경계",
      "question": "버퍼 신호, 내부 갱신과 요청 통지는 어떤 순서입니까?",
      "visual_status": "보완 필요",
      "reason": "그림이 queuedRequests_ 선두 검사보다 camera 통지를 먼저 배치합니다."
    },
    {
      "anchor": "콜백의 스레드와 재진입을 구분하기",
      "question": "Auto 연결은 Direct와 Queued 중 무엇을 선택합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "현재 스레드와 수신 스레드 비교 및 두 실행 방식을 표시합니다."
    },
    {
      "anchor": "정지와 연결 해제를 구분하기",
      "question": "정지 순서와 연결 해제 TODO는 어떻게 다릅니까?",
      "visual_status": "보완 필요",
      "reason": "정지와 연결 해제 그림은 있으나 stopDevice 관찰 그림의 구현 미검토 표기가 현재 분석과 충돌합니다."
    },
    {
      "anchor": "UVC 정지의 정상 경로와 실패 경계",
      "question": "STREAMOFF 실패는 버퍼 반환에 어떤 영향을 줍니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "ioctl 실패의 조기 반환과 성공 시 버퍼 반환, 이후 releaseBuffers 호출을 구분합니다."
    },
    {
      "anchor": "변경 검토와 실행 확인",
      "question": "변경 전에 어떤 불변조건과 실패 분기를 확인합니까?",
      "visual_status": "보완 필요",
      "reason": "여러 실패 분기와 검증 조건을 연결하는 질문별 그림이나 충분한 표가 없습니다."
    },
    {
      "anchor": "공개 가상 카메라의 콜백 관찰",
      "question": "가상 프로브의 콜백 표식은 어디에 배치되었습니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "연결별 표식과 실제 C++ 반환을 추적하지 않은 한계를 별도 그림으로 표시합니다."
    },
    {
      "anchor": "소스 근거",
      "question": "문서에 인용된 근거 원문은 무엇입니까?",
      "visual_status": "생략 가능",
      "reason": "원문과 출처를 제공하는 참조 항목입니다."
    }
  ],
  "unreviewed_scope": [
    "다른 파이프라인, IPA 처리 및 커널 UVC 드라이버 구현은 범위에서 제외되었습니다.",
    "물리 UVC 촬영, DMA 정확성, 성능 및 내부 Camera HAL 검증은 수행하지 않았습니다.",
    "실제 비저자 독자 평가와 사람 검토는 수행하지 않았습니다.",
    "제공된 전체 소스 창과 문서 발췌를 검토했습니다. 별도 원고, Mermaid 원본 파일 및 원시 프로브 이벤트는 제공되지 않아 독립적으로 대조하지 못했습니다."
  ]
}
