{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "제출에서 완료까지; 준비 대기와 재진입을 좁히기; UVC의 장치 제출과 완료를 추적하기",
      "diagnosis_values": "queued 호출의 실행 여부, waitingRequests_ 선두, prepared_, notifiers_, 300ms 타이머, queuedRequests_ 크기와 한도, 선두 요청 상태",
      "next_branch": "호출이 실행되지 않았다면 수신 스레드의 메시지 처리부터 확인합니다. 실행되었다면 fence·타임아웃과 큐 한도를 확인한 뒤 UVC 제출 및 DQBUF 분기로 이동합니다.",
      "change_validation": "준비 취소와 재귀 전달에서 선행 pop, 중복 처리 부재 및 제출 순서를 확인합니다.",
      "answerable": false,
      "source_windows": [
        "src/libcamera/camera.cpp:1308-1383",
        "src/libcamera/base/object.cpp:postMessage, invokeMethod",
        "src/libcamera/request.cpp:192-312",
        "src/libcamera/pipeline_handler.cpp:428-620",
        "src/libcamera/v4l2_videodevice.cpp:1814-1987"
      ],
      "missing": [
        "0 반환 후 PipelineHandler::queueRequest 호출 자체가 아직 실행되지 않은 경우의 메시지 큐·이벤트 루프 조사 경로"
      ]
    },
    {
      "id": "Q2",
      "answer_location": "UVC의 장치 제출과 완료를 추적하기; 변경 검토와 실행 확인",
      "diagnosis_values": "findBuffer 결과, processControl 및 setControls 결과, error_idx, queueBuffer와 VIDIOC_QBUF ret, queuedBuffers_, sequence_",
      "next_branch": "버퍼 없음 또는 전파된 음수 결과는 공통 cancelRequest로 이어집니다. 개별 processControl 반환은 무시되며, 제어 처리 후 QBUF가 실패할 수도 있습니다.",
      "change_validation": "제어 오류와 QBUF 실패를 별도로 주입하고 취소·순번·큐 등록 및 제어 부작용을 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:327-470",
        "src/libcamera/v4l2_device.cpp:309-430",
        "src/libcamera/v4l2_videodevice.cpp:1648-1814",
        "src/libcamera/pipeline_handler.cpp:483-501"
      ],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "UVC의 장치 제출과 완료를 추적하기; 버퍼 알림과 요청 반환의 내부 경계",
      "diagnosis_values": "DQBUF ret와 index, 버퍼 metadata.status, pending_, 요청 cancelled_와 status, queuedRequests_ 선두, requestCompleted",
      "next_branch": "DQBUF 실패나 미등록 인덱스는 이번 bufferReady를 생략합니다. 유효 버퍼는 UVC 완료 경로를 거치며 FrameError와 RequestComplete를 별도로 확인합니다.",
      "change_validation": "오류 플래그, DQBUF 실패 및 예상 밖 인덱스를 각각 검사하고 버퍼 추적과 제출 순서를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/v4l2_videodevice.cpp:1814-1987",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:893-905",
        "src/libcamera/pipeline_handler.cpp:547-620",
        "src/libcamera/request.cpp:91-139"
      ],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "요청·버퍼·fence의 수명; 버퍼 알림과 요청 반환의 내부 경계; 콜백의 스레드와 재진입을 구분하기",
      "diagnosis_values": "소유자, fence 유무, 연결 종류, pending_, 버퍼의 request 연결, 지연된 포인터와 수신 완료",
      "next_branch": "직접 버퍼 콜백은 내부 pending 제거 전에 실행될 수 있습니다. 요청 완료와 모든 지연 수신자의 포인터 사용을 구분합니다.",
      "change_validation": "콜백 중 재사용이 내부 추적을 손상하지 않는지, queued 수신이 끝날 때까지 인자가 유효한지 검토합니다.",
      "answerable": false,
      "source_windows": [
        "src/libcamera/request.cpp:91-173, 376-475",
        "src/libcamera/framebuffer.cpp:FrameBuffer::request, releaseFence",
        "src/libcamera/pipeline_handler.cpp:547-620",
        "src/libcamera/base/signal.cpp:73-113",
        "src/libcamera/base/object.cpp:invokeMethod"
      ],
      "missing": [
        "버퍼 완료 콜백에서 즉시 재사용하거나 요청 연결을 바꾸는 경우의 구체적인 제한과 안전한 판단 경계",
        "queueRequest의 queued invokeMethod에 전달된 Request 포인터도 호출될 때까지 유효해야 한다는 연결"
      ]
    },
    {
      "id": "Q5",
      "answer_location": "정지와 연결 해제를 구분하기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "waitingRequests_, queuedRequests_, STREAMOFF ret, state_, queuedBuffers_, cache_, releaseBuffers ret 및 ASSERT 도달 여부",
      "next_branch": "STREAMOFF 실패는 버퍼 반환 루프를 건너뛰지만 UVC는 releaseBuffers를 호출합니다. 공통 정지의 큐 검사와 CameraStopping 이후 경로를 별도로 확인합니다.",
      "change_validation": "정상 정지, STREAMOFF 실패, releaseBuffers 실패 및 정지 중 재투입을 별도 사례로 기록합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp:359-414",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320-327",
        "src/libcamera/v4l2_videodevice.cpp:1616-1629, 2023-2059",
        "src/libcamera/camera.cpp:1431-1475"
      ],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "콜백의 스레드와 재진입을 구분하기; 정지와 연결 해제를 구분하기; 공개 가상 카메라의 콜백 관찰",
      "diagnosis_values": "연결 종류, 현재·수신 스레드, 이벤트 루프 진행, Blocking 호출 및 별도 queued 콜백의 완료 표식",
      "next_branch": "Auto는 스레드 비교로 Direct 또는 Queued를 선택합니다. Blocking stop 복귀와 별도 수신자의 queued 콜백 처리를 구분합니다.",
      "change_validation": "직접 콜백의 중첩 호출 허용 여부, 호출자 동기화, 지연된 인자의 수명과 콜백 처리 완료를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/base/bound_method.cpp:22-110",
        "include/libcamera/base/bound_method.h:59-209",
        "src/libcamera/base/object.cpp:postMessage, message, invokeMethod",
        "Documentation/thread-safety.dox:1-46",
        "src/libcamera/camera.cpp:769-784, 1431-1475"
      ],
      "missing": []
    },
    {
      "id": "Q7",
      "answer_location": "변경 검토와 실행 확인; 준비 대기와 재진입을 좁히기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "cookie, sequence, 버퍼별 완료 횟수, pending_, 큐 선두와 잔존 항목, 실패별 ret, 콜백 및 정지 표식",
      "next_branch": "준비 취소, 제어·QBUF 실패, DQBUF 오류, FrameError, 정상·실패 정지와 재진입을 각각 검토합니다.",
      "change_validation": "재귀 전달 전 pop, 정상 완료에서 버퍼당 한 번의 내부 완료, 요청 완료 시 pending 없음, 완료 후 접근 금지 및 정지 중 재투입 방지를 확인합니다.",
      "answerable": false,
      "source_windows": [
        "src/libcamera/request.cpp:91-173, 192-312",
        "src/libcamera/pipeline_handler.cpp:359-620",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320-470, 893-905",
        "src/libcamera/v4l2_videodevice.cpp:1648-2059",
        "src/libcamera/base/bound_method.cpp:22-110"
      ],
      "missing": [
        "취소 경로는 각 pending 버퍼에 대해 PipelineHandler::completeBuffer를 호출하지 않는다는 예외",
        "변경 검토 항목의 독립적인 질문별 그림 또는 구체적인 생략 사유"
      ]
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q7",
      "claim": "변경 검토 절은 각 버퍼를 요청 완료 전에 정확히 한 번 completeBuffer로 완료해야 한다고 무조건 서술합니다.",
      "counterevidence": "src/libcamera/request.cpp:139-173의 doCancelRequest()는 pending 버퍼를 cancel하고 bufferCompleted를 직접 발생시킨 뒤 pending_을 clear합니다. 준비 타임아웃과 cancelRequest도 이 경로를 사용합니다.",
      "fix": "정상 버퍼 완료의 내부 completeBuffer 일회 호출 계약과 취소 시 직접 신호 및 pending_ 정리 경로를 분리하고, 두 경로에서 중복 완료가 없는지 검증하도록 수정합니다."
    },
    {
      "blocking": true,
      "question": "Q3",
      "claim": "callback-order-flow 그림은 bufferCompleted 신호를 보낸 뒤 completeBuffer를 호출한다고 표시합니다.",
      "counterevidence": "src/libcamera/pipeline_handler.cpp:547-568에서 이미 실행 중인 PipelineHandler::completeBuffer()가 신호를 발생시킨 다음 Request::Private::completeBuffer()를 호출합니다.",
      "fix": "그림에 두 함수의 한정된 이름을 표시하고 PipelineHandler::completeBuffer 진입 → 신호 → Request::Private::completeBuffer 및 pending 제거 순서로 수정합니다."
    },
    {
      "blocking": true,
      "question": "Q1, Q4",
      "claim": "문서는 queued 제출과 일반적인 신호 포인터 수명을 설명하지만, 제출 호출 자체가 실행되지 않은 경우와 그 Request 포인터의 수명을 연결하지 않습니다.",
      "counterevidence": "src/libcamera/camera.cpp:1308-1383은 Request 포인터를 ConnectionTypeQueued로 전달합니다. src/libcamera/base/object.cpp의 invokeMethod 계약은 포인터가 호출될 때까지 유효해야 하며 queued 호출이 스레드 정지 전에 실행된다고 보장하지 않습니다.",
      "fix": "제출 메시지의 수신·이벤트 루프 상태를 첫 조사 분기에 추가하고, 전달된 Request 포인터의 유효 기간을 명시합니다."
    },
    {
      "blocking": true,
      "question": "Q4",
      "claim": "문서는 bufferCompleted가 pending 제거보다 이르다고 설명하지만, 직접 버퍼 콜백에서 재사용할 수 있는지에 대한 실질적인 결론을 제공하지 않습니다.",
      "counterevidence": "src/libcamera/pipeline_handler.cpp:547-568은 신호 후 내부 완료를 호출하고, src/libcamera/request.cpp:103-116은 이후 pending_에서 지우고 buffer의 request 연결을 nullptr로 설정합니다. 콜백 중 연결을 바꾸면 후속 내부 갱신과 충돌할 수 있습니다.",
      "fix": "직접 버퍼 콜백에서 내부 완료가 끝났다고 가정해 요청이나 버퍼 연결을 재설정하지 않도록 설명하고, 요청 완료와 지연된 수신자의 수명 조건을 함께 제시합니다."
    },
    {
      "blocking": true,
      "question": "Q5",
      "claim": "callback-order-flow 그림은 연결이 끊긴 카메라도 요청을 완료할 수 있다고 조건 없이 표시합니다.",
      "counterevidence": "src/libcamera/camera.cpp의 Camera::Private::disconnect()는 Running을 Configured로 바꾸며, Camera::requestComplete():1475-1491은 연결 해제를 허용하더라도 상태가 CameraStopping부터 CameraRunning 범위 밖이면 Fatal을 기록합니다.",
      "fix": "연결 해제 허용 플래그와 별도의 상태 검사를 구분하고 Running 중 연결 해제로 Configured가 되는 반례를 표시합니다."
    },
    {
      "blocking": true,
      "question": "Q7",
      "claim": "변경 검토와 실행 확인은 여러 실패 주입과 불변조건을 다루지만 해당 독립 항목에 그림이나 생략 사유가 없습니다.",
      "counterevidence": "집필 규칙 README.md의 항목 9-12는 독립적인 긴 분기·단계 항목의 질문별 그림을 검토하고, 필요한 그림의 누락 또는 생략 사유를 기록하도록 요구합니다.",
      "fix": "실패 주입과 확인할 불변조건을 연결하는 해당 항목 전용 그림을 추가하거나 구체적인 생략 사유를 기록합니다."
    }
  ],
  "items": [
    {
      "anchor": "제출에서 완료까지",
      "question": "제출과 완료는 어떻게 연결됩니까?",
      "visual_status": "보완 필요",
      "reason": "단계별 그림은 있으나 별도로 지적한 완료 순서 그림의 함수 경계를 수정해야 합니다."
    },
    {
      "anchor": "제출·준비·장치 처리·완료의 연결",
      "question": "정상 요청 단계는 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "정상 경로와 명시적 요청 완료를 구분합니다."
    },
    {
      "anchor": "접수 반환과 완료 알림",
      "question": "0 반환과 완료 알림은 어떻게 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "queued 호출과 별도 완료 알림을 구분합니다."
    },
    {
      "anchor": "선두 요청을 전달하거나 반복을 멈추는 조건",
      "question": "대기 요청 전달은 언제 멈춥니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "선두 준비 상태, 큐 한도와 pop 순서를 표시합니다."
    },
    {
      "anchor": "void 전달 함수의 두 취소 경로",
      "question": "준비 취소와 장치 제출 실패는 어떻게 처리합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "이미 취소된 요청과 장치 반환 오류를 분기합니다."
    },
    {
      "anchor": "버퍼 완료와 명시적 요청 완료의 경계",
      "question": "마지막 버퍼 완료 후 무엇이 필요합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "completeBuffer 결과와 별도 completeRequest 의무를 구분합니다."
    },
    {
      "anchor": "제출 큐의 선두 상태와 반환 순서",
      "question": "완료된 요청은 언제 반환됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "선두 Pending 검사와 큐 제거 후 통지를 표시합니다."
    },
    {
      "anchor": "준비 대기와 재진입을 좁히기",
      "question": "fence 준비와 재귀 전달은 어떻게 연결됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "해당 절의 그림이 준비 신호와 선행 pop을 연결합니다."
    },
    {
      "anchor": "준비 대기와 재진입을 좁히기 그림",
      "question": "준비 완료와 타임아웃은 어느 분기로 이어집니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "fence, 타임아웃, prepared와 전달 조건을 표시합니다."
    },
    {
      "anchor": "UVC의 장치 제출과 완료를 추적하기",
      "question": "UVC 제출 실패와 완료는 어떻게 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "해당 절의 그림이 취소와 장치 버퍼 완료를 분리합니다."
    },
    {
      "anchor": "UVC의 장치 제출과 완료를 추적하기 그림",
      "question": "제출 실패와 bufferReady는 어느 완료 경로로 이어집니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "제출 실패 취소와 명시적 요청 완료를 구분합니다."
    },
    {
      "anchor": "요청·버퍼·fence의 수명",
      "question": "자원의 소유권과 재사용 조건은 무엇입니까?",
      "visual_status": "보완 필요",
      "reason": "수명 그림은 있으나 직접 버퍼 콜백의 재사용 경계와 queued 요청 포인터 수명 설명이 부족합니다."
    },
    {
      "anchor": "요청과 버퍼를 유지할 기간",
      "question": "요청과 버퍼는 누가 유지합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "호출자 소유와 핸들러의 반환 후 접근 금지를 구분합니다."
    },
    {
      "anchor": "타임아웃 뒤 펜스 회수",
      "question": "타임아웃 뒤 버퍼를 재사용하려면 무엇이 필요합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "남은 fence의 회수 조건을 표시합니다."
    },
    {
      "anchor": "버퍼 재사용과 펜스 권고",
      "question": "ReuseBuffers와 fence의 범위는 어떻게 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "버퍼 재사용과 fence에 대한 should-not 권고를 구분합니다."
    },
    {
      "anchor": "버퍼 알림과 요청 반환의 내부 경계",
      "question": "버퍼 신호와 내부 추적은 어떤 순서입니까?",
      "visual_status": "보완 필요",
      "reason": "전용 그림의 completeBuffer 호출 순서와 연결 해제 상태 설명에 오류가 있습니다."
    },
    {
      "anchor": "버퍼 알림과 요청 반환의 내부 경계 그림",
      "question": "신호, pending 제거와 요청 통지는 어떻게 이어집니까?",
      "visual_status": "보완 필요",
      "reason": "공개 핸들러 함수와 Request의 내부 함수를 구별하지 않아 호출 순서를 잘못 표시합니다."
    },
    {
      "anchor": "콜백의 스레드와 재진입을 구분하기",
      "question": "연결 종류에 따라 콜백은 어디서 실행됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "전용 그림과 본문이 Auto, Direct, Queued 및 Blocking을 구분합니다."
    },
    {
      "anchor": "콜백의 스레드와 재진입을 구분하기 그림",
      "question": "Auto는 Direct와 Queued 중 무엇을 선택합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "현재 스레드와 수신 스레드의 비교 분기를 표시합니다."
    },
    {
      "anchor": "정지와 연결 해제를 구분하기",
      "question": "정지와 연결 해제 계약은 어떻게 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "정상 정지 순서와 연결 해제 TODO를 전용 그림으로 구분합니다."
    },
    {
      "anchor": "정지할 때 대기 요청을 처리하는 순서",
      "question": "정상 정지에서 대기 요청은 어떤 순서로 처리됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "대기 큐 분리, 장치 정지 및 취소 순서를 표시합니다."
    },
    {
      "anchor": "정지 API 계약과 연결 해제 TODO",
      "question": "정지 계약과 연결 해제 TODO는 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "두 소스의 서로 다른 범위를 표시합니다."
    },
    {
      "anchor": "Camera::stop의 미실행·오류·정상 경로",
      "question": "Camera::stop은 어떤 조건으로 반환합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "미실행, 접근 오류 및 정상 경로를 분기합니다."
    },
    {
      "anchor": "stopDevice 호출 구간의 관찰 계획",
      "question": "stopDevice의 진입과 복귀를 어떻게 조사합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "호출 지점과 구현 진입·복귀를 별도 관찰 항목으로 표시합니다."
    },
    {
      "anchor": "완료 통지의 호출자 의무와 반환 뒤 경계",
      "question": "완료 함수 호출자의 의무는 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "호출 스레드, 반환 순서 및 반환 후 접근 금지를 연결합니다."
    },
    {
      "anchor": "UVC 정지의 정상 경로와 실패 경계",
      "question": "STREAMOFF 실패는 정상 반환과 어떻게 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "전용 그림과 본문이 조기 반환 및 무시된 반환값을 다룹니다."
    },
    {
      "anchor": "UVC 정지의 정상 경로와 실패 경계 그림",
      "question": "STREAMOFF 성공과 실패는 어떤 분기로 이어집니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "실패 시 버퍼 반환 루프 생략과 releaseBuffers 호출을 표시합니다."
    },
    {
      "anchor": "변경 검토와 실행 확인",
      "question": "변경 후 어떤 실패와 불변조건을 검증합니까?",
      "visual_status": "보완 필요",
      "reason": "여러 독립 실패 사례와 불변조건을 다루지만 전용 그림이나 구체적인 생략 사유가 없습니다."
    },
    {
      "anchor": "공개 가상 카메라의 콜백 관찰",
      "question": "가상 프로브에서 무엇이 관찰되었습니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "연결별 표식과 반환 근처 표식의 한계를 별도로 표시합니다."
    },
    {
      "anchor": "가상 CPU 프로브의 연결별 취소 콜백 표시",
      "question": "연결별 취소 콜백 표식은 어디에 있었습니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "세 실행의 제한된 관찰 범위를 표시합니다."
    },
    {
      "anchor": "반환 근처 표시로 알 수 있는 범위",
      "question": "콜백 반환 표식은 무엇을 증명하지 못합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "표식 이후 작업과 실제 C++ 반환 미추적을 구분합니다."
    },
    {
      "anchor": "소스 근거",
      "question": "인용한 원문을 어디서 대조합니까?",
      "visual_status": "생략 가능",
      "reason": "펼칠 수 있는 근거 발췌 목록이며 독립적인 처리 분기를 설명하는 항목이 아닙니다."
    }
  ],
  "unreviewed_scope": [
    "실제 독자 평가와 비작성자 사람 검토는 수행되지 않았습니다.",
    "물리 UVC 촬영, DMA 정확성, 성능 및 내부 Camera HAL 검증은 범위 밖입니다.",
    "다른 파이프라인, IPA와 커널 UVC 드라이버 구현은 범위 밖입니다.",
    "src/libcamera/base/thread.cpp 전체와 프로브 원본 코드는 제공된 전체 소스 창에 없으며, 각각 문서에 포함된 발췌와 보존된 관측 기록만 대조했습니다."
  ]
}
