{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "「준비 대기와 재진입을 좁히기」와 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "camera.cpp:1308의 queued 호출, pipeline_handler.cpp:435의 waitingRequests_ 선두와 queuedRequests_ 크기, request.cpp:192의 prepared_, notifiers_, 300ms 타이머, pipeline_handler.cpp:571의 선두 status를 확인합니다.",
      "next_branch": "메시지가 소비되지 않았다면 대상 스레드와 dispatch를 확인합니다. 소비되었다면 fence 또는 큐 한도를 확인하고, 장치에 제출되었다면 QBUF와 DQBUF 분기를 확인합니다.",
      "change_validation": "준비 취소와 재귀 호출에서 선두 pop이 전달보다 앞서는지, 요청별 전달 횟수와 제출 순서가 유지되는지 검증합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/base/thread.cpp",
        "src/libcamera/base/object.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "「UVC의 장치 제출과 완료를 추적하기」와 「실패 주입별 다음 관찰 분기」",
      "diagnosis_values": "uvcvideo.cpp:427 및 :448의 findBuffer, processControl과 setControls 반환값, v4l2_device.cpp:309의 error_idx, v4l2_videodevice.cpp:1648의 cache_, QBUF ret와 index, pipeline_handler.cpp:483의 sequence_를 확인합니다.",
      "next_branch": "버퍼가 없거나 제어 처리 또는 큐잉이 음수를 반환하면 공통 cancelRequest 경로를 확인합니다. cache_ 부재는 Fatal 경계로 따로 취급합니다.",
      "change_validation": "제어 처리 실패와 제어 처리 후 QBUF 실패를 각각 주입해 등록 여부, 취소 횟수와 통지 순서를 확인하고 제어 롤백을 가정하지 않습니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_device.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/pipeline_handler.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "「버퍼 알림과 요청 반환의 내부 경계」와 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "pipeline_handler.cpp:547의 bufferCompleted 발생과 pending 제거 순서, request.cpp:103의 cancelled_와 status, v4l2_videodevice.cpp:1814의 DQBUF ret, index와 FrameMetadata status, queuedRequests_ 선두 상태를 확인합니다.",
      "next_branch": "DQBUF 실패 또는 미등록 index면 해당 bufferReady 없이 반환합니다. 유효 버퍼면 UVC의 명시적 completeRequest와 선두 대기 여부를 확인합니다.",
      "change_validation": "FrameError와 RequestComplete가 함께 가능한 사례, pending 제거 횟수, 요청 완료와 연결별 콜백을 각각 기록합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/framebuffer.cpp",
        "src/libcamera/camera.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "「요청·버퍼·fence의 수명」, 「버퍼 알림과 요청 반환의 내부 경계」, 「Queued 수신과 해제 시점의 책임」",
      "diagnosis_values": "camera.cpp:1243의 요청 소유권, request.cpp:442의 버퍼 유지 계약과 fence 소유권, request.cpp:103 및 :139의 pending 처리, object.cpp:258의 포인터 인자 수명을 확인합니다.",
      "next_branch": "직접 버퍼 콜백에서는 내부 연결 해제 전인지 확인합니다. timeout이면 releaseFence를 확인하고, 지연 수신자가 있으면 마지막 사용을 별도로 추적합니다.",
      "change_validation": "정상 완료와 bulk 취소에서 연결 값 및 완료 횟수를 구분하고, 요청 재사용 또는 삭제 전에 모든 관련 지연 수신자의 마지막 사용을 동기화합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/framebuffer.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/base/object.cpp",
        "src/libcamera/base/signal.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "「정지와 연결 해제를 구분하기」와 「UVC 정지의 정상 경로와 실패 경계」",
      "diagnosis_values": "pipeline_handler.cpp:359의 waitingRequests_ swap과 두 ASSERT, camera.cpp:1431의 CameraStopping 및 Blocking 호출, uvcvideo.cpp:320의 무시된 반환값, v4l2_videodevice.cpp:1616 및 :2023의 ret, cache_, notifier와 queuedBuffers_를 확인합니다.",
      "next_branch": "STREAMOFF 실패면 버퍼 반환 루프에 도달하지 않은 채 UVC가 releaseBuffers를 호출하는 경로와, 잔존 알림 후 알려진 index의 DQBUF를 확인합니다.",
      "change_validation": "정상 정지, STREAMOFF 실패, releaseBuffers 실패를 따로 주입해 완료 횟수, 큐 잔존, ASSERT 도달과 재투입 여부를 기록합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "「콜백의 스레드와 재진입을 구분하기」와 「stop 반환과 별도 수신의 마지막 사용 확인」",
      "diagnosis_values": "bound_method.cpp:68의 Auto, Direct, Queued, Blocking 분기, thread.cpp:558 및 :613의 메시지 게시와 필터, camera.cpp:769 및 :1431의 호출자 동기화와 stop 상태를 확인합니다.",
      "next_branch": "수신자의 Object 여부와 스레드가 같으면 Direct 가능성을, 다르면 게시와 메시지 소비 여부를 확인합니다. stop 반환만으로 별도 수신자의 마지막 사용을 판단하지 않습니다.",
      "change_validation": "연결별 송신·수신 TID, 재귀 깊이, 콜백 진입·복귀와 포인터 마지막 사용을 기록하고 상태 변경 호출을 동기화합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/base/bound_method.cpp",
        "src/libcamera/base/thread.cpp",
        "src/libcamera/base/object.cpp",
        "src/libcamera/base/signal.cpp",
        "include/libcamera/base/signal.h",
        "include/libcamera/base/bound_method.h",
        "Documentation/thread-safety.dox",
        "src/libcamera/camera.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q7",
      "answer_location": "「변경 검토와 실행 확인」과 「실패 주입별 다음 관찰 분기」",
      "diagnosis_values": "pipeline_handler.cpp:435의 pop 순서, request.cpp:91 및 :139의 pending 처리, pipeline_handler.cpp:547의 완료와 접근 금지 계약, v4l2_videodevice.cpp:2023의 정지 분기를 확인합니다.",
      "next_branch": "준비 timeout, 제어 처리 및 QBUF 실패, DQBUF 오류와 FrameError, 정상 정지와 STREAMOFF 실패를 별도 사례로 추적합니다.",
      "change_validation": "버퍼별 완료 횟수, 요청 완료 전 pending 부재, 제출 순서, 완료 후 접근 금지, 정지 중 재투입 부재와 지연 콜백의 마지막 사용을 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_device.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/base/bound_method.cpp",
        "src/libcamera/camera.cpp"
      ],
      "missing": []
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q6",
      "claim": "「직접 중첩 호출과 별도 Queued 수신의 경계」 그림은 bufferCompleted.emit이 연결된 슬롯을 순서대로 호출한다고 단정합니다.",
      "counterevidence": "include/libcamera/base/signal.h:138은 슬롯의 activate를 순서대로 호출합니다. 그러나 src/libcamera/base/bound_method.cpp:68의 Queued 분기는 메시지를 게시하고 수신 완료를 기다리지 않으므로 서로 다른 수신 함수의 실제 실행 순서나 완료 순서는 그 문구만으로 보장되지 않습니다.",
      "fix": "그림에서 연결 순서대로 수행되는 동작을 슬롯 activate로 명시하고, Queued 수신 함수의 실행과 완료 순서는 별도라고 표시합니다."
    },
    {
      "blocking": false,
      "question": "Q1",
      "claim": "「동시 제출의 순서를 관찰할 경계」 그림의 영문 번역에는 메시지 처리 설명이 'execution is \"'에서 끊긴 항목이 있습니다.",
      "counterevidence": "같은 그림의 한국어 원문은 메시지 처리 시 waitingRequests_에 추가하고 준비하며 스레드 정지 전 실행은 보장되지 않는다고 설명합니다. src/libcamera/base/object.cpp:258도 Queued 호출의 정지 전 실행을 보장하지 않습니다.",
      "fix": "잘린 영문 번역과 근거 표의 data-sdd-label-en을 완전한 문장으로 복원하고 한국어와 조건을 대조합니다."
    },
    {
      "blocking": false,
      "question": "Q6",
      "claim": "「stop 반환과 별도 수신의 마지막 사용 확인」 그림의 영문 근거 라벨에는 'its cat'과 'not a test ce'에서 끊긴 문구가 있습니다.",
      "counterevidence": "한국어 그림은 다른 스레드에서 해당 InvokeMessage의 semaphore를 기다리는 분기와 마지막 사용 확인이 검증 계획이라는 한계를 명시합니다. src/libcamera/base/bound_method.cpp:68은 Blocking 분기의 semaphore 대기를 보여 줍니다.",
      "fix": "잘린 영문 라벨을 한국어 원문과 일치하도록 복원합니다."
    }
  ],
  "items": [
    {"anchor":"item-01","visual_status":"diagram","question":"제출과 완료는 어떻게 연결됩니까?","reason":"제출 단계와 완료 책임을 연결하는 그림이 있습니다."},
    {"anchor":"item-02","visual_status":"diagram","question":"준비부터 명시적 완료까지 어떻게 진행됩니까?","reason":"정상 경로의 단계와 완료 분기를 나타냅니다."},
    {"anchor":"item-03","visual_status":"diagram","question":"접수 반환과 완료 알림은 어떻게 다릅니까?","reason":"0 반환과 완료 통지 경로를 구분합니다."},
    {"anchor":"item-04","visual_status":"diagram","question":"선두 요청 전달은 언제 중단됩니까?","reason":"큐 한도와 prepared_ 분기를 나타냅니다."},
    {"anchor":"item-05","visual_status":"diagram","question":"이미 취소된 요청과 장치 제출 실패는 어떻게 처리됩니까?","reason":"두 취소 경로와 void 함수 경계를 구분합니다."},
    {"anchor":"item-06","visual_status":"diagram","question":"마지막 버퍼 완료와 요청 완료는 어떻게 다릅니까?","reason":"completeBuffer 반환과 명시적 completeRequest를 구분합니다."},
    {"anchor":"item-07","visual_status":"diagram","question":"완료된 요청은 어떤 순서로 반환됩니까?","reason":"선두의 Pending 검사와 pop 후 통지를 나타냅니다."},
    {"anchor":"item-08","visual_status":"diagram","question":"준비 대기와 재진입을 어디서 조사합니까?","reason":"fence, timeout, 준비 신호와 pop 순서를 다루는 그림이 있습니다."},
    {"anchor":"item-09","visual_status":"diagram","question":"fence와 timeout은 준비 완료 신호로 어떻게 이어집니까?","reason":"두 생산자와 재귀 전달 전 pop을 나타냅니다."},
    {"anchor":"item-10","visual_status":"diagram","question":"동시 호출의 게시와 등록 순서는 어디서 구분합니까?","reason":"게시, 대기 큐, sequence와 통지를 구분하지만 영문 라벨 하나가 잘렸습니다."},
    {"anchor":"item-11","visual_status":"diagram","question":"UVC 제출 실패와 장치 완료는 어디서 갈라집니까?","reason":"제어, QBUF, 취소와 별도 완료 경로 그림이 있습니다."},
    {"anchor":"item-12","visual_status":"diagram","question":"UVC 제출과 DQBUF 이후에는 어떤 분기가 있습니까?","reason":"제어 처리, 큐잉, 취소 및 완료를 연결합니다."},
    {"anchor":"item-13","visual_status":"diagram","question":"요청과 버퍼, fence는 누가 유지합니까?","reason":"소유권과 fence 회수 및 재사용 그림이 있습니다."},
    {"anchor":"item-14","visual_status":"diagram","question":"요청과 버퍼는 언제까지 유효해야 합니까?","reason":"호출자 책임과 완료 후 삭제·재사용 경계를 표시합니다."},
    {"anchor":"item-15","visual_status":"diagram","question":"timeout 뒤 fence를 어떻게 회수합니까?","reason":"남은 fence와 releaseFence 선행 조건을 나타냅니다."},
    {"anchor":"item-16","visual_status":"diagram","question":"ReuseBuffers와 fence 권고는 무엇입니까?","reason":"버퍼 재사용 범위와 should-not 권고를 구분합니다."},
    {"anchor":"item-17","visual_status":"diagram","question":"버퍼 알림과 내부 추적 갱신은 어떤 순서입니까?","reason":"emit, pending 제거와 요청 완료 순서를 나타내는 그림이 있습니다."},
    {"anchor":"item-18","visual_status":"diagram","question":"버퍼 신호부터 요청 반환까지 내부 순서는 무엇입니까?","reason":"신호 반환, pending 제거, 명시적 완료와 선두 검사를 표시합니다."},
    {"anchor":"item-19","visual_status":"diagram","question":"연결 종류별 스레드와 재진입은 어떻게 다릅니까?","reason":"연결 분기와 직접·큐 수신 경계 그림이 있으나 슬롯 실행 순서 문구를 수정해야 합니다."},
    {"anchor":"item-20","visual_status":"diagram","question":"Auto는 Direct와 Queued를 어떻게 선택합니까?","reason":"현재 스레드와 수신 스레드 비교를 나타냅니다."},
    {"anchor":"item-21","visual_status":"diagram","question":"Queued 수신의 포인터 수명은 어떻게 관리합니까?","reason":"발신자 책임과 지연 수신자의 마지막 사용 확인을 나타냅니다."},
    {"anchor":"item-22","visual_status":"diagram","question":"직접 중첩 호출과 Queued 메시지 처리는 어떻게 다릅니까?","reason":"직접 호출과 게시·dispatch 경로가 있으나 슬롯 실제 실행 순서 문구가 부정확합니다."},
    {"anchor":"item-23","visual_status":"diagram","question":"stop 반환 뒤 별도 수신자의 마지막 사용은 어떻게 확인합니까?","reason":"Blocking 호출과 별도 수신자의 수명 확인을 구분하며 영문 라벨 두 곳은 잘렸습니다."},
    {"anchor":"item-24","visual_status":"diagram","question":"정지와 연결 해제의 요청 처리 계약은 어떻게 다릅니까?","reason":"정지 순서와 연결 해제 TODO를 각각 나타내는 그림이 있습니다."},
    {"anchor":"item-25","visual_status":"diagram","question":"정지 시 대기 요청은 어떤 순서로 처리됩니까?","reason":"대기 큐 분리, 장치 정지, 취소와 ASSERT를 표시합니다."},
    {"anchor":"item-26","visual_status":"diagram","question":"정지 계약과 연결 해제 TODO는 무엇입니까?","reason":"두 원문의 범위를 나란히 구분합니다."},
    {"anchor":"item-27","visual_status":"diagram","question":"Camera::stop은 어떤 조건에서 반환합니까?","reason":"미실행, 접근 오류와 정상 경로를 분기합니다."},
    {"anchor":"item-28","visual_status":"diagram","question":"stopDevice 진입과 복귀는 어떻게 관찰합니까?","reason":"호출 전, 구현 진입과 복귀 관찰을 구분합니다."},
    {"anchor":"item-29","visual_status":"diagram","question":"완료 호출자의 의무와 반환 뒤 경계는 무엇입니까?","reason":"호출 스레드, 제출 순서와 접근 금지를 연결합니다."},
    {"anchor":"item-30","visual_status":"diagram","question":"UVC 정지의 정상 경로와 실패 경계는 무엇입니까?","reason":"STREAMOFF 분기와 releaseBuffers 경로를 나타내는 그림이 있습니다."},
    {"anchor":"item-31","visual_status":"diagram","question":"streamOff의 세 반환 경로는 언제 합류합니까?","reason":"즉시 반환, ioctl 실패와 정상 정리 후 실제 반환을 구분합니다."},
    {"anchor":"item-32","visual_status":"diagram","question":"변경 전에 어떤 불변조건과 실패 분기를 확인합니까?","reason":"완료·bulk 취소와 실패 주입 분기 그림이 있습니다."},
    {"anchor":"item-33","visual_status":"diagram","question":"정상 완료와 bulk 취소의 검증 위치는 어디입니까?","reason":"각 pending 처리와 요청 완료 검사를 구분합니다."},
    {"anchor":"item-34","visual_status":"diagram","question":"실패 주입별 다음 분기는 무엇입니까?","reason":"timeout, 제출 실패, DQBUF와 STREAMOFF 실패를 표시합니다."},
    {"anchor":"item-35","visual_status":"diagram","question":"가상 프로브의 관찰 범위와 한계는 무엇입니까?","reason":"연결별 표식과 반환 근처 표식의 한계를 나타내는 그림이 있습니다."},
    {"anchor":"item-36","visual_status":"diagram","question":"가상 프로브에서 취소 콜백 표식은 어디에 있었습니까?","reason":"세 실행의 연결별 스레드와 애플리케이션 표식 관계를 표시합니다."},
    {"anchor":"item-37","visual_status":"diagram","question":"반환 근처 표식으로 무엇을 알 수 있습니까?","reason":"후속 카운터·객체 소멸과 실제 반환 미추적을 구분합니다."},
    {"anchor":"item-38","visual_status":"omitted-with-reason","question":"근거 원문은 어디서 확인합니까?","reason":"항목은 출처별 원문과 메타데이터를 제공하는 참조 목록이므로 별도 처리 그림이 필요하지 않습니다."}
  ],
  "unreviewed_scope": [
    "다른 파이프라인 구현, IPA 처리와 커널 UVC 드라이버 구현은 범위 밖입니다.",
    "물리 UVC 캡처, DMA 정확성, 성능과 내부 Camera HAL은 검증하지 않았습니다.",
    "실제 비작성자 독자 평가와 사람 검토는 수행되지 않았습니다."
  ]
}
