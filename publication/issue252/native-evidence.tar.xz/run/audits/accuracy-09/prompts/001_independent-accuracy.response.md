{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "제출에서 완료까지; 준비 대기와 재진입을 좁히기; UVC의 장치 제출과 완료를 추적하기",
      "diagnosis_values": "Queued 메시지 실행 여부, waitingRequests_ 선두, prepared_, notifiers_, 300ms 타이머, queuedRequests_ 크기와 선두 상태를 확인합니다.",
      "next_branch": "메시지가 실행됐다면 fence 또는 timeout과 큐 한도를 확인하고, 장치에 전달됐다면 UVC 제출 및 DQBUF 분기를 확인합니다.",
      "change_validation": "재진입 전에 선두를 pop하는 순서와 요청별 중복 처리, 취소 및 제출 순서를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1308-1383",
        "src/libcamera/pipeline_handler.cpp:428-620",
        "src/libcamera/request.cpp:192-312",
        "src/libcamera/v4l2_videodevice.cpp:1648-1987",
        "src/libcamera/base/object.cpp:258-284"
      ],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "UVC의 장치 제출과 완료를 추적하기; 변경 검토와 실행 확인",
      "diagnosis_values": "findBuffer 결과, 개별 processControl 결과, setControls의 ret과 error_idx, QBUF ret과 index, sequence_ 및 queuedBuffers_를 확인합니다.",
      "next_branch": "버퍼가 없거나 processControls 또는 queueBuffer가 음수를 반환하면 공통 호출자가 cancelRequest를 호출합니다. 개별 processControl의 반환값은 무시됩니다.",
      "change_validation": "제어 처리 후 QBUF 실패와 부분 제어 쓰기 실패를 따로 주입하고, 제어 상태를 관찰하며 롤백을 가정하지 않습니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:327-470",
        "src/libcamera/v4l2_device.cpp:309-430",
        "src/libcamera/v4l2_videodevice.cpp:1648-1814",
        "src/libcamera/pipeline_handler.cpp:483-501"
      ],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "UVC의 장치 제출과 완료를 추적하기; 버퍼 알림과 요청 반환의 내부 경계",
      "diagnosis_values": "DQBUF ret과 index, 프레임 metadata.status, pending_, 요청 status 및 queuedRequests_ 선두를 확인합니다.",
      "next_branch": "DQBUF가 실패하거나 예상 밖 인덱스를 반환하면 bufferReady가 발생하지 않습니다. 버퍼가 반환되면 UVC가 completeBuffer와 completeRequest를 차례로 호출합니다.",
      "change_validation": "FrameError와 RequestComplete를 별도로 기록하고, bufferCompleted 발생과 pending 제거, 명시적 요청 완료 및 선두 순서를 검증합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/v4l2_videodevice.cpp:1814-1987",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:893-905",
        "src/libcamera/pipeline_handler.cpp:547-620",
        "src/libcamera/request.cpp:91-139"
      ],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "요청·버퍼·fence의 수명; 버퍼 알림과 요청 반환의 내부 경계; 콜백의 스레드와 재진입을 구분하기",
      "diagnosis_values": "요청 소유자, 버퍼 유효 기간, fence 보유 여부, pending_, FrameBuffer::request() 연결 및 지연 수신자의 마지막 사용을 확인합니다.",
      "next_branch": "미신호 fence가 남았다면 다른 요청에 버퍼를 추가하기 전에 releaseFence로 회수합니다. 직접 버퍼 콜백에서는 이전 요청의 내부 정리가 끝나지 않았습니다.",
      "change_validation": "정상 완료와 일괄 취소를 구분하고, 별도 Queued 수신자의 마지막 사용을 동기화한 뒤 삭제 또는 재사용을 검증합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1243-1263",
        "src/libcamera/request.cpp:91-173",
        "src/libcamera/request.cpp:326-505",
        "src/libcamera/framebuffer.cpp:368-451",
        "src/libcamera/base/object.cpp:258-284",
        "src/libcamera/base/signal.cpp:73-113"
      ],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "정지와 연결 해제를 구분하기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "waitingRequests_ 분리, STREAMOFF ret, state_, queuedBuffers_, cache_, notifier, 두 요청 큐와 ASSERT 도달 여부를 확인합니다.",
      "next_branch": "STREAMOFF 성공이면 장치 버퍼를 취소해 반환합니다. 실패하면 해당 루프를 건너뛰며 UVC는 반환값을 무시하고 releaseBuffers를 호출합니다.",
      "change_validation": "STREAMOFF와 releaseBuffers 실패를 따로 주입하고 잔존 큐·notifier, 후속 DQBUF의 cache_ 접근, 완료 횟수와 재투입 여부를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1431-1491",
        "src/libcamera/pipeline_handler.cpp:359-414",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320-327",
        "src/libcamera/v4l2_videodevice.cpp:1616-1629",
        "src/libcamera/v4l2_videodevice.cpp:1814-1987",
        "src/libcamera/v4l2_videodevice.cpp:2023-2059"
      ],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "콜백의 스레드와 재진입을 구분하기; 정지와 연결 해제를 구분하기",
      "diagnosis_values": "수신자의 Object 여부, 연결 종류, 발신 및 수신 스레드, 이벤트 루프, 콜백 진입·복귀와 포인터 수명을 확인합니다.",
      "next_branch": "Auto는 같은 스레드면 Direct, 다르면 Queued입니다. 명시적 Direct는 발신 스레드에서 실행하며, Queued는 처리 완료를 기다리지 않습니다.",
      "change_validation": "상태 변경을 호출자가 동기화하고, Blocking stop의 반환과 별도 Queued 수신자의 마지막 사용을 구분합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/base/bound_method.cpp:22-108",
        "src/libcamera/base/object.cpp:97-125",
        "src/libcamera/base/object.cpp:184-284",
        "src/libcamera/base/thread.cpp:558-683",
        "include/libcamera/base/signal.h:38-153",
        "include/libcamera/base/bound_method.h:59-209",
        "Documentation/thread-safety.dox:1-46"
      ],
      "missing": []
    },
    {
      "id": "Q7",
      "answer_location": "변경 검토와 실행 확인",
      "diagnosis_values": "pop 순서, 요청·버퍼별 완료 횟수, pending_, sequence, 상태, 큐 잔존, 정지 중 재투입 및 지연 수신자의 마지막 사용을 확인합니다.",
      "next_branch": "준비 timeout, 제어 또는 QBUF 실패, DQBUF 오류·예상 밖 인덱스, FrameError, STREAMOFF 및 releaseBuffers 실패를 각각 조사합니다.",
      "change_validation": "정상 완료의 단일 pending 제거, 완료 시 pending 부재, completeRequest 반환 후 접근 금지, 정지 중 재투입 방지와 제출 순서를 검증합니다. Blocking 호출에 관한 문서의 모순을 수정해야 합니다.",
      "answerable": false,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp:359-620",
        "src/libcamera/request.cpp:91-312",
        "src/libcamera/camera.cpp:1431-1475",
        "src/libcamera/v4l2_videodevice.cpp:1648-2059",
        "src/libcamera/base/bound_method.cpp:68-108",
        "Documentation/thread-safety.dox:1-46"
      ],
      "missing": [
        "Camera::stop의 명시적인 ConnectionTypeBlocking 호출과 실제 호출 관찰 여부를 구분하는 일관된 검증 조건"
      ]
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q7",
      "claim": "변경 검토 절은 “stop의 Blocking 호출 여부는 확인되지 않았으므로 해당 호출이 확인되는 경우”라고 조건을 둡니다.",
      "counterevidence": "제공된 src/libcamera/camera.cpp:1431-1475에서 실행 중이고 접근 검사를 통과한 Camera::stop은 PipelineHandler::stop을 ConnectionTypeBlocking으로 명시적으로 호출합니다. 같은 문서의 정지 설명도 이 사실을 명시합니다. 실행 중이 아닌 경로와 접근 검사 실패 경로는 그 호출에 도달하지 않습니다.",
      "fix": "선택된 실행 중 정상 경로의 Blocking 호출은 정적 소스 사실로 기술하고, 특정 실행에서 그 경로에 도달했는지와 별도 Queued 콜백이 끝났는지는 관찰 대상으로 분리합니다."
    },
    {
      "blocking": false,
      "question": "Q3",
      "claim": "“분할에 부족한 bytesused도 FrameError로 처리합니다”라는 설명은 부족한 모든 크기가 오류가 되는 것처럼 읽힐 수 있습니다.",
      "counterevidence": "src/libcamera/v4l2_videodevice.cpp:1814-1987은 단일 V4L2 플레인을 여러 프레임 버퍼 플레인으로 나눌 때 각 플레인을 처리하기 전에 remaining이 0이면 FrameError를 설정합니다. 마지막 플레인은 길이보다 적은 bytesused를 가질 수 있습니다.",
      "fix": "플레인 처리를 시작할 때 남은 바이트가 없는 구체 조건과 마지막 플레인의 부분 사용 허용을 명시합니다."
    }
  ],
  "items": [
    {
      "anchor": "제출에서 완료까지",
      "question": "제출과 완료의 관계",
      "visual_status": "적절한 그림 있음",
      "reason": "하위 그림이 제출, 준비, 완료 및 순서를 각각 설명합니다."
    },
    {
      "anchor": "제출·준비·장치 처리·완료의 연결",
      "question": "정상 요청 경로",
      "visual_status": "적절한 그림 있음",
      "reason": "정상 경로와 명시적 요청 완료를 구분합니다."
    },
    {
      "anchor": "접수 반환과 완료 알림",
      "question": "0 반환과 완료 신호",
      "visual_status": "적절한 그림 있음",
      "reason": "호출 반환과 완료 통지 경로를 구분합니다."
    },
    {
      "anchor": "선두 요청을 전달하거나 반복을 멈추는 조건",
      "question": "대기 큐 전달 조건",
      "visual_status": "적절한 그림 있음",
      "reason": "큐 한도, 준비 상태와 pop 순서를 표시합니다."
    },
    {
      "anchor": "void 전달 함수의 두 취소 경로",
      "question": "준비 취소와 장치 제출 실패",
      "visual_status": "적절한 그림 있음",
      "reason": "기존 취소와 장치 함수 오류를 분기합니다."
    },
    {
      "anchor": "버퍼 완료와 명시적 요청 완료의 경계",
      "question": "버퍼 완료와 요청 완료",
      "visual_status": "적절한 그림 있음",
      "reason": "completeBuffer 반환과 별도 completeRequest 의무를 표시합니다."
    },
    {
      "anchor": "제출 큐의 선두 상태와 반환 순서",
      "question": "완료 요청의 반환 순서",
      "visual_status": "적절한 그림 있음",
      "reason": "선두 상태, ASSERT 및 pop 후 통지를 표시합니다."
    },
    {
      "anchor": "준비 대기와 재진입을 좁히기",
      "question": "준비 대기와 재진입",
      "visual_status": "적절한 그림 있음",
      "reason": "바로 아래 그림이 fence, timeout 및 재진입 전 pop을 연결합니다."
    },
    {
      "anchor": "준비 대기와 재진입을 좁히기 그림",
      "question": "준비 완료의 생산자와 소비자",
      "visual_status": "적절한 그림 있음",
      "reason": "fence와 timeout에서 prepared 신호 및 전달 분기로 이어집니다."
    },
    {
      "anchor": "UVC의 장치 제출과 완료를 추적하기",
      "question": "UVC 제출 실패와 완료",
      "visual_status": "적절한 그림 있음",
      "reason": "하위 그림과 본문이 제출 실패와 버퍼 완료 경로를 구분합니다."
    },
    {
      "anchor": "UVC의 장치 제출과 완료를 추적하기 그림",
      "question": "UVC 취소와 버퍼 알림",
      "visual_status": "적절한 그림 있음",
      "reason": "제출 실패의 취소와 bufferReady 이후 완료 호출을 구분합니다."
    },
    {
      "anchor": "요청·버퍼·fence의 수명",
      "question": "자원 소유와 재사용",
      "visual_status": "적절한 그림 있음",
      "reason": "소유권, fence 회수 및 재사용 범위를 별도 그림으로 설명합니다."
    },
    {
      "anchor": "요청과 버퍼를 유지할 기간",
      "question": "요청과 버퍼의 소유 및 수명",
      "visual_status": "적절한 그림 있음",
      "reason": "호출자의 버퍼 유지 의무와 핸들러의 반환 후 접근 경계를 표시합니다."
    },
    {
      "anchor": "타임아웃 뒤 펜스 회수",
      "question": "미신호 fence의 회수",
      "visual_status": "적절한 그림 있음",
      "reason": "타임아웃 후 유지와 재사용 전 회수를 연결합니다."
    },
    {
      "anchor": "버퍼 재사용과 펜스 권고",
      "question": "ReuseBuffers의 범위",
      "visual_status": "적절한 그림 있음",
      "reason": "버퍼 재사용과 fence에 관한 should-not 권고를 구분합니다."
    },
    {
      "anchor": "버퍼 알림과 요청 반환의 내부 경계",
      "question": "신호와 내부 상태 갱신의 순서",
      "visual_status": "적절한 그림 있음",
      "reason": "하위 그림이 신호 발생부터 pending 제거와 요청 통지까지 설명합니다."
    },
    {
      "anchor": "버퍼 알림과 요청 반환의 내부 경계 그림",
      "question": "버퍼 신호 후 내부 처리",
      "visual_status": "적절한 그림 있음",
      "reason": "신호 발생을 pending 제거보다 앞에 두고 선두 검사와 상태 검사도 표시합니다."
    },
    {
      "anchor": "콜백의 스레드와 재진입을 구분하기",
      "question": "연결 종류와 수신자 수명",
      "visual_status": "적절한 그림 있음",
      "reason": "Auto 분기와 Queued 수명 책임을 각각 그림으로 설명합니다."
    },
    {
      "anchor": "콜백의 스레드와 재진입을 구분하기 그림",
      "question": "Auto의 Direct·Queued 선택",
      "visual_status": "적절한 그림 있음",
      "reason": "현재 스레드와 수신 스레드의 비교를 표시합니다."
    },
    {
      "anchor": "Queued 수신과 해제 시점의 책임",
      "question": "지연 수신자의 포인터 수명",
      "visual_status": "적절한 그림 있음",
      "reason": "발신자 의무와 마지막 사용을 별도로 확인할 필요를 표시합니다."
    },
    {
      "anchor": "정지와 연결 해제를 구분하기",
      "question": "정지와 연결 해제의 차이",
      "visual_status": "적절한 그림 있음",
      "reason": "정지 순서, API 분기와 연결 해제 TODO를 개별 그림으로 설명합니다."
    },
    {
      "anchor": "정지할 때 대기 요청을 처리하는 순서",
      "question": "정상 정지 순서",
      "visual_status": "적절한 그림 있음",
      "reason": "대기 큐 분리, 장치 정지, 취소 및 ASSERT 위치를 표시합니다."
    },
    {
      "anchor": "정지 API 계약과 연결 해제 TODO",
      "question": "정지 계약과 연결 해제",
      "visual_status": "적절한 그림 있음",
      "reason": "계약과 미완료 TODO를 구분합니다."
    },
    {
      "anchor": "Camera::stop의 미실행·오류·정상 경로",
      "question": "Camera::stop 반환 분기",
      "visual_status": "적절한 그림 있음",
      "reason": "미실행, 접근 오류 및 Blocking 호출 경로를 분기합니다."
    },
    {
      "anchor": "stopDevice 호출 구간의 관찰 계획",
      "question": "stopDevice 진입과 복귀 관찰",
      "visual_status": "적절한 그림 있음",
      "reason": "호출 직전 표시와 실제 구현 진입·복귀를 구분합니다."
    },
    {
      "anchor": "완료 통지의 호출자 의무와 반환 뒤 경계",
      "question": "완료 호출의 스레드와 수명",
      "visual_status": "적절한 그림 있음",
      "reason": "호출 스레드, 제출 순서 및 반환 후 접근 금지를 표시합니다."
    },
    {
      "anchor": "UVC 정지의 정상 경로와 실패 경계",
      "question": "UVC STREAMOFF 실패",
      "visual_status": "적절한 그림 있음",
      "reason": "하위 그림이 ioctl 성공과 조기 반환을 구분하며 본문이 잔존 notifier 위험을 설명합니다."
    },
    {
      "anchor": "UVC 정지의 정상 경로와 실패 경계 그림",
      "question": "STREAMOFF와 releaseBuffers",
      "visual_status": "적절한 그림 있음",
      "reason": "오류 시 버퍼 반환 루프를 건너뛰는 분기와 별도 해제 호출을 표시합니다."
    },
    {
      "anchor": "변경 검토와 실행 확인",
      "question": "변경 전후 불변조건",
      "visual_status": "적절한 그림 있음",
      "reason": "하위 그림이 정상 완료와 일괄 취소의 pending 정리를 구분합니다."
    },
    {
      "anchor": "정상 완료와 bulk 취소의 검증 위치",
      "question": "정상 완료와 일괄 취소의 검증",
      "visual_status": "적절한 그림 있음",
      "reason": "서로 다른 pending 정리와 완료 시 ASSERT를 표시합니다."
    },
    {
      "anchor": "공개 가상 카메라의 콜백 관찰",
      "question": "가상 프로브 관찰 범위",
      "visual_status": "적절한 그림 있음",
      "reason": "연결별 표식과 반환 근처 표식의 한계를 각각 표시합니다."
    },
    {
      "anchor": "가상 CPU 프로브의 연결별 취소 콜백 표시",
      "question": "가상 프로브의 연결별 관찰",
      "visual_status": "적절한 그림 있음",
      "reason": "세 실행의 표식 위치와 스레드를 관찰 범위로 제한합니다."
    },
    {
      "anchor": "반환 근처 표시로 알 수 있는 범위",
      "question": "반환 근처 표식의 한계",
      "visual_status": "적절한 그림 있음",
      "reason": "표식 이후 작업과 실제 C++ 반환 미추적을 구분합니다."
    },
    {
      "anchor": "소스 근거",
      "question": "근거 원문 찾기",
      "visual_status": "생략 가능",
      "reason": "이 항목은 출처별 원문 목록이므로 별도의 처리 그림이 필요하지 않습니다."
    }
  ],
  "unreviewed_scope": [
    "제공된 전체 소스 창과 문서에 한정한 정적 감사입니다. 다른 파이프라인, IPA 및 커널 UVC 구현은 범위 밖입니다.",
    "물리 UVC 촬영, DMA 정확성, 성능 및 내부 Camera HAL은 검증하지 않았습니다.",
    "비작성자 독자 평가는 실행되지 않았으며 사람 검토는 대기 중입니다. 전체 문서 집합의 시각 검토는 범위 밖입니다."
  ]
}
