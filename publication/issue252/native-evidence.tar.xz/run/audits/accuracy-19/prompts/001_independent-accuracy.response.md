{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "「준비 대기와 재진입을 좁히기」와 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "camera.cpp:1308의 게시 여부, pipeline_handler.cpp:435의 waitingRequests_ 선두·prepared_·queuedRequests_ 크기와 한도, request.cpp:192의 notifiers_·300ms timeout을 확인합니다.",
      "next_branch": "게시 메시지가 소비되지 않았다면 수신 스레드의 진행을 조사합니다. 준비 취소이면 공통 완료 경로를, 장치에 제출되었다면 QBUF·DQBUF와 완료 큐 선두를 조사합니다.",
      "change_validation": "timeout과 미준비 선두 및 큐 한도를 각각 조사하고, 재진입 전에 pop하는 순서와 요청별 단일 전달을 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/base/object.cpp",
        "src/libcamera/base/thread.cpp",
        "src/libcamera/v4l2_videodevice.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "「UVC의 장치 제출과 완료를 추적하기」와 「실패 주입별 다음 관찰 분기」",
      "diagnosis_values": "uvcvideo.cpp:427,448의 findBuffer·processControl·setControls·queueBuffer 반환값, v4l2_device.cpp:309의 error_idx, v4l2_videodevice.cpp:1648의 QBUF 인덱스와 queuedBuffers_, pipeline_handler.cpp:483의 sequence_를 확인합니다.",
      "next_branch": "findBuffer 실패나 음수 제어 처리 결과는 QBUF 전에 반환됩니다. queueBuffer 실패는 제어 처리 뒤 반환되며 공통 호출자는 0이 아닌 결과에서 cancelRequest를 호출합니다. cache_ 부재의 Fatal은 별도로 취급합니다.",
      "change_validation": "개별 변환 실패와 빈 제어 목록, 부분 제어 쓰기, 제어 처리 후 QBUF 실패를 구분하고 취소·등록 여부와 통지 순서를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_device.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/pipeline_handler.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "「버퍼 알림과 요청 반환의 내부 경계」와 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "pipeline_handler.cpp:547의 bufferCompleted와 pending 제거 순서, request.cpp:103의 cancelled_와 status, v4l2_videodevice.cpp:1814의 DQBUF 결과·인덱스·FrameMetadata status, queuedRequests_ 선두를 확인합니다.",
      "next_branch": "DQBUF 오류나 미등록 인덱스이면 해당 bufferReady 없이 반환합니다. 버퍼가 반환되면 UVC의 completeBuffer와 명시적 completeRequest를 추적하고 프레임 상태를 요청 상태와 따로 판정합니다.",
      "change_validation": "FrameError와 RequestComplete가 함께 가능한 사례, 선두 Pending에 따른 지연, 버퍼별 단일 완료와 제출 순서 통지를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/framebuffer.cpp",
        "src/libcamera/camera.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "「요청·버퍼·fence의 수명」과 「버퍼 알림과 요청 반환의 내부 경계」",
      "diagnosis_values": "camera.cpp:1243의 요청 소유권, request.cpp:442의 버퍼와 fence 계약, request.cpp:103,139의 pending_ 및 연결 처리, object.cpp:258의 포인터 인자 수명을 확인합니다.",
      "next_branch": "미신호 fence가 남으면 releaseFence를 확인합니다. 직접 버퍼 콜백에서는 이전 pending 정리가 끝나지 않았고, 지연 수신자는 요청 완료 신호와 별도로 마지막 사용을 확인해야 합니다.",
      "change_validation": "정상 완료와 일괄 취소에서 연결 값과 단일 완료를 비교하고, 모든 지연 수신자의 마지막 사용 전에 포인터 대상이 삭제되거나 재사용되지 않도록 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/framebuffer.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/base/object.cpp",
        "src/libcamera/base/signal.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "「정지와 연결 해제를 구분하기」와 「UVC 정지의 정상 경로와 실패 경계」",
      "diagnosis_values": "camera.cpp:1431의 CameraStopping과 ASSERT, pipeline_handler.cpp:359의 waitingRequests_ swap 및 두 큐, uvcvideo.cpp:320의 반환값 무시, v4l2_videodevice.cpp:1616,2023의 ret·state_·cache_·notifier·queuedBuffers_를 확인합니다.",
      "next_branch": "STREAMOFF가 실패하면 버퍼 반환 루프 전에 복귀하지만 UVC는 releaseBuffers를 호출합니다. 잔존 notifier와 큐에서 알려진 인덱스가 다시 DQBUF될 조건을 따로 조사합니다.",
      "change_validation": "정상 정지, STREAMOFF 실패, releaseBuffers 실패를 나누어 완료 횟수·순서·ASSERT 도달·재투입과 잔존 상태를 기록합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "「콜백의 스레드와 재진입을 구분하기」와 「stop 반환과 별도 수신의 마지막 사용 확인」",
      "diagnosis_values": "bound_method.cpp:68의 연결 종류와 현재·수신 스레드, thread.cpp:613의 dispatch 필터, camera.cpp:1431의 Blocking 호출과 호출자 동기화 조건을 확인합니다.",
      "next_branch": "Auto는 스레드 비교에 따라 Direct 또는 Queued를 선택합니다. Blocking은 같은 스레드에서 직접 호출하고 다른 스레드에서는 해당 호출을 기다립니다. 별도 Queued 수신자의 실행과 마지막 사용은 따로 확인합니다.",
      "change_validation": "Direct 중첩과 명시적 또는 재귀적 dispatch, 수신 스레드 진행, 콜백 진입·복귀 및 포인터 마지막 사용을 기록합니다. stop 반환을 전체 콜백 drain으로 취급하지 않습니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/base/bound_method.cpp",
        "src/libcamera/base/signal.cpp",
        "include/libcamera/base/signal.h",
        "include/libcamera/base/bound_method.h",
        "src/libcamera/base/thread.cpp",
        "src/libcamera/base/message.cpp",
        "src/libcamera/base/object.cpp",
        "src/libcamera/camera.cpp",
        "Documentation/thread-safety.dox"
      ],
      "missing": []
    },
    {
      "id": "Q7",
      "answer_location": "「변경 검토와 실행 확인」",
      "diagnosis_values": "pipeline_handler.cpp:435의 pop 순서, request.cpp:91,139의 erase 결과와 일괄 취소, pipeline_handler.cpp:547의 pending 검사와 요청 접근 경계, v4l2_videodevice.cpp:2023의 정지 분기를 확인합니다.",
      "next_branch": "준비 timeout, 제어 처리와 QBUF 실패, DQBUF 오류 및 예상 밖 인덱스, FrameError, STREAMOFF와 releaseBuffers 실패를 각각 추적합니다.",
      "change_validation": "각 버퍼의 단일 완료, 요청 완료 전 pending 부재, completeRequest 반환 후 접근 금지, 정지 중 재투입 방지와 제출 순서 반환을 검증합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_device.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/camera.cpp",
        "Documentation/thread-safety.dox"
      ],
      "missing": []
    }
  ],
  "findings": [
    {
      "blocking": false,
      "question": "Q2",
      "claim": "「실패 주입별 다음 관찰 분기」 그림의 영어 원문은 queueBuffer 오류를 “after controls have been applied”라고 표현합니다.",
      "counterevidence": "uvcvideo.cpp:427의 processControls는 개별 processControl 반환값을 무시하고, v4l2_device.cpp:309의 setControls는 빈 목록에도 0을 반환합니다. 따라서 queueBuffer에 도달했다는 사실만으로 요청한 제어가 실제 적용되었다고 확정할 수 없습니다.",
      "fix": "해당 그림의 문구를 “after control processing”으로 바꾸고, 제어가 일부 또는 전혀 적용되지 않았을 가능성과 롤백을 보장하지 않는다는 조건을 유지합니다."
    }
  ],
  "items": [
    {"anchor":"item-01","visual_status":"diagram","question":"제출에서 완료까지","reason":"제출, 준비, 장치 처리와 명시적 완료를 연결하는 그림이 있습니다."},
    {"anchor":"item-02","visual_status":"diagram","question":"제출·준비·장치 처리·완료의 연결","reason":"정상 경로와 선두 대기를 나타냅니다."},
    {"anchor":"item-03","visual_status":"diagram","question":"접수 반환과 완료 알림","reason":"0 반환과 별도 완료 알림을 구분합니다."},
    {"anchor":"item-04","visual_status":"diagram","question":"선두 요청을 전달하거나 반복을 멈추는 조건","reason":"큐 한도, 준비 여부와 pop 순서를 표시합니다."},
    {"anchor":"item-05","visual_status":"diagram","question":"void 전달 함수의 두 취소 경로","reason":"기존 취소와 장치 제출 실패를 구분합니다."},
    {"anchor":"item-06","visual_status":"diagram","question":"버퍼 완료와 명시적 요청 완료의 경계","reason":"마지막 버퍼와 명시적 요청 완료를 구분합니다."},
    {"anchor":"item-07","visual_status":"diagram","question":"제출 큐의 선두 상태와 반환 순서","reason":"선두 상태 검사와 pop 뒤 통지를 표시합니다."},
    {"anchor":"item-08","visual_status":"diagram","question":"준비 대기와 재진입을 좁히기","reason":"fence, timeout, 준비 신호와 재진입 전 pop을 다룹니다."},
    {"anchor":"item-09","visual_status":"diagram","question":"준비 대기와 재진입을 좁히기 그림","reason":"준비 완료 생산자와 대기 큐 소비자를 연결합니다."},
    {"anchor":"item-10","visual_status":"diagram","question":"동시 제출의 순서를 관찰할 경계","reason":"호출 시작, 메시지 게시, 등록과 통지의 관찰 지점을 구분합니다."},
    {"anchor":"item-11","visual_status":"diagram","question":"UVC의 장치 제출과 완료를 추적하기","reason":"제어 처리, QBUF, 취소와 별도 완료 경로를 표시합니다."},
    {"anchor":"item-12","visual_status":"diagram","question":"UVC의 장치 제출과 완료를 추적하기 그림","reason":"제출 실패와 DQBUF 후 완료의 분기를 표시합니다."},
    {"anchor":"item-13","visual_status":"diagram","question":"요청·버퍼·fence의 수명","reason":"요청 소유권, 버퍼 유효 기간과 fence 회수 그림이 있습니다."},
    {"anchor":"item-14","visual_status":"diagram","question":"요청과 버퍼를 유지할 기간","reason":"호출자 책임, 완료 콜백과 핸들러 접근 경계를 표시합니다."},
    {"anchor":"item-15","visual_status":"diagram","question":"타임아웃 뒤 펜스 회수","reason":"남은 fence와 재사용 전 회수 의무를 표시합니다."},
    {"anchor":"item-16","visual_status":"diagram","question":"버퍼 재사용과 펜스 권고","reason":"ReuseBuffers의 대상과 fence 관련 권고를 구분합니다."},
    {"anchor":"item-17","visual_status":"diagram","question":"버퍼 알림과 요청 반환의 내부 경계","reason":"신호, pending 제거, 명시적 완료와 통지 순서를 표시합니다."},
    {"anchor":"item-18","visual_status":"diagram","question":"버퍼 알림과 요청 반환의 내부 경계 그림","reason":"emit 반환과 내부 갱신 및 선두 검사를 연결합니다."},
    {"anchor":"item-19","visual_status":"diagram","question":"콜백의 스레드와 재진입을 구분하기","reason":"연결 방식, dispatch와 수명 경계를 질문별 그림으로 설명합니다."},
    {"anchor":"item-20","visual_status":"diagram","question":"콜백의 스레드와 재진입을 구분하기 그림","reason":"Auto의 Direct와 Queued 선택을 표시합니다."},
    {"anchor":"item-21","visual_status":"diagram","question":"Queued 수신과 해제 시점의 책임","reason":"지연 수신자의 마지막 사용과 포인터 유효성을 다룹니다."},
    {"anchor":"item-22","visual_status":"diagram","question":"직접 중첩 호출과 별도 Queued 수신의 경계","reason":"동기 호출, 게시, dispatch와 내부 갱신을 구분합니다."},
    {"anchor":"item-23","visual_status":"diagram","question":"stop 반환과 별도 수신의 마지막 사용 확인","reason":"Blocking stop과 별도 Queued 수신자의 수명을 구분합니다."},
    {"anchor":"item-24","visual_status":"diagram","question":"정지와 연결 해제를 구분하기","reason":"정지 순서와 연결 해제 TODO를 각각 표시합니다."},
    {"anchor":"item-25","visual_status":"diagram","question":"정지할 때 대기 요청을 처리하는 순서","reason":"대기열 분리, 장치 정지, 취소와 ASSERT 순서를 표시합니다."},
    {"anchor":"item-26","visual_status":"diagram","question":"정지 API 계약과 연결 해제 TODO","reason":"정지 계약과 연결 해제 TODO를 대비합니다."},
    {"anchor":"item-27","visual_status":"diagram","question":"Camera::stop의 미실행·오류·정상 경로","reason":"실행 상태와 접근 검사에 따른 반환 분기를 표시합니다."},
    {"anchor":"item-28","visual_status":"diagram","question":"stopDevice 호출 구간의 관찰 계획","reason":"호출 전, 구현 진입과 복귀 관찰을 구분합니다."},
    {"anchor":"item-29","visual_status":"diagram","question":"완료 통지의 호출자 의무와 반환 뒤 경계","reason":"호출 스레드, 반환 순서와 접근 금지 의무를 연결합니다."},
    {"anchor":"item-30","visual_status":"diagram","question":"UVC 정지의 정상 경로와 실패 경계","reason":"STREAMOFF 분기와 releaseBuffers 경계를 표시합니다."},
    {"anchor":"item-31","visual_status":"diagram","question":"UVC 정지의 정상 경로와 실패 경계 그림","reason":"조기 반환, ioctl 실패와 성공 정리의 조건을 구분합니다."},
    {"anchor":"item-32","visual_status":"diagram","question":"변경 검토와 실행 확인","reason":"완료·일괄 취소와 실패 주입별 조사 그림이 있습니다."},
    {"anchor":"item-33","visual_status":"diagram","question":"정상 완료와 bulk 취소의 검증 위치","reason":"서로 다른 pending 정리와 완료 검사를 표시합니다."},
    {"anchor":"item-34","visual_status":"diagram","question":"실패 주입별 다음 관찰 분기","reason":"timeout, 제출, DQBUF와 STREAMOFF 실패를 나눕니다. 제어 적용을 확정하는 영어 문구는 수정이 필요합니다."},
    {"anchor":"item-35","visual_status":"diagram","question":"공개 가상 카메라의 콜백 관찰","reason":"프로브의 연결별 관찰과 표식의 한계를 별도 그림으로 표시합니다."},
    {"anchor":"item-36","visual_status":"diagram","question":"가상 CPU 프로브의 연결별 취소 콜백 표시","reason":"세 실행에서 관찰한 스레드와 애플리케이션 표식의 관계를 표시합니다."},
    {"anchor":"item-37","visual_status":"diagram","question":"반환 근처 표시로 알 수 있는 범위","reason":"표식 이후 작업과 실제 C++ 반환 미추적을 표시합니다."},
    {"anchor":"item-38","visual_status":"omitted-with-reason","question":"소스 근거","reason":"근거 원문과 출처 메타데이터를 나열하는 참조 항목이므로 별도 그림이 필요하지 않습니다."}
  ],
  "unreviewed_scope": [
    "다른 파이프라인, IPA와 커널 UVC 드라이버 구현은 지정 범위 밖입니다.",
    "물리 UVC 캡처, DMA 정확성, 성능 및 내부 Camera HAL은 검증하지 않았습니다.",
    "실제 비작성자 독자 평가와 사람 검토는 수행하지 않았습니다."
  ]
}
