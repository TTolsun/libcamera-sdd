{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "「제출에서 완료까지」, 「준비 대기와 재진입을 좁히기」, 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "camera.cpp:1308의 Queued 게시와 진입 여부, pipeline_handler.cpp:435의 waitingRequests_ 선두·prepared_·queuedRequests_ 크기·한도, request.cpp:192의 notifiers_와 300ms 타이머를 확인합니다.",
      "next_branch": "준비 취소면 sequence 등록 후 공통 완료로, 준비된 요청이면 UVC 제출 및 DQBUF로 진행합니다. 완료된 요청도 queuedRequests_ 선두가 Pending이면 반환을 기다립니다.",
      "change_validation": "fence 미신호, 미준비 선두, 큐 한도와 재귀 호출에서 pop이 전달보다 앞서는지, 중복 처리와 제출 순서가 유지되는지 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/base/object.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "「UVC의 장치 제출과 완료를 추적하기」, 「변경 검토와 실행 확인」",
      "diagnosis_values": "uvcvideo.cpp:427, 448의 findBuffer와 processControls 반환, v4l2_device.cpp:309의 error_idx, v4l2_videodevice.cpp:1648의 QBUF ret·인덱스, pipeline_handler.cpp:483의 sequence와 cancelled_를 확인합니다.",
      "next_branch": "findBuffer 실패나 음수 제어·큐 반환은 공통 cancelRequest로 이어집니다. 개별 processControl 반환은 무시되며, cache_ 부재의 Fatal은 일반 반환과 구분합니다.",
      "change_validation": "제어 쓰기 실패와 제어 처리 후 QBUF 실패를 각각 주입하고 부분 적용 가능성, 큐 등록, 취소 횟수와 제출 순서 통지를 기록합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_device.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/pipeline_handler.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "「버퍼 알림과 요청 반환의 내부 경계」, 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "pipeline_handler.cpp:547에서 bufferCompleted emit과 pending 제거 순서, request.cpp:103의 cancelled_와 status, v4l2_videodevice.cpp:1814의 DQBUF 결과·인덱스·FrameError를 확인합니다.",
      "next_branch": "DQBUF 오류 또는 미등록 인덱스는 bufferReady 없이 반환합니다. 유효 버퍼는 UVC의 completeBuffer와 명시적 completeRequest를 거치며 Pending 선두가 있으면 뒤 요청의 통지는 지연됩니다.",
      "change_validation": "FrameError와 RequestComplete를 별도로 기록하고 버퍼별 완료 횟수, pending 부재, 선두 순서와 requestCompleted를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/framebuffer.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "「요청·버퍼·fence의 수명」, 「버퍼 알림과 요청 반환의 내부 경계」, 「Queued 수신과 해제 시점의 책임」",
      "diagnosis_values": "camera.cpp:1243의 요청 소유권, request.cpp:442의 버퍼·fence 계약, request.cpp:103, 139의 pending과 연결 처리, object.cpp:258의 포인터 인자 계약을 확인합니다.",
      "next_branch": "미신호 fence가 남으면 releaseFence 후 다른 요청에 재사용합니다. 직접 버퍼 콜백에서는 이전 pending 정리가 아직 남고, 지연 수신자는 별도 마지막 사용 확인이 필요합니다.",
      "change_validation": "정상 완료와 bulk 취소에서 연결 값과 콜백 순서, fence 회수 및 각 Queued 수신자의 마지막 사용을 확인한 뒤 삭제·재사용합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/framebuffer.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/base/object.cpp",
        "src/libcamera/base/signal.cpp",
        "src/libcamera/base/bound_method.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "「정지와 연결 해제를 구분하기」, 「UVC 정지의 정상 경로와 실패 경계」",
      "diagnosis_values": "pipeline_handler.cpp:359의 큐 swap과 ASSERT, uvcvideo.cpp:320의 반환값 무시, v4l2_videodevice.cpp:1616, 2023의 ret·state_·cache_·queuedBuffers_·notifier, camera.cpp:1431의 CameraStopping을 확인합니다.",
      "next_branch": "정상 STREAMOFF는 장치 버퍼를 취소해 반환한 뒤 분리된 대기 요청을 처리합니다. 오류면 버퍼 반환 루프를 건너뛰고 UVC는 releaseBuffers를 호출합니다.",
      "change_validation": "STREAMOFF와 REQBUFS 실패를 각각 주입해 잔존 큐·notifier·cache_, ASSERT 도달, 후속 DQBUF 및 재투입 여부를 기록합니다. 정상 반환이나 모든 버퍼 반환을 가정하지 않습니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "「콜백의 스레드와 재진입을 구분하기」, 「직접 중첩 호출과 별도 Queued 수신의 경계」",
      "diagnosis_values": "bound_method.cpp:68의 Auto·Direct·Queued·Blocking 분기, thread.cpp:558, 613의 게시와 재귀 dispatch, camera.cpp:1431의 Blocking 정지와 반환 경로를 확인합니다.",
      "next_branch": "Direct는 발신 스레드에서 즉시 실행됩니다. Queued는 메시지 소비에 의존하며 명시적 재귀 dispatch로 외부 핸들러 복귀 전에 실행될 수 있습니다. stop 반환은 별도 수신자의 drain을 뜻하지 않습니다.",
      "change_validation": "연결 종류, 양쪽 TID, dispatch 필터·재귀 깊이, 콜백 진입·복귀와 마지막 포인터 사용을 기록하고 카메라 상태 변경을 호출자가 동기화합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/base/bound_method.cpp",
        "src/libcamera/base/signal.cpp",
        "include/libcamera/base/signal.h",
        "include/libcamera/base/bound_method.h",
        "src/libcamera/base/object.cpp",
        "src/libcamera/base/thread.cpp",
        "src/libcamera/base/message.cpp",
        "src/libcamera/camera.cpp",
        "Documentation/thread-safety.dox"
      ],
      "missing": [
        "두 본문의 무조건적인 이벤트 루프 전달 표현을 명시적·재귀적 dispatch 및 메시지 미소비 가능성과 일치시켜야 합니다."
      ]
    },
    {
      "id": "Q7",
      "answer_location": "「변경 검토와 실행 확인」, 「준비 대기와 재진입을 좁히기」",
      "diagnosis_values": "pipeline_handler.cpp:435, 547의 pop 순서와 완료 경계, request.cpp:91, 139의 erase 결과와 bulk 취소, v4l2_videodevice.cpp:1648, 1814, 2023의 실패 분기를 확인합니다.",
      "next_branch": "준비 timeout, 제어·QBUF 실패, DQBUF 오류·미등록 인덱스, FrameError, STREAMOFF·releaseBuffers 실패를 별도 사례로 추적합니다.",
      "change_validation": "버퍼별 중복 완료 부재, 요청 완료 전 pending 부재, completeRequest 반환 후 접근 금지, 정지 중 재투입 금지와 제출 순서를 각 사례에서 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_device.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/camera.cpp",
        "src/libcamera/base/bound_method.cpp",
        "Documentation/thread-safety.dox"
      ],
      "missing": []
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q6",
      "claim": "「버퍼 알림과 요청 반환의 내부 경계」는 별도 Queued 수신자가 이벤트 루프로 제어가 돌아왔을 때 호출된다고 서술하며, 「콜백의 스레드와 재진입을 구분하기」에도 같은 무조건적 표현이 있습니다.",
      "counterevidence": "src/libcamera/base/thread.cpp:613의 dispatchMessages는 이벤트 루프 밖에서도 호출할 수 있고 같은 스레드의 메시지 핸들러에서 재귀 호출할 수 있습니다. src/libcamera/base/thread.cpp:630과 src/libcamera/base/object.cpp:184에서는 필터가 맞는 메시지가 소비되면 Object::message가 InvokeMessage를 실행합니다. 반대로 스레드 정지 전 메시지 소비는 보장되지 않습니다.",
      "fix": "두 문장을 일반적인 이벤트 루프 경로의 설명으로 한정하고, 명시적 또는 재귀적 dispatch가 더 일찍 전달할 수 있으며 실제 소비가 보장되지 않는다는 조건을 바로 연결합니다."
    }
  ],
  "items": [
    {
      "anchor": "item-01",
      "visual_status": "diagram",
      "question": "제출에서 완료까지",
      "reason": "제출·준비·완료와 순서 반환을 연결하는 그림이 있습니다."
    },
    {
      "anchor": "item-02",
      "visual_status": "diagram",
      "question": "제출·준비·장치 처리·완료의 연결",
      "reason": "정상 경로의 단계와 명시적 완료를 나타냅니다."
    },
    {
      "anchor": "item-03",
      "visual_status": "diagram",
      "question": "접수 반환과 완료 알림",
      "reason": "Queued 호출의 반환과 완료 알림을 구분합니다."
    },
    {
      "anchor": "item-04",
      "visual_status": "diagram",
      "question": "선두 요청을 전달하거나 반복을 멈추는 조건",
      "reason": "큐 한도, 선두 준비 상태와 pop 분기를 나타냅니다."
    },
    {
      "anchor": "item-05",
      "visual_status": "diagram",
      "question": "void 전달 함수의 두 취소 경로",
      "reason": "사전 취소와 장치 제출 실패의 처리 분기를 구분합니다."
    },
    {
      "anchor": "item-06",
      "visual_status": "diagram",
      "question": "버퍼 완료와 명시적 요청 완료의 경계",
      "reason": "마지막 버퍼의 반환값과 별도 완료 호출을 연결합니다."
    },
    {
      "anchor": "item-07",
      "visual_status": "diagram",
      "question": "제출 큐의 선두 상태와 반환 순서",
      "reason": "선두 Pending 검사와 pop 후 통지 순서를 나타냅니다."
    },
    {
      "anchor": "item-08",
      "visual_status": "diagram",
      "question": "준비 대기와 재진입을 좁히기",
      "reason": "fence·timeout에서 준비 신호와 재진입 전 pop까지 연결합니다."
    },
    {
      "anchor": "item-09",
      "visual_status": "diagram",
      "question": "준비 대기와 재진입을 좁히기 그림",
      "reason": "준비 생산자와 대기 큐 소비 조건을 나타냅니다."
    },
    {
      "anchor": "item-10",
      "visual_status": "diagram",
      "question": "UVC의 장치 제출과 완료를 추적하기",
      "reason": "제어, QBUF, 취소 및 별도 완료 사건을 연결합니다."
    },
    {
      "anchor": "item-11",
      "visual_status": "diagram",
      "question": "UVC의 장치 제출과 완료를 추적하기 그림",
      "reason": "제출 실패와 DQBUF 후 완료 분기를 구분합니다."
    },
    {
      "anchor": "item-12",
      "visual_status": "diagram",
      "question": "요청·버퍼·fence의 수명",
      "reason": "소유권과 버퍼 유지, timeout fence 회수 및 재사용을 각각 나타냅니다."
    },
    {
      "anchor": "item-13",
      "visual_status": "diagram",
      "question": "요청과 버퍼를 유지할 기간",
      "reason": "호출자의 소유·유효성 책임과 완료 핸들러 경계를 구분합니다."
    },
    {
      "anchor": "item-14",
      "visual_status": "diagram",
      "question": "타임아웃 뒤 펜스 회수",
      "reason": "남은 fence의 회수와 다른 요청에서의 재사용 조건을 나타냅니다."
    },
    {
      "anchor": "item-15",
      "visual_status": "diagram",
      "question": "버퍼 재사용과 펜스 권고",
      "reason": "ReuseBuffers의 대상과 fence 사용 권고를 구분합니다."
    },
    {
      "anchor": "item-16",
      "visual_status": "diagram",
      "question": "버퍼 알림과 요청 반환의 내부 경계",
      "reason": "신호 발생, pending 제거, 명시적 완료와 순서 반환을 나타냅니다."
    },
    {
      "anchor": "item-17",
      "visual_status": "diagram",
      "question": "버퍼 알림과 요청 반환의 내부 경계 그림",
      "reason": "emit 반환 뒤 내부 갱신과 요청 통지를 순서대로 표시합니다."
    },
    {
      "anchor": "item-18",
      "visual_status": "diagram",
      "question": "콜백의 스레드와 재진입을 구분하기",
      "reason": "연결 방식, 수신 경계와 포인터 수명을 다루는 질문별 그림이 있습니다."
    },
    {
      "anchor": "item-19",
      "visual_status": "diagram",
      "question": "콜백의 스레드와 재진입을 구분하기 그림",
      "reason": "Auto의 Direct·Queued 선택을 나타냅니다."
    },
    {
      "anchor": "item-20",
      "visual_status": "diagram",
      "question": "Queued 수신과 해제 시점의 책임",
      "reason": "신호 발신자의 포인터 유효성 책임과 지연 수신자의 마지막 사용을 구분합니다."
    },
    {
      "anchor": "item-21",
      "visual_status": "diagram",
      "question": "직접 중첩 호출과 별도 Queued 수신의 경계",
      "reason": "Direct와 Queued 실행 및 emit 뒤 내부 갱신을 나타냅니다."
    },
    {
      "anchor": "item-22",
      "visual_status": "diagram",
      "question": "정지와 연결 해제를 구분하기",
      "reason": "정지 순서와 연결 해제 TODO를 각각 설명하는 그림이 있습니다."
    },
    {
      "anchor": "item-23",
      "visual_status": "diagram",
      "question": "정지할 때 대기 요청을 처리하는 순서",
      "reason": "대기 큐 분리, 장치 정지, 취소 및 정상 반환 경계를 표시합니다."
    },
    {
      "anchor": "item-24",
      "visual_status": "diagram",
      "question": "정지 API 계약과 연결 해제 TODO",
      "reason": "정지 계약과 연결 해제 시 미완료 TODO를 구분합니다."
    },
    {
      "anchor": "item-25",
      "visual_status": "diagram",
      "question": "Camera::stop의 미실행·오류·정상 경로",
      "reason": "실행 상태, 접근 오류와 정상 정지 분기를 표시합니다."
    },
    {
      "anchor": "item-26",
      "visual_status": "diagram",
      "question": "stopDevice 호출 구간의 관찰 계획",
      "reason": "호출 전, 구현 진입과 복귀 관찰을 구분합니다."
    },
    {
      "anchor": "item-27",
      "visual_status": "diagram",
      "question": "완료 통지의 호출자 의무와 반환 뒤 경계",
      "reason": "호출 스레드, 제출 순서와 반환 후 접근 금지를 표시합니다."
    },
    {
      "anchor": "item-28",
      "visual_status": "diagram",
      "question": "UVC 정지의 정상 경로와 실패 경계",
      "reason": "STREAMOFF 실패와 정상 버퍼 반환 분기를 나타냅니다."
    },
    {
      "anchor": "item-29",
      "visual_status": "diagram",
      "question": "UVC 정지의 정상 경로와 실패 경계 그림",
      "reason": "STREAMOFF 오류의 조기 반환과 releaseBuffers 호출을 표시합니다."
    },
    {
      "anchor": "item-30",
      "visual_status": "diagram",
      "question": "변경 검토와 실행 확인",
      "reason": "완료·bulk 취소 검증 위치와 실패별 조사 분기를 각각 나타냅니다."
    },
    {
      "anchor": "item-31",
      "visual_status": "diagram",
      "question": "정상 완료와 bulk 취소의 검증 위치",
      "reason": "두 경로의 pending 정리와 완료 ASSERT를 구분합니다."
    },
    {
      "anchor": "item-32",
      "visual_status": "diagram",
      "question": "실패 주입별 다음 관찰 분기",
      "reason": "timeout, 제출, DQBUF 및 STREAMOFF 실패의 다음 분기를 표시합니다."
    },
    {
      "anchor": "item-33",
      "visual_status": "diagram",
      "question": "공개 가상 카메라의 콜백 관찰",
      "reason": "연결별 관찰 표식과 반환 근처 표식의 한계를 별도로 나타냅니다."
    },
    {
      "anchor": "item-34",
      "visual_status": "diagram",
      "question": "가상 CPU 프로브의 연결별 취소 콜백 표시",
      "reason": "세 실행에서 관찰된 연결별 스레드와 애플리케이션 표식 관계를 표시합니다."
    },
    {
      "anchor": "item-35",
      "visual_status": "diagram",
      "question": "반환 근처 표시로 알 수 있는 범위",
      "reason": "표식 뒤 작업과 실제 C++ 반환 미추적을 구분합니다."
    },
    {
      "anchor": "item-36",
      "visual_status": "omitted-with-reason",
      "question": "소스 근거",
      "reason": "이 항목은 펼쳐 볼 수 있는 원문과 출처의 목록이므로 별도의 처리 흐름 그림이 필요하지 않습니다."
    }
  ],
  "unreviewed_scope": [
    "물리 UVC 촬영, DMA 정확성, 성능 및 사내 Camera HAL 검증은 범위에서 제외됩니다.",
    "다른 파이프라인, 커널 UVC 드라이버, 사용자 정의 이벤트 디스패처 및 동시 연결 소멸은 검토 범위 밖입니다.",
    "비저자 독자의 실제 평가와 사람의 의미 검토는 수행된 것으로 주장하지 않습니다."
  ]
}
