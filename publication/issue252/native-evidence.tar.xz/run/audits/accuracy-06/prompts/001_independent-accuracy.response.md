{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "준비 대기와 재진입을 좁히기; UVC의 장치 제출과 완료를 추적하기",
      "diagnosis_values": "queued 호출의 실행 여부, waitingRequests_ 선두, prepared_, notifiers_, 300ms timeout, queuedRequests_ 크기와 한도, 선두 status",
      "next_branch": "준비 취소와 장치 제출을 구분한 뒤 UVC의 QBUF와 DQBUF 분기로 이동합니다.",
      "change_validation": "재귀 전달 전 pop, 중복 투입 부재와 제출 순서를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1-1491",
        "src/libcamera/request.cpp:1-616",
        "src/libcamera/pipeline_handler.cpp:1-1011",
        "src/libcamera/base/object.cpp:1-361"
      ],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "UVC의 장치 제출과 완료를 추적하기; 변경 검토와 실행 확인",
      "diagnosis_values": "findBuffer 결과, 개별 processControl 및 setControls 반환값, error_idx, queueBuffer와 VIDIOC_QBUF 반환값, sequence",
      "next_branch": "장치 제출의 음수 반환은 cancelRequest로 이어집니다. QBUF 실패 전 제어 적용 여부도 조사합니다.",
      "change_validation": "제어 실패와 QBUF 실패를 구분하고 큐 등록, 취소 완료 및 제어 부작용을 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:1-907",
        "src/libcamera/v4l2_device.cpp:1-1107",
        "src/libcamera/v4l2_videodevice.cpp:1-2257",
        "src/libcamera/pipeline_handler.cpp:1-1011"
      ],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "버퍼 알림과 요청 반환의 내부 경계; UVC의 장치 제출과 완료를 추적하기",
      "diagnosis_values": "bufferCompleted와 pending_ 제거 순서, 버퍼 metadata.status, 요청 status, queuedRequests_ 선두",
      "next_branch": "DQBUF 오류나 예상 밖 인덱스는 알림 없이 반환합니다. 반환된 FrameError 버퍼는 별도로 요청 완료 경로를 따를 수 있습니다.",
      "change_validation": "버퍼별 단일 완료, 명시적 completeRequest와 제출 순서 통지를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/v4l2_videodevice.cpp:1-2257",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:1-907",
        "src/libcamera/request.cpp:1-616",
        "src/libcamera/pipeline_handler.cpp:1-1011"
      ],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "요청·버퍼·fence의 수명; 버퍼 알림과 요청 반환의 내부 경계",
      "diagnosis_values": "요청 소유자, 버퍼 완료 콜백, pending_, FrameBuffer::request(), fence와 지연된 포인터 인자",
      "next_branch": "직접 버퍼 콜백과 요청 완료 콜백을 구분하고, 미신호 fence는 재사용 전에 releaseFence로 회수합니다.",
      "change_validation": "정상 완료와 일괄 취소에서 연결 값, 포인터 유효 기간과 지연 수신자 수명을 각각 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1-1491",
        "src/libcamera/request.cpp:1-616",
        "src/libcamera/framebuffer.cpp:1-451",
        "src/libcamera/base/object.cpp:1-361",
        "src/libcamera/base/signal.cpp:1-205"
      ],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "정지와 연결 해제를 구분하기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "CameraStopping, 분리된 waitingRequests_, STREAMOFF ret, state_, cache_, notifier, queuedBuffers_와 queuedRequests_, ASSERT",
      "next_branch": "STREAMOFF 실패는 버퍼 반환 루프를 건너뛰지만 UVC는 releaseBuffers를 호출합니다. 잔존 notifier와 reset된 cache의 후속 DQBUF 경계를 조사합니다.",
      "change_validation": "정상 정지, STREAMOFF 실패와 releaseBuffers 실패를 각각 주입하여 완료 횟수와 큐 잔존을 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1-1491",
        "src/libcamera/pipeline_handler.cpp:1-1011",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:1-907",
        "src/libcamera/v4l2_videodevice.cpp:1-2257"
      ],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "콜백의 스레드와 재진입을 구분하기; 정지와 연결 해제를 구분하기",
      "diagnosis_values": "연결 종류, 현재·수신 스레드, 이벤트 루프 진행, Blocking 반환과 별도 Queued 수신 완료 표식",
      "next_branch": "Auto는 스레드를 비교하고 Direct는 동기 호출하며 Queued는 메시지를 게시합니다. 정지 반환과 별도 수신자의 처리 완료를 구분합니다.",
      "change_validation": "직접 재진입과 지연 수신을 각각 확인하고 포인터 수명 및 호출자 동기화를 검증합니다.",
      "answerable": false,
      "source_windows": [
        "src/libcamera/base/bound_method.cpp:1-110",
        "src/libcamera/base/object.cpp:1-361",
        "src/libcamera/base/signal.cpp:1-205",
        "include/libcamera/base/bound_method.h:1-209",
        "include/libcamera/base/signal.h:1-153",
        "Documentation/thread-safety.dox:1-46"
      ],
      "missing": [
        "Queued 수신이 이벤트 루프 복귀만으로 반드시 실행된다는 표현을 조건부 전달로 수정해야 합니다."
      ]
    },
    {
      "id": "Q7",
      "answer_location": "변경 검토와 실행 확인",
      "diagnosis_values": "cookie, sequence, pending_, 버퍼와 요청 status, 완료 횟수, 큐 상태, 오류 반환값과 ASSERT",
      "next_branch": "준비 취소, 제어 및 QBUF 실패, DQBUF 오류, FrameError, 정지 실패와 지연 콜백을 각각 구분합니다.",
      "change_validation": "재귀 전 pop, 버퍼 단일 완료, 요청 완료 전 pending 부재, 완료 반환 후 접근 금지와 정지 중 재투입 부재를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/request.cpp:1-616",
        "src/libcamera/pipeline_handler.cpp:1-1011",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:1-907",
        "src/libcamera/v4l2_device.cpp:1-1107",
        "src/libcamera/v4l2_videodevice.cpp:1-2257",
        "Documentation/thread-safety.dox:1-46"
      ],
      "missing": []
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q6",
      "claim": "콜백 그림과 본문은 Queued 수신자가 수신 스레드의 이벤트 루프로 제어가 돌아오면 호출된다고 단정합니다.",
      "counterevidence": "src/libcamera/base/object.cpp:258의 invokeMethod 계약은 Queued 호출이 스레드가 멈추기 전에 실행된다는 보장이 없다고 명시합니다. 같은 파일의 Object 소멸자는 대기 메시지를 제거합니다. src/libcamera/base/bound_method.cpp:68의 구현은 메시지를 게시할 뿐 수신 실행을 기다리지 않습니다.",
      "fix": "이벤트 루프가 메시지를 처리하고 수신 객체가 유효한 경우 비동기로 실행된다고 조건을 명시하고, 이벤트 루프 복귀 또는 stop 반환만으로 콜백 처리 완료를 추론하지 않도록 그림과 본문을 수정합니다."
    }
  ],
  "items": [
    {
      "anchor": "제출에서 완료까지",
      "question": "제출부터 완료까지 어떤 단계가 있습니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "제출, 준비, 장치 전달 및 명시적 완료를 연결합니다."
    },
    {
      "anchor": "제출·준비·장치 처리·완료의 연결",
      "question": "정상 경로의 단계는 어떻게 연결됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "정상 경로임을 한정한 흐름도입니다."
    },
    {
      "anchor": "접수 반환과 완료 알림",
      "question": "0 반환과 완료 알림은 어떻게 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "호출 반환과 완료 알림을 별도로 표시합니다."
    },
    {
      "anchor": "선두 요청을 전달하거나 반복을 멈추는 조건",
      "question": "대기 큐의 전달 조건은 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "큐 한도와 선두 준비 상태를 분기합니다."
    },
    {
      "anchor": "void 전달 함수의 두 취소 경로",
      "question": "준비 취소와 장치 제출 실패는 어떻게 처리됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "두 취소 경로를 구분합니다."
    },
    {
      "anchor": "버퍼 완료와 명시적 요청 완료의 경계",
      "question": "버퍼 완료와 요청 완료는 어떻게 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "completeBuffer의 반환과 명시적 completeRequest를 구분합니다."
    },
    {
      "anchor": "제출 큐의 선두 상태와 반환 순서",
      "question": "완료 요청은 어떤 순서로 반환됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "선두 Pending 검사와 제거 후 통지를 표시합니다."
    },
    {
      "anchor": "준비 대기와 재진입을 좁히기",
      "question": "준비 완료와 재귀 전달은 어떻게 연결됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "fence, timeout, prepared 신호와 pop 순서를 표시합니다."
    },
    {
      "anchor": "준비 대기와 재진입을 좁히기 그림",
      "question": "준비 대기 흐름의 분기는 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "준비 완료 생산자와 전달 조건을 연결합니다."
    },
    {
      "anchor": "UVC의 장치 제출과 완료를 추적하기",
      "question": "UVC 제출 실패와 완료는 어떻게 연결됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "제출 실패의 취소와 버퍼 알림의 완료를 구분합니다."
    },
    {
      "anchor": "UVC의 장치 제출과 완료를 추적하기 그림",
      "question": "장치 제출 실패와 버퍼 알림은 어느 함수로 이어집니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "각 경로의 다음 함수를 표시합니다."
    },
    {
      "anchor": "요청·버퍼·fence의 수명",
      "question": "자원별 소유와 재사용 경계는 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "요청 소유와 버퍼 유효 기간 및 fence 회수 그림이 있습니다."
    },
    {
      "anchor": "요청과 버퍼를 유지할 기간",
      "question": "요청과 버퍼는 언제까지 유지합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "호출자의 책임과 완료 콜백 경계를 표시합니다."
    },
    {
      "anchor": "타임아웃 뒤 펜스 회수",
      "question": "미신호 fence가 남으면 무엇을 해야 합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "다른 요청에서 재사용하기 전 회수 조건을 표시합니다."
    },
    {
      "anchor": "버퍼 재사용과 펜스 권고",
      "question": "ReuseBuffers와 fence의 관계는 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "재사용 대상과 API의 should-not 권고를 구분합니다."
    },
    {
      "anchor": "버퍼 알림과 요청 반환의 내부 경계",
      "question": "버퍼 신호와 내부 추적 갱신은 어떤 순서입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "신호, pending 제거, 명시적 완료와 선두 검사를 연결합니다."
    },
    {
      "anchor": "버퍼 알림과 요청 반환의 내부 경계 그림",
      "question": "정상 완료에서 내부 갱신과 통지는 어떤 순서입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "상태 검사를 통과하는 경로로 범위를 한정합니다."
    },
    {
      "anchor": "콜백의 스레드와 재진입을 구분하기",
      "question": "연결 종류에 따라 콜백은 어디서 실행됩니까?",
      "visual_status": "보완 필요",
      "reason": "Queued 수신 실행을 보장하는 듯한 표현을 조건부로 수정해야 합니다."
    },
    {
      "anchor": "콜백의 스레드와 재진입을 구분하기 그림",
      "question": "Auto는 Direct와 Queued를 어떻게 선택합니까?",
      "visual_status": "보완 필요",
      "reason": "분기는 표시하지만 Queued 메시지가 반드시 처리되는 것처럼 서술합니다."
    },
    {
      "anchor": "정지와 연결 해제를 구분하기",
      "question": "정지 계약과 연결 해제 TODO는 어떻게 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "정상 정지 순서와 연결 해제 TODO를 별도로 표시합니다."
    },
    {
      "anchor": "정지할 때 대기 요청을 처리하는 순서",
      "question": "정상 정지에서 대기 요청은 어떤 순서로 처리됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "큐 분리, 장치 정지, 취소 및 ASSERT 위치를 표시합니다."
    },
    {
      "anchor": "정지 API 계약과 연결 해제 TODO",
      "question": "두 경로의 계약과 TODO는 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "계약과 미완료 TODO를 분리합니다."
    },
    {
      "anchor": "Camera::stop의 미실행·오류·정상 경로",
      "question": "Camera::stop은 어떤 조건에서 반환합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "실행 여부와 접근 검사 분기를 표시합니다."
    },
    {
      "anchor": "stopDevice 호출 구간의 관찰 계획",
      "question": "호출과 구현 진입·복귀를 어떻게 조사합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "관찰 계획과 미확정 원인을 구분합니다."
    },
    {
      "anchor": "완료 통지의 호출자 의무와 반환 뒤 경계",
      "question": "완료 호출의 스레드와 접근 의무는 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "호출 스레드와 반환 후 접근 금지를 표시합니다."
    },
    {
      "anchor": "UVC 정지의 정상 경로와 실패 경계",
      "question": "STREAMOFF 실패는 정상 정지와 어떻게 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "실패 시 조기 반환과 반환값을 무시한 해제 호출을 표시합니다."
    },
    {
      "anchor": "UVC 정지의 정상 경로와 실패 경계 그림",
      "question": "STREAMOFF 실패는 어느 루프를 건너뜁니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "ioctl 결과와 버퍼 반환 루프를 분기합니다."
    },
    {
      "anchor": "변경 검토와 실행 확인",
      "question": "변경 후 어떤 불변조건을 확인합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "정상 완료와 일괄 취소의 pending 처리 차이를 표시합니다."
    },
    {
      "anchor": "정상 완료와 bulk 취소의 검증 위치",
      "question": "두 경로의 pending 정리는 어떻게 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "개별 erase와 일괄 clear를 구분합니다."
    },
    {
      "anchor": "공개 가상 카메라의 콜백 관찰",
      "question": "가상 프로브에서 무엇을 관찰했습니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "연결별 표식과 반환 근처 표식의 한계를 별도로 표시합니다."
    },
    {
      "anchor": "가상 CPU 프로브의 연결별 취소 콜백 표시",
      "question": "이 프로브에서 콜백과 정지 표식은 어떻게 배치됐습니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "세 실행의 제한된 관찰로 범위를 한정합니다."
    },
    {
      "anchor": "반환 근처 표시로 알 수 있는 범위",
      "question": "반환 근처 표식은 실제 함수 반환을 증명합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "표식 뒤 작업과 추적하지 않은 실제 반환을 구분합니다."
    },
    {
      "anchor": "소스 근거",
      "question": "설명에 연결된 원문은 어디에 있습니까?",
      "visual_status": "생략 가능",
      "reason": "소스 발췌와 근거 목록이 목적이므로 별도 흐름도가 필요하지 않습니다."
    }
  ],
  "unreviewed_scope": [
    "제공된 과거 프로브 기록은 역사적 자료로만 검토했으며 원시 이벤트와 별도 프로브 소스는 제공되지 않았습니다.",
    "물리 UVC 촬영, DMA 정확성, 성능, 내부 HAL 및 실제 비작성자 독자 평가는 범위 밖입니다.",
    "src/libcamera/base/thread.cpp는 문서에 발췌가 제공됐지만 전체 파일 창은 제공되지 않았습니다.",
    "request-diagnosis.md의 연결 대상과 전체 문서 집합은 제공되지 않았으므로 검토하지 않았습니다."
  ]
}
