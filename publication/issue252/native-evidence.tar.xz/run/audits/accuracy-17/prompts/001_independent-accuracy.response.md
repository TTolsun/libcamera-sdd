{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "「제출에서 완료까지」, 「준비 대기와 재진입을 좁히기」, 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "camera.cpp:1308의 Queued 호출과 pipeline_handler.cpp:435의 진입 여부, waitingRequests_ 선두의 prepared_, request.cpp:192의 notifiers_와 300ms 타이머, queuedRequests_ 크기와 한도, 선두 요청 상태를 확인합니다.",
      "next_branch": "호출이 실행되지 않았으면 수신 스레드와 메시지 처리를 확인합니다. 준비를 기다리면 fence 알림 또는 timeout을, 준비됐으면 큐 한도와 UVC 제출 및 DQBUF 분기를 확인합니다.",
      "change_validation": "fence 미신호와 한도 도달을 각각 시험하고, 재귀 전달 전에 선두를 pop하는 순서와 취소된 요청의 sequence 및 중복 완료 여부를 기록합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/camera.cpp", "src/libcamera/pipeline_handler.cpp", "src/libcamera/request.cpp", "src/libcamera/base/object.cpp", "src/libcamera/base/thread.cpp", "src/libcamera/base/event_dispatcher_poll.cpp", "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/v4l2_videodevice.cpp"],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "「UVC의 장치 제출과 완료를 추적하기」 및 「변경 검토와 실행 확인」",
      "diagnosis_values": "uvcvideo.cpp:327, 427, 448의 findBuffer, 개별 processControl 반환, setControls 결과와 error_idx를 확인합니다. v4l2_videodevice.cpp:1648의 cache_, QBUF ret 및 queuedBuffers_ 등록과 pipeline_handler.cpp:483의 sequence_를 확인합니다.",
      "next_branch": "버퍼가 없거나 제어 처리 또는 queueBuffer가 음수를 반환하면 공통 cancelRequest로 이어집니다. cache_ 부재의 Fatal은 일반 반환과 분리하고, 제어 적용 뒤 QBUF 실패에서는 제어 상태를 조사합니다.",
      "change_validation": "개별 변환 실패, setControls 실패 및 제어 적용 후 QBUF 실패를 구분해 주입하고, 취소와 통지 순서 및 제어의 부분 적용 여부를 기록합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/v4l2_device.cpp", "src/libcamera/v4l2_videodevice.cpp", "src/libcamera/pipeline_handler.cpp"],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "「버퍼 알림과 요청 반환의 내부 경계」 및 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "pipeline_handler.cpp:547의 bufferCompleted와 pending 제거 순서, request.cpp:103의 cancelled_와 status, pipeline_handler.cpp:571의 선두 상태, v4l2_videodevice.cpp:1814의 DQBUF 결과와 FrameMetadata 상태를 확인합니다.",
      "next_branch": "DQBUF 오류나 미등록 인덱스면 해당 bufferReady가 없습니다. 유효 버퍼면 UVC가 completeBuffer 뒤 completeRequest를 호출하며, 선두가 Pending이면 뒤 요청의 반환이 대기합니다.",
      "change_validation": "FrameError와 RequestComplete의 동시 발생, bufferCompleted 시점의 pending_, 명시적 요청 완료와 제출 순서별 requestCompleted를 각각 기록합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/pipeline_handler.cpp", "src/libcamera/request.cpp", "src/libcamera/camera.cpp", "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/v4l2_videodevice.cpp", "src/libcamera/framebuffer.cpp"],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "「요청·버퍼·fence의 수명」, 「버퍼 알림과 요청 반환의 내부 경계」, 「Queued 수신과 해제 시점의 책임」",
      "diagnosis_values": "camera.cpp:1243의 요청 소유권, request.cpp:442의 버퍼 유효 기간과 fence 이동, request.cpp:103 및 139의 정상·일괄 취소 처리, object.cpp:258의 포인터 인자 계약을 확인합니다.",
      "next_branch": "미신호 fence가 남으면 releaseFence로 회수합니다. 직접 버퍼 콜백에서는 이전 pending 정리가 끝나지 않았으며, 지연 수신자는 마지막 사용까지 별도 동기화가 필요합니다.",
      "change_validation": "정상 완료와 bulk 취소에서 연결 값과 pending_을 비교하고, 요청 완료 및 각 지연 수신자의 마지막 사용 이전에 버퍼와 요청을 해제하거나 재사용하지 않는지 확인합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/camera.cpp", "src/libcamera/request.cpp", "src/libcamera/framebuffer.cpp", "src/libcamera/pipeline_handler.cpp", "src/libcamera/base/object.cpp", "src/libcamera/base/signal.cpp", "src/libcamera/base/bound_method.cpp"],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "「정지와 연결 해제를 구분하기」 및 「UVC 정지의 정상 경로와 실패 경계」",
      "diagnosis_values": "pipeline_handler.cpp:359의 waitingRequests_ swap과 두 ASSERT, uvcvideo.cpp:320의 무시된 반환값, v4l2_videodevice.cpp:1616, 2023의 ret, cache_, queuedBuffers_, notifier 및 state_를 확인합니다.",
      "next_branch": "STREAMOFF 성공이면 장치 버퍼를 취소한 뒤 분리된 대기 요청을 처리합니다. 실패면 버퍼 반환 루프 전에 빠져나오지만 UVC는 releaseBuffers를 호출하므로 잔존 큐와 후속 DQBUF를 확인합니다.",
      "change_validation": "STREAMOFF와 releaseBuffers 실패를 별도로 주입해 ASSERT 도달, 큐 잔존, 알려진 인덱스의 후속 DQBUF와 cache_->put 경계를 기록합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/camera.cpp", "src/libcamera/pipeline_handler.cpp", "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/v4l2_videodevice.cpp"],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "「콜백의 스레드와 재진입을 구분하기」 및 「정지와 연결 해제를 구분하기」",
      "diagnosis_values": "bound_method.cpp:68의 연결 유형과 현재·수신 스레드, thread.cpp:558, 613의 게시와 필터, camera.cpp:1431의 Blocking 호출 및 별도 수신자의 마지막 사용을 확인합니다.",
      "next_branch": "Auto는 같은 스레드면 Direct, 다르면 Queued입니다. Blocking은 같은 스레드면 직접 호출하고 다르면 해당 호출을 기다리지만, 별도 Queued 수신자의 배출은 보장하지 않습니다.",
      "change_validation": "Direct 중첩과 필터가 맞는 재귀 dispatch를 구분하고, 각 콜백 진입·복귀 및 포인터 마지막 사용을 기록하며 호출자 상태 동기화를 확인합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/base/bound_method.cpp", "src/libcamera/base/signal.cpp", "src/libcamera/base/object.cpp", "src/libcamera/base/thread.cpp", "src/libcamera/base/message.cpp", "src/libcamera/base/event_dispatcher_poll.cpp", "include/libcamera/base/signal.h", "include/libcamera/base/bound_method.h", "Documentation/thread-safety.dox", "src/libcamera/camera.cpp", "src/libcamera/pipeline_handler.cpp"],
      "missing": []
    },
    {
      "id": "Q7",
      "answer_location": "「변경 검토와 실행 확인」",
      "diagnosis_values": "pipeline_handler.cpp:435의 pop 순서와 sequence_, request.cpp:91, 139의 pending_ 및 취소 경로, pipeline_handler.cpp:359, 547의 ASSERT와 반환 후 접근 금지를 확인합니다.",
      "next_branch": "준비 취소, 제어 또는 QBUF 실패, DQBUF 오류·미등록 인덱스, FrameError, 정상 정지와 STREAMOFF 실패를 각각 추적합니다.",
      "change_validation": "각 버퍼 완료 횟수와 요청 완료 전 pending 부재, 제출 순서, 정지 중 재투입 및 지연 수신자의 마지막 사용을 확인합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/pipeline_handler.cpp", "src/libcamera/request.cpp", "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/v4l2_videodevice.cpp", "src/libcamera/v4l2_device.cpp", "src/libcamera/camera.cpp", "src/libcamera/base/bound_method.cpp", "Documentation/thread-safety.dox"],
      "missing": []
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q2",
      "claim": "UVC 그림은 processControls가 요청의 제어를 장치에 설정하고 결과를 반환한다고 단정합니다.",
      "counterevidence": "uvcvideo.cpp:327의 processControl은 지원하지 않는 ID나 사용 가능한 노출 모드가 없는 경우 -EINVAL을 반환할 수 있지만, uvcvideo.cpp:427의 반복문은 각 반환값을 무시하고 구성된 목록만 setControls에 전달합니다. 빈 목록은 v4l2_device.cpp:309에서 0을 반환합니다.",
      "fix": "그림에서 개별 변환 실패가 무시될 수 있고 setControls가 구성된 목록에만 적용된다고 명시합니다. 0이 모든 요청 제어의 적용을 증명하지 않는다는 조건도 표시합니다."
    },
    {
      "blocking": true,
      "question": "item-10",
      "claim": "「동시 제출의 순서를 관찰할 경계」 그림은 API 호출, 게시, 등록 및 완료 통지의 순서를 구분한다고 설명합니다.",
      "counterevidence": "그림에는 API 호출, postMessage 및 requestCompleted 노드가 있지만 연결된 전이는 waitingRequests_에서 등록으로 가는 하나뿐입니다. thread.cpp:558은 mutex 안에서 메시지를 추가하고 pipeline_handler.cpp:435는 이후 대기·등록을 수행합니다.",
      "fix": "호출 시작과 실제 게시 순서를 구분하고, 게시·대기 등록·sequence 할당·신호 발생 및 수신 관찰을 조건부 관계로 연결한 질문별 그림으로 수정합니다."
    }
  ],
  "items": [
    {"anchor":"item-01","visual_status":"diagram","question":"제출에서 완료까지","reason":"제출, 준비, 장치 처리와 명시적 완료를 연결한 그림이 있습니다."},
    {"anchor":"item-02","visual_status":"diagram","question":"제출·준비·장치 처리·완료의 연결","reason":"정상 경로와 선두 대기를 표시합니다."},
    {"anchor":"item-03","visual_status":"diagram","question":"접수 반환과 완료 알림","reason":"Queued 호출의 반환과 별도 완료 알림을 구분합니다."},
    {"anchor":"item-04","visual_status":"diagram","question":"선두 요청을 전달하거나 반복을 멈추는 조건","reason":"대기 큐, 한도, 준비 상태와 pop 순서를 표시합니다."},
    {"anchor":"item-05","visual_status":"diagram","question":"void 전달 함수의 두 취소 경로","reason":"기존 취소와 장치 제출 실패를 분기합니다."},
    {"anchor":"item-06","visual_status":"diagram","question":"버퍼 완료와 명시적 요청 완료의 경계","reason":"버퍼 완료 반환값과 명시적 요청 완료를 구분합니다."},
    {"anchor":"item-07","visual_status":"diagram","question":"제출 큐의 선두 상태와 반환 순서","reason":"Pending 선두에서 중단하고 완료 선두를 반환하는 경로를 표시합니다."},
    {"anchor":"item-08","visual_status":"diagram","question":"준비 대기와 재진입을 좁히기","reason":"fence, timeout, 준비 신호와 재귀 전달을 다루는 그림이 있습니다."},
    {"anchor":"item-09","visual_status":"diagram","question":"준비 대기와 재진입을 좁히기 그림","reason":"준비 완료 생산자와 pop 후 전달 경계를 표시합니다."},
    {"anchor":"item-10","visual_status":"missing","question":"동시 제출의 순서를 관찰할 경계","reason":"그림의 게시와 통지 노드가 연결되지 않아 질문의 순서 관계를 설명하지 못합니다."},
    {"anchor":"item-11","visual_status":"diagram","question":"UVC의 장치 제출과 완료를 추적하기","reason":"제출 실패와 별도 완료 이벤트를 다루는 그림이 있으나 제어 적용 표현은 수정해야 합니다."},
    {"anchor":"item-12","visual_status":"diagram","question":"UVC의 장치 제출과 완료를 추적하기 그림","reason":"QBUF 실패와 완료 경로를 분기하지만 개별 제어 변환 실패의 표현이 부정확합니다."},
    {"anchor":"item-13","visual_status":"diagram","question":"요청·버퍼·fence의 수명","reason":"소유권, 완료 콜백 및 fence 회수 그림이 있습니다."},
    {"anchor":"item-14","visual_status":"diagram","question":"요청과 버퍼를 유지할 기간","reason":"요청 소유자와 버퍼 유효 기간 및 완료 후 경계를 표시합니다."},
    {"anchor":"item-15","visual_status":"diagram","question":"타임아웃 뒤 펜스 회수","reason":"잔존 fence의 회수와 재사용 선행 조건을 표시합니다."},
    {"anchor":"item-16","visual_status":"diagram","question":"버퍼 재사용과 펜스 권고","reason":"ReuseBuffers의 대상과 should-not 권고를 구분합니다."},
    {"anchor":"item-17","visual_status":"diagram","question":"버퍼 알림과 요청 반환의 내부 경계","reason":"신호 발생부터 pending 제거와 요청 반환까지의 순서를 표시합니다."},
    {"anchor":"item-18","visual_status":"diagram","question":"버퍼 알림과 요청 반환의 내부 경계 그림","reason":"emit 반환, 내부 갱신, 명시적 완료 및 선두 검사를 연결합니다."},
    {"anchor":"item-19","visual_status":"diagram","question":"콜백의 스레드와 재진입을 구분하기","reason":"연결 방식과 수신·내부 갱신 경계를 다루는 그림이 있습니다."},
    {"anchor":"item-20","visual_status":"diagram","question":"콜백의 스레드와 재진입을 구분하기 그림","reason":"Auto의 Direct와 Queued 선택을 표시합니다."},
    {"anchor":"item-21","visual_status":"diagram","question":"Queued 수신과 해제 시점의 책임","reason":"신호 포인터와 지연 수신자의 수명 책임을 표시합니다."},
    {"anchor":"item-22","visual_status":"diagram","question":"직접 중첩 호출과 별도 Queued 수신의 경계","reason":"Direct, Queued, dispatch와 emit 뒤 갱신을 구분하며 정지 반환의 한계를 명시합니다."},
    {"anchor":"item-23","visual_status":"diagram","question":"정지와 연결 해제를 구분하기","reason":"정지 순서와 연결 해제 TODO를 구분한 그림이 있습니다."},
    {"anchor":"item-24","visual_status":"diagram","question":"정지할 때 대기 요청을 처리하는 순서","reason":"대기 큐 분리, 장치 정지 및 대기 요청 취소 순서를 표시합니다."},
    {"anchor":"item-25","visual_status":"diagram","question":"정지 API 계약과 연결 해제 TODO","reason":"정지 계약과 연결 해제 TODO를 별도로 표시합니다."},
    {"anchor":"item-26","visual_status":"diagram","question":"Camera::stop의 미실행·오류·정상 경로","reason":"실행 상태, 접근 검사 및 Blocking 정지 분기를 표시합니다."},
    {"anchor":"item-27","visual_status":"diagram","question":"stopDevice 호출 구간의 관찰 계획","reason":"호출 직전과 구현 진입·복귀 관찰을 구분합니다."},
    {"anchor":"item-28","visual_status":"diagram","question":"완료 통지의 호출자 의무와 반환 뒤 경계","reason":"호출 스레드, 제출 순서 및 반환 후 접근 금지를 표시합니다."},
    {"anchor":"item-29","visual_status":"diagram","question":"UVC 정지의 정상 경로와 실패 경계","reason":"STREAMOFF의 조기 반환과 성공 경로 및 releaseBuffers를 표시합니다."},
    {"anchor":"item-30","visual_status":"diagram","question":"UVC 정지의 정상 경로와 실패 경계 그림","reason":"실제 반환 조건을 한정하여 실패와 성공 분기를 연결합니다."},
    {"anchor":"item-31","visual_status":"diagram","question":"변경 검토와 실행 확인","reason":"정상·취소 검증 위치와 실패별 조사 분기 그림이 있습니다."},
    {"anchor":"item-32","visual_status":"diagram","question":"정상 완료와 bulk 취소의 검증 위치","reason":"각 경로의 pending 처리와 요청 완료 검사를 구분합니다."},
    {"anchor":"item-33","visual_status":"diagram","question":"실패 주입별 다음 관찰 분기","reason":"timeout, 제출 실패, DQBUF 및 STREAMOFF의 조사 분기를 표시합니다."},
    {"anchor":"item-34","visual_status":"diagram","question":"공개 가상 카메라의 콜백 관찰","reason":"가상 프로브의 연결별 관측과 반환 표식 한계를 표시합니다."},
    {"anchor":"item-35","visual_status":"diagram","question":"가상 CPU 프로브의 연결별 취소 콜백 표시","reason":"세 실행에서 관측한 연결별 스레드와 표식 위치를 구분합니다."},
    {"anchor":"item-36","visual_status":"diagram","question":"반환 근처 표시로 알 수 있는 범위","reason":"후속 카운터 증가와 실제 C++ 반환 미추적을 표시합니다."},
    {"anchor":"item-37","visual_status":"omitted-with-reason","question":"소스 근거","reason":"이 항목은 출처별 원문과 기록을 제공하는 참조 목록이므로 별도 처리 그림이 필요하지 않습니다."}
  ],
  "unreviewed_scope": [
    "다른 파이프라인 구현, IPA 처리 및 커널 UVC 드라이버 구현은 제외되었습니다.",
    "물리 카메라 캡처, DMA 정확성, 성능 및 사내 Camera HAL은 검증하지 않았습니다.",
    "제공된 과거 가상 프로브 기록은 원문과 대조했으며 새 하드웨어 실행이나 비저자 독자 평가는 수행하지 않았습니다."
  ]
}
