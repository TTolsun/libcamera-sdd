{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "준비 대기와 재진입을 좁히기; UVC의 장치 제출과 완료를 추적하기",
      "diagnosis_values": "게시된 호출의 대상 스레드와 실행 여부, waitingRequests_ 선두, prepared_, notifiers_, 300ms 타이머, queuedRequests_ 크기와 선두 상태를 확인합니다.",
      "next_branch": "준비가 끝나지 않았다면 fence 알림 또는 timeout을 확인합니다. 준비되었다면 큐 한도, 취소 여부, UVC 제출과 DQBUF를 차례로 확인합니다.",
      "change_validation": "재귀 전달 전에 pop하는 순서, 요청별 전달 횟수, 준비 취소 및 선두 순서 지연을 검증합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/camera.cpp:1308-1383", "src/libcamera/pipeline_handler.cpp:428-607", "src/libcamera/request.cpp:192-312", "src/libcamera/v4l2_videodevice.cpp:1814-1987", "src/libcamera/base/object.cpp:258-284"],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "UVC의 장치 제출과 완료를 추적하기; 변경 검토와 실행 확인",
      "diagnosis_values": "findBuffer 결과, 각 processControl 결과, setControls의 ret과 error_idx, QBUF ret과 index, sequence_ 및 queuedBuffers_를 확인합니다.",
      "next_branch": "버퍼가 없거나 전파되는 제어 처리 또는 큐잉 오류가 있으면 공통 cancelRequest 경로를 확인합니다. 제어 적용 후 QBUF가 실패해도 롤백을 가정하지 않습니다.",
      "change_validation": "제어 오류와 QBUF 오류를 각각 주입하고 취소, 버퍼 등록 여부 및 제출 순서에 따른 통지를 확인합니다. queueBuffer의 출력 플레인 오류 조건은 수정해야 합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:327-470", "src/libcamera/v4l2_device.cpp:309-430", "src/libcamera/v4l2_videodevice.cpp:1648-1814", "src/libcamera/pipeline_handler.cpp:483-501"],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "버퍼 알림과 요청 반환의 내부 경계; UVC의 장치 제출과 완료를 추적하기",
      "diagnosis_values": "bufferCompleted 발생, pending_ 제거, FrameMetadata 상태, cancelled_, 요청 상태 및 queuedRequests_ 선두를 각각 확인합니다.",
      "next_branch": "DQBUF가 유효한 버퍼를 반환하면 UVC의 completeBuffer와 completeRequest를 추적합니다. 선두가 RequestPending이면 뒤 요청의 통지는 대기합니다.",
      "change_validation": "FrameError와 RequestComplete의 동시 가능성, 버퍼당 한 번의 완료 및 명시적 요청 완료를 검증합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/v4l2_videodevice.cpp:1814-1987", "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:893-905", "src/libcamera/request.cpp:91-139", "src/libcamera/pipeline_handler.cpp:547-607"],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "요청·버퍼·fence의 수명; 버퍼 알림과 요청 반환의 내부 경계; 콜백의 스레드와 재진입을 구분하기",
      "diagnosis_values": "요청 소유자, 버퍼 유효 기간, 남은 fence, pending_과 버퍼의 요청 연결, 지연 수신자의 마지막 사용을 확인합니다.",
      "next_branch": "timeout으로 fence가 남았다면 releaseFence를 확인합니다. 직접 버퍼 콜백에서는 내부 추적 갱신 전이라는 점을 확인하고, Queued 수신자는 별도로 동기화합니다.",
      "change_validation": "정상 완료와 일괄 취소를 구분하고 요청 완료 콜백 및 모든 지연 수신자의 마지막 사용까지 수명을 검증합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/camera.cpp:1243-1263", "src/libcamera/request.cpp:91-173", "src/libcamera/request.cpp:326-505", "src/libcamera/framebuffer.cpp:368-451", "src/libcamera/base/object.cpp:258-284", "src/libcamera/base/signal.cpp:73-113"],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "정지와 연결 해제를 구분하기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "CameraStopping, 분리된 waitingRequests_, STREAMOFF ret, state_, cache_, queuedBuffers_, queuedRequests_ 및 ASSERT 도달 여부를 확인합니다.",
      "next_branch": "STREAMOFF 성공 시 버퍼 반환을 추적합니다. 실패 시 조기 반환, UVC의 무시된 반환값, releaseBuffers와 잔존 notifier 경로를 확인합니다.",
      "change_validation": "정상 정지와 STREAMOFF 및 releaseBuffers 실패를 구분하여 완료 횟수, 순서, 큐 잔존 및 재투입을 검증합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/camera.cpp:1431-1491", "src/libcamera/pipeline_handler.cpp:359-414", "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320-327", "src/libcamera/v4l2_videodevice.cpp:1616-1629", "src/libcamera/v4l2_videodevice.cpp:1814-1987", "src/libcamera/v4l2_videodevice.cpp:2023-2059"],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "콜백의 스레드와 재진입을 구분하기; 공개 가상 카메라의 콜백 관찰",
      "diagnosis_values": "수신자의 Object 여부, 연결 종류, 현재 및 수신 스레드, 이벤트 루프와 콜백 진입·복귀 표식을 확인합니다.",
      "next_branch": "Auto는 스레드 비교로 Direct 또는 Queued를 선택합니다. Blocking 정지 반환과 별도 Queued 수신자의 마지막 사용을 분리해 확인합니다.",
      "change_validation": "호출자 동기화, 허용된 내부 재진입, 포인터 수명 및 지연 콜백 완료를 별도로 검증합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/base/bound_method.cpp:22-110", "include/libcamera/base/bound_method.h:59-209", "include/libcamera/base/signal.h:38-153", "src/libcamera/base/thread.cpp:558-683", "src/libcamera/base/object.cpp:97-125", "Documentation/thread-safety.dox:1-46"],
      "missing": []
    },
    {
      "id": "Q7",
      "answer_location": "변경 검토와 실행 확인",
      "diagnosis_values": "요청별 sequence와 status, 버퍼 status, pending_, 큐 잔존, 신호 횟수, 오류별 ret 및 ASSERT 조건을 확인합니다.",
      "next_branch": "준비 취소, 제어 및 QBUF 실패, DQBUF 오류, FrameError, 정상 정지와 정지 실패를 각각 추적합니다.",
      "change_validation": "재귀 전달 전 pop, 중복 완료 부재, 요청 완료 전 pending 부재, 완료 함수 반환 후 접근 금지 및 정지 중 재투입 방지를 검증합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/pipeline_handler.cpp:359-414", "src/libcamera/pipeline_handler.cpp:435-620", "src/libcamera/request.cpp:91-312", "src/libcamera/v4l2_videodevice.cpp:1648-2059", "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320-470"],
      "missing": []
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q2",
      "claim": "UVC 제출 절은 출력 버퍼에서 마지막이 아닌 플레인에 빈 부분이 있으면 queueBuffer가 -EINVAL을 반환한다고 조건 없이 설명합니다.",
      "counterevidence": "src/libcamera/v4l2_videodevice.cpp:1648-1814에서 해당 검사는 V4L2_TYPE_IS_OUTPUT 분기 안에서도 numV4l2Planes != planes.size()일 때만 실행됩니다. 플레인 수가 같으면 이 검사를 거치지 않습니다.",
      "fix": "출력 버퍼의 V4L2 플레인 수와 FrameBuffer 플레인 수가 다른 경우에만 해당 빈 부분 검사를 수행한다고 한정합니다."
    }
  ],
  "items": [
    {"anchor": "제출에서-완료까지", "question": "제출에서 완료까지의 단계", "visual_status": "적절한 그림 있음", "reason": "하위 그림들이 준비, 전달 및 완료 책임을 각각 설명합니다."},
    {"anchor": "제출준비장치-처리완료의-연결", "question": "정상 요청 경로", "visual_status": "적절한 그림 있음", "reason": "정상 경로의 단계와 명시적 요청 완료를 표시합니다."},
    {"anchor": "접수-반환과-완료-알림", "question": "0 반환과 완료 통지", "visual_status": "적절한 그림 있음", "reason": "호출 예약과 별도 완료 통지 계약을 구분합니다."},
    {"anchor": "선두-요청을-전달하거나-반복을-멈추는-조건", "question": "대기 큐 전달 조건", "visual_status": "적절한 그림 있음", "reason": "선두 준비 상태, 큐 한도와 pop 순서를 표시합니다."},
    {"anchor": "void-전달-함수의-두-취소-경로", "question": "준비 취소와 제출 실패", "visual_status": "적절한 그림 있음", "reason": "이미 취소된 요청과 장치 제출 실패를 구분합니다."},
    {"anchor": "버퍼-완료와-명시적-요청-완료의-경계", "question": "버퍼 완료와 요청 완료", "visual_status": "적절한 그림 있음", "reason": "마지막 버퍼의 반환값과 별도 완료 호출을 구분합니다."},
    {"anchor": "제출-큐의-선두-상태와-반환-순서", "question": "완료 요청의 반환 순서", "visual_status": "적절한 그림 있음", "reason": "선두 Pending 검사와 큐 제거 후 통지를 표시합니다."},
    {"anchor": "준비-대기와-재진입을-좁히기", "question": "준비 생산자와 재진입", "visual_status": "적절한 그림 있음", "reason": "fence, timeout, prepared 신호와 pop 후 전달을 연결합니다."},
    {"anchor": "준비-대기와-재진입을-좁히기-그림", "question": "준비 대기의 분기", "visual_status": "적절한 그림 있음", "reason": "타임아웃과 fence 완료의 공통 준비 신호를 표시합니다."},
    {"anchor": "uvc의-장치-제출과-완료를-추적하기", "question": "UVC 제출과 완료", "visual_status": "적절한 그림 있음", "reason": "장치 제출 실패와 버퍼 알림 경로를 구분합니다. 출력 플레인 조건의 문장 오류는 별도 finding에 기록했습니다."},
    {"anchor": "uvc의-장치-제출과-완료를-추적하기-그림", "question": "UVC 취소와 완료 경로", "visual_status": "적절한 그림 있음", "reason": "제출 실패의 취소와 DQBUF 이후 완료를 구분합니다."},
    {"anchor": "요청버퍼fence의-수명", "question": "자원 소유권과 수명", "visual_status": "적절한 그림 있음", "reason": "소유권, timeout 후 fence 회수 및 재사용을 각각 표시합니다."},
    {"anchor": "요청과-버퍼를-유지할-기간", "question": "요청과 버퍼의 수명", "visual_status": "적절한 그림 있음", "reason": "호출자의 책임과 핸들러의 반환 후 접근 경계를 구분합니다."},
    {"anchor": "타임아웃-뒤-펜스-회수", "question": "남은 fence의 회수", "visual_status": "적절한 그림 있음", "reason": "timeout 후 다른 요청에 재사용하기 위한 회수 조건을 표시합니다."},
    {"anchor": "버퍼-재사용과-펜스-권고", "question": "ReuseBuffers와 fence", "visual_status": "적절한 그림 있음", "reason": "버퍼 재사용과 fence 사용 시 권고를 구분합니다."},
    {"anchor": "버퍼-알림과-요청-반환의-내부-경계", "question": "버퍼 신호와 내부 추적 순서", "visual_status": "적절한 그림 있음", "reason": "신호 발생, pending 제거, 요청 완료와 선두 통지를 연결합니다."},
    {"anchor": "버퍼-알림과-요청-반환의-내부-경계-그림", "question": "완료 처리의 내부 순서", "visual_status": "적절한 그림 있음", "reason": "선택한 UVC 경로에서 신호 발생과 내부 상태 갱신을 구분합니다."},
    {"anchor": "콜백의-스레드와-재진입을-구분하기", "question": "연결 종류와 수명", "visual_status": "적절한 그림 있음", "reason": "Auto의 분기와 Queued 수명 책임을 별도 그림으로 다룹니다."},
    {"anchor": "콜백의-스레드와-재진입을-구분하기-그림", "question": "Auto의 연결 분기", "visual_status": "적절한 그림 있음", "reason": "현재 스레드와 수신 스레드 비교를 표시합니다."},
    {"anchor": "queued-수신과-해제-시점의-책임", "question": "지연 수신자의 포인터 수명", "visual_status": "적절한 그림 있음", "reason": "발신자 책임과 마지막 수신 사용의 별도 확인을 표시합니다."},
    {"anchor": "정지와-연결-해제를-구분하기", "question": "정지와 연결 해제", "visual_status": "적절한 그림 있음", "reason": "정지 순서, API 분기와 연결 해제 TODO를 구분합니다."},
    {"anchor": "정지할-때-대기-요청을-처리하는-순서", "question": "정상 정지 순서", "visual_status": "적절한 그림 있음", "reason": "대기 큐 분리, 장치 정지와 대기 요청 취소 순서를 표시합니다."},
    {"anchor": "정지-api-계약과-연결-해제-todo", "question": "정지 계약과 연결 해제", "visual_status": "적절한 그림 있음", "reason": "계약과 미완료 TODO를 나란히 구분합니다."},
    {"anchor": "camerastop의-미실행오류정상-경로", "question": "Camera::stop 분기", "visual_status": "적절한 그림 있음", "reason": "미실행, 접근 오류 및 정상 호출 경로를 구분합니다."},
    {"anchor": "stopdevice-호출-구간의-관찰-계획", "question": "stopDevice 관찰 위치", "visual_status": "적절한 그림 있음", "reason": "호출 전, 구현 진입 및 복귀 관찰을 구분합니다."},
    {"anchor": "완료-통지의-호출자-의무와-반환-뒤-경계", "question": "완료 호출의 의무", "visual_status": "적절한 그림 있음", "reason": "호출 스레드, 제출 순서와 반환 후 접근 금지를 표시합니다."},
    {"anchor": "uvc-정지의-정상-경로와-실패-경계", "question": "UVC 정지 실패", "visual_status": "적절한 그림 있음", "reason": "STREAMOFF 실패의 조기 반환과 releaseBuffers 호출을 다룹니다."},
    {"anchor": "uvc-정지의-정상-경로와-실패-경계-그림", "question": "STREAMOFF와 버퍼 반환", "visual_status": "적절한 그림 있음", "reason": "ioctl 성공과 실패의 버퍼 반환 분기를 구분합니다."},
    {"anchor": "변경-검토와-실행-확인", "question": "변경 시 검증 조건", "visual_status": "적절한 그림 있음", "reason": "정상 완료와 일괄 취소의 서로 다른 pending 처리 위치를 표시합니다."},
    {"anchor": "정상-완료와-bulk-취소의-검증-위치", "question": "완료와 일괄 취소의 검증 위치", "visual_status": "적절한 그림 있음", "reason": "개별 erase와 일괄 clear를 구분합니다."},
    {"anchor": "공개-가상-카메라의-콜백-관찰", "question": "가상 프로브 관찰 범위", "visual_status": "적절한 그림 있음", "reason": "연결별 표식과 반환 근처 표식의 한계를 구분합니다."},
    {"anchor": "가상-cpu-프로브의-연결별-취소-콜백-표시", "question": "프로브의 콜백 표식", "visual_status": "적절한 그림 있음", "reason": "세 실행에서 관찰된 연결별 표식 위치를 표시합니다."},
    {"anchor": "반환-근처-표시로-알-수-있는-범위", "question": "반환 표식의 한계", "visual_status": "적절한 그림 있음", "reason": "표식 이후 작업과 실제 반환 미추적을 표시합니다."},
    {"anchor": "소스-근거", "question": "인용된 소스 찾기", "visual_status": "생략 가능", "reason": "출처별 원문과 식별자를 제공하는 참조 목록입니다."}
  ],
  "unreviewed_scope": [
    "물리 UVC 캡처, DMA 정확성, 성능 및 내부 Camera HAL은 검토 범위 밖입니다.",
    "다른 파이프라인, IPA, 커널 UVC 드라이버 및 사용자 정의 이벤트 디스패처는 검토 범위 밖입니다.",
    "실제 비저자 독자 평가와 사람 검토는 수행되지 않았습니다."
  ]
}
