{
  "status": "passed",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "제출에서 완료까지; 준비 대기와 재진입을 좁히기; UVC의 장치 제출과 완료를 추적하기",
      "diagnosis_values": "queued 호출의 실행 여부와 대상 스레드, waitingRequests_ 선두, prepared_, 남은 fence와 notifier, 300ms timer, queuedRequests_ 크기와 한도, 선두 status를 확인합니다.",
      "next_branch": "호출이 실행되지 않았다면 이벤트 루프와 포인터 수명을 확인합니다. 실행됐다면 fence 신호 또는 timeout, 한도와 선두 준비 상태를 확인한 뒤 UVC 제출 및 DQBUF 분기로 이동합니다.",
      "change_validation": "준비 취소와 재귀 전달에서 선두 pop, 요청별 처리 횟수, pending 상태와 제출 순서에 따른 통지를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1308-1383",
        "src/libcamera/pipeline_handler.cpp:428-607",
        "src/libcamera/request.cpp:192-312",
        "src/libcamera/base/object.cpp:258-284",
        "src/libcamera/v4l2_videodevice.cpp:1648-1987"
      ],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "UVC의 장치 제출과 완료를 추적하기; 변경 검토와 실행 확인",
      "diagnosis_values": "findBuffer 결과, 개별 processControl과 setControls 결과, error_idx, queueBuffer와 VIDIOC_QBUF의 ret, cache_, queuedBuffers_ 및 sequence_를 확인합니다.",
      "next_branch": "버퍼가 없으면 -ENOENT를 확인합니다. 제어 처리의 음수 반환은 QBUF 이전에, queueBuffer의 음수 반환은 그 이후에 공통 cancelRequest로 이어지는지 확인합니다. cache_ 부재의 Fatal 경계는 별도로 다룹니다.",
      "change_validation": "제어 쓰기 실패와 제어 적용 후 QBUF 실패를 구분하고, 취소·완료 횟수와 순서를 확인합니다. 제어 변경의 롤백은 가정하지 않습니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:327-470",
        "src/libcamera/v4l2_device.cpp:309-430",
        "src/libcamera/v4l2_videodevice.cpp:1648-1814",
        "src/libcamera/pipeline_handler.cpp:483-501"
      ],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "제출에서 완료까지; UVC의 장치 제출과 완료를 추적하기; 버퍼 알림과 요청 반환의 내부 경계",
      "diagnosis_values": "DQBUF ret과 index, 프레임 status·flags·planes·bytesused, pending_, cancelled_, queuedRequests_ 선두 status와 requestCompleted 신호를 확인합니다.",
      "next_branch": "DQBUF 실패나 예상 밖 index라면 해당 bufferAvailable 호출은 알림 없이 반환합니다. 유효 버퍼라면 bufferCompleted 발행 후 pending 제거, 명시적 completeRequest, 선두 검사를 따라갑니다.",
      "change_validation": "FrameError와 다른 취소 원인이 없는 RequestComplete를 별도로 기록하고, 버퍼당 완료 횟수와 요청의 제출 순서 통지를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/v4l2_videodevice.cpp:1814-1987",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:535-537,893-905",
        "src/libcamera/pipeline_handler.cpp:547-607",
        "src/libcamera/request.cpp:91-139",
        "src/libcamera/framebuffer.cpp:40-59"
      ],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "요청·버퍼·fence의 수명; 버퍼 알림과 요청 반환의 내부 경계; 콜백의 스레드와 재진입을 구분하기",
      "diagnosis_values": "요청 소유자, 버퍼 유효 기간, fence 잔존 여부, pending_, FrameBuffer::request() 연결 값과 각 지연 수신자의 마지막 사용을 확인합니다.",
      "next_branch": "fence timeout이면 releaseFence를 확인합니다. 직접 버퍼 콜백에서는 이전 요청의 추적 갱신이 아직 끝나지 않았는지 확인하고, Queued 수신은 별도로 수명을 추적합니다.",
      "change_validation": "정상 완료와 bulk 취소의 연결 처리 차이, 요청 재설정 및 모든 지연 수신자의 사용 종료 전에 삭제하거나 재사용하지 않는 조건을 검증합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1243-1263",
        "src/libcamera/request.cpp:91-173,326-338,376-407,442-505",
        "src/libcamera/framebuffer.cpp:368-383",
        "src/libcamera/base/object.cpp:258-284",
        "src/libcamera/base/signal.cpp:73-113"
      ],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "정지와 연결 해제를 구분하기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "CameraStopping, 분리된 waitingRequests_, stopDevice 진입·복귀, STREAMOFF ret, state_, queuedBuffers_, cache_, notifier와 각 ASSERT를 확인합니다.",
      "next_branch": "정상 STREAMOFF는 버퍼 취소와 bufferReady를 따라갑니다. 실패하면 반환 루프를 건너뛰고 UVC가 반환값을 무시한 채 releaseBuffers를 호출하는 경로 및 잔존 notifier 이후 DQBUF를 조사합니다.",
      "change_validation": "STREAMOFF와 releaseBuffers 실패를 별도로 주입하여 큐 잔존, 완료 횟수, 재투입, ASSERT 도달 여부와 reset된 cache에 대한 후속 접근을 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1431-1491",
        "src/libcamera/pipeline_handler.cpp:359-414",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320-327,893-905",
        "src/libcamera/v4l2_videodevice.cpp:1616-1629,1814-1987,2023-2059"
      ],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "콜백의 스레드와 재진입을 구분하기; 정지와 연결 해제를 구분하기; 공개 가상 카메라의 콜백 관찰",
      "diagnosis_values": "연결 종류, 현재 스레드와 Object 수신 스레드, 이벤트 루프 진행, 콜백 진입·복귀 표식과 별도 Queued 수신자의 마지막 사용을 확인합니다.",
      "next_branch": "Auto는 스레드 비교에 따라 Direct 또는 Queued를 선택합니다. Blocking은 같은 스레드에서 Direct로 처리되고 다른 스레드에서는 해당 호출의 완료를 기다립니다. 별도 Queued 콜백의 drain은 따로 확인합니다.",
      "change_validation": "Direct 중첩 호출과 지연 Queued 수신을 구분하고, 카메라 상태 변경의 호출자 동기화와 전달된 포인터의 수명을 검증합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/base/bound_method.cpp:22-110",
        "include/libcamera/base/signal.h:38-153",
        "include/libcamera/base/bound_method.h:59-209",
        "src/libcamera/base/object.cpp:97-125,184-284",
        "src/libcamera/base/thread.cpp:558-683",
        "src/libcamera/base/message.cpp:151-157",
        "Documentation/thread-safety.dox:1-46"
      ],
      "missing": []
    },
    {
      "id": "Q7",
      "answer_location": "변경 검토와 실행 확인; 준비 대기와 재진입을 좁히기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "cookie, sequence, 요청·버퍼 status, pending_, 양쪽 요청 큐, ioctl ret과 index, 콜백 횟수 및 객체 수명을 기록합니다.",
      "next_branch": "준비 timeout, 제어·QBUF 실패, DQBUF 오류·예상 밖 index, FrameError, 정상 정지와 STREAMOFF·releaseBuffers 실패를 각각 확인합니다.",
      "change_validation": "재귀 전달 전 pop, 정상 버퍼의 정확히 한 번의 완료, 요청 완료 전 pending 부재, completeRequest 반환 후 접근 금지, 정지 중 재투입 부재와 제출 순서를 검증합니다. bulk 취소는 별도 경로로 검사합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp:359-414,428-620",
        "src/libcamera/request.cpp:91-173,192-312",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320-470,893-905",
        "src/libcamera/v4l2_device.cpp:309-430",
        "src/libcamera/v4l2_videodevice.cpp:1616-2059",
        "Documentation/thread-safety.dox:1-46"
      ],
      "missing": []
    }
  ],
  "findings": [],
  "items": [
    {
      "anchor": "제출에서 완료까지",
      "question": "제출과 완료는 어떻게 연결됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "제출, 준비, 명시적 완료와 제출 순서 반환을 표시합니다."
    },
    {
      "anchor": "제출·준비·장치 처리·완료의 연결",
      "question": "정상 경로의 단계와 완료 책임은 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "정상 경로의 조건과 명시적 완료를 구분합니다."
    },
    {
      "anchor": "접수 반환과 완료 알림",
      "question": "0 반환과 완료 알림은 무엇을 뜻합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "Queued 호출의 반환과 별도 완료 알림을 구분합니다."
    },
    {
      "anchor": "선두 요청을 전달하거나 반복을 멈추는 조건",
      "question": "준비와 큐 한도는 전달을 어떻게 제한합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "한도, 선두 준비 상태와 pop 순서를 표시합니다."
    },
    {
      "anchor": "void 전달 함수의 두 취소 경로",
      "question": "준비 취소와 장치 제출 실패는 어떻게 처리됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "이미 취소된 요청과 장치 함수의 비영 반환을 구분합니다."
    },
    {
      "anchor": "버퍼 완료와 명시적 요청 완료의 경계",
      "question": "마지막 버퍼 완료 뒤 무엇을 호출해야 합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "completeBuffer의 반환과 별도 completeRequest 의무를 표시합니다."
    },
    {
      "anchor": "제출 큐의 선두 상태와 반환 순서",
      "question": "어느 요청부터 반환합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "Pending 선두의 중단과 완료된 선두의 제거·통지를 표시합니다."
    },
    {
      "anchor": "준비 대기와 재진입을 좁히기",
      "question": "fence와 timeout은 전달에 어떻게 연결됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "준비 완료 생산자, 취소와 재귀 전달 전 pop을 연결합니다."
    },
    {
      "anchor": "UVC의 장치 제출과 완료를 추적하기",
      "question": "UVC 제출 실패와 장치 버퍼 완료는 어떻게 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "제출 실패의 취소와 bufferReady 이후 명시적 완료를 구분하며, 본문이 제어와 QBUF의 세부 조건을 보완합니다."
    },
    {
      "anchor": "요청·버퍼·fence의 수명",
      "question": "누가 자원을 얼마나 오래 유지합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "요청 소유, 버퍼 유효 기간, 완료 후 접근과 fence 회수를 별도 그림으로 설명합니다."
    },
    {
      "anchor": "요청과 버퍼를 유지할 기간",
      "question": "요청 소유자와 핸들러의 책임은 어떻게 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "소유자의 삭제·재사용과 핸들러의 반환 후 접근 경계를 구분합니다."
    },
    {
      "anchor": "타임아웃 뒤 펜스 회수",
      "question": "미신호 fence가 남으면 무엇을 해야 합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "다른 요청에서 버퍼를 재사용하기 전 releaseFence 회수 조건을 표시합니다."
    },
    {
      "anchor": "버퍼 재사용과 펜스 권고",
      "question": "ReuseBuffers와 fence 권고는 어떻게 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "버퍼 재사용과 fence 비재사용 및 should-not 권고를 구분합니다."
    },
    {
      "anchor": "버퍼 알림과 요청 반환의 내부 경계",
      "question": "신호와 내부 추적 갱신은 어떤 순서입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "신호 발행, pending 제거, 명시적 요청 완료와 선두 검사를 순서대로 표시합니다."
    },
    {
      "anchor": "콜백의 스레드와 재진입을 구분하기",
      "question": "연결 종류와 수신자에 따라 호출이 어떻게 달라집니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "Auto의 Direct·Queued 선택과 별도 Queued 수명 책임을 해당 항목의 그림으로 설명합니다."
    },
    {
      "anchor": "Queued 수신과 해제 시점의 책임",
      "question": "지연 수신자의 포인터 수명은 어떻게 확인합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "발신자의 수명 책임과 별도 수신자의 마지막 사용 확인을 구분합니다."
    },
    {
      "anchor": "정지와 연결 해제를 구분하기",
      "question": "정지와 연결 해제의 요청 처리는 어떻게 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "정상 정지 순서와 연결 해제 TODO를 각각 표시합니다."
    },
    {
      "anchor": "정지할 때 대기 요청을 처리하는 순서",
      "question": "정상 정지에서 대기 요청은 언제 취소됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "대기 큐 분리, 장치 정지, 취소 반복과 ASSERT 위치를 표시합니다."
    },
    {
      "anchor": "정지 API 계약과 연결 해제 TODO",
      "question": "정지 계약과 연결 해제 TODO는 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "두 원문의 서로 다른 범위를 직접 비교합니다."
    },
    {
      "anchor": "Camera::stop의 미실행·오류·정상 경로",
      "question": "Camera::stop은 조건에 따라 어떻게 반환합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "실행 여부, 접근 오류와 Blocking 호출 뒤 정상 경로를 구분합니다."
    },
    {
      "anchor": "stopDevice 호출 구간의 관찰 계획",
      "question": "호출과 실제 구현의 진입·복귀를 어떻게 조사합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "관찰 지점과 복귀 미관찰의 한계를 구분합니다."
    },
    {
      "anchor": "완료 통지의 호출자 의무와 반환 뒤 경계",
      "question": "완료 호출의 스레드와 접근 제한은 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "호출 스레드, 제출 순서 계약과 반환 후 접근 금지를 표시합니다."
    },
    {
      "anchor": "UVC 정지의 정상 경로와 실패 경계",
      "question": "STREAMOFF 실패는 어느 처리를 건너뜁니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "ioctl 실패의 조기 반환과 정상 버퍼 반환 루프 및 releaseBuffers 호출을 구분합니다."
    },
    {
      "anchor": "변경 검토와 실행 확인",
      "question": "변경 후 어떤 불변조건과 실패 사례를 검증합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "정상 완료와 bulk 취소의 pending 처리 위치를 비교하고, 본문이 실패 주입 사례를 제시합니다."
    },
    {
      "anchor": "공개 가상 카메라의 콜백 관찰",
      "question": "가상 프로브에서 무엇을 관찰했고 무엇은 측정하지 않았습니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "연결별 표식과 실제 C++ 반환을 추적하지 않은 한계를 별도로 표시합니다."
    },
    {
      "anchor": "가상 CPU 프로브의 연결별 취소 콜백 표시",
      "question": "각 연결의 취소 콜백 표식은 stop 표식과 어떻게 배치됐습니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "세 실행의 관측을 해당 프로브 범위로 한정합니다."
    },
    {
      "anchor": "반환 근처 표시로 알 수 있는 범위",
      "question": "반환 근처 표식은 실제 함수 반환을 증명합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "표식 이후의 후속 작업과 실제 반환 미추적을 표시합니다."
    },
    {
      "anchor": "소스 근거",
      "question": "설명에 사용한 원문은 어디에 있습니까?",
      "visual_status": "생략 가능",
      "reason": "소스 발췌와 식별자를 제공하는 참조 항목입니다."
    }
  ],
  "unreviewed_scope": [
    "다른 파이프라인 구현, IPA 처리 및 커널 UVC 드라이버 구현은 검토 범위 밖입니다.",
    "물리 카메라 캡처, DMA 정확성, 성능 및 내부 Camera HAL 검증은 수행하지 않았습니다.",
    "실제 비저자 독자 평가와 사람 검토는 수행하지 않았습니다.",
    "제공된 범위 밖의 전체 문서 집합과 별도 페이지의 화면은 검토하지 않았습니다."
  ]
}
