{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "「준비 대기와 재진입을 좁히기」와 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "camera.cpp:1308의 Queued 게시, pipeline_handler.cpp:435의 waitingRequests_ 선두·prepared_·queuedRequests_ 크기와 한도, request.cpp:192의 fence·notifier·300ms 타이머, pipeline_handler.cpp:571의 선두 상태를 확인합니다.",
      "next_branch": "핸들러에 진입하지 않았다면 대상 스레드와 메시지 소비를 확인합니다. 진입했다면 준비와 큐 한도를 확인하고, 장치에 전달됐다면 UVC 제출과 DQBUF 분기를 확인합니다.",
      "change_validation": "재귀 전달 전 pop, 준비 취소 요청의 단일 등록, Pending 선두 뒤 요청의 제출 순서 반환을 대조합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/base/thread.cpp",
        "src/libcamera/base/event_dispatcher_poll.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "「UVC의 장치 제출과 완료를 추적하기」와 「실패 주입별 다음 관찰 분기」",
      "diagnosis_values": "uvcvideo.cpp:427,448의 findBuffer·processControl·setControls·queueBuffer 결과, v4l2_device.cpp:309의 error_idx, v4l2_videodevice.cpp:1648의 cache와 QBUF 결과를 확인합니다.",
      "next_branch": "버퍼 부재나 장치 함수의 음수 반환은 pipeline_handler.cpp:483의 cancelRequest로 이어집니다. QBUF가 성공하면 등록과 별도의 DQBUF 이벤트를 확인합니다.",
      "change_validation": "제어 처리 뒤 QBUF 실패에서 원래 ret, cache put, 신규 등록 부재, sequence와 취소를 대조합니다. 전체 제어 적용이나 롤백은 가정하지 않습니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_device.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "include/libcamera/base/utils.h"
      ],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "「버퍼 알림과 요청 반환의 내부 경계」와 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "pipeline_handler.cpp:547과 request.cpp:103의 emit·pending_.erase·cancelled_·status, v4l2_videodevice.cpp:1814의 DQBUF 결과와 FrameError, queuedRequests_ 선두와 requestCompleted를 확인합니다.",
      "next_branch": "DQBUF 오류나 미등록 index이면 해당 호출은 bufferReady 없이 반환합니다. 버퍼가 반환되면 UVC의 completeBuffer, completeRequest와 선두 반환을 확인합니다.",
      "change_validation": "FrameError와 RequestComplete의 공존, 버퍼별 단일 완료, 빈 pending 및 Pending 선두에 따른 지연을 대조합니다. 상태 선택은 취소된 버퍼의 존재가 아니라 cancelled_ 값으로 확인해야 합니다.",
      "answerable": false,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/framebuffer.cpp",
        "src/libcamera/camera.cpp"
      ],
      "missing": [
        "버퍼 취소 여부만으로 요청 상태를 결정한다는 설명을 cancelled_ 기준으로 수정해야 합니다."
      ]
    },
    {
      "id": "Q4",
      "answer_location": "「요청·버퍼·fence의 수명」과 「Queued 수신과 해제 시점의 책임」",
      "diagnosis_values": "camera.cpp:1243의 요청 소유권, request.cpp:442의 버퍼와 fence 계약, framebuffer.cpp:368의 request 포인터 유효 구간, object.cpp:258의 포인터 인수 수명을 확인합니다.",
      "next_branch": "미신호 fence가 남았다면 다른 요청에 버퍼를 추가하기 전에 releaseFence를 확인합니다. Direct 버퍼 콜백에서는 pending 제거 전 경계를, Queued 수신에서는 마지막 포인터 사용을 확인합니다.",
      "change_validation": "정상 완료와 bulk 취소의 연결 해제 차이, reuse 전 초기화 및 지연 수신자의 마지막 사용과 삭제·재사용 사이의 동기화를 대조합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/framebuffer.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/base/object.cpp",
        "src/libcamera/base/signal.cpp",
        "src/libcamera/base/bound_method.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "「정지와 연결 해제를 구분하기」와 「UVC 정지의 정상 경로와 실패 경계」",
      "diagnosis_values": "pipeline_handler.cpp:359의 waitingRequests_ swap과 두 ASSERT, camera.cpp:1431의 CameraStopping 및 Blocking 호출, uvcvideo.cpp:320과 v4l2_videodevice.cpp:1616,2023의 반환값·큐·cache·notifier를 확인합니다.",
      "next_branch": "STREAMOFF 실패는 버퍼 반환 루프 전에 반환하며 UVC는 releaseBuffers를 호출합니다. 잔존 notifier의 후속 DQBUF와 reset된 cache 접근 조건을 확인합니다.",
      "change_validation": "정상 정지, STREAMOFF 실패 및 releaseBuffers 실패를 구분해 ret, 큐 잔존, ASSERT 도달, 완료 횟수와 정지 중 재투입을 기록합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/camera.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "「콜백의 스레드와 재진입을 구분하기」와 「stop 반환과 별도 수신의 마지막 사용 확인」",
      "diagnosis_values": "bound_method.cpp:68의 연결 종류와 스레드 비교, thread.cpp:613의 필터와 재귀 깊이, camera.cpp:1431의 Blocking 호출, 수신자의 진입과 마지막 사용을 확인합니다.",
      "next_branch": "Direct는 발신 스레드에서 동기 실행합니다. Queued는 게시 후 소비 여부를 확인하고, Blocking은 같은 스레드의 Direct와 다른 스레드의 semaphore 대기를 구분합니다.",
      "change_validation": "호출자의 상태 변경 동기화와 지연 수신자의 마지막 사용을 확인합니다. 서로 다른 필터를 쓰는 재귀 dispatch의 전달 순서도 게시 순서와 비교합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/base/bound_method.cpp",
        "src/libcamera/base/signal.cpp",
        "include/libcamera/base/signal.h",
        "src/libcamera/base/object.cpp",
        "src/libcamera/base/thread.cpp",
        "src/libcamera/base/message.cpp",
        "src/libcamera/camera.cpp",
        "Documentation/thread-safety.dox"
      ],
      "missing": []
    },
    {
      "id": "Q7",
      "answer_location": "「변경 검토와 실행 확인」",
      "diagnosis_values": "pipeline_handler.cpp:483,516의 등록·pop 순서, request.cpp:103,139의 erase 또는 bulk clear, pipeline_handler.cpp:571의 pending ASSERT와 접근 경계, streamOff 실패 시 잔존 큐를 확인합니다.",
      "next_branch": "준비 timeout, 제어·QBUF 실패, DQBUF 오류·예상 밖 index, FrameError 및 STREAMOFF 실패를 각각 추적합니다.",
      "change_validation": "요청별 단일 투입과 버퍼별 단일 완료, 요청 완료 전 빈 pending, 완료 함수 반환 후 접근 금지, 정지 중 재투입 부재 및 지연 수신자의 마지막 사용을 검증합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/base/bound_method.cpp",
        "Documentation/thread-safety.dox"
      ],
      "missing": []
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q3",
      "claim": "「버퍼 알림과 요청 반환의 내부 경계」는 취소된 버퍼가 있으면 RequestCancelled이고 그렇지 않으면 RequestComplete라고 설명합니다.",
      "counterevidence": "src/libcamera/request.cpp:103의 complete()는 cancelled_만 검사합니다. request.cpp:139의 doCancelRequest()는 pending_이 비어 있어 취소할 버퍼가 없어도 cancelled_를 true로 설정합니다. 따라서 취소된 버퍼가 없다는 사실만으로 RequestComplete를 판정할 수 없습니다.",
      "fix": "본문과 callback-order-flow 그림에서 cancelled_가 true이면 RequestCancelled, false이면 RequestComplete라고 명시하고, 버퍼 취소가 cancelled_를 설정하는 한 경로임을 구분하세요."
    }
  ],
  "items": [
    {
      "anchor": "item-01",
      "visual_status": "diagram",
      "question": "제출에서 완료까지",
      "reason": "제출부터 명시적 완료까지의 단계 그림이 있습니다."
    },
    {
      "anchor": "item-02",
      "visual_status": "diagram",
      "question": "제출·준비·장치 처리·완료의 연결",
      "reason": "준비와 완료의 정상 경로를 나타냅니다."
    },
    {
      "anchor": "item-03",
      "visual_status": "diagram",
      "question": "접수 반환과 완료 알림",
      "reason": "게시 성공 반환과 완료 신호를 구분합니다."
    },
    {
      "anchor": "item-04",
      "visual_status": "diagram",
      "question": "선두 요청을 전달하거나 반복을 멈추는 조건",
      "reason": "큐 한도와 선두 준비 상태를 분기합니다."
    },
    {
      "anchor": "item-05",
      "visual_status": "diagram",
      "question": "void 전달 함수의 두 취소 경로",
      "reason": "기존 취소와 장치 제출 실패를 구분합니다."
    },
    {
      "anchor": "item-06",
      "visual_status": "diagram",
      "question": "버퍼 완료와 명시적 요청 완료의 경계",
      "reason": "버퍼 완료와 명시적 요청 완료를 구분합니다."
    },
    {
      "anchor": "item-07",
      "visual_status": "diagram",
      "question": "제출 큐의 선두 상태와 반환 순서",
      "reason": "Pending 선두와 완료된 선두의 분기를 나타냅니다."
    },
    {
      "anchor": "item-08",
      "visual_status": "diagram",
      "question": "준비 대기와 재진입을 좁히기",
      "reason": "fence와 준비 신호에서 재진입 전 pop까지 연결합니다."
    },
    {
      "anchor": "item-09",
      "visual_status": "diagram",
      "question": "준비 대기와 재진입을 좁히기 그림",
      "reason": "준비 신호와 선두 전달 조건을 나타냅니다."
    },
    {
      "anchor": "item-10",
      "visual_status": "diagram",
      "question": "동시 제출의 순서를 관찰할 경계",
      "reason": "호출 시작, 게시, 등록 및 통지를 구분합니다."
    },
    {
      "anchor": "item-11",
      "visual_status": "diagram",
      "question": "같은 Poll 회차의 fence와 타이머 처리",
      "reason": "notifier와 타이머의 조건부 처리 순서를 나타냅니다."
    },
    {
      "anchor": "item-12",
      "visual_status": "diagram",
      "question": "UVC의 장치 제출과 완료를 추적하기",
      "reason": "UVC 제출 실패와 별도 완료 경로를 나타냅니다."
    },
    {
      "anchor": "item-13",
      "visual_status": "diagram",
      "question": "UVC의 장치 제출과 완료를 추적하기 그림",
      "reason": "제어 처리, QBUF, 취소 및 완료를 구분합니다."
    },
    {
      "anchor": "item-14",
      "visual_status": "diagram",
      "question": "QBUF 호출 전 실패와 cache 반환",
      "reason": "cache 획득 실패와 plane 검증 실패를 구분합니다."
    },
    {
      "anchor": "item-15",
      "visual_status": "diagram",
      "question": "요청·버퍼·fence의 수명",
      "reason": "소유권과 완료·지연 수신의 수명 경계를 나타냅니다."
    },
    {
      "anchor": "item-16",
      "visual_status": "omitted-with-reason",
      "question": "제출 성공 뒤에도 남는 수명 문제",
      "reason": "짧은 문장이 게시 성공과 별도 완료 신호를 구분하므로 독립된 그림이 필수는 아닙니다."
    },
    {
      "anchor": "item-17",
      "visual_status": "diagram",
      "question": "소유권과 두 완료 경계",
      "reason": "호출자 소유권과 완료 핸들러 및 지연 수신을 나타냅니다."
    },
    {
      "anchor": "item-18",
      "visual_status": "diagram",
      "question": "정상 완료와 다음 요청 준비",
      "reason": "버퍼 신호 이후 내부 갱신과 명시적 완료를 나타냅니다."
    },
    {
      "anchor": "item-19",
      "visual_status": "diagram",
      "question": "알림 순서와 취소가 달라질 때",
      "reason": "상태 선택, 선두 대기 및 fence 회수 조건을 나타냅니다."
    },
    {
      "anchor": "item-20",
      "visual_status": "diagram",
      "question": "완료 책임을 변경하기 전에",
      "reason": "스레드, 반환 순서와 수명 계약을 연결합니다."
    },
    {
      "anchor": "item-21",
      "visual_status": "diagram",
      "question": "버퍼 알림과 요청 반환의 내부 경계",
      "reason": "신호, pending 제거 및 요청 반환 순서를 나타냅니다. 상태 선택 문구는 Q3의 지적에 따라 수정해야 합니다."
    },
    {
      "anchor": "item-22",
      "visual_status": "diagram",
      "question": "버퍼 알림과 요청 반환의 내부 경계 그림",
      "reason": "내부 추적과 완료 통지의 순서를 나타내지만 상태 선택 문구는 Q3의 지적에 따라 수정해야 합니다."
    },
    {
      "anchor": "item-23",
      "visual_status": "diagram",
      "question": "콜백의 스레드와 재진입을 구분하기",
      "reason": "연결 방식과 전달 및 내부 갱신 경계를 나타냅니다."
    },
    {
      "anchor": "item-24",
      "visual_status": "diagram",
      "question": "콜백의 스레드와 재진입을 구분하기 그림",
      "reason": "Auto의 Direct와 Queued 선택을 나타냅니다."
    },
    {
      "anchor": "item-25",
      "visual_status": "diagram",
      "question": "Queued 수신과 해제 시점의 책임",
      "reason": "포인터 유효성과 지연 수신의 마지막 사용을 구분합니다."
    },
    {
      "anchor": "item-26",
      "visual_status": "diagram",
      "question": "직접 중첩 호출과 별도 Queued 수신의 경계",
      "reason": "동기 호출, 게시, dispatch 및 내부 갱신을 구분합니다."
    },
    {
      "anchor": "item-27",
      "visual_status": "diagram",
      "question": "stop 반환과 별도 수신의 마지막 사용 확인",
      "reason": "Blocking 정지와 별도 수신자의 수명을 구분합니다."
    },
    {
      "anchor": "item-28",
      "visual_status": "diagram",
      "question": "정지와 연결 해제를 구분하기",
      "reason": "정지 순서와 연결 해제 TODO를 나타냅니다."
    },
    {
      "anchor": "item-29",
      "visual_status": "diagram",
      "question": "정지할 때 대기 요청을 처리하는 순서",
      "reason": "대기 큐 분리, 장치 정지 및 취소를 나타냅니다."
    },
    {
      "anchor": "item-30",
      "visual_status": "diagram",
      "question": "정지 API 계약과 연결 해제 TODO",
      "reason": "정지 계약과 연결 해제 TODO를 구분합니다."
    },
    {
      "anchor": "item-31",
      "visual_status": "diagram",
      "question": "Camera::stop의 미실행·오류·정상 경로",
      "reason": "실행 여부와 접근 검사에 따른 반환 경로를 나타냅니다."
    },
    {
      "anchor": "item-32",
      "visual_status": "diagram",
      "question": "stopDevice 호출 구간의 관찰 계획",
      "reason": "호출 직전, 구현 진입과 복귀 관찰을 구분합니다."
    },
    {
      "anchor": "item-33",
      "visual_status": "diagram",
      "question": "완료 통지의 호출자 의무와 반환 뒤 경계",
      "reason": "호출 스레드, 반환 순서 및 접근 금지를 연결합니다."
    },
    {
      "anchor": "item-34",
      "visual_status": "diagram",
      "question": "제출 회차별 완료 기록의 비교 계획",
      "reason": "논리적 제출 식별과 완료 진입·통지 기록을 구분합니다."
    },
    {
      "anchor": "item-35",
      "visual_status": "diagram",
      "question": "UVC 정지의 정상 경로와 실패 경계",
      "reason": "STREAMOFF 분기와 releaseBuffers 호출을 나타냅니다."
    },
    {
      "anchor": "item-36",
      "visual_status": "diagram",
      "question": "UVC 정지의 정상 경로와 실패 경계 그림",
      "reason": "즉시 반환, ioctl 실패 및 성공 정리를 구분합니다."
    },
    {
      "anchor": "item-37",
      "visual_status": "diagram",
      "question": "변경 검토와 실행 확인",
      "reason": "완료·취소 검증 위치와 실패 분기를 나타냅니다."
    },
    {
      "anchor": "item-38",
      "visual_status": "diagram",
      "question": "정상 완료와 bulk 취소의 검증 위치",
      "reason": "pending erase와 bulk clear 및 완료 검사를 비교합니다."
    },
    {
      "anchor": "item-39",
      "visual_status": "diagram",
      "question": "실패 주입별 다음 관찰 분기",
      "reason": "timeout, 제출 및 DQBUF 분기를 나타내며 nullptr 경로는 반환 노드에서 끝납니다."
    },
    {
      "anchor": "item-40",
      "visual_status": "diagram",
      "question": "공개 가상 카메라의 콜백 관찰",
      "reason": "연결별 표식과 반환 근처 표식의 한계를 나타냅니다."
    },
    {
      "anchor": "item-41",
      "visual_status": "diagram",
      "question": "가상 CPU 프로브의 연결별 취소 콜백 표시",
      "reason": "관찰된 연결별 스레드와 stop 표식의 관계를 나타냅니다."
    },
    {
      "anchor": "item-42",
      "visual_status": "diagram",
      "question": "반환 근처 표시로 알 수 있는 범위",
      "reason": "표식 이후 작업과 실제 C++ 반환 미추적을 구분합니다."
    },
    {
      "anchor": "item-43",
      "visual_status": "omitted-with-reason",
      "question": "소스 근거",
      "reason": "원문 발췌와 출처를 열람하는 색인이므로 처리 그림이 필요하지 않습니다."
    }
  ],
  "unreviewed_scope": [
    "물리 UVC 촬영, DMA 정확성, 성능 및 사내 Camera HAL은 이 감사의 범위 밖입니다.",
    "별도 비저자 독자 평가와 사람 검토는 수행되지 않았습니다."
  ]
}
