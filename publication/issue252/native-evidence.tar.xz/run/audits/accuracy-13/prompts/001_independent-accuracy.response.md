{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "「제출에서 완료까지」와 「준비 대기와 재진입을 좁히기」",
      "diagnosis_values": "camera.cpp:1308의 Queued 호출, pipeline_handler.cpp:435의 waitingRequests_ 선두와 prepared_, request.cpp:192의 notifiers_와 300ms 타이머, queuedRequests_ 크기와 한도를 확인합니다.",
      "next_branch": "호출이 실행되지 않았으면 대상 스레드와 메시지 처리를 확인합니다. 실행됐다면 fence 신호 또는 timeout, 큐 한도와 선두 상태를 거쳐 UVC 제출과 완료 분기를 확인합니다.",
      "change_validation": "미신호 fence의 취소와 prepared 발행, 재귀 전달 전 pop, 한도에 걸린 요청의 재시도와 제출 순서 반환을 검사합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/camera.cpp", "src/libcamera/pipeline_handler.cpp", "src/libcamera/request.cpp", "src/libcamera/base/object.cpp", "src/libcamera/base/thread.cpp", "src/libcamera/base/event_dispatcher_poll.cpp"],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "「UVC의 장치 제출과 완료를 추적하기」와 「실패 주입별 다음 관찰 분기」",
      "diagnosis_values": "uvcvideo.cpp:448의 findBuffer와 processControls 및 queueBuffer 반환값, v4l2_device.cpp:309의 error_idx, v4l2_videodevice.cpp:1648의 QBUF 결과와 버퍼 인덱스, pipeline_handler.cpp:483의 sequence_를 확인합니다.",
      "next_branch": "버퍼가 없으면 -ENOENT, 제어 또는 버퍼 제출이 실패하면 반환값이 공통 doQueueRequest로 전달되어 cancelRequest가 호출됩니다. cache_ 부재의 Fatal은 별도 경계입니다.",
      "change_validation": "각 실패에 대해 요청 순번과 취소 완료를 검사하고, 제어 설정 뒤 QBUF 실패 시 이미 적용됐을 수 있는 제어를 별도로 확인합니다.",
      "answerable": false,
      "source_windows": ["src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/v4l2_device.cpp", "src/libcamera/v4l2_videodevice.cpp", "src/libcamera/pipeline_handler.cpp"],
      "missing": ["실패 주입 그림이 제출 실패에서 cancelRequest로 가는 필수 경로를 확인할 수 없다고 잘못 명시합니다."]
    },
    {
      "id": "Q3",
      "answer_location": "「UVC의 장치 제출과 완료를 추적하기」와 「버퍼 알림과 요청 반환의 내부 경계」",
      "diagnosis_values": "v4l2_videodevice.cpp:1814의 DQBUF 결과, 인덱스와 FrameMetadata 상태, request.cpp:103의 pending_ 및 cancelled_, pipeline_handler.cpp:571의 큐 선두 status를 확인합니다.",
      "next_branch": "DQBUF 실패 또는 미등록 인덱스면 해당 bufferReady 없이 돌아갑니다. 버퍼가 반환되면 UVC의 completeBuffer와 completeRequest, 선두 검사 및 requestCompleted를 확인합니다.",
      "change_validation": "FrameError와 RequestComplete가 함께 가능한 사례, 버퍼당 한 번의 완료, pending 없는 요청 완료와 선두 지연을 검증합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/v4l2_videodevice.cpp", "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/pipeline_handler.cpp", "src/libcamera/request.cpp", "src/libcamera/framebuffer.cpp", "src/libcamera/camera.cpp"],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "「요청·버퍼·fence의 수명」과 「버퍼 알림과 요청 반환의 내부 경계」",
      "diagnosis_values": "camera.cpp:1243의 요청 소유권, request.cpp:442의 버퍼와 fence 계약, request.cpp:103과 139의 pending_ 및 연결 처리, object.cpp:258의 포인터 인자를 확인합니다.",
      "next_branch": "직접 버퍼 콜백에서는 이전 pending 제거 전임을 확인합니다. 미신호 fence가 남으면 releaseFence를 호출하고, 지연 수신자의 마지막 사용과 요청 완료를 구분합니다.",
      "change_validation": "정상 완료와 일괄 취소에서 연결 값과 유효 구간을 구분하고, 재사용 전 fence 회수와 모든 지연 수신자의 마지막 사용을 확인합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/camera.cpp", "src/libcamera/request.cpp", "src/libcamera/framebuffer.cpp", "src/libcamera/pipeline_handler.cpp", "src/libcamera/base/object.cpp", "src/libcamera/base/signal.cpp"],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "「정지와 연결 해제를 구분하기」와 「UVC 정지의 정상 경로와 실패 경계」",
      "diagnosis_values": "pipeline_handler.cpp:359의 swap과 두 ASSERT, camera.cpp:1431의 CameraStopping과 Blocking 호출, v4l2_videodevice.cpp:2023의 STREAMOFF 결과, state_, 큐 및 notifier를 확인합니다.",
      "next_branch": "정상 경로는 장치 버퍼 반환 뒤 분리된 대기 요청을 취소합니다. STREAMOFF 오류는 반환 루프 전에 끝나지만 UVC는 releaseBuffers를 호출하고 두 반환값을 무시합니다.",
      "change_validation": "STREAMOFF와 releaseBuffers 실패를 따로 주입하고 cache_, 잔여 큐, notifier, ASSERT 도달과 조건부 후속 DQBUF의 cache 접근을 확인합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/camera.cpp", "src/libcamera/pipeline_handler.cpp", "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/v4l2_videodevice.cpp"],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "「콜백의 스레드와 재진입을 구분하기」",
      "diagnosis_values": "bound_method.cpp:68의 현재·수신 스레드와 연결 유형, thread.cpp:558과 630의 게시·전달, camera.cpp:769와 1431의 동기화 및 stop 경계를 확인합니다.",
      "next_branch": "Auto는 같은 스레드에서 Direct, 다른 스레드에서 Queued를 선택합니다. Direct는 발신 스레드에서 실행되고 Blocking은 해당 호출을 기다리며 별도 Queued 수신을 배출하지 않습니다.",
      "change_validation": "직접 중첩 호출의 허용 여부와 각 지연 수신자의 마지막 포인터 사용을 확인하고, stop 반환만으로 수신 종료를 추정하지 않습니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/base/bound_method.cpp", "src/libcamera/base/thread.cpp", "src/libcamera/base/message.cpp", "src/libcamera/base/object.cpp", "src/libcamera/base/signal.cpp", "include/libcamera/base/signal.h", "include/libcamera/base/bound_method.h", "Documentation/thread-safety.dox", "src/libcamera/camera.cpp", "src/libcamera/pipeline_handler.cpp"],
      "missing": []
    },
    {
      "id": "Q7",
      "answer_location": "「변경 검토와 실행 확인」",
      "diagnosis_values": "pipeline_handler.cpp:483과 516의 순번 및 pop 순서, request.cpp:103과 139의 pending 처리, v4l2_videodevice.cpp:1648·1814·2023의 오류 분기를 확인합니다.",
      "next_branch": "준비 취소, 제어·QBUF 실패, DQBUF 오류, FrameError와 정지 실패를 각각 정상 완료 및 일괄 취소 경로와 대조합니다.",
      "change_validation": "버퍼별 완료 횟수, 완료 전 pending 부재, completeRequest 반환 후 접근 금지, 정지 중 재투입 방지와 지연 수신자 수명을 검사합니다.",
      "answerable": false,
      "source_windows": ["src/libcamera/pipeline_handler.cpp", "src/libcamera/request.cpp", "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/v4l2_device.cpp", "src/libcamera/v4l2_videodevice.cpp", "src/libcamera/camera.cpp", "src/libcamera/base/bound_method.cpp"],
      "missing": ["실패 주입 그림이 제출 실패 후 공통 취소 경로를 부정하여 검증 분기와 본문이 충돌합니다."]
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q2, Q7",
      "claim": "「실패 주입별 다음 관찰 분기」 그림은 제출 실패가 cancelRequest로 이어지는 호출 경로를 제공된 소스에서 확인할 수 없다고 명시합니다.",
      "counterevidence": "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:448은 findBuffer, processControls 또는 queueBuffer 실패를 반환합니다. src/libcamera/pipeline_handler.cpp:483은 queueRequestDevice의 반환값이 0이 아니면 cancelRequest(request)를 호출합니다.",
      "fix": "그림에 findBuffer 및 제어·버퍼 제출 실패에서 doQueueRequest의 반환값 검사와 cancelRequest로 이어지는 경로를 표시하고, Fatal 경계는 별도로 유지합니다."
    },
    {
      "blocking": true,
      "question": "Q6",
      "claim": "「직접 중첩 호출과 별도 Queued 수신의 경계」 그림에서 슬롯 활성화 노드와 Direct·Queued 분기 노드가 연결되지 않습니다.",
      "counterevidence": "include/libcamera/base/signal.h:138의 emit은 슬롯별 activate를 호출하고, src/libcamera/base/bound_method.cpp:68은 Object 슬롯의 연결 유형에 따라 직접 호출 또는 메시지 게시를 선택합니다.",
      "fix": "슬롯 활성화에서 연결 유형 분기로 이어지는 간선을 추가하고, Queued 수신과 emit 반환의 순서는 고정하지 않습니다."
    }
  ],
  "items": [
    {"anchor": "item-01", "visual_status": "diagram", "question": "제출부터 완료까지 어떻게 연결됩니까?", "reason": "제출·준비·장치·명시적 완료 흐름을 표시합니다."},
    {"anchor": "item-02", "visual_status": "diagram", "question": "요청 처리 단계는 어떻게 이어집니까?", "reason": "정상 경로의 준비, 장치 제출과 완료를 표시합니다."},
    {"anchor": "item-03", "visual_status": "diagram", "question": "접수 반환과 완료 알림은 어떻게 다릅니까?", "reason": "Queued 호출의 반환과 별도 완료 통지를 구분합니다."},
    {"anchor": "item-04", "visual_status": "diagram", "question": "선두 요청은 언제 전달됩니까?", "reason": "대기 큐, 한도, 준비 상태 및 pop 순서를 표시합니다."},
    {"anchor": "item-05", "visual_status": "diagram", "question": "두 취소 경로는 어떻게 다릅니까?", "reason": "기취소 요청과 장치 제출 실패의 분기를 표시합니다."},
    {"anchor": "item-06", "visual_status": "diagram", "question": "마지막 버퍼 완료 뒤 무엇이 필요합니까?", "reason": "completeBuffer의 반환과 명시적 요청 완료를 구분합니다."},
    {"anchor": "item-07", "visual_status": "diagram", "question": "완료 요청은 어떤 순서로 반환됩니까?", "reason": "선두 Pending 검사와 pop 및 통지를 표시합니다."},
    {"anchor": "item-08", "visual_status": "diagram", "question": "준비 대기와 재진입을 어떻게 조사합니까?", "reason": "fence 또는 timeout부터 준비 신호와 재귀 전달 전 pop까지 표시합니다."},
    {"anchor": "item-09", "visual_status": "diagram", "question": "준비 완료와 재진입은 어떻게 연결됩니까?", "reason": "notifier, timeout, prepared 및 전달 조건을 표시합니다."},
    {"anchor": "item-10", "visual_status": "diagram", "question": "UVC 제출 실패와 완료는 어디서 갈라집니까?", "reason": "제어, QBUF, 취소와 별도 장치 완료 경로를 표시합니다."},
    {"anchor": "item-11", "visual_status": "diagram", "question": "UVC 장치 제출과 완료의 경계는 무엇입니까?", "reason": "제출 결과와 DQBUF 이후 완료를 구분합니다."},
    {"anchor": "item-12", "visual_status": "diagram", "question": "요청, 버퍼와 fence는 누가 유지합니까?", "reason": "소유권과 버퍼 유효 기간을 표시하고 fence 회수 그림을 별도로 제공합니다."},
    {"anchor": "item-13", "visual_status": "diagram", "question": "요청과 버퍼는 언제까지 유지합니까?", "reason": "호출자 책임, 완료 콜백과 핸들러 접근 경계를 표시합니다."},
    {"anchor": "item-14", "visual_status": "diagram", "question": "timeout 뒤 fence는 어떻게 회수합니까?", "reason": "남은 fence와 재사용 전 releaseFence 조건을 표시합니다."},
    {"anchor": "item-15", "visual_status": "diagram", "question": "ReuseBuffers와 fence 권고는 어떻게 다릅니까?", "reason": "버퍼 재사용과 fence 비재사용 및 should-not 권고를 구분합니다."},
    {"anchor": "item-16", "visual_status": "diagram", "question": "버퍼 신호와 내부 갱신의 순서는 무엇입니까?", "reason": "emit 반환 후 pending 제거와 요청 완료 및 통지를 표시합니다."},
    {"anchor": "item-17", "visual_status": "diagram", "question": "버퍼 알림 이후 요청은 어떻게 반환됩니까?", "reason": "내부 추적 갱신, 명시적 완료와 선두 검사를 표시합니다."},
    {"anchor": "item-18", "visual_status": "diagram", "question": "콜백 스레드와 재진입은 어떻게 다릅니까?", "reason": "Auto의 Direct·Queued 선택과 별도 수명 경계를 표시합니다."},
    {"anchor": "item-19", "visual_status": "diagram", "question": "Auto는 어떤 전달 방식을 선택합니까?", "reason": "현재 스레드와 수신 스레드 비교를 표시합니다."},
    {"anchor": "item-20", "visual_status": "diagram", "question": "Queued 수신자의 포인터 수명은 누가 확인합니까?", "reason": "발신자의 유효성 책임과 소유자의 마지막 사용 확인을 표시합니다."},
    {"anchor": "item-21", "visual_status": "missing", "question": "Direct 중첩 호출과 Queued 수신은 어떻게 갈라집니까?", "reason": "그림은 존재하지만 슬롯 활성화와 전달 방식 분기가 연결되지 않아 핵심 흐름을 완성하지 못합니다."},
    {"anchor": "item-22", "visual_status": "diagram", "question": "정지와 연결 해제의 요청 처리는 어떻게 다릅니까?", "reason": "정지 순서와 연결 해제 TODO를 질문별 그림으로 구분합니다."},
    {"anchor": "item-23", "visual_status": "diagram", "question": "정지할 때 요청은 어떤 순서로 처리됩니까?", "reason": "대기 큐 분리, 장치 정지, 취소와 ASSERT를 표시합니다."},
    {"anchor": "item-24", "visual_status": "diagram", "question": "정지 계약과 연결 해제 TODO는 무엇입니까?", "reason": "서로 다른 두 소스 계약을 분리해 표시합니다."},
    {"anchor": "item-25", "visual_status": "diagram", "question": "Camera::stop은 어느 경로로 반환합니까?", "reason": "미실행, 접근 오류와 정상 Blocking 경로를 구분합니다."},
    {"anchor": "item-26", "visual_status": "diagram", "question": "stopDevice의 어느 지점을 관찰합니까?", "reason": "호출 직전, 구현 진입과 복귀 미관찰을 구분합니다."},
    {"anchor": "item-27", "visual_status": "diagram", "question": "완료 호출자의 의무는 무엇입니까?", "reason": "호출 스레드, 제출 순서와 반환 후 접근 금지를 표시합니다."},
    {"anchor": "item-28", "visual_status": "diagram", "question": "UVC 정지 실패는 정상 경로와 어떻게 다릅니까?", "reason": "STREAMOFF 오류의 조기 반환과 releaseBuffers 호출을 표시합니다."},
    {"anchor": "item-29", "visual_status": "diagram", "question": "STREAMOFF 실패는 어느 처리를 건너뜁니까?", "reason": "ioctl 오류와 버퍼 반환 루프의 정상 분기를 구분합니다."},
    {"anchor": "item-30", "visual_status": "diagram", "question": "변경 전 어떤 불변조건과 실패를 검사합니까?", "reason": "정상 완료와 bulk 취소의 검증 위치 및 실패별 분기 그림이 있습니다. 제출 실패 그림의 오류는 별도 결함입니다."},
    {"anchor": "item-31", "visual_status": "diagram", "question": "정상 완료와 bulk 취소의 pending 처리는 어디서 다릅니까?", "reason": "개별 erase와 일괄 clear 및 요청 완료 검사를 표시합니다."},
    {"anchor": "item-32", "visual_status": "diagram", "question": "실패별 다음 관찰 분기는 무엇입니까?", "reason": "timeout, 제출, DQBUF와 STREAMOFF 분기 그림이 있으나 제출 실패에서 취소로 이어지는 경로에 잘못된 주장이 있습니다."},
    {"anchor": "item-33", "visual_status": "diagram", "question": "가상 카메라 프로브에서 무엇을 관찰했습니까?", "reason": "연결별 취소 콜백 표식과 반환 근처 표식의 한계를 각각 표시합니다."},
    {"anchor": "item-34", "visual_status": "diagram", "question": "가상 프로브의 취소 콜백 표식은 어디에 있습니까?", "reason": "연결 유형별 스레드와 애플리케이션 stop 표식 관계를 표시합니다."},
    {"anchor": "item-35", "visual_status": "diagram", "question": "반환 근처 표식이 증명하는 범위는 무엇입니까?", "reason": "후속 카운터 및 소멸과 실제 반환 미추적을 구분합니다."},
    {"anchor": "item-36", "visual_status": "omitted-with-reason", "question": "근거 원문은 어디에 있습니까?", "reason": "소스 발췌와 출처를 찾는 참조 목록이므로 별도 처리 흐름 그림이 필요하지 않습니다."}
  ],
  "unreviewed_scope": [
    "실제 비작성자 독자 평가와 사람 검토는 수행되지 않았습니다.",
    "물리 UVC 캡처, DMA 정확성, 성능 및 내부 Camera HAL 검증은 범위 밖입니다.",
    "다른 파이프라인, IPA 처리, 커널 UVC 드라이버와 전체 문서 세트는 검토 대상이 아닙니다."
  ]
}
