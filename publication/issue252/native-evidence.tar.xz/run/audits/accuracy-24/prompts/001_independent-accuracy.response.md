{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "「준비 대기와 재진입을 좁히기」와 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "camera.cpp:1308의 queued 호출, pipeline_handler.cpp:435의 waitingRequests_ 선두와 queuedRequests_ 크기, request.cpp:192의 prepared_, notifiers_, 300ms 타이머와 cancelled_를 확인합니다.",
      "next_branch": "호출이 소비되지 않았으면 수신 스레드의 메시지 처리를 확인합니다. 소비됐다면 준비·한도 분기, UVC 제출, DQBUF와 완료 큐 선두를 차례로 확인합니다.",
      "change_validation": "미신호 fence 타임아웃과 재귀 전달에서 pop 순서, 요청별 처리 횟수, 선두 상태와 완료 통지를 대조합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/base/thread.cpp",
        "src/libcamera/v4l2_videodevice.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "「UVC의 장치 제출과 완료를 추적하기」와 「실패 주입별 다음 관찰 분기」",
      "diagnosis_values": "uvcvideo.cpp:327, 427, 448에서 findBuffer, 개별 변환 결과, setControls와 queueBuffer의 ret를 확인합니다. v4l2_device.cpp:309의 error_idx와 v4l2_videodevice.cpp:1648의 cache 및 QBUF 결과를 구분합니다.",
      "next_branch": "findBuffer 실패 또는 전파된 음수는 doQueueRequest의 cancelRequest로 이어집니다. cache 부재 Fatal은 정상 음수 반환과 구분합니다.",
      "change_validation": "제어 처리 뒤 QBUF 실패를 주입해 원래 ret, cache put, 신규 등록 부재와 취소를 대조하고 제어 적용이나 롤백을 가정하지 않습니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_device.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "include/libcamera/base/utils.h"
      ],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "「버퍼 알림과 요청 반환의 내부 경계」와 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "pipeline_handler.cpp:547의 emit과 내부 완료 순서, request.cpp:103의 pending_ 및 cancelled_, v4l2_videodevice.cpp:1814의 DQBUF 결과와 FrameError를 확인합니다.",
      "next_branch": "DQBUF 실패나 예상 밖 인덱스는 bufferReady 없이 반환합니다. 유효한 버퍼는 UVC가 completeBuffer 다음 completeRequest를 호출하며 선두 Pending이면 반환이 지연됩니다.",
      "change_validation": "FrameError와 RequestComplete를 별도로 기록하고 버퍼당 한 번의 완료, pending 부재 및 제출 순서 통지를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/framebuffer.cpp",
        "src/libcamera/camera.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "「요청·버퍼·fence의 수명」과 「버퍼 알림과 요청 반환의 내부 경계」",
      "diagnosis_values": "camera.cpp:1243의 요청 소유권, request.cpp:442의 버퍼와 fence 계약, request.cpp:103의 pending 제거 및 framebuffer.cpp:368의 request 포인터 유효 구간을 확인합니다.",
      "next_branch": "타임아웃으로 남은 fence는 다른 요청에 재사용하기 전에 releaseFence로 회수합니다. 별도 Queued 수신자가 있으면 마지막 사용까지의 수명을 별도로 조정합니다.",
      "change_validation": "직접 bufferCompleted 콜백 중 재연결과 bulk 취소를 구분하고, 요청 완료 콜백까지 버퍼 유효성 및 지연 수신자의 마지막 사용을 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/framebuffer.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/base/object.cpp",
        "src/libcamera/base/signal.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "「정지와 연결 해제를 구분하기」와 「UVC 정지의 정상 경로와 실패 경계」",
      "diagnosis_values": "pipeline_handler.cpp:359의 waitingRequests_ swap과 두 ASSERT, camera.cpp:1431의 CameraStopping과 Blocking 호출, v4l2_videodevice.cpp:2023의 STREAMOFF ret 및 cache_, queuedBuffers_를 확인합니다.",
      "next_branch": "STREAMOFF 음수는 버퍼 반환 루프 전에 반환합니다. UVC는 그 값을 무시하고 releaseBuffers를 호출하므로 잔존 notifier와 reset된 cache의 후속 DQBUF 분기를 확인합니다.",
      "change_validation": "STREAMOFF와 releaseBuffers 실패를 각각 주입해 큐, notifier, ASSERT 도달 여부 및 요청·버퍼 완료 횟수를 기록합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "「콜백의 스레드와 재진입을 구분하기」와 「stop 반환과 별도 수신의 마지막 사용 확인」",
      "diagnosis_values": "bound_method.cpp:68의 Auto, Direct, Queued, Blocking 분기와 thread.cpp:613의 type·receiver 필터, 수신 스레드 및 객체 수명을 확인합니다.",
      "next_branch": "Direct는 송신 스레드에서 동기 호출합니다. Queued는 실제 메시지 소비를 확인하고, Blocking stop의 반환과 별도 수신자의 마지막 사용을 구분합니다.",
      "change_validation": "콜백 진입·복귀, 재귀 깊이와 필터, 포인터 마지막 사용 및 호출자의 상태 변경 동기화를 기록합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/base/bound_method.cpp",
        "src/libcamera/base/thread.cpp",
        "src/libcamera/base/object.cpp",
        "src/libcamera/base/signal.cpp",
        "Documentation/thread-safety.dox",
        "src/libcamera/camera.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q7",
      "answer_location": "「변경 검토와 실행 확인」",
      "diagnosis_values": "pipeline_handler.cpp:435의 pop 전후, request.cpp:103의 erase 결과와 pending, pipeline_handler.cpp:547의 완료 및 반환 경계, v4l2_videodevice.cpp:1648, 1814, 2023의 오류 분기를 확인합니다.",
      "next_branch": "준비 취소, 제어·QBUF 실패, DQBUF 오류·예상 밖 인덱스, FrameError 및 STREAMOFF 실패를 각각 별도 사례로 추적합니다.",
      "change_validation": "버퍼당 완료 횟수, 완료 전 pending 부재, completeRequest 반환 후 접근 금지, 정지 중 재투입 부재와 제출 순서를 대조합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/base/bound_method.cpp",
        "Documentation/thread-safety.dox"
      ],
      "missing": []
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q4",
      "claim": "「같은 Poll 회차의 fence와 타이머 처리」 그림은 timeout이 「남은 fence를 지우고」 요청을 취소한다고 설명합니다.",
      "counterevidence": "src/libcamera/request.cpp:192의 timeout()은 notifiers_.clear()를 호출하지만 버퍼에 남은 fence를 해제하지 않습니다. src/libcamera/request.cpp:442는 신호되지 않은 fence가 타임아웃 뒤 버퍼에 남으며 다른 요청에 재사용하기 전에 releaseFence()로 회수해야 한다고 명시합니다.",
      "fix": "그림의 해당 전이를 「남은 notifier를 지우고 요청을 취소한다」로 고치고, 미신호 fence는 버퍼에 남는다는 조건을 유지합니다."
    }
  ],
  "items": [
    {
      "anchor": "item-01",
      "visual_status": "diagram",
      "question": "제출에서 완료까지",
      "reason": "제출·준비·장치·완료 연결 그림이 이 절의 핵심 경로를 나타냅니다."
    },
    {
      "anchor": "item-02",
      "visual_status": "diagram",
      "question": "제출·준비·장치 처리·완료의 연결",
      "reason": "정상 경로와 명시적 요청 완료를 흐름도로 나타냅니다."
    },
    {
      "anchor": "item-03",
      "visual_status": "diagram",
      "question": "접수 반환과 완료 알림",
      "reason": "queued 호출의 반환과 완료 통지 계약을 구분합니다."
    },
    {
      "anchor": "item-04",
      "visual_status": "diagram",
      "question": "선두 요청을 전달하거나 반복을 멈추는 조건",
      "reason": "대기 큐, 한도와 준비 상태의 분기를 나타냅니다."
    },
    {
      "anchor": "item-05",
      "visual_status": "diagram",
      "question": "void 전달 함수의 두 취소 경로",
      "reason": "기존 취소와 장치 제출 실패의 처리 함수를 구분합니다."
    },
    {
      "anchor": "item-06",
      "visual_status": "diagram",
      "question": "버퍼 완료와 명시적 요청 완료의 경계",
      "reason": "completeBuffer의 결과와 명시적 완료 의무를 구분합니다."
    },
    {
      "anchor": "item-07",
      "visual_status": "diagram",
      "question": "제출 큐의 선두 상태와 반환 순서",
      "reason": "선두 Pending 검사와 pop 후 통지의 순서를 나타냅니다."
    },
    {
      "anchor": "item-08",
      "visual_status": "diagram",
      "question": "준비 대기와 재진입을 좁히기",
      "reason": "준비 완료에서 선두 검사와 재귀 전달까지의 그림이 있습니다."
    },
    {
      "anchor": "item-09",
      "visual_status": "diagram",
      "question": "준비 대기와 재진입을 좁히기 그림",
      "reason": "fence·타임아웃과 prepared 신호 및 pop 순서를 연결합니다."
    },
    {
      "anchor": "item-10",
      "visual_status": "diagram",
      "question": "동시 제출의 순서를 관찰할 경계",
      "reason": "호출 시작, 게시, 등록과 통지의 계측 경계를 구분합니다."
    },
    {
      "anchor": "item-11",
      "visual_status": "diagram",
      "question": "같은 Poll 회차의 fence와 타이머 처리",
      "reason": "notifier와 타이머 분기를 나타내지만 timeout 전이에서 fence와 notifier를 혼동하므로 수정이 필요합니다."
    },
    {
      "anchor": "item-12",
      "visual_status": "diagram",
      "question": "UVC의 장치 제출과 완료를 추적하기",
      "reason": "제어 처리, QBUF 실패와 별도 완료 이벤트를 연결하는 그림이 있습니다."
    },
    {
      "anchor": "item-13",
      "visual_status": "diagram",
      "question": "UVC의 장치 제출과 완료를 추적하기 그림",
      "reason": "제출·취소·장치 완료의 분기를 나타냅니다."
    },
    {
      "anchor": "item-14",
      "visual_status": "diagram",
      "question": "QBUF 호출 전 실패와 cache 반환",
      "reason": "cache 획득과 plane 검증 실패, guard 반환을 구분합니다."
    },
    {
      "anchor": "item-15",
      "visual_status": "diagram",
      "question": "요청·버퍼·fence의 수명",
      "reason": "소유권과 완료 경계 그림 및 fence 회수 그림이 절의 수명 질문을 다룹니다."
    },
    {
      "anchor": "item-16",
      "visual_status": "omitted-with-reason",
      "question": "제출 성공 뒤에도 남는 수명 문제",
      "reason": "queued 호출과 별도 완료 신호를 짧게 구분하는 두 문장입니다."
    },
    {
      "anchor": "item-17",
      "visual_status": "diagram",
      "question": "소유권과 두 완료 경계",
      "reason": "요청 소유자, 버퍼 유효성, 완료 핸들러와 지연 수신자의 책임을 나타냅니다."
    },
    {
      "anchor": "item-18",
      "visual_status": "diagram",
      "question": "정상 완료와 다음 요청 준비",
      "reason": "버퍼 통지, 내부 추적 갱신과 요청 반환 순서를 나타냅니다."
    },
    {
      "anchor": "item-19",
      "visual_status": "diagram",
      "question": "알림 순서와 취소가 달라질 때",
      "reason": "완료 상태와 선두 검사, fence 회수 및 재사용 권고를 각각 나타냅니다."
    },
    {
      "anchor": "item-20",
      "visual_status": "diagram",
      "question": "완료 책임을 변경하기 전에",
      "reason": "변경 시 호출 스레드, 순서와 수명 계약을 함께 확인하는 그림이 있습니다."
    },
    {
      "anchor": "item-21",
      "visual_status": "diagram",
      "question": "버퍼 알림과 요청 반환의 내부 경계",
      "reason": "신호 발생부터 pending 제거와 요청 통지까지의 순서 그림이 있습니다."
    },
    {
      "anchor": "item-22",
      "visual_status": "diagram",
      "question": "버퍼 알림과 요청 반환의 내부 경계 그림",
      "reason": "emit 반환 뒤 내부 갱신과 선두 요청 통지를 나타냅니다."
    },
    {
      "anchor": "item-23",
      "visual_status": "diagram",
      "question": "콜백의 스레드와 재진입을 구분하기",
      "reason": "연결 종류별 호출과 직접·지연 수신 경계 그림이 있습니다."
    },
    {
      "anchor": "item-24",
      "visual_status": "diagram",
      "question": "콜백의 스레드와 재진입을 구분하기 그림",
      "reason": "Auto가 스레드 비교에 따라 Direct 또는 Queued를 선택하는 분기를 나타냅니다."
    },
    {
      "anchor": "item-25",
      "visual_status": "diagram",
      "question": "Queued 수신과 해제 시점의 책임",
      "reason": "신호 발신자의 유효성 책임과 별도 수신자의 마지막 사용을 구분합니다."
    },
    {
      "anchor": "item-26",
      "visual_status": "diagram",
      "question": "직접 중첩 호출과 별도 Queued 수신의 경계",
      "reason": "Direct 호출, Queued 게시, dispatch와 내부 갱신을 구분합니다."
    },
    {
      "anchor": "item-27",
      "visual_status": "diagram",
      "question": "stop 반환과 별도 수신의 마지막 사용 확인",
      "reason": "Blocking stop 경로와 별도 Queued 수신자의 수명을 구분합니다."
    },
    {
      "anchor": "item-28",
      "visual_status": "diagram",
      "question": "정지와 연결 해제를 구분하기",
      "reason": "정지 순서와 연결 해제 TODO를 각각 나타냅니다."
    },
    {
      "anchor": "item-29",
      "visual_status": "diagram",
      "question": "정지할 때 대기 요청을 처리하는 순서",
      "reason": "대기 큐 분리, 장치 정지, 취소와 ASSERT의 순서를 나타냅니다."
    },
    {
      "anchor": "item-30",
      "visual_status": "diagram",
      "question": "정지 API 계약과 연결 해제 TODO",
      "reason": "정지 계약과 연결 해제 시 미완료 요청 TODO를 구분합니다."
    },
    {
      "anchor": "item-31",
      "visual_status": "diagram",
      "question": "Camera::stop의 미실행·오류·정상 경로",
      "reason": "실행 상태와 접근 검사에 따른 반환 분기를 나타냅니다."
    },
    {
      "anchor": "item-32",
      "visual_status": "diagram",
      "question": "stopDevice 호출 구간의 관찰 계획",
      "reason": "호출 전, 구현 진입과 복귀 관찰을 구분합니다."
    },
    {
      "anchor": "item-33",
      "visual_status": "diagram",
      "question": "완료 통지의 호출자 의무와 반환 뒤 경계",
      "reason": "호출 스레드, 제출 순서와 반환 후 접근 금지를 연결합니다."
    },
    {
      "anchor": "item-34",
      "visual_status": "diagram",
      "question": "UVC 정지의 정상 경로와 실패 경계",
      "reason": "streamOff 반환 분기와 releaseBuffers 호출을 나타냅니다."
    },
    {
      "anchor": "item-35",
      "visual_status": "diagram",
      "question": "UVC 정지의 정상 경로와 실패 경계 그림",
      "reason": "즉시 반환, ioctl 실패 및 정상 정리의 합류 조건을 나타냅니다."
    },
    {
      "anchor": "item-36",
      "visual_status": "diagram",
      "question": "변경 검토와 실행 확인",
      "reason": "정상 완료·bulk 취소와 실패 주입별 검증 위치를 나타냅니다."
    },
    {
      "anchor": "item-37",
      "visual_status": "diagram",
      "question": "정상 완료와 bulk 취소의 검증 위치",
      "reason": "두 경로의 pending 처리와 완료 검사를 구분합니다."
    },
    {
      "anchor": "item-38",
      "visual_status": "diagram",
      "question": "실패 주입별 다음 관찰 분기",
      "reason": "준비, 제출, DQBUF 및 STREAMOFF 실패의 관찰 분기를 나타냅니다."
    },
    {
      "anchor": "item-39",
      "visual_status": "diagram",
      "question": "공개 가상 카메라의 콜백 관찰",
      "reason": "가상 프로브의 연결별 표식과 반환 근처 표식의 한계를 나타냅니다."
    },
    {
      "anchor": "item-40",
      "visual_status": "diagram",
      "question": "가상 CPU 프로브의 연결별 취소 콜백 표시",
      "reason": "세 실행에서 관찰된 연결별 스레드와 stop 표식 관계를 나타냅니다."
    },
    {
      "anchor": "item-41",
      "visual_status": "diagram",
      "question": "반환 근처 표시로 알 수 있는 범위",
      "reason": "표식 뒤의 작업과 실제 C++ 반환 미추적을 구분합니다."
    },
    {
      "anchor": "item-42",
      "visual_status": "omitted-with-reason",
      "question": "소스 근거",
      "reason": "인용 원문과 출처를 제공하는 자료 목록이므로 별도 처리 그림이 필요하지 않습니다."
    }
  ],
  "unreviewed_scope": [
    "다른 파이프라인, IPA 처리와 커널 UVC 드라이버 구현은 범위 밖입니다.",
    "물리 카메라 촬영, DMA 정확성, 성능 및 내부 Camera HAL은 검증하지 않았습니다.",
    "비작성자 독자의 실제 평가와 전체 문서 집합의 시각 검토는 수행하지 않았습니다."
  ]
}
