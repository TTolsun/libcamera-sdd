{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "「준비 대기와 재진입을 좁히기」와 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "camera.cpp:1308의 게시와 반환, pipeline_handler.cpp:435의 waitingRequests_, prepared_, queuedRequests_ 크기와 한도, request.cpp:192의 fence·notifier·300ms timer, pipeline_handler.cpp:571의 선두 상태를 확인합니다.",
      "next_branch": "메서드 진입 전이면 메시지 소비를 확인합니다. 진입 후에는 미준비 선두와 한도를 확인하고, 전달됐으면 UVC 제출 및 DQBUF 분기로 이동합니다.",
      "change_validation": "재귀 전달 전에 선두를 pop하는 순서와 요청별 단일 투입을 확인하고, 준비 취소와 선두 Pending에 따른 반환 지연을 각각 대조합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/base/thread.cpp",
        "src/libcamera/base/event_dispatcher_poll.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "「UVC의 장치 제출과 완료를 추적하기」와 「실패 주입별 다음 관찰 분기」",
      "diagnosis_values": "uvcvideo.cpp:427과 448에서 findBuffer 결과, 개별 변환 결과, setControls 및 queueBuffer의 ret를 확인합니다. v4l2_device.cpp:309의 error_idx와 v4l2_videodevice.cpp:1648의 cache 및 QBUF 결과를 구분합니다.",
      "next_branch": "버퍼 부재 또는 음수 반환이면 pipeline_handler.cpp:483의 cancelRequest로 이동합니다. QBUF 성공이면 등록과 별도 DQBUF 알림을 확인합니다.",
      "change_validation": "제어 처리 뒤 QBUF 실패를 주입하고 원래 ret, cache put, 신규 등록 부재, 취소 및 sequence를 대조합니다. 제어 적용이나 롤백은 가정하지 않습니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_device.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "include/libcamera/base/utils.h"
      ],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "「버퍼 알림과 요청 반환의 내부 경계」와 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "pipeline_handler.cpp:547과 request.cpp:103에서 emit, pending_.erase, cancelled_ 및 status를 확인합니다. v4l2_videodevice.cpp:1814의 DQBUF 결과와 FrameError, queuedRequests_ 선두 및 requestCompleted를 별도로 확인합니다.",
      "next_branch": "DQBUF 오류 또는 미등록 index면 해당 bufferReady 없이 반환합니다. 유효한 버퍼면 UVC의 completeBuffer 다음 completeRequest와 선두 반환을 확인합니다.",
      "change_validation": "FrameError와 RequestComplete가 공존하는 사례, 한 버퍼의 단일 완료, 빈 pending 및 선두 Pending에 따른 지연을 각각 검증합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/framebuffer.cpp",
        "src/libcamera/camera.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "「요청·버퍼·fence의 수명」과 「Queued 수신과 해제 시점의 책임」",
      "diagnosis_values": "camera.cpp:1243의 요청 소유권, request.cpp:442의 버퍼 유효성과 fence 소유권, framebuffer.cpp:368의 request 포인터 유효 구간, object.cpp:258의 포인터 인수 수명을 확인합니다.",
      "next_branch": "미신호 fence가 남았다면 다른 요청에 추가하기 전에 releaseFence를 확인합니다. Direct 버퍼 콜백이면 pending 제거 전 경계를, Queued 수신이면 마지막 포인터 사용을 확인합니다.",
      "change_validation": "정상 완료와 bulk 취소의 연결 해제 차이, reuse 전 상태 초기화 및 별도 수신자의 마지막 사용과 삭제·재사용 사이의 동기화를 대조합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/framebuffer.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/base/object.cpp",
        "src/libcamera/base/signal.cpp",
        "src/libcamera/base/bound_method.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "「정지와 연결 해제를 구분하기」와 「UVC 정지의 정상 경로와 실패 경계」",
      "diagnosis_values": "pipeline_handler.cpp:359의 waitingRequests_ swap과 두 ASSERT, camera.cpp:1431의 CameraStopping 및 Blocking 호출, uvcvideo.cpp:320과 v4l2_videodevice.cpp:1616, 2023의 반환값·큐·cache·notifier를 확인합니다.",
      "next_branch": "STREAMOFF가 실패하면 버퍼 반환 루프 이전에 돌아가며 UVC는 releaseBuffers를 계속 호출합니다. 잔존 notifier의 후속 DQBUF와 reset된 cache 접근 조건을 따로 확인합니다.",
      "change_validation": "정상 정지와 STREAMOFF 및 releaseBuffers 실패를 분리하여 ret, 큐 잔존, ASSERT 도달, 완료 횟수와 정지 중 재투입을 기록합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/camera.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "「콜백의 스레드와 재진입을 구분하기」와 「stop 반환과 별도 수신의 마지막 사용 확인」",
      "diagnosis_values": "bound_method.cpp:68의 연결 종류와 스레드 비교, thread.cpp:613의 필터와 재귀 깊이, camera.cpp:1431의 Blocking 호출, 각 수신자의 진입·마지막 사용을 확인합니다.",
      "next_branch": "Direct는 발신 스레드에서 동기 실행합니다. Queued는 게시 후 소비 여부를 확인하고, Blocking은 같은 스레드의 Direct 또는 다른 스레드의 semaphore 대기를 구분합니다.",
      "change_validation": "호출자의 상태 변경 동기화와 각 지연 수신자의 마지막 사용을 확인합니다. dispatchMessages의 게시 순서에 관한 Doxygen 문구와 필터·재귀 구현의 차이를 먼저 바로잡아야 합니다.",
      "answerable": false,
      "source_windows": [
        "src/libcamera/base/bound_method.cpp",
        "src/libcamera/base/signal.cpp",
        "include/libcamera/base/signal.h",
        "src/libcamera/base/object.cpp",
        "src/libcamera/base/thread.cpp",
        "src/libcamera/base/message.cpp",
        "src/libcamera/camera.cpp",
        "Documentation/thread-safety.dox"
      ],
      "missing": [
        "필터가 서로 다른 재귀 dispatch에서 실제 전달 순서가 게시 순서와 달라질 수 있다는 구현 반례가 필요합니다."
      ]
    },
    {
      "id": "Q7",
      "answer_location": "「변경 검토와 실행 확인」",
      "diagnosis_values": "pipeline_handler.cpp:483과 516의 등록·pop 순서, request.cpp:103과 139의 erase 또는 bulk clear, pipeline_handler.cpp:571의 pending ASSERT와 접근 경계, streamOff 실패 시 잔존 큐를 확인합니다.",
      "next_branch": "준비 timeout, 제어·QBUF 실패, DQBUF 오류·예상 밖 index, FrameError 및 STREAMOFF 실패를 각각 다른 예상 분기로 추적합니다.",
      "change_validation": "요청별 단일 투입과 버퍼별 단일 완료, 요청 완료 전 빈 pending, 완료 함수 반환 후 접근 금지, 정지 중 재투입 부재 및 지연 수신자의 마지막 사용을 검증합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/base/bound_method.cpp",
        "Documentation/thread-safety.dox"
      ],
      "missing": []
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q6",
      "claim": "「콜백의 스레드와 재진입을 구분하기」는 Thread::dispatchMessages가 모든 경우에 메시지를 게시 순서대로 전달한다고 보장한다고 서술합니다.",
      "counterevidence": "src/libcamera/base/thread.cpp:613의 Doxygen에는 해당 보장 문구가 있지만, :630의 구현은 type과 receiver가 일치하지 않는 앞선 메시지를 건너뛰고 잠금을 해제한 채 핸들러를 호출합니다. 그 핸들러가 다른 필터로 재귀 호출하면 앞서 건너뛴 메시지보다 뒤에 게시된 메시지를 먼저 전달할 수 있습니다.",
      "fix": "게시 순서 보장을 Doxygen 계약으로 명시하고, 서로 다른 필터를 사용하는 재귀 호출에서는 구현상 전달 순서가 달라질 수 있는 반례와 검증 조건을 별도로 설명합니다."
    }
  ],
  "items": [
    {"anchor":"item-01","visual_status":"diagram","question":"제출에서 완료까지","reason":"제출, 준비, 장치 처리 및 완료 경로를 연결하는 그림이 있습니다."},
    {"anchor":"item-02","visual_status":"diagram","question":"제출·준비·장치 처리·완료의 연결","reason":"정상 경로의 단계와 명시적 요청 완료를 나타냅니다."},
    {"anchor":"item-03","visual_status":"diagram","question":"접수 반환과 완료 알림","reason":"게시 성공 반환과 완료 알림을 구분합니다."},
    {"anchor":"item-04","visual_status":"diagram","question":"선두 요청을 전달하거나 반복을 멈추는 조건","reason":"큐 한도와 선두 준비 상태의 분기를 나타냅니다."},
    {"anchor":"item-05","visual_status":"diagram","question":"void 전달 함수의 두 취소 경로","reason":"기존 취소와 장치 제출 실패의 처리 함수를 구분합니다."},
    {"anchor":"item-06","visual_status":"diagram","question":"버퍼 완료와 명시적 요청 완료의 경계","reason":"마지막 버퍼 완료와 별도의 요청 완료 호출을 구분합니다."},
    {"anchor":"item-07","visual_status":"diagram","question":"제출 큐의 선두 상태와 반환 순서","reason":"Pending 선두의 중단과 완료된 선두의 반환을 나타냅니다."},
    {"anchor":"item-08","visual_status":"diagram","question":"준비 대기와 재진입을 좁히기","reason":"fence와 타이머에서 준비 신호 및 재진입 전 pop까지 연결합니다."},
    {"anchor":"item-09","visual_status":"diagram","question":"준비 대기와 재진입을 좁히기 그림","reason":"준비 신호, 큐 한도 및 선두 전달 조건을 나타냅니다."},
    {"anchor":"item-10","visual_status":"diagram","question":"동시 제출의 순서를 관찰할 경계","reason":"호출 시작, 메시지 게시, 등록 및 통지를 구분합니다."},
    {"anchor":"item-11","visual_status":"diagram","question":"같은 Poll 회차의 fence와 타이머 처리","reason":"notifier 처리와 만료 타이머의 조건부 분기를 나타냅니다."},
    {"anchor":"item-12","visual_status":"diagram","question":"UVC의 장치 제출과 완료를 추적하기","reason":"UVC 제출 실패와 별도 버퍼 완료 경로를 나타냅니다."},
    {"anchor":"item-13","visual_status":"diagram","question":"UVC의 장치 제출과 완료를 추적하기 그림","reason":"제어 처리, QBUF, 취소 및 완료 경로를 구분합니다."},
    {"anchor":"item-14","visual_status":"diagram","question":"QBUF 호출 전 실패와 cache 반환","reason":"cache 획득 실패와 plane 검증 실패의 반환을 구분합니다."},
    {"anchor":"item-15","visual_status":"diagram","question":"요청·버퍼·fence의 수명","reason":"요청 소유권, 버퍼 유효 기간 및 지연 수신자의 수명을 나타냅니다."},
    {"anchor":"item-16","visual_status":"omitted-with-reason","question":"제출 성공 뒤에도 남는 수명 문제","reason":"짧은 두 문장이 게시 성공과 별도 완료 신호를 구분하므로 별도 그림이 필수는 아닙니다."},
    {"anchor":"item-17","visual_status":"diagram","question":"소유권과 두 완료 경계","reason":"호출자 소유권, 완료 핸들러 및 지연 수신자의 관계를 나타냅니다."},
    {"anchor":"item-18","visual_status":"diagram","question":"정상 완료와 다음 요청 준비","reason":"버퍼 신호 이후 내부 갱신과 명시적 완료를 나타냅니다."},
    {"anchor":"item-19","visual_status":"diagram","question":"알림 순서와 취소가 달라질 때","reason":"상태 선택, 선두 대기 및 fence 회수의 조건을 각각 나타냅니다."},
    {"anchor":"item-20","visual_status":"diagram","question":"완료 책임을 변경하기 전에","reason":"스레드, 반환 순서와 수명 계약의 확인 관계를 나타냅니다."},
    {"anchor":"item-21","visual_status":"diagram","question":"버퍼 알림과 요청 반환의 내부 경계","reason":"신호, pending 제거, 명시적 완료 및 선두 반환 순서를 나타냅니다."},
    {"anchor":"item-22","visual_status":"diagram","question":"버퍼 알림과 요청 반환의 내부 경계 그림","reason":"정상 완료 경로에서 내부 추적과 통지의 순서를 구체화합니다."},
    {"anchor":"item-23","visual_status":"diagram","question":"콜백의 스레드와 재진입을 구분하기","reason":"연결 방식, 전달 및 내부 갱신의 경계를 설명하는 그림이 있습니다."},
    {"anchor":"item-24","visual_status":"diagram","question":"콜백의 스레드와 재진입을 구분하기 그림","reason":"Auto가 Direct 또는 Queued를 선택하는 분기를 나타냅니다."},
    {"anchor":"item-25","visual_status":"diagram","question":"Queued 수신과 해제 시점의 책임","reason":"발신자의 포인터 유효성과 지연 수신자의 마지막 사용을 구분합니다."},
    {"anchor":"item-26","visual_status":"diagram","question":"직접 중첩 호출과 별도 Queued 수신의 경계","reason":"동기 호출, 게시, dispatch 및 내부 갱신을 구분합니다."},
    {"anchor":"item-27","visual_status":"diagram","question":"stop 반환과 별도 수신의 마지막 사용 확인","reason":"Blocking 정지와 별도 Queued 수신자의 수명을 구분합니다."},
    {"anchor":"item-28","visual_status":"diagram","question":"정지와 연결 해제를 구분하기","reason":"정지 순서와 연결 해제 TODO를 각각 나타냅니다."},
    {"anchor":"item-29","visual_status":"diagram","question":"정지할 때 대기 요청을 처리하는 순서","reason":"대기 큐 분리, 장치 정지 및 대기 요청 취소를 나타냅니다."},
    {"anchor":"item-30","visual_status":"diagram","question":"정지 API 계약과 연결 해제 TODO","reason":"정지 계약과 연결 해제 시 미완료 요청 TODO를 구분합니다."},
    {"anchor":"item-31","visual_status":"diagram","question":"Camera::stop의 미실행·오류·정상 경로","reason":"실행 여부와 접근 검사에 따른 반환 경로를 나타냅니다."},
    {"anchor":"item-32","visual_status":"diagram","question":"stopDevice 호출 구간의 관찰 계획","reason":"호출 직전, 구현 진입과 실제 복귀 관찰을 구분합니다."},
    {"anchor":"item-33","visual_status":"diagram","question":"완료 통지의 호출자 의무와 반환 뒤 경계","reason":"호출 스레드, 반환 순서 및 요청 접근 금지를 연결합니다."},
    {"anchor":"item-34","visual_status":"diagram","question":"UVC 정지의 정상 경로와 실패 경계","reason":"STREAMOFF 분기와 UVC의 releaseBuffers 호출을 나타냅니다."},
    {"anchor":"item-35","visual_status":"diagram","question":"UVC 정지의 정상 경로와 실패 경계 그림","reason":"즉시 반환, ioctl 실패 및 성공 정리의 조건부 합류를 나타냅니다."},
    {"anchor":"item-36","visual_status":"diagram","question":"변경 검토와 실행 확인","reason":"정상 완료와 취소의 검증 위치 및 실패별 다음 분기를 나타냅니다."},
    {"anchor":"item-37","visual_status":"diagram","question":"정상 완료와 bulk 취소의 검증 위치","reason":"pending erase와 bulk clear 및 완료 검사를 비교합니다."},
    {"anchor":"item-38","visual_status":"diagram","question":"실패 주입별 다음 관찰 분기","reason":"timeout, 제출, DQBUF 및 STREAMOFF 실패의 관찰 위치를 구분합니다."},
    {"anchor":"item-39","visual_status":"diagram","question":"공개 가상 카메라의 콜백 관찰","reason":"프로브의 연결별 표식과 반환 근처 표식의 한계를 나타냅니다."},
    {"anchor":"item-40","visual_status":"diagram","question":"가상 CPU 프로브의 연결별 취소 콜백 표시","reason":"세 실행에서 관찰한 연결별 스레드와 stop 표식의 관계를 나타냅니다."},
    {"anchor":"item-41","visual_status":"diagram","question":"반환 근처 표시로 알 수 있는 범위","reason":"표식 이후 작업과 실제 C++ 반환 미추적을 구분합니다."},
    {"anchor":"item-42","visual_status":"omitted-with-reason","question":"소스 근거","reason":"이 항목은 원문 발췌와 출처를 열람하는 색인이므로 별도 처리 그림이 필요하지 않습니다."}
  ],
  "unreviewed_scope": [
    "물리 UVC 촬영, DMA 정확성, 성능 및 사내 Camera HAL은 이 정적 감사의 범위 밖입니다.",
    "별도 비저자 독자 평가와 사람 검토는 수행되지 않았습니다."
  ]
}
