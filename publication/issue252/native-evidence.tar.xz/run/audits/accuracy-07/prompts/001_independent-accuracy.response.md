{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "제출에서 완료까지; 준비 대기와 재진입을 좁히기; UVC의 장치 제출과 완료를 추적하기",
      "diagnosis_values": "Queued 메시지 처리 여부, waitingRequests_ 선두, prepared_, notifiers_, timeout, queuedRequests_ 크기와 선두 상태를 확인합니다.",
      "next_branch": "준비 취소와 장치 제출을 구분한 뒤 QBUF, DQBUF 및 requestCompleted 전달을 확인합니다.",
      "change_validation": "재진입 전에 pop하는 순서, 중복 제출 부재와 선두 요청에 따른 반환 순서를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1308-1383",
        "src/libcamera/pipeline_handler.cpp:428-620",
        "src/libcamera/request.cpp:192-312",
        "src/libcamera/base/object.cpp:258-284",
        "src/libcamera/v4l2_videodevice.cpp:1648-1987"
      ],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "UVC의 장치 제출과 완료를 추적하기; 변경 검토와 실행 확인",
      "diagnosis_values": "findBuffer 결과, 개별 processControl 결과, setControls의 ret와 error_idx, queueBuffer와 VIDIOC_QBUF의 ret 및 sequence를 확인합니다.",
      "next_branch": "버퍼 부재 또는 음수 반환은 공통 취소 경로로 추적하고, Fatal 경계는 반환이 보장되는 경로로 취급하지 않습니다.",
      "change_validation": "제어 적용 후 QBUF 실패에서 큐 등록 여부, 취소 완료와 앞선 제어의 상태를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:327-470",
        "src/libcamera/v4l2_device.cpp:309-430",
        "src/libcamera/v4l2_videodevice.cpp:1648-1814",
        "src/libcamera/pipeline_handler.cpp:483-501"
      ],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "제출에서 완료까지; UVC의 장치 제출과 완료를 추적하기; 버퍼 알림과 요청 반환의 내부 경계",
      "diagnosis_values": "버퍼 metadata.status, pending_, 요청 status, queuedRequests_ 선두와 신호 발생을 확인합니다.",
      "next_branch": "DQBUF 실패와 예상 밖 인덱스는 알림 없이 반환합니다. 유효 버퍼는 UVC의 명시적 완료와 선두 순회로 이어집니다.",
      "change_validation": "FrameError와 가능한 RequestComplete를 별도로 기록하고, 각 버퍼의 완료 및 요청 반환 순서를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/v4l2_videodevice.cpp:1814-1987",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:893-905",
        "src/libcamera/request.cpp:103-139",
        "src/libcamera/pipeline_handler.cpp:547-620",
        "src/libcamera/camera.cpp:1475-1491"
      ],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "요청·버퍼·fence의 수명; 버퍼 알림과 요청 반환의 내부 경계",
      "diagnosis_values": "요청 소유자, 버퍼 유효 기간, fence 잔존 여부, pending_과 버퍼의 요청 연결을 확인합니다.",
      "next_branch": "정상 완료의 연결 해제와 bulk 취소의 잔존 연결값을 구분하고 지연 수신자의 포인터 수명을 확인합니다.",
      "change_validation": "요청 완료 콜백에서의 재사용, releaseFence와 지연 콜백 수명을 각각 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1243-1263",
        "src/libcamera/request.cpp:103-173",
        "src/libcamera/request.cpp:326-338",
        "src/libcamera/request.cpp:376-407",
        "src/libcamera/request.cpp:442-505",
        "src/libcamera/framebuffer.cpp:368-383",
        "src/libcamera/base/object.cpp:258-284"
      ],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "정지와 연결 해제를 구분하기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "CameraStopping, 분리된 waitingRequests_, STREAMOFF ret, state_, cache_, notifier, queuedBuffers_, queuedRequests_ 및 ASSERT 도달 여부를 확인합니다.",
      "next_branch": "STREAMOFF 실패 시 버퍼 반환 루프를 건너뛰고 UVC가 releaseBuffers를 호출하는 경로와 후속 DQBUF를 조사합니다.",
      "change_validation": "정상 정지, STREAMOFF 실패와 releaseBuffers 실패를 각각 시험해 완료 횟수, 순서, 잔존 큐와 재투입을 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1431-1491",
        "src/libcamera/pipeline_handler.cpp:359-414",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320-327",
        "src/libcamera/v4l2_videodevice.cpp:1616-1629",
        "src/libcamera/v4l2_videodevice.cpp:1814-1987",
        "src/libcamera/v4l2_videodevice.cpp:2023-2059"
      ],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "콜백의 스레드와 재진입을 구분하기; 공개 가상 카메라의 콜백 관찰",
      "diagnosis_values": "수신자의 Object 여부, 연결 종류, 송신·수신 스레드, 이벤트 루프 및 콜백 진입·복귀를 확인합니다.",
      "next_branch": "Auto의 스레드 비교, Direct의 동기 호출, Queued의 메시지 처리 및 Blocking의 호출 완료 대기를 구분합니다.",
      "change_validation": "상태 변경 호출의 동기화와 별도 Queued 수신자의 처리 완료 및 포인터 수명을 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/base/bound_method.cpp:22-110",
        "include/libcamera/base/bound_method.h:59-209",
        "include/libcamera/base/signal.h:38-153",
        "src/libcamera/base/object.cpp:97-125",
        "src/libcamera/base/object.cpp:258-284",
        "Documentation/thread-safety.dox:1-46"
      ],
      "missing": []
    },
    {
      "id": "Q7",
      "answer_location": "변경 검토와 실행 확인; 준비 대기와 재진입을 좁히기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "cookie, sequence, pending_, 각 완료 횟수, 큐 상태, ASSERT, 반환값과 콜백 표식을 확인합니다.",
      "next_branch": "fence timeout, 제어 및 QBUF 실패, DQBUF 오류, FrameError, 정지 실패와 재진입을 각각 추적합니다.",
      "change_validation": "재귀 전달 전 pop, 버퍼당 한 번의 완료, 요청 완료 전 pending 부재, 완료 반환 후 접근 금지 및 정지 중 재투입 부재를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp:359-620",
        "src/libcamera/request.cpp:91-312",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320-470",
        "src/libcamera/v4l2_device.cpp:309-430",
        "src/libcamera/v4l2_videodevice.cpp:1616-2059",
        "Documentation/thread-safety.dox:1-46"
      ],
      "missing": []
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q3, Q6",
      "claim": "「버퍼 알림과 요청 반환의 내부 경계」 본문은 completeRequest가 완료된 요청을 반환하고 requestCompleted를 알린다고 조건 없이 서술합니다.",
      "counterevidence": "src/libcamera/pipeline_handler.cpp:594-600은 선두가 RequestPending이면 알림 없이 순회를 중단합니다. src/libcamera/camera.cpp:1475-1491은 CameraStopping부터 CameraRunning까지의 상태 검사가 실패하면 신호 발생 전에 Fatal 로그에 도달합니다.",
      "fix": "선두가 완료되고 Camera::requestComplete의 상태 검사를 통과하는 경로에서 신호를 발생시킨다고 한정하고, 신호 발생과 지연된 콜백 실행을 구분합니다."
    }
  ],
  "items": [
    {
      "anchor": "제출에서 완료까지",
      "question": "제출과 완료를 어떻게 연결합니까?",
      "visual_status": "적절",
      "reason": "하위 그림들이 준비, 전달, 버퍼 완료와 제출 순서 반환을 각각 설명합니다."
    },
    {
      "anchor": "제출·준비·장치 처리·완료의 연결",
      "question": "정상 요청의 단계는 무엇입니까?",
      "visual_status": "적절",
      "reason": "준비 조건과 명시적 요청 완료를 표시합니다."
    },
    {
      "anchor": "접수 반환과 완료 알림",
      "question": "0 반환과 완료 알림은 어떻게 다릅니까?",
      "visual_status": "적절",
      "reason": "Queued 호출과 별도 완료 통지 계약을 구분합니다."
    },
    {
      "anchor": "선두 요청을 전달하거나 반복을 멈추는 조건",
      "question": "대기 큐 순회는 언제 멈춥니까?",
      "visual_status": "적절",
      "reason": "큐 한도, 선두 준비와 pop 순서를 표시합니다."
    },
    {
      "anchor": "void 전달 함수의 두 취소 경로",
      "question": "준비 취소와 장치 제출 실패는 어떻게 처리합니까?",
      "visual_status": "적절",
      "reason": "이미 취소된 요청과 장치 반환 오류를 구분합니다."
    },
    {
      "anchor": "버퍼 완료와 명시적 요청 완료의 경계",
      "question": "마지막 버퍼 완료 뒤 무엇을 호출합니까?",
      "visual_status": "적절",
      "reason": "completeBuffer 반환과 명시적 completeRequest를 구분합니다."
    },
    {
      "anchor": "제출 큐의 선두 상태와 반환 순서",
      "question": "완료된 요청은 어느 순서로 반환합니까?",
      "visual_status": "적절",
      "reason": "Pending 선두에서 중단하고 완료된 선두를 제거하는 순서를 표시합니다."
    },
    {
      "anchor": "준비 대기와 재진입을 좁히기",
      "question": "준비 완료와 재진입은 어떻게 연결됩니까?",
      "visual_status": "적절",
      "reason": "fence, timeout, prepared 신호와 pop 순서를 해당 항목의 그림이 설명합니다."
    },
    {
      "anchor": "준비 대기와 재진입을 좁히기 그림",
      "question": "준비 생산자와 전달 소비자는 어떻게 연결됩니까?",
      "visual_status": "적절",
      "reason": "fence와 timeout의 준비 완료 분기 및 재귀 전달 전 pop을 표시합니다."
    },
    {
      "anchor": "UVC의 장치 제출과 완료를 추적하기",
      "question": "UVC 제출 실패와 완료는 어떻게 갈립니까?",
      "visual_status": "적절",
      "reason": "해당 항목의 그림이 제출 실패 취소와 버퍼 알림 후 완료를 구분합니다."
    },
    {
      "anchor": "UVC의 장치 제출과 완료를 추적하기 그림",
      "question": "UVC 제출과 완료의 주요 분기는 무엇입니까?",
      "visual_status": "적절",
      "reason": "취소 경로와 bufferReady에서 명시적 요청 완료까지의 경로를 표시합니다."
    },
    {
      "anchor": "요청·버퍼·fence의 수명",
      "question": "자원의 소유권과 재사용 경계는 무엇입니까?",
      "visual_status": "적절",
      "reason": "소유권, timeout 후 fence 회수와 ReuseBuffers를 별도 그림으로 설명합니다."
    },
    {
      "anchor": "요청과 버퍼를 유지할 기간",
      "question": "요청과 버퍼는 누가 언제까지 유지합니까?",
      "visual_status": "적절",
      "reason": "호출자 책임과 완료 콜백 및 핸들러의 접근 금지 경계를 표시합니다."
    },
    {
      "anchor": "타임아웃 뒤 펜스 회수",
      "question": "신호되지 않은 fence는 언제 회수합니까?",
      "visual_status": "적절",
      "reason": "timeout 후 fence 잔존과 재사용 전 회수 의무를 표시합니다."
    },
    {
      "anchor": "버퍼 재사용과 펜스 권고",
      "question": "ReuseBuffers는 무엇을 재사용합니까?",
      "visual_status": "적절",
      "reason": "버퍼와 fence를 구분하고 should not 권고를 보존합니다."
    },
    {
      "anchor": "버퍼 알림과 요청 반환의 내부 경계",
      "question": "버퍼 신호와 내부 추적 갱신은 어떤 순서입니까?",
      "visual_status": "적절",
      "reason": "해당 항목의 그림이 신호, pending 제거, 명시적 완료와 상태 검사를 연결합니다."
    },
    {
      "anchor": "버퍼 알림과 요청 반환의 내부 경계 그림",
      "question": "정상 완료의 내부 처리 순서는 무엇입니까?",
      "visual_status": "적절",
      "reason": "신호가 pending 제거보다 앞서는 순서와 상태 검사를 통과하는 경로를 표시합니다."
    },
    {
      "anchor": "콜백의 스레드와 재진입을 구분하기",
      "question": "연결 종류에 따라 콜백은 어떻게 실행됩니까?",
      "visual_status": "적절",
      "reason": "해당 항목의 그림이 Auto의 Direct·Queued 선택을 표시하며 Blocking과 수명 조건은 본문에 있습니다."
    },
    {
      "anchor": "콜백의 스레드와 재진입을 구분하기 그림",
      "question": "Auto는 어떤 전달 방식을 선택합니까?",
      "visual_status": "적절",
      "reason": "현재 스레드와 수신 스레드의 비교 및 두 실행 방식을 표시합니다."
    },
    {
      "anchor": "정지와 연결 해제를 구분하기",
      "question": "정지와 연결 해제의 계약은 어떻게 다릅니까?",
      "visual_status": "적절",
      "reason": "정지 순서, API 분기, 연결 해제 TODO와 관찰 계획에 각각 그림이 있습니다."
    },
    {
      "anchor": "정지할 때 대기 요청을 처리하는 순서",
      "question": "정상 정지의 공통 처리 순서는 무엇입니까?",
      "visual_status": "적절",
      "reason": "대기 큐 분리, 장치 정지, 취소 및 ASSERT 순서를 표시합니다."
    },
    {
      "anchor": "정지 API 계약과 연결 해제 TODO",
      "question": "정지 계약과 연결 해제 TODO는 무엇입니까?",
      "visual_status": "적절",
      "reason": "두 원문의 서로 다른 범위를 구분합니다."
    },
    {
      "anchor": "Camera::stop의 미실행·오류·정상 경로",
      "question": "Camera::stop은 어떤 조건에서 반환합니까?",
      "visual_status": "적절",
      "reason": "미실행, 접근 오류와 정상 경로의 분기를 표시합니다."
    },
    {
      "anchor": "stopDevice 호출 구간의 관찰 계획",
      "question": "장치 정지 호출의 진입과 복귀를 어떻게 구분합니까?",
      "visual_status": "적절",
      "reason": "호출 지점과 실제 구현 진입·복귀의 관찰 표식을 구분합니다."
    },
    {
      "anchor": "완료 통지의 호출자 의무와 반환 뒤 경계",
      "question": "완료 호출자의 스레드와 접근 의무는 무엇입니까?",
      "visual_status": "적절",
      "reason": "호출 스레드, 제출 순서 계약과 반환 후 접근 금지를 표시합니다."
    },
    {
      "anchor": "UVC 정지의 정상 경로와 실패 경계",
      "question": "STREAMOFF 실패는 정상 정지와 어떻게 다릅니까?",
      "visual_status": "적절",
      "reason": "해당 항목의 그림과 본문이 오류 조기 반환과 releaseBuffers 호출을 다룹니다."
    },
    {
      "anchor": "UVC 정지의 정상 경로와 실패 경계 그림",
      "question": "STREAMOFF 오류는 어느 루프를 건너뜁니까?",
      "visual_status": "적절",
      "reason": "ioctl 오류와 버퍼 취소·반환 루프를 구분합니다."
    },
    {
      "anchor": "변경 검토와 실행 확인",
      "question": "변경 전후에 어떤 불변조건을 검사합니까?",
      "visual_status": "적절",
      "reason": "해당 항목의 그림이 정상 완료와 bulk 취소의 pending 처리 차이를 표시하고 본문이 실패 사례를 열거합니다."
    },
    {
      "anchor": "정상 완료와 bulk 취소의 검증 위치",
      "question": "두 완료 경로의 pending 정리는 어떻게 다릅니까?",
      "visual_status": "적절",
      "reason": "개별 erase와 bulk clear 및 요청 완료의 ASSERT를 구분합니다."
    },
    {
      "anchor": "공개 가상 카메라의 콜백 관찰",
      "question": "가상 프로브에서 무엇을 관찰했습니까?",
      "visual_status": "적절",
      "reason": "연결별 표식과 반환 근처 표식의 한계를 각각 표시합니다."
    },
    {
      "anchor": "가상 CPU 프로브의 연결별 취소 콜백 표시",
      "question": "연결별 콜백 표식은 정지 표식과 어떻게 배치됐습니까?",
      "visual_status": "적절",
      "reason": "세 실행의 제한된 관찰을 연결별로 표시합니다."
    },
    {
      "anchor": "반환 근처 표시로 알 수 있는 범위",
      "question": "콜백 반환 근처 표식은 무엇을 증명합니까?",
      "visual_status": "적절",
      "reason": "카운터 증가와 지역 객체 소멸 전 표식 및 실제 반환 미추적을 구분합니다."
    },
    {
      "anchor": "소스 근거",
      "question": "설명에 사용한 원문은 어디에 있습니까?",
      "visual_status": "생략 가능",
      "reason": "원문 발췌와 근거 목록으로 이루어진 참조 항목입니다."
    }
  ],
  "unreviewed_scope": [
    "제공된 20개 전체 소스 창과 문서 내 발췌를 기준으로 검토했습니다. 다른 파이프라인, IPA 및 커널 UVC 드라이버 구현은 범위 밖입니다.",
    "물리 UVC 실행, DMA 정확성, 성능, 사내 Camera HAL과 실제 비저자 독자 평가는 수행하지 않았습니다.",
    "request-diagnosis.md의 본문과 링크 대상은 제공되지 않아 검토하지 않았습니다.",
    "기존 가상 프로브는 제공된 기록으로만 대조했으며 원시 이벤트 파일과 프로브 소스 자체는 제공되지 않았습니다."
  ]
}
