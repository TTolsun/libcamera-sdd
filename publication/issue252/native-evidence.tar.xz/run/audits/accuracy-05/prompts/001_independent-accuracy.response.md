{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "제출에서 완료까지; 준비 대기와 재진입을 좁히기; UVC의 장치 제출과 완료를 추적하기",
      "diagnosis_values": "queued 호출의 게시·실행, 이벤트 루프, waitingRequests_ 선두, prepared_, notifiers_, 300ms 타이머, queuedRequests_ 크기와 선두 상태",
      "next_branch": "준비 취소와 큐 한도를 확인한 뒤 UVC 제출, DQBUF 및 requestCompleted 경로로 이동합니다.",
      "change_validation": "재귀 전달 전에 pop하는 순서, 중복 처리, 선두 대기와 제출 순서를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1-1491",
        "src/libcamera/pipeline_handler.cpp:1-1011",
        "src/libcamera/request.cpp:1-616",
        "src/libcamera/base/object.cpp:1-361",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:1-907",
        "src/libcamera/v4l2_videodevice.cpp:1-2257"
      ],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "UVC의 장치 제출과 완료를 추적하기; 변경 검토와 실행 확인",
      "diagnosis_values": "findBuffer 결과, 개별 processControl 반환, setControls의 ret과 error_idx, queueBuffer와 VIDIOC_QBUF의 ret, sequence_",
      "next_branch": "UVC가 음수를 반환하면 공통 doQueueRequest가 cancelRequest를 호출합니다. 제어 처리 이후 QBUF가 실패하면 이미 발생한 제어 변경도 조사합니다.",
      "change_validation": "제어 오류와 QBUF 실패를 구분해 제어 상태, 큐 등록, 취소 횟수와 반환 순서를 확인합니다.",
      "answerable": false,
      "source_windows": [
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:1-907",
        "src/libcamera/v4l2_device.cpp:1-1107",
        "src/libcamera/v4l2_videodevice.cpp:1-2257",
        "src/libcamera/pipeline_handler.cpp:1-1011"
      ],
      "missing": [
        "cache_가 없을 때 Fatal 로그가 -ENOENT 반환과 공통 취소 분기에 미치는 경계를 정확히 설명해야 합니다."
      ]
    },
    {
      "id": "Q3",
      "answer_location": "제출에서 완료까지; UVC의 장치 제출과 완료를 추적하기; 버퍼 알림과 요청 반환의 내부 경계",
      "diagnosis_values": "bufferCompleted, pending_, 버퍼 metadata.status, request status, queuedRequests_ 선두, requestCompleted",
      "next_branch": "DQBUF 오류나 예상 밖 인덱스는 알림 없이 반환합니다. 유효 버퍼는 UVC가 버퍼와 요청을 명시적으로 완료하며 선두 상태에 따라 통지가 대기합니다.",
      "change_validation": "버퍼별 완료 횟수, pending 제거, FrameError와 RequestComplete의 조합 및 제출 순서를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/v4l2_videodevice.cpp:1-2257",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:1-907",
        "src/libcamera/pipeline_handler.cpp:1-1011",
        "src/libcamera/request.cpp:1-616"
      ],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "요청·버퍼·fence의 수명; 버퍼 알림과 요청 반환의 내부 경계; 콜백의 스레드와 재진입을 구분하기",
      "diagnosis_values": "요청 소유자, 버퍼 유효 기간, fence 소유권과 releaseFence, pending_, 버퍼의 request 연결, 지연 수신자의 포인터",
      "next_branch": "직접 버퍼 콜백에서는 내부 정리 전임을 확인하고, 요청 완료 콜백과 지연 수신자별 수명을 따로 판단합니다.",
      "change_validation": "reuse 전 상태 초기화, 미신호 fence 회수, 재연결과 지연 포인터의 유효 기간을 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1-1491",
        "src/libcamera/request.cpp:1-616",
        "src/libcamera/framebuffer.cpp:1-451",
        "src/libcamera/base/object.cpp:1-361",
        "src/libcamera/base/signal.cpp:1-205",
        "src/libcamera/pipeline_handler.cpp:1-1011"
      ],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "정지와 연결 해제를 구분하기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "waitingRequests_ swap, CameraStopping, STREAMOFF ret, state_, queuedBuffers_, cache_, notifier, releaseBuffers ret 및 ASSERT 도달 여부",
      "next_branch": "정상 STREAMOFF의 버퍼 반환과 실패 시 조기 반환을 구분하고, UVC가 반환값을 무시한 뒤 cache를 reset하는 경로를 확인합니다.",
      "change_validation": "대기·장치 요청의 완료 횟수와 순서, 재투입, 실패 후 잔존 notifier 및 알려진 인덱스의 후속 DQBUF를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1-1491",
        "src/libcamera/pipeline_handler.cpp:1-1011",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:1-907",
        "src/libcamera/v4l2_videodevice.cpp:1-2257"
      ],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "콜백의 스레드와 재진입을 구분하기; 정지와 연결 해제를 구분하기; 공개 가상 카메라의 콜백 관찰",
      "diagnosis_values": "수신자 유형, 연결 종류, 현재·수신 스레드, 이벤트 루프, 콜백 진입·복귀 표식, Blocking 반환 및 별도 queued 수신 완료",
      "next_branch": "Auto의 스레드 비교와 Direct·Queued·Blocking 분기를 구분하고, 정지 반환과 지연 수신자의 처리 완료를 별도로 확인합니다.",
      "change_validation": "호출자 동기화, 허용되지 않은 중첩 호출, 포인터 수명과 콜백 처리 완료를 검증합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/base/bound_method.cpp:1-110",
        "src/libcamera/base/signal.cpp:1-205",
        "src/libcamera/base/object.cpp:1-361",
        "include/libcamera/base/signal.h:1-153",
        "include/libcamera/base/bound_method.h:1-209",
        "Documentation/thread-safety.dox:1-46",
        "src/libcamera/camera.cpp:1-1491"
      ],
      "missing": []
    },
    {
      "id": "Q7",
      "answer_location": "변경 검토와 실행 확인; 준비 대기와 재진입을 좁히기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "cookie, sequence, pop 순서, 버퍼·요청 완료 횟수, pending_, 큐 상태, 상태별 ret과 콜백 표식",
      "next_branch": "준비 취소, 제어·QBUF 실패, DQBUF 오류·예상 밖 인덱스, FrameError, 정상·실패 정지 및 지연 콜백을 각각 조사합니다.",
      "change_validation": "재귀 전달 전 pop, 버퍼당 한 번의 완료, 요청 완료 전 pending 부재, completeRequest 후 접근 금지와 정지 중 재투입 방지를 확인합니다.",
      "answerable": false,
      "source_windows": [
        "src/libcamera/request.cpp:1-616",
        "src/libcamera/pipeline_handler.cpp:1-1011",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:1-907",
        "src/libcamera/v4l2_videodevice.cpp:1-2257",
        "src/libcamera/base/bound_method.cpp:1-110",
        "Documentation/thread-safety.dox:1-46"
      ],
      "missing": [
        "cache_ 부재 시 Fatal 경로를 단순 오류 반환으로 검증해서는 안 됩니다."
      ]
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q2, Q7",
      "claim": "UVC 장치 제출 조사에서 queueBuffer는 캐시가 없으면 -ENOENT를 반환하며, 장치 제출 오류는 취소 분기로 이어진다고 설명합니다.",
      "counterevidence": "src/libcamera/v4l2_videodevice.cpp:1648의 !cache_ 분기는 return -ENOENT 앞에 LOG(V4L2, Fatal)을 실행합니다. 이 Fatal 경계를 무시하고 반환 및 src/libcamera/pipeline_handler.cpp:483의 cancelRequest 도달을 보장할 수 없습니다.",
      "fix": "cache_ 부재를 Fatal 로그가 발생하는 별도 경로로 설명하고, -ENOENT 및 후속 취소를 정상적으로 관찰 가능한 결과로 단정하지 않도록 수정합니다."
    }
  ],
  "items": [
    {
      "anchor": "제출에서 완료까지",
      "question": "제출과 완료의 관계",
      "visual_status": "그림 있음",
      "reason": "제출, 준비, 장치 처리와 완료 순서를 연결합니다."
    },
    {
      "anchor": "제출·준비·장치 처리·완료의 연결",
      "question": "정상 요청 처리 단계",
      "visual_status": "그림 있음",
      "reason": "정상 경로와 명시적 요청 완료를 표시합니다."
    },
    {
      "anchor": "접수 반환과 완료 알림",
      "question": "0 반환과 완료 통지",
      "visual_status": "그림 있음",
      "reason": "queued 호출과 별도 완료 통지를 구분합니다."
    },
    {
      "anchor": "선두 요청을 전달하거나 반복을 멈추는 조건",
      "question": "준비와 큐 한도",
      "visual_status": "그림 있음",
      "reason": "선두 검사와 전달 전 pop을 표시합니다."
    },
    {
      "anchor": "void 전달 함수의 두 취소 경로",
      "question": "준비 취소와 제출 실패",
      "visual_status": "그림 있음",
      "reason": "이미 취소된 요청과 장치 반환 오류를 구분합니다."
    },
    {
      "anchor": "버퍼 완료와 명시적 요청 완료의 경계",
      "question": "마지막 버퍼와 요청 완료",
      "visual_status": "그림 있음",
      "reason": "completeBuffer 반환과 별도 완료 의무를 구분합니다."
    },
    {
      "anchor": "제출 큐의 선두 상태와 반환 순서",
      "question": "요청 반환 순서",
      "visual_status": "그림 있음",
      "reason": "선두 상태 검사, ASSERT 및 통지를 표시합니다."
    },
    {
      "anchor": "준비 대기와 재진입을 좁히기",
      "question": "준비 생산자와 전달",
      "visual_status": "그림 있음",
      "reason": "fence, timeout, prepared와 재귀 전달을 연결합니다."
    },
    {
      "anchor": "준비 대기와 재진입을 좁히기 그림",
      "question": "준비와 재진입 순서",
      "visual_status": "그림 있음",
      "reason": "알림과 타임아웃에서 선두 pop까지의 분기를 표시합니다."
    },
    {
      "anchor": "UVC의 장치 제출과 완료를 추적하기",
      "question": "UVC 제출 실패와 완료",
      "visual_status": "그림 있음",
      "reason": "취소 경로와 버퍼 알림 경로를 구분합니다."
    },
    {
      "anchor": "UVC의 장치 제출과 완료를 추적하기 그림",
      "question": "UVC 제출과 명시적 완료",
      "visual_status": "그림 있음",
      "reason": "제출 결과와 bufferReady 이후 완료 경로를 표시합니다."
    },
    {
      "anchor": "요청·버퍼·fence의 수명",
      "question": "자원 소유권과 재사용",
      "visual_status": "그림 있음",
      "reason": "요청 소유, 버퍼 유지 및 fence 회수 관계를 각각 표시합니다."
    },
    {
      "anchor": "요청과 버퍼를 유지할 기간",
      "question": "소유자와 접근 경계",
      "visual_status": "그림 있음",
      "reason": "호출자의 유지 책임과 핸들러의 접근 금지를 구분합니다."
    },
    {
      "anchor": "타임아웃 뒤 펜스 회수",
      "question": "미신호 fence의 재사용",
      "visual_status": "그림 있음",
      "reason": "타임아웃 후 releaseFence가 필요한 관계를 표시합니다."
    },
    {
      "anchor": "버퍼 재사용과 펜스 권고",
      "question": "ReuseBuffers의 범위",
      "visual_status": "그림 있음",
      "reason": "버퍼 재사용과 fence 관련 권고를 구분합니다."
    },
    {
      "anchor": "버퍼 알림과 요청 반환의 내부 경계",
      "question": "신호와 내부 정리의 순서",
      "visual_status": "그림 있음",
      "reason": "버퍼 신호부터 pending 제거와 요청 통지까지 연결합니다."
    },
    {
      "anchor": "버퍼 알림과 요청 반환의 내부 경계 그림",
      "question": "완료 처리 순서",
      "visual_status": "그림 있음",
      "reason": "신호, 내부 추적 갱신, 선두 검사와 상태 검사를 표시합니다."
    },
    {
      "anchor": "콜백의 스레드와 재진입을 구분하기",
      "question": "연결 종류별 실행",
      "visual_status": "그림 있음",
      "reason": "Auto의 Direct·Queued 분기를 그림으로 표시하고 Blocking은 본문에서 설명합니다."
    },
    {
      "anchor": "콜백의 스레드와 재진입을 구분하기 그림",
      "question": "Auto의 연결 선택",
      "visual_status": "그림 있음",
      "reason": "현재 스레드와 수신 스레드 비교를 표시합니다."
    },
    {
      "anchor": "정지와 연결 해제를 구분하기",
      "question": "정지 계약과 연결 해제",
      "visual_status": "그림 있음",
      "reason": "정지 순서, API 분기와 연결 해제 TODO를 별도로 표시합니다."
    },
    {
      "anchor": "정지할 때 대기 요청을 처리하는 순서",
      "question": "정상 정지 순서",
      "visual_status": "그림 있음",
      "reason": "대기열 분리, 장치 정지, 취소 및 ASSERT 위치를 표시합니다."
    },
    {
      "anchor": "정지 API 계약과 연결 해제 TODO",
      "question": "정지와 연결 해제의 계약",
      "visual_status": "그림 있음",
      "reason": "정지 계약과 연결 해제 TODO를 구분합니다."
    },
    {
      "anchor": "Camera::stop의 미실행·오류·정상 경로",
      "question": "stop 반환 분기",
      "visual_status": "그림 있음",
      "reason": "실행 상태와 접근 검사별 분기를 표시합니다."
    },
    {
      "anchor": "stopDevice 호출 구간의 관찰 계획",
      "question": "정지 구현의 진입과 복귀",
      "visual_status": "그림 있음",
      "reason": "호출 지점, 구현 진입 및 복귀 미관찰을 구분합니다."
    },
    {
      "anchor": "완료 통지의 호출자 의무와 반환 뒤 경계",
      "question": "완료 호출의 의무",
      "visual_status": "그림 있음",
      "reason": "호출 스레드와 반환 후 접근 금지를 표시합니다."
    },
    {
      "anchor": "UVC 정지의 정상 경로와 실패 경계",
      "question": "STREAMOFF 성공과 실패",
      "visual_status": "그림 있음",
      "reason": "조기 반환과 버퍼 반환 루프를 구분합니다."
    },
    {
      "anchor": "UVC 정지의 정상 경로와 실패 경계 그림",
      "question": "STREAMOFF와 releaseBuffers",
      "visual_status": "그림 있음",
      "reason": "ioctl 실패와 성공 및 후속 해제 호출을 표시합니다."
    },
    {
      "anchor": "변경 검토와 실행 확인",
      "question": "변경 시 확인할 불변조건",
      "visual_status": "그림 있음",
      "reason": "정상 완료와 bulk 취소의 추적 경계를 표시하고 나머지 실패 주입은 본문에 기록합니다."
    },
    {
      "anchor": "정상 완료와 bulk 취소의 검증 위치",
      "question": "pending 정리의 두 경로",
      "visual_status": "그림 있음",
      "reason": "개별 완료와 bulk 취소의 정리 차이를 표시합니다."
    },
    {
      "anchor": "공개 가상 카메라의 콜백 관찰",
      "question": "가상 프로브의 관측 범위",
      "visual_status": "그림 있음",
      "reason": "연결별 관측 표식과 반환 근처 표식의 한계를 표시합니다."
    },
    {
      "anchor": "가상 CPU 프로브의 연결별 취소 콜백 표시",
      "question": "연결별 관측 표식",
      "visual_status": "그림 있음",
      "reason": "세 실행에서 관측한 스레드와 정지 표식 관계를 표시합니다."
    },
    {
      "anchor": "반환 근처 표시로 알 수 있는 범위",
      "question": "실제 C++ 반환 추적 여부",
      "visual_status": "그림 있음",
      "reason": "표식 뒤 작업과 추적하지 않은 반환 완료를 구분합니다."
    },
    {
      "anchor": "소스 근거",
      "question": "원문 대조",
      "visual_status": "생략 가능",
      "reason": "항목은 인용 원문과 출처 목록으로 구성되어 별도 처리 흐름을 설명하지 않습니다."
    }
  ],
  "unreviewed_scope": [
    "물리 UVC 캡처, DMA 정확성, 성능 및 내부 Camera HAL 검증은 범위 밖입니다.",
    "다른 파이프라인, IPA 처리 및 커널 UVC 드라이버 구현은 범위 밖입니다.",
    "실제 비저자 독자 평가와 사람의 의미 검토는 수행되지 않았습니다.",
    "문서가 인용한 src/libcamera/base/thread.cpp:502는 발췌만 제공되어 전체 파일 경계는 검토하지 못했습니다."
  ]
}
