{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "「준비 대기와 재진입을 좁히기」와 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "camera.cpp:1308의 Queued 호출 진입 여부, pipeline_handler.cpp:435의 waitingRequests_ 선두·prepared_·queuedRequests_ 크기·한도, request.cpp:192의 notifiers_·300ms 타이머를 확인합니다.",
      "next_branch": "준비 취소면 sequence 등록 후 completeRequest를 확인하고, 장치 제출 후에는 QBUF·DQBUF와 queuedRequests_ 선두 상태를 확인합니다.",
      "change_validation": "fence 미신호, 미준비 선두, 큐 한도와 재귀 호출에서 pop 순서와 요청별 처리 횟수를 확인합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/camera.cpp", "src/libcamera/pipeline_handler.cpp", "src/libcamera/request.cpp", "src/libcamera/v4l2_videodevice.cpp", "src/libcamera/base/object.cpp"],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "uvcvideo.cpp:327·427·448의 findBuffer, 개별 processControl 결과, setControls 반환값과 v4l2_device.cpp:309의 error_idx를 확인합니다. queueBuffer의 cache_·인덱스·QBUF 반환값도 확인합니다.",
      "next_branch": "버퍼 부재 또는 제어·큐잉의 음수 반환은 doQueueRequest의 cancelRequest로 이어집니다. cache_ 부재의 Fatal은 일반 반환과 구분합니다.",
      "change_validation": "부분 제어 쓰기와 제어 적용 후 QBUF 실패를 각각 주입하고 sequence, queuedBuffers_ 등록 여부와 취소 통지를 기록합니다. 제어 롤백은 가정하지 않습니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/v4l2_device.cpp", "src/libcamera/v4l2_videodevice.cpp", "src/libcamera/pipeline_handler.cpp"],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "「버퍼 알림과 요청 반환의 내부 경계」와 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "pipeline_handler.cpp:547의 bufferCompleted와 pending 제거 순서, request.cpp:103의 cancelled_·status, v4l2_videodevice.cpp:1814의 프레임 상태와 큐 인덱스를 확인합니다.",
      "next_branch": "DQBUF 오류나 예상 밖 인덱스면 bufferReady 없이 반환합니다. 유효 버퍼면 UVC가 completeBuffer 뒤 completeRequest를 호출하고 선두 Pending 여부를 확인합니다.",
      "change_validation": "FrameError와 취소 원인이 없는 RequestComplete를 별도로 기록하고, 버퍼별 완료 횟수와 제출 순서에 따른 requestCompleted를 확인합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/pipeline_handler.cpp", "src/libcamera/request.cpp", "src/libcamera/v4l2_videodevice.cpp", "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/framebuffer.cpp"],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "「요청·버퍼·fence의 수명」과 「버퍼 알림과 요청 반환의 내부 경계」",
      "diagnosis_values": "camera.cpp:1243의 요청 소유권, request.cpp:442·475의 버퍼·fence 계약, request.cpp:103·139의 pending과 연결 값을 확인합니다.",
      "next_branch": "직접 버퍼 콜백에서는 내부 제거가 아직 남아 있습니다. timeout으로 남은 fence는 releaseFence로 회수하고, 별도 Queued 수신자의 마지막 사용도 확인합니다.",
      "change_validation": "정상 완료와 일괄 취소에서 연결 값의 유효 기간, 재사용 전 pending 정리 및 지연된 포인터 사용 종료를 검증합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/camera.cpp", "src/libcamera/request.cpp", "src/libcamera/framebuffer.cpp", "src/libcamera/pipeline_handler.cpp", "src/libcamera/base/object.cpp", "src/libcamera/base/signal.cpp"],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "「UVC 정지의 정상 경로와 실패 경계」",
      "diagnosis_values": "pipeline_handler.cpp:359의 waitingRequests_ swap과 두 ASSERT, camera.cpp:1431의 CameraStopping, v4l2_videodevice.cpp:2023의 STREAMOFF ret·state_·큐·notifier·cache_를 확인합니다.",
      "next_branch": "STREAMOFF 실패는 버퍼 반환 루프 전에 반환하며 UVC stopDevice는 결과를 무시하고 releaseBuffers를 호출합니다. 잔존 notifier와 reset된 cache의 후속 DQBUF를 조사합니다.",
      "change_validation": "STREAMOFF와 releaseBuffers 실패를 별도로 주입해 요청·버퍼 완료 횟수, ASSERT 도달, 큐 잔존과 정지 중 재투입을 기록합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/camera.cpp", "src/libcamera/pipeline_handler.cpp", "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/v4l2_videodevice.cpp"],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "「콜백의 스레드와 재진입을 구분하기」",
      "diagnosis_values": "bound_method.cpp:68의 연결 종류와 현재·수신 스레드, thread.cpp:630의 dispatchMessages 호출 및 재귀 깊이, object.cpp:184의 메시지 처리를 확인합니다.",
      "next_branch": "Direct는 즉시 실행하고 Queued는 게시합니다. Queued 메시지는 이벤트 루프 외에도 수신 스레드의 명시적 dispatchMessages에서 소비될 수 있습니다. Blocking은 해당 호출만 기다립니다.",
      "change_validation": "같은 스레드와 다른 스레드에서 명시적 Queued, 재귀 dispatchMessages 및 별도 수신자의 마지막 사용을 확인하고 stop 반환을 전체 콜백 drain으로 간주하지 않습니다.",
      "answerable": false,
      "source_windows": ["src/libcamera/base/bound_method.cpp", "src/libcamera/base/thread.cpp", "src/libcamera/base/object.cpp", "src/libcamera/base/message.cpp", "src/libcamera/base/event_dispatcher_poll.cpp", "include/libcamera/base/thread.h", "Documentation/thread-safety.dox", "src/libcamera/camera.cpp"],
      "missing": ["수신 스레드에서 dispatchMessages를 직접 또는 메시지 핸들러에서 재귀 호출하는 필수 분기와 그에 따른 Queued 수신 시점이 문서에 없습니다."]
    },
    {
      "id": "Q7",
      "answer_location": "「변경 검토와 실행 확인」",
      "diagnosis_values": "pipeline_handler.cpp:435의 pop 순서, request.cpp:91·139의 erase·일괄 취소, pipeline_handler.cpp:547의 pending ASSERT와 반환 후 접근 금지를 확인합니다.",
      "next_branch": "준비 timeout, 제어·QBUF 실패, DQBUF 오류·예상 밖 인덱스, FrameError 및 STREAMOFF 실패를 각각 분리합니다.",
      "change_validation": "요청·버퍼별 완료 횟수와 순서, 완료 전 pending 부재, 정지 중 재투입 및 지연 수신자의 마지막 사용을 기록합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/pipeline_handler.cpp", "src/libcamera/request.cpp", "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/v4l2_videodevice.cpp", "src/libcamera/base/bound_method.cpp", "Documentation/thread-safety.dox"],
      "missing": []
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q6",
      "claim": "문서는 Queued 수신이 수신 스레드의 이벤트 루프로 제어가 돌아왔을 때 실행된다고 설명하지만, 명시적 메시지 dispatch 경계를 제시하지 않습니다.",
      "counterevidence": "src/libcamera/base/thread.cpp:630의 Thread::dispatchMessages()는 현재 스레드에서 게시된 메시지를 즉시 전달하며, 객체의 메시지 핸들러에서 같은 스레드의 재귀 호출도 허용합니다. src/libcamera/base/object.cpp:184는 전달된 InvokeMessage를 실행합니다. 따라서 이벤트 루프로 복귀해야만 수신이 시작된다는 설명은 완전하지 않습니다.",
      "fix": "이벤트 루프 전달을 일반 경로로 한정하고, 수신 스레드의 명시적·재귀 dispatchMessages가 Queued 메시지를 소비할 수 있음을 설명합니다. 같은 스레드 Queued 게시 후 재귀 dispatch와 다른 스레드 수신의 실행 순서 및 포인터 수명을 검증 조건에 추가합니다."
    }
  ],
  "items": [
    {"anchor":"item-01","visual_status":"diagram","question":"제출에서 완료까지의 단계는 어떻게 연결됩니까?","reason":"제출·준비·장치 처리·완료 그림이 이 항목의 전체 경로를 설명합니다."},
    {"anchor":"item-02","visual_status":"diagram","question":"제출·준비·장치 처리·완료는 어떻게 연결됩니까?","reason":"정상 경로의 단계와 완료 책임을 흐름도로 표시합니다."},
    {"anchor":"item-03","visual_status":"diagram","question":"접수 반환과 완료 알림은 어떻게 다릅니까?","reason":"Queued 호출의 반환과 별도 완료 통지를 구분합니다."},
    {"anchor":"item-04","visual_status":"diagram","question":"선두 요청 전달은 어느 조건에서 멈춥니까?","reason":"대기 큐, 한도와 준비 상태의 분기를 표시합니다."},
    {"anchor":"item-05","visual_status":"diagram","question":"전달 함수의 두 취소 경로는 무엇입니까?","reason":"기존 취소와 장치 제출 실패의 분기를 표시합니다."},
    {"anchor":"item-06","visual_status":"diagram","question":"버퍼 완료와 명시적 요청 완료는 어떻게 다릅니까?","reason":"마지막 버퍼의 반환값과 별도 완료 호출을 표시합니다."},
    {"anchor":"item-07","visual_status":"diagram","question":"선두 상태는 요청 반환 순서에 어떤 영향을 줍니까?","reason":"Pending 선두의 중단과 완료 선두의 반환 반복을 표시합니다."},
    {"anchor":"item-08","visual_status":"diagram","question":"준비 대기와 재진입은 어떻게 조사합니까?","reason":"준비 완료 생산자와 선두 검사 및 pop 순서를 표시합니다."},
    {"anchor":"item-09","visual_status":"diagram","question":"fence와 timeout은 전달 재시도로 어떻게 이어집니까?","reason":"fence·timeout·prepared·재진입 전 pop 경로를 표시합니다."},
    {"anchor":"item-10","visual_status":"diagram","question":"UVC 제출 실패와 완료는 어디서 갈라집니까?","reason":"제어·QBUF·DQBUF 및 완료의 선택 경로를 표시합니다."},
    {"anchor":"item-11","visual_status":"diagram","question":"UVC 장치 제출과 완료는 어떻게 이어집니까?","reason":"제출 실패와 별도 장치 완료 알림을 구분합니다."},
    {"anchor":"item-12","visual_status":"diagram","question":"요청·버퍼·fence는 언제까지 유지합니까?","reason":"소유권과 버퍼 유효 기간을 표시하고 fence 회수 그림을 별도로 둡니다."},
    {"anchor":"item-13","visual_status":"diagram","question":"요청과 버퍼의 유지 책임은 누구에게 있습니까?","reason":"소유자, 완료 콜백 및 핸들러의 접근 경계를 표시합니다."},
    {"anchor":"item-14","visual_status":"diagram","question":"timeout 뒤 fence는 어떻게 회수합니까?","reason":"남은 fence와 재사용 전 회수 의무를 표시합니다."},
    {"anchor":"item-15","visual_status":"diagram","question":"ReuseBuffers와 fence 권고는 어떻게 다릅니까?","reason":"버퍼 재사용 범위와 fence 사용 시 권고를 구분합니다."},
    {"anchor":"item-16","visual_status":"diagram","question":"버퍼 신호와 내부 추적 갱신은 어떤 순서입니까?","reason":"emit, pending 제거, 명시적 완료 및 요청 통지를 표시합니다."},
    {"anchor":"item-17","visual_status":"diagram","question":"버퍼 알림부터 요청 반환까지 내부 경계는 무엇입니까?","reason":"선택한 UVC 완료 경로의 각 내부 단계를 표시합니다."},
    {"anchor":"item-18","visual_status":"diagram","question":"콜백 연결 종류와 스레드는 어떻게 다릅니까?","reason":"Auto의 Direct·Queued 선택을 표시합니다. 명시적 재귀 dispatch의 설명은 별도 결함으로 기록했습니다."},
    {"anchor":"item-19","visual_status":"diagram","question":"Auto는 어떤 연결 방식을 선택합니까?","reason":"현재 스레드와 수신 스레드 비교에 따른 분기를 표시합니다."},
    {"anchor":"item-20","visual_status":"diagram","question":"Queued 수신 시 포인터 수명은 누가 확인합니까?","reason":"발신자 책임과 지연 수신자의 마지막 사용 확인을 표시합니다."},
    {"anchor":"item-21","visual_status":"diagram","question":"Direct 중첩과 Queued 수신의 경계는 무엇입니까?","reason":"동기 실행, 메시지 게시 및 내부 갱신을 표시합니다. 재귀 dispatch의 누락은 별도 결함입니다."},
    {"anchor":"item-22","visual_status":"diagram","question":"정지와 연결 해제는 요청을 어떻게 다르게 다룹니까?","reason":"정지 계약과 연결 해제 TODO를 비교하는 그림이 있습니다."},
    {"anchor":"item-23","visual_status":"diagram","question":"정지 시 대기 요청은 어떤 순서로 처리됩니까?","reason":"대기 큐 분리, 장치 정지와 취소 반복을 표시합니다."},
    {"anchor":"item-24","visual_status":"diagram","question":"정지 계약과 연결 해제 TODO의 차이는 무엇입니까?","reason":"두 원문의 범위를 나란히 표시합니다."},
    {"anchor":"item-25","visual_status":"diagram","question":"Camera::stop의 반환 분기는 무엇입니까?","reason":"미실행, 접근 오류와 정상 경로를 표시합니다."},
    {"anchor":"item-26","visual_status":"diagram","question":"stopDevice의 진입과 복귀는 어떻게 관찰합니까?","reason":"호출 전 표식과 실제 구현 진입·복귀를 구분합니다."},
    {"anchor":"item-27","visual_status":"diagram","question":"완료 호출자의 의무와 반환 뒤 경계는 무엇입니까?","reason":"호출 스레드, 제출 순서 및 반환 후 접근 금지를 표시합니다."},
    {"anchor":"item-28","visual_status":"diagram","question":"UVC 정지 성공과 실패는 어디서 갈라집니까?","reason":"STREAMOFF 반환에 따른 버퍼 반환 및 해제 경로를 표시합니다."},
    {"anchor":"item-29","visual_status":"diagram","question":"STREAMOFF 실패는 어느 정리 경로를 건너뜁니까?","reason":"실패 조기 반환과 성공 시 버퍼 취소 순서를 표시합니다."},
    {"anchor":"item-30","visual_status":"diagram","question":"변경 후 어떤 완료·실패 경계를 확인합니까?","reason":"정상 완료와 일괄 취소의 검증 위치 및 별도 실패 분기 그림을 제공합니다."},
    {"anchor":"item-31","visual_status":"diagram","question":"정상 완료와 bulk 취소의 검증 위치는 어디입니까?","reason":"각 경로의 pending 처리와 요청 완료 검사를 구분합니다."},
    {"anchor":"item-32","visual_status":"diagram","question":"실패 주입별 다음 관찰 분기는 무엇입니까?","reason":"timeout, 제출, DQBUF 및 STREAMOFF 실패를 별도로 표시합니다."},
    {"anchor":"item-33","visual_status":"diagram","question":"가상 프로브의 콜백 표식은 무엇을 보여 줍니까?","reason":"연결별 스레드와 정지 표식의 관찰 관계를 표시합니다."},
    {"anchor":"item-34","visual_status":"diagram","question":"가상 프로브에서 취소 콜백 표식은 어떻게 배치됐습니까?","reason":"세 실행에서 관찰한 연결별 표식 위치를 표시합니다."},
    {"anchor":"item-35","visual_status":"diagram","question":"반환 근처 표식으로 무엇을 알 수 있습니까?","reason":"후속 카운터·소멸과 실제 반환 미추적의 경계를 표시합니다."},
    {"anchor":"item-36","visual_status":"omitted-with-reason","question":"선택한 설명의 원문 근거는 어디에 있습니까?","reason":"이 항목은 출처별 발췌와 식별자를 제공하는 참조 목록이므로 별도 그림이 필요하지 않습니다."}
  ],
  "unreviewed_scope": [
    "다른 파이프라인 구현, IPA 처리 및 커널 UVC 드라이버 구현은 지정된 범위 밖입니다.",
    "물리 카메라 캡처, DMA 정확성, 성능과 내부 Camera HAL은 검증하지 않았습니다.",
    "실제 비작성자 독자 평가와 전체 문서 집합의 승인은 수행하지 않았습니다."
  ]
}
