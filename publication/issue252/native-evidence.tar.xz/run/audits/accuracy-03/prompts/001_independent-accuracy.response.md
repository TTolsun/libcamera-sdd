{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "제출에서 완료까지; 준비 대기와 재진입을 좁히기; UVC의 장치 제출과 완료를 추적하기",
      "diagnosis_values": "queued 호출의 대상 스레드와 진입 여부, waitingRequests_ 선두, prepared_, notifiers_, timeout, queuedRequests_ 크기와 한도, 선두 status",
      "next_branch": "메시지 전달을 확인한 뒤 준비·한도 분기, 취소 또는 UVC 제출, DQBUF와 완료 통지를 차례로 확인합니다.",
      "change_validation": "timeout 취소와 재진입에서 pop 순서, 중복 처리 부재 및 제출 순서 반환을 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1308-1383",
        "src/libcamera/base/object.cpp:258-284",
        "src/libcamera/request.cpp:192-312",
        "src/libcamera/pipeline_handler.cpp:428-620",
        "src/libcamera/v4l2_videodevice.cpp:1814-1987"
      ],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "UVC의 장치 제출과 완료를 추적하기; 변경 검토와 실행 확인",
      "diagnosis_values": "findBuffer 결과, processControl과 setControls 반환값, error_idx, QBUF ret, queuedBuffers_, sequence_",
      "next_branch": "버퍼 없음 또는 제어 처리 오류면 queueBuffer 전에 반환합니다. QBUF 오류를 포함한 장치 제출 오류는 공통 cancelRequest로 이어집니다.",
      "change_validation": "제어 변환 오류, setControls의 일반·개별 오류와 제어 처리 후 QBUF 오류를 각각 주입하고 요청 상태와 부작용을 확인합니다.",
      "answerable": false,
      "source_windows": [
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:327-470",
        "src/libcamera/v4l2_device.cpp:278-430",
        "src/libcamera/v4l2_videodevice.cpp:1648-1814",
        "src/libcamera/pipeline_handler.cpp:483-501"
      ],
      "missing": [
        "setControls 자체가 개별 제어 쓰기에 실패했을 때도 앞선 제어가 이미 적용됐을 수 있다는 설명이 없습니다."
      ]
    },
    {
      "id": "Q3",
      "answer_location": "제출에서 완료까지; UVC의 장치 제출과 완료를 추적하기; 버퍼 알림과 요청 반환의 내부 경계",
      "diagnosis_values": "bufferCompleted 시점의 pending_, 버퍼 metadata.status, cancelled_, 요청 status, queuedRequests_ 선두",
      "next_branch": "DQBUF 실패 또는 예상 밖 인덱스면 해당 알림에서 bufferReady가 없습니다. 버퍼가 반환되면 UVC는 completeBuffer 다음 completeRequest를 호출합니다.",
      "change_validation": "FrameError와 RequestComplete의 공존, pending 제거 횟수, 선두 대기와 제출 순서 통지를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/v4l2_videodevice.cpp:1814-1987",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:893-905",
        "src/libcamera/request.cpp:91-139",
        "src/libcamera/pipeline_handler.cpp:547-607",
        "src/libcamera/camera.cpp:1475-1491"
      ],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "요청·버퍼·fence의 수명; 버퍼 알림과 요청 반환의 내부 경계; 준비 대기와 재진입을 좁히기",
      "diagnosis_values": "요청 소유자, 버퍼 유효 기간, fence 유무, pending_과 버퍼의 request 연결, 지연된 포인터 수명",
      "next_branch": "fence timeout 후 다른 요청에 재사용하려면 releaseFence를 확인합니다. 직접 버퍼 콜백에서는 내부 완료 갱신이 아직 남아 있습니다.",
      "change_validation": "요청 완료 콜백까지 버퍼를 유지하고, 지연 수신자의 포인터 수명과 재연결 시점을 별도로 검증합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1243-1263",
        "src/libcamera/request.cpp:91-173",
        "src/libcamera/request.cpp:326-505",
        "src/libcamera/framebuffer.cpp:1-451",
        "src/libcamera/base/object.cpp:258-284",
        "src/libcamera/base/signal.cpp:73-113"
      ],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "정지와 연결 해제를 구분하기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "waitingRequests_, queuedRequests_, streamOff ret, state_, queuedBuffers_, cache_, releaseBuffers 결과와 ASSERT 도달 여부",
      "next_branch": "대기 큐를 분리하고 stopDevice를 호출합니다. STREAMOFF 실패는 버퍼 반환 루프 전에 반환하지만 UVC는 releaseBuffers를 호출합니다.",
      "change_validation": "정상 정지, STREAMOFF 실패와 releaseBuffers 실패를 별도로 주입하고 완료 횟수, 순서, 잔존 큐와 재투입 여부를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp:359-414",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320-327",
        "src/libcamera/v4l2_videodevice.cpp:1616-1629",
        "src/libcamera/v4l2_videodevice.cpp:2023-2059",
        "src/libcamera/camera.cpp:1431-1491"
      ],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "콜백의 스레드와 재진입을 구분하기; 정지와 연결 해제를 구분하기; 공개 가상 카메라의 콜백 관찰",
      "diagnosis_values": "수신자의 Object 여부, 연결 종류, 현재·수신 스레드, 이벤트 루프, 콜백 진입·복귀와 별도 처리 완료 표식",
      "next_branch": "Auto는 스레드 비교로 Direct 또는 Queued를 선택합니다. Blocking 반환과 별도 Queued 수신자의 처리를 구분합니다.",
      "change_validation": "Direct의 동기 호출, Queued의 지연과 포인터 수명, 호출자 동기화 및 콜백 처리 완료를 별도로 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/base/bound_method.cpp:22-110",
        "include/libcamera/base/bound_method.h:59-209",
        "include/libcamera/base/signal.h:38-153",
        "src/libcamera/base/object.cpp:1-361",
        "Documentation/thread-safety.dox:1-46",
        "src/libcamera/camera.cpp:769-784",
        "product-evidence/libcamera-callback-probe/callback-run.txt:1-96"
      ],
      "missing": []
    },
    {
      "id": "Q7",
      "answer_location": "변경 검토와 실행 확인; 준비 대기와 재진입을 좁히기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "cookie, sequence, pop·투입 순서, pending_, 버퍼·요청 상태와 완료 횟수, 큐 잔존 및 ASSERT",
      "next_branch": "정상 완료와 bulk 취소를 구분하고 fence, 제어, QBUF, DQBUF, FrameError 및 정지 실패를 개별 사례로 검사합니다.",
      "change_validation": "버퍼별 단일 완료, 완료 시 pending 부재, 완료 반환 후 접근 금지, 정지 중 재투입 부재와 제출 순서를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/request.cpp:91-312",
        "src/libcamera/pipeline_handler.cpp:359-620",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320-470",
        "src/libcamera/v4l2_device.cpp:309-430",
        "src/libcamera/v4l2_videodevice.cpp:1616-2059",
        "Documentation/thread-safety.dox:1-46"
      ],
      "missing": []
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q2",
      "claim": "문서는 제어 처리 성공 후 QBUF가 실패하는 경우의 부작용은 설명하지만, setControls 자체가 실패하는 경우 이미 적용된 제어의 가능성을 명시하지 않습니다.",
      "counterevidence": "src/libcamera/v4l2_device.cpp의 setControls 계약은 쓰기 오류 시 성공적으로 쓰인 제어가 있을 수 있다고 설명합니다. 구현은 개별 오류의 error_idx 앞 항목을 updateControls에 넘기고 -EIO를 반환합니다. UVC는 그 음수 반환을 전달하고 공통 경로는 요청을 취소합니다.",
      "fix": "개별 제어 쓰기 오류에서도 일부 제어가 이미 적용됐을 수 있음을 추가하고, 원래 호출의 ret과 error_idx 및 앞선 제어 상태를 조사하도록 명시합니다. 롤백이나 실제 적용 결과를 단정하지 않습니다."
    },
    {
      "blocking": false,
      "question": "Q4",
      "claim": "첫 제출 절은 버퍼가 유효한 Stream을 참조하지 않으면 addBuffer가 -EINVAL을 반환한다고 구현의 일반적인 분기처럼 서술합니다.",
      "counterevidence": "src/libcamera/request.cpp:475-505의 구현은 stream 포인터가 nullptr인지 검사합니다. 임의의 유효하지 않은 비 null Stream을 검증하는 분기는 없습니다. Doxygen의 반환 계약과 구현 검사를 구분해야 합니다.",
      "fix": "해당 문장을 API 반환 계약으로 표시하고, 구현에서 확인한 조건은 null stream이라고 별도로 적습니다."
    }
  ],
  "items": [
    {
      "anchor": "제출에서 완료까지",
      "question": "제출부터 완료까지 어떻게 연결됩니까?",
      "visual_status": "적절",
      "reason": "단계와 완료 책임을 나타내는 그림이 있습니다."
    },
    {
      "anchor": "제출·준비·장치 처리·완료의 연결",
      "question": "정상 경로의 단계는 무엇입니까?",
      "visual_status": "적절",
      "reason": "준비, 장치 제출, 버퍼와 요청 완료를 연결합니다."
    },
    {
      "anchor": "접수 반환과 완료 알림",
      "question": "0 반환과 완료 알림은 어떻게 다릅니까?",
      "visual_status": "적절",
      "reason": "호출 예약과 완료 통지의 계약을 구분합니다."
    },
    {
      "anchor": "선두 요청을 전달하거나 반복을 멈추는 조건",
      "question": "대기열 전달은 언제 멈춥니까?",
      "visual_status": "적절",
      "reason": "큐 한도, 선두 준비 상태와 pop 순서를 보여 줍니다."
    },
    {
      "anchor": "void 전달 함수의 두 취소 경로",
      "question": "준비 취소와 장치 제출 실패는 어떻게 처리합니까?",
      "visual_status": "적절",
      "reason": "이미 취소된 요청과 장치 반환값의 분기를 구분합니다."
    },
    {
      "anchor": "버퍼 완료와 명시적 요청 완료의 경계",
      "question": "마지막 버퍼 완료가 요청을 자동 완료합니까?",
      "visual_status": "적절",
      "reason": "completeBuffer 반환과 명시적 completeRequest를 구분합니다."
    },
    {
      "anchor": "제출 큐의 선두 상태와 반환 순서",
      "question": "완료 요청은 언제 반환합니까?",
      "visual_status": "적절",
      "reason": "선두 상태 검사와 순서별 반환을 보여 줍니다."
    },
    {
      "anchor": "준비 대기와 재진입을 좁히기",
      "question": "준비 완료와 재진입은 어떻게 연결됩니까?",
      "visual_status": "적절",
      "reason": "fence, timeout, 준비 신호와 선행 pop을 연결하는 그림이 있습니다."
    },
    {
      "anchor": "준비 대기와 재진입을 좁히기 그림",
      "question": "준비 신호에서 전달까지 어떤 분기를 거칩니까?",
      "visual_status": "적절",
      "reason": "fence와 timeout 경로 및 큐 조건을 표시합니다."
    },
    {
      "anchor": "UVC의 장치 제출과 완료를 추적하기",
      "question": "UVC 제출 실패와 완료는 어떻게 구분합니까?",
      "visual_status": "적절",
      "reason": "제출 오류 취소와 bufferReady 이후 완료를 구분하는 그림이 있습니다. 제어 쓰기 오류의 부분 부작용은 본문에서 보완해야 합니다."
    },
    {
      "anchor": "UVC의 장치 제출과 완료를 추적하기 그림",
      "question": "제출 실패와 버퍼 알림은 어느 완료 경로로 이어집니까?",
      "visual_status": "적절",
      "reason": "취소 분기와 장치 알림 후 명시적 완료를 구분합니다."
    },
    {
      "anchor": "요청·버퍼·fence의 수명",
      "question": "각 자원의 소유와 재사용 조건은 무엇입니까?",
      "visual_status": "적절",
      "reason": "요청 소유와 fence 회수 및 재사용 조건을 각각 시각화합니다."
    },
    {
      "anchor": "요청과 버퍼를 유지할 기간",
      "question": "호출자와 핸들러의 수명 책임은 무엇입니까?",
      "visual_status": "적절",
      "reason": "버퍼 유지와 요청 삭제·접근 경계를 구분합니다."
    },
    {
      "anchor": "타임아웃 뒤 펜스 회수",
      "question": "timeout 뒤 버퍼를 다시 쓰려면 무엇을 해야 합니까?",
      "visual_status": "적절",
      "reason": "남은 fence와 releaseFence 선행 조건을 보여 줍니다."
    },
    {
      "anchor": "버퍼 재사용과 펜스 권고",
      "question": "ReuseBuffers와 fence의 범위는 어떻게 다릅니까?",
      "visual_status": "적절",
      "reason": "버퍼 재사용과 fence에 관한 should-not 권고를 구분합니다."
    },
    {
      "anchor": "버퍼 알림과 요청 반환의 내부 경계",
      "question": "신호와 내부 추적 갱신은 어떤 순서입니까?",
      "visual_status": "적절",
      "reason": "신호, pending 제거, 요청 완료와 선두 통지의 순서 그림이 있습니다."
    },
    {
      "anchor": "버퍼 알림과 요청 반환의 내부 경계 그림",
      "question": "버퍼 신호부터 요청 통지까지 무엇이 먼저 일어납니까?",
      "visual_status": "적절",
      "reason": "정상 완료 경로의 내부 순서와 상태 검사 조건을 표시합니다."
    },
    {
      "anchor": "콜백의 스레드와 재진입을 구분하기",
      "question": "연결 방식에 따라 콜백은 어디서 실행됩니까?",
      "visual_status": "적절",
      "reason": "Auto가 Direct 또는 Queued를 선택하는 분기를 그림으로 설명합니다. Blocking과 수명 조건은 본문에 있습니다."
    },
    {
      "anchor": "콜백의 스레드와 재진입을 구분하기 그림",
      "question": "Auto는 어떤 연결 방식을 선택합니까?",
      "visual_status": "적절",
      "reason": "현재 스레드와 수신 스레드의 비교를 표시합니다."
    },
    {
      "anchor": "정지와 연결 해제를 구분하기",
      "question": "정지 계약과 연결 해제는 어떻게 다릅니까?",
      "visual_status": "적절",
      "reason": "정지 순서, API 분기와 연결 해제 TODO를 별도 그림으로 다룹니다."
    },
    {
      "anchor": "정지할 때 대기 요청을 처리하는 순서",
      "question": "정상 정지는 어떤 순서로 진행됩니까?",
      "visual_status": "적절",
      "reason": "대기 큐 분리부터 장치 정지, 취소와 assertion을 표시합니다."
    },
    {
      "anchor": "정지 API 계약과 연결 해제 TODO",
      "question": "정지 계약과 연결 해제 TODO는 무엇입니까?",
      "visual_status": "적절",
      "reason": "두 원문의 범위를 구분합니다."
    },
    {
      "anchor": "Camera::stop의 미실행·오류·정상 경로",
      "question": "Camera::stop은 어떤 조건에서 반환합니까?",
      "visual_status": "적절",
      "reason": "미실행, 접근 오류와 정상 경로를 분기합니다."
    },
    {
      "anchor": "stopDevice 호출 구간의 관찰 계획",
      "question": "구현 진입과 복귀는 어떻게 조사합니까?",
      "visual_status": "적절",
      "reason": "호출 전 표시와 실제 구현 진입·복귀를 구분합니다."
    },
    {
      "anchor": "완료 통지의 호출자 의무와 반환 뒤 경계",
      "question": "완료 호출의 스레드와 접근 의무는 무엇입니까?",
      "visual_status": "적절",
      "reason": "호출 스레드, 제출 순서와 반환 후 접근 금지를 표시합니다."
    },
    {
      "anchor": "UVC 정지의 정상 경로와 실패 경계",
      "question": "STREAMOFF 실패는 정상 반환 경로와 어떻게 다릅니까?",
      "visual_status": "적절",
      "reason": "버퍼 반환 루프의 성공·실패 분기와 releaseBuffers 호출을 표시합니다."
    },
    {
      "anchor": "UVC 정지의 정상 경로와 실패 경계 그림",
      "question": "STREAMOFF 오류는 무엇을 건너뜁니까?",
      "visual_status": "적절",
      "reason": "오류 반환과 정상 버퍼 반환 루프를 구분합니다."
    },
    {
      "anchor": "변경 검토와 실행 확인",
      "question": "변경 전에 어떤 불변조건과 반례를 검사합니까?",
      "visual_status": "적절",
      "reason": "정상 완료와 bulk 취소의 추적 차이를 그림으로 설명하고 실패 사례는 본문에 명시합니다."
    },
    {
      "anchor": "정상 완료와 bulk 취소의 검증 위치",
      "question": "두 경로에서 pending_ 정리는 어떻게 다릅니까?",
      "visual_status": "적절",
      "reason": "개별 erase와 bulk clear 및 완료 assertion을 구분합니다."
    },
    {
      "anchor": "공개 가상 카메라의 콜백 관찰",
      "question": "과거 가상 프로브에서 무엇을 관찰했습니까?",
      "visual_status": "적절",
      "reason": "연결별 관측과 반환 근처 표식의 한계를 별도 그림으로 표시합니다."
    },
    {
      "anchor": "가상 CPU 프로브의 연결별 취소 콜백 표시",
      "question": "이 프로브의 취소 콜백 표식은 어디에 배치됐습니까?",
      "visual_status": "적절",
      "reason": "세 실행에 한정된 스레드와 애플리케이션 표식의 관계를 표시합니다."
    },
    {
      "anchor": "반환 근처 표시로 알 수 있는 범위",
      "question": "반환 근처 표식은 무엇을 증명하지 못합니까?",
      "visual_status": "적절",
      "reason": "후속 카운터·소멸과 실제 C++ 반환 추적의 한계를 표시합니다."
    },
    {
      "anchor": "소스 근거",
      "question": "인용 원문을 어디서 대조합니까?",
      "visual_status": "생략 가능",
      "reason": "출처별 원문과 해시를 제공하는 참조 목록입니다."
    }
  ],
  "unreviewed_scope": [
    "다른 파이프라인, IPA 및 커널 UVC 드라이버 구현은 제외 범위입니다.",
    "물리 UVC 캡처, DMA 정확성, 성능 및 내부 Camera HAL은 검증하지 않았습니다.",
    "실제 비저자 독자 평가와 전체 문서 집합의 시각 검토는 수행하지 않았습니다.",
    "src/libcamera/base/thread.cpp는 문서에 발췌가 제공됐지만 전체 소스 창은 제공되지 않았습니다. 과거 프로브의 원시 이벤트와 프로브 전체 코드도 제공되지 않아 요약 기록 범위에서만 대조했습니다."
  ]
}
