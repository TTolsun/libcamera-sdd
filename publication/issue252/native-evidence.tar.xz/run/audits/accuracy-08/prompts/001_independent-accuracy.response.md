{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "제출에서 완료까지; 준비 대기와 재진입을 좁히기; UVC의 장치 제출과 완료를 추적하기",
      "diagnosis_values": "Queued 메시지 처리 여부, waitingRequests_ 선두, prepared_, notifiers_, 300ms 타이머, queuedRequests_ 크기와 한도, 선두 요청 상태를 확인합니다.",
      "next_branch": "준비 취소 여부와 장치 제출 결과를 구분한 뒤 QBUF 및 DQBUF 분기를 확인합니다.",
      "change_validation": "재귀 호출 전에 pop하는 순서, 요청별 투입 횟수, 선두 차단과 완료 반환 순서를 검증합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1308-1383",
        "src/libcamera/pipeline_handler.cpp:428-620",
        "src/libcamera/request.cpp:192-312",
        "src/libcamera/v4l2_videodevice.cpp:1648-1987",
        "src/libcamera/base/object.cpp:258-284"
      ],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "UVC의 장치 제출과 완료를 추적하기; 변경 검토와 실행 확인",
      "diagnosis_values": "findBuffer 결과, processControl과 setControls 결과, error_idx, QBUF ret와 index, sequence_를 확인합니다.",
      "next_branch": "장치 제출의 음수 반환은 공통 cancelRequest로 이어지는지 확인하고, 제어 변경의 부작용을 별도로 조사합니다.",
      "change_validation": "제어 처리 실패와 제어 적용 후 QBUF 실패를 분리하고 취소, 큐 등록 및 반환 순서를 검증합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:327-470",
        "src/libcamera/v4l2_device.cpp:309-430",
        "src/libcamera/v4l2_videodevice.cpp:1648-1814",
        "src/libcamera/pipeline_handler.cpp:483-501"
      ],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "UVC의 장치 제출과 완료를 추적하기; 버퍼 알림과 요청 반환의 내부 경계",
      "diagnosis_values": "bufferCompleted 발생과 pending_ 제거, 버퍼 status, 요청 status, queuedRequests_ 선두를 확인합니다.",
      "next_branch": "DQBUF 실패와 예상 밖 인덱스를 반환된 FrameError 버퍼와 구분하고, UVC의 명시적 completeRequest 및 requestCompleted까지 추적합니다.",
      "change_validation": "버퍼 완료 횟수와 pending 제거, 요청 상태, 제출 순서 및 FrameError와 RequestComplete의 공존을 검증합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/v4l2_videodevice.cpp:1814-1987",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:893-905",
        "src/libcamera/pipeline_handler.cpp:547-620",
        "src/libcamera/request.cpp:91-139",
        "src/libcamera/camera.cpp:1475-1491"
      ],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "요청·버퍼·fence의 수명; 버퍼 알림과 요청 반환의 내부 경계; 콜백의 스레드와 재진입을 구분하기",
      "diagnosis_values": "요청 소유자, 버퍼와 fence 상태, pending_, FrameBuffer::request(), 지연 수신자의 마지막 포인터 사용을 확인합니다.",
      "next_branch": "직접 버퍼 콜백과 요청 완료 콜백을 구분하고, 타임아웃 시 releaseFence 및 별도 Queued 수신자 수명을 확인합니다.",
      "change_validation": "pending 정리 전 재연결, bulk 취소, 재사용 및 모든 지연 수신자의 마지막 사용을 검증합니다.",
      "answerable": false,
      "source_windows": [
        "src/libcamera/request.cpp:91-173",
        "src/libcamera/request.cpp:326-505",
        "src/libcamera/framebuffer.cpp:368-451",
        "src/libcamera/base/object.cpp:258-284",
        "src/libcamera/base/bound_method.cpp:68-108",
        "include/libcamera/base/signal.h:38-153"
      ],
      "missing": [
        "Queued 수신 실행이 Signal::emit 반환보다 먼저 일어날 수 있는 구현 경계를 정확히 설명해야 합니다."
      ]
    },
    {
      "id": "Q5",
      "answer_location": "정지와 연결 해제를 구분하기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "분리된 waitingRequests_, STREAMOFF ret, state_, cache_, queuedBuffers_, queuedRequests_, notifier 및 ASSERT 도달 여부를 확인합니다.",
      "next_branch": "STREAMOFF 실패의 조기 반환과 UVC의 releaseBuffers 호출을 추적하고, 잔존 notifier와 후속 DQBUF를 조사합니다.",
      "change_validation": "정상 정지, STREAMOFF 실패, releaseBuffers 실패를 나누어 완료 횟수, 순서, 잔존 큐 및 재투입을 검증합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp:1431-1475",
        "src/libcamera/pipeline_handler.cpp:359-414",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320-327",
        "src/libcamera/v4l2_videodevice.cpp:1616-1629",
        "src/libcamera/v4l2_videodevice.cpp:1814-1987",
        "src/libcamera/v4l2_videodevice.cpp:2023-2059"
      ],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "콜백의 스레드와 재진입을 구분하기; 정지와 연결 해제를 구분하기",
      "diagnosis_values": "수신자 종류, 연결 종류, 현재 및 수신 스레드, 이벤트 루프, 콜백 진입과 복귀를 확인합니다.",
      "next_branch": "Auto의 Direct 또는 Queued 분기와 Blocking 호출을 구분하고, 별도 Queued 수신자의 처리 및 수명을 조사합니다.",
      "change_validation": "직접 재진입, 호출자 동기화, 지연 수신자의 마지막 사용 및 stop 반환과 콜백 처리를 별도로 검증합니다.",
      "answerable": false,
      "source_windows": [
        "src/libcamera/base/bound_method.cpp:22-110",
        "include/libcamera/base/bound_method.h:59-209",
        "include/libcamera/base/signal.h:38-153",
        "src/libcamera/base/object.cpp:97-125",
        "src/libcamera/base/object.cpp:258-284",
        "Documentation/thread-safety.dox:1-46"
      ],
      "missing": [
        "명시적 Direct 연결의 예외와 Queued 실행 및 emit 반환 사이의 실제 시간 관계를 일반 설명과 그림에서 보존해야 합니다."
      ]
    },
    {
      "id": "Q7",
      "answer_location": "변경 검토와 실행 확인; 준비 대기와 재진입을 좁히기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "요청과 버퍼별 완료 횟수, pending_, sequence, 큐 상태, 실패 반환값 및 콜백 수명을 기록합니다.",
      "next_branch": "준비 취소, 제어 및 QBUF 실패, DQBUF 실패, FrameError, 정지 실패와 지연 수신을 각각 확인합니다.",
      "change_validation": "재귀 전 pop, 버퍼 중복 완료 부재, 요청 완료 전 pending 없음, 완료 후 접근 금지와 정지 중 재투입 여부를 검증합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp:359-620",
        "src/libcamera/request.cpp:91-312",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320-470",
        "src/libcamera/v4l2_videodevice.cpp:1616-2059",
        "src/libcamera/base/bound_method.cpp:22-110"
      ],
      "missing": []
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q4, Q6",
      "claim": "‘Queued 수신과 해제 시점의 책임’ 그림과 본문은 다른 스레드의 Object 슬롯이 Signal::emit() 반환 후 비동기로 호출된다고 조건 없이 설명합니다.",
      "counterevidence": "src/libcamera/base/signal.cpp:73-113의 일반 Doxygen 설명에는 반환 후라는 표현이 있지만, include/libcamera/base/signal.h:emit은 슬롯마다 activate를 호출하고 src/libcamera/base/bound_method.cpp:68-108의 Queued 분기는 메시지를 게시한 즉시 계속 진행합니다. 수신 스레드가 동시에 메시지를 처리하면 슬롯 실행이 발신자의 emit 반환 전에 시작될 수 있습니다. 또한 명시적 ConnectionTypeDirect는 서로 다른 스레드에서도 발신 스레드에서 동기 호출됩니다.",
      "fix": "일반 Doxygen 설명과 구현을 구분하고, Auto의 서로 다른 스레드 또는 명시적 Queued에 한정해 비동기 게시라고 설명합니다. emit 반환과 수신 실행의 선후 관계는 보장하지 않는다고 그림과 본문을 수정합니다."
    }
  ],
  "items": [
    {
      "anchor": "제출에서 완료까지",
      "question": "제출, 준비, 완료 및 반환 순서는 무엇입니까?",
      "visual_status": "그림 있음",
      "reason": "단계, 대기 조건, 취소, 버퍼 완료 및 제출 순서 반환을 각각 그림으로 표시합니다."
    },
    {
      "anchor": "제출·준비·장치 처리·완료의 연결",
      "question": "정상 경로의 단계는 어떻게 연결됩니까?",
      "visual_status": "그림 있음",
      "reason": "정상 경로로 범위를 한정한 흐름도입니다."
    },
    {
      "anchor": "접수 반환과 완료 알림",
      "question": "0 반환과 완료 알림은 어떻게 다릅니까?",
      "visual_status": "그림 있음",
      "reason": "접수 반환과 완료 통지의 경로를 구분합니다."
    },
    {
      "anchor": "선두 요청을 전달하거나 반복을 멈추는 조건",
      "question": "준비 상태와 큐 한도는 전달을 어떻게 제한합니까?",
      "visual_status": "그림 있음",
      "reason": "선두와 한도 검사 및 pop 순서를 표시합니다."
    },
    {
      "anchor": "void 전달 함수의 두 취소 경로",
      "question": "이미 취소된 요청과 장치 제출 실패는 어떻게 처리합니까?",
      "visual_status": "그림 있음",
      "reason": "두 취소 분기를 구분합니다."
    },
    {
      "anchor": "버퍼 완료와 명시적 요청 완료의 경계",
      "question": "마지막 버퍼 완료 뒤 누가 요청을 완료합니까?",
      "visual_status": "그림 있음",
      "reason": "completeBuffer 반환과 명시적 completeRequest를 구분합니다."
    },
    {
      "anchor": "제출 큐의 선두 상태와 반환 순서",
      "question": "완료 요청의 반환 반복은 언제 멈춥니까?",
      "visual_status": "그림 있음",
      "reason": "선두 상태 검사와 pop 및 통지 순서를 표시합니다."
    },
    {
      "anchor": "준비 대기와 재진입을 좁히기",
      "question": "fence와 타임아웃이 준비 및 전달에 어떻게 연결됩니까?",
      "visual_status": "그림 있음",
      "reason": "준비 신호, 큐 조건 및 재진입 전 pop을 표시합니다."
    },
    {
      "anchor": "UVC의 장치 제출과 완료를 추적하기",
      "question": "UVC 제출 실패와 버퍼 완료는 어떻게 구분됩니까?",
      "visual_status": "그림 있음",
      "reason": "취소와 bufferReady 이후 명시적 완료를 구분합니다."
    },
    {
      "anchor": "요청·버퍼·fence의 수명",
      "question": "누가 자원을 유지하고 언제 재사용합니까?",
      "visual_status": "그림 있음",
      "reason": "요청 소유권, 버퍼 유효 기간 및 fence 회수와 재사용 권고를 별도로 표시합니다."
    },
    {
      "anchor": "요청과 버퍼를 유지할 기간",
      "question": "요청 소유와 버퍼 유효성의 경계는 무엇입니까?",
      "visual_status": "그림 있음",
      "reason": "호출자의 책임과 완료 핸들러 및 파이프라인의 접근 경계를 표시합니다."
    },
    {
      "anchor": "타임아웃 뒤 펜스 회수",
      "question": "신호되지 않은 fence는 언제 회수합니까?",
      "visual_status": "그림 있음",
      "reason": "타임아웃 뒤 잔존 fence와 재사용 전 회수를 연결합니다."
    },
    {
      "anchor": "버퍼 재사용과 펜스 권고",
      "question": "ReuseBuffers의 범위와 권고는 무엇입니까?",
      "visual_status": "그림 있음",
      "reason": "버퍼와 fence의 재사용 범위를 구분합니다."
    },
    {
      "anchor": "버퍼 알림과 요청 반환의 내부 경계",
      "question": "신호, 내부 추적 갱신 및 요청 통지는 어떤 순서입니까?",
      "visual_status": "그림 있음",
      "reason": "신호 발생부터 pending 제거와 요청 상태 및 선두 검사까지 표시합니다."
    },
    {
      "anchor": "콜백의 스레드와 재진입을 구분하기",
      "question": "연결 종류와 포인터 수명은 어떻게 다릅니까?",
      "visual_status": "보완 필요",
      "reason": "Auto 분기 그림은 있으나 Queued 수명 그림이 emit 반환 후 실행을 무조건 보장합니다."
    },
    {
      "anchor": "Queued 수신과 해제 시점의 책임",
      "question": "지연 수신자의 포인터 수명은 어떻게 관리합니까?",
      "visual_status": "보완 필요",
      "reason": "그림이 서로 다른 스레드의 모든 Object 슬롯과 emit 반환 후 실행을 일반화합니다."
    },
    {
      "anchor": "정지와 연결 해제를 구분하기",
      "question": "정지 순서와 연결 해제 TODO는 어떻게 다릅니까?",
      "visual_status": "그림 있음",
      "reason": "정상 정지, API 분기, 관찰 계획 및 연결 해제 계약을 별도로 표시합니다."
    },
    {
      "anchor": "정지할 때 대기 요청을 처리하는 순서",
      "question": "정상 정지에서 대기 요청은 언제 취소합니까?",
      "visual_status": "그림 있음",
      "reason": "대기 큐 분리, 장치 정지 및 취소 반복을 표시합니다."
    },
    {
      "anchor": "정지 API 계약과 연결 해제 TODO",
      "question": "정지 계약과 연결 해제 TODO는 무엇입니까?",
      "visual_status": "그림 있음",
      "reason": "계약과 미완료 TODO를 구분합니다."
    },
    {
      "anchor": "Camera::stop의 미실행·오류·정상 경로",
      "question": "Camera::stop은 각 상태에서 어떻게 반환합니까?",
      "visual_status": "그림 있음",
      "reason": "실행 여부, 접근 검사 및 정상 경로를 표시합니다."
    },
    {
      "anchor": "stopDevice 호출 구간의 관찰 계획",
      "question": "호출 직전과 구현 진입 및 복귀는 어떻게 구분합니까?",
      "visual_status": "그림 있음",
      "reason": "관찰 계획과 미확정 원인을 표시합니다."
    },
    {
      "anchor": "완료 통지의 호출자 의무와 반환 뒤 경계",
      "question": "완료 통지의 스레드와 접근 의무는 무엇입니까?",
      "visual_status": "그림 있음",
      "reason": "호출 스레드, 순서 계약 및 반환 후 접근 금지를 표시합니다."
    },
    {
      "anchor": "UVC 정지의 정상 경로와 실패 경계",
      "question": "STREAMOFF 실패는 정상 반환 루프와 어떻게 다릅니까?",
      "visual_status": "그림 있음",
      "reason": "조기 반환과 버퍼 반환 루프 및 releaseBuffers 호출을 구분합니다."
    },
    {
      "anchor": "변경 검토와 실행 확인",
      "question": "정상 완료와 bulk 취소의 불변조건은 무엇입니까?",
      "visual_status": "그림 있음",
      "reason": "각 pending 정리 경로와 요청 완료 검사를 표시합니다."
    },
    {
      "anchor": "공개 가상 카메라의 콜백 관찰",
      "question": "가상 프로브에서 연결별 표식은 어떻게 관찰됐습니까?",
      "visual_status": "그림 있음",
      "reason": "연결별 정지 표식과 실제 C++ 반환을 추적하지 않은 한계를 별도로 표시합니다."
    },
    {
      "anchor": "가상 CPU 프로브의 연결별 취소 콜백 표시",
      "question": "취소 콜백 표식은 stop 표식과 어떻게 배치됐습니까?",
      "visual_status": "그림 있음",
      "reason": "세 실행의 연결별 관찰 범위를 표시합니다."
    },
    {
      "anchor": "반환 근처 표시로 알 수 있는 범위",
      "question": "반환 근처 표식으로 무엇을 증명할 수 있습니까?",
      "visual_status": "그림 있음",
      "reason": "후속 카운터 증가와 실제 반환 미추적을 구분합니다."
    },
    {
      "anchor": "소스 근거",
      "question": "문서에 인용된 원문은 어디에 있습니까?",
      "visual_status": "생략 가능",
      "reason": "접을 수 있는 원문과 출처 목록이 목적이므로 별도 그림이 필요하지 않습니다."
    }
  ],
  "unreviewed_scope": [
    "물리 UVC 캡처, DMA 정확성, 성능 및 내부 Camera HAL은 범위에서 제외되어 있습니다.",
    "실제 비저자 독자 평가와 사람의 의미 검토는 수행되지 않았습니다.",
    "src/libcamera/base/thread.cpp 전체와 프로브 원본 코드는 제공되지 않았으므로 해당 문서 발췌와 보존된 관찰 기록만 대조했습니다.",
    "다른 파이프라인, IPA 및 커널 UVC 드라이버 구현은 검토 범위 밖입니다."
  ]
}
