{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "「제출에서 완료까지」, 「준비 대기와 재진입을 좁히기」, 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "camera.cpp:1308의 Queued 호출 진입 여부, pipeline_handler.cpp:435의 waitingRequests_ 선두·prepared_·queuedRequests_ 크기와 한도, request.cpp:192의 notifiers_와 300ms 타이머를 확인합니다.",
      "next_branch": "준비 취소면 sequence 등록 후 completeRequest를, 장치 제출이면 QBUF와 DQBUF 및 queuedRequests_ 선두 상태를 확인합니다.",
      "change_validation": "미신호 fence와 큐 한도를 각각 시험하고, 재진입 전에 pop되는지와 요청별 투입 횟수 및 제출 순서 반환을 기록합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/camera.cpp", "src/libcamera/request.cpp", "src/libcamera/pipeline_handler.cpp", "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/v4l2_videodevice.cpp", "src/libcamera/base/object.cpp", "src/libcamera/base/event_notifier.cpp", "src/libcamera/base/timer.cpp", "src/libcamera/base/event_dispatcher_poll.cpp", "include/libcamera/internal/camera.h", "include/libcamera/internal/request.h", "include/libcamera/internal/pipeline_handler.h"],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "「UVC의 장치 제출과 완료를 추적하기」와 「변경 검토와 실행 확인」",
      "diagnosis_values": "uvcvideo.cpp:327, 427, 448의 변환 결과와 setControls ret, v4l2_device.cpp:309의 error_idx, v4l2_videodevice.cpp:1648의 cache·QBUF ret·index, pipeline_handler.cpp:483의 sequence를 확인합니다.",
      "next_branch": "findBuffer 실패 또는 반환된 음수는 공통 cancelRequest로 이어집니다. 개별 processControl 오류는 무시되며 cache 부재 Fatal은 일반 반환과 구분합니다.",
      "change_validation": "제어 쓰기 실패와 제어 처리 후 QBUF 실패를 분리하고, 이미 적용된 제어와 queuedBuffers_ 등록 여부 및 취소 통지를 기록합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/v4l2_device.cpp", "src/libcamera/v4l2_videodevice.cpp", "src/libcamera/pipeline_handler.cpp", "src/libcamera/request.cpp"],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "「버퍼 알림과 요청 반환의 내부 경계」와 「UVC의 장치 제출과 완료를 추적하기」",
      "diagnosis_values": "pipeline_handler.cpp:547의 emit과 pending 갱신 순서, request.cpp:103의 cancelled_·status, v4l2_videodevice.cpp:1814의 DQBUF ret·index·FrameError 및 queuedRequests_ 선두를 확인합니다.",
      "next_branch": "DQBUF가 null이면 bufferReady 없이 반환합니다. 유효 버퍼는 UVC의 completeBuffer와 명시적 completeRequest로 진행하며, 선두가 Pending이면 요청 통지가 대기합니다.",
      "change_validation": "DQBUF 오류와 미등록 인덱스, FrameError와 다른 취소 원인이 없는 RequestComplete를 각각 구분하고 버퍼별 완료 횟수와 요청 통지 순서를 확인합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/pipeline_handler.cpp", "src/libcamera/request.cpp", "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/v4l2_videodevice.cpp", "src/libcamera/framebuffer.cpp", "src/libcamera/camera.cpp"],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "「요청·버퍼·fence의 수명」, 「버퍼 알림과 요청 반환의 내부 경계」, 「Queued 수신과 해제 시점의 책임」",
      "diagnosis_values": "camera.cpp:1243의 요청 소유권, request.cpp:103, 139, 442의 pending·버퍼 수명과 fence, framebuffer.cpp:368의 request 포인터 유효 구간을 확인합니다.",
      "next_branch": "직접 버퍼 콜백에서는 이전 pending 정리가 남아 있습니다. 시간 초과로 남은 fence는 releaseFence로 회수하고, 지연 수신자의 마지막 사용은 별도로 동기화합니다.",
      "change_validation": "정상 완료와 일괄 취소를 구분해 연결 값과 실제 유효 기간을 확인하고, 각 Queued 수신자의 마지막 사용 전에 삭제하거나 재사용하지 않는지 검증합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/camera.cpp", "src/libcamera/request.cpp", "src/libcamera/framebuffer.cpp", "src/libcamera/pipeline_handler.cpp", "src/libcamera/base/object.cpp", "src/libcamera/base/signal.cpp", "src/libcamera/base/bound_method.cpp", "include/libcamera/internal/framebuffer.h"],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "「정지와 연결 해제를 구분하기」와 「UVC 정지의 정상 경로와 실패 경계」",
      "diagnosis_values": "pipeline_handler.cpp:359의 swap·두 ASSERT, camera.cpp:1431의 CameraStopping과 Blocking 호출, uvcvideo.cpp:320의 무시된 반환값, v4l2_videodevice.cpp:1616, 2023의 ret·state_·cache_·queuedBuffers_를 확인합니다.",
      "next_branch": "STREAMOFF 오류는 버퍼 반환과 notifier 비활성화 전에 반환하지만 UVC는 releaseBuffers를 호출합니다. 남은 알림과 알려진 DQBUF 인덱스가 있으면 null cache 접근 경계를 확인합니다.",
      "change_validation": "정상 정지, STREAMOFF 실패와 releaseBuffers 실패를 따로 기록하고 완료 횟수·순서·큐 잔존·ASSERT 도달 및 재투입 여부를 확인합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/camera.cpp", "src/libcamera/pipeline_handler.cpp", "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/v4l2_videodevice.cpp", "src/libcamera/request.cpp", "include/libcamera/internal/v4l2_videodevice.h"],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "「콜백의 스레드와 재진입을 구분하기」와 「정지와 연결 해제를 구분하기」",
      "diagnosis_values": "bound_method.cpp:68의 연결 종류와 송신·수신 스레드, thread.cpp:558, 613의 게시·필터·재귀 dispatch, camera.cpp:1431의 Blocking 호출을 확인합니다.",
      "next_branch": "Direct는 송신 스레드에서 동기 실행하고 Queued는 소비될 때 실행합니다. Blocking은 같은 스레드에서 Direct이고 다른 스레드에서는 해당 호출 완료를 기다립니다.",
      "change_validation": "각 수신자의 진입·복귀와 마지막 포인터 사용, 이벤트 루프 진행 및 호출자 상태 동기화를 기록합니다. stop 반환을 별도 Queued 수신자의 배출 완료로 간주하지 않습니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/base/bound_method.cpp", "src/libcamera/base/signal.cpp", "src/libcamera/base/object.cpp", "src/libcamera/base/thread.cpp", "src/libcamera/base/message.cpp", "src/libcamera/base/event_dispatcher_poll.cpp", "include/libcamera/base/signal.h", "include/libcamera/base/bound_method.h", "include/libcamera/base/thread.h", "include/libcamera/base/message.h", "Documentation/thread-safety.dox", "src/libcamera/camera.cpp", "src/libcamera/pipeline_handler.cpp"],
      "missing": []
    },
    {
      "id": "Q7",
      "answer_location": "「변경 검토와 실행 확인」의 두 그림과 실패 사례별 문단",
      "diagnosis_values": "pipeline_handler.cpp:435, 547의 pop·완료 순서, request.cpp:91, 139의 erase 횟수·pending과 bulk 취소, v4l2_videodevice.cpp:1648, 1814, 2023의 오류 분기를 확인합니다.",
      "next_branch": "준비 취소, 제어 및 QBUF 실패, DQBUF 오류·예상 밖 인덱스, FrameError, STREAMOFF와 releaseBuffers 실패를 각각 구분합니다.",
      "change_validation": "요청별 중복 투입과 버퍼별 중복 완료가 없고 완료 시 pending이 없으며 completeRequest 반환 후 접근하지 않는지 확인합니다. 정지 중 재투입과 지연 수신자의 수명도 별도로 기록합니다.",
      "answerable": true,
      "source_windows": ["src/libcamera/pipeline_handler.cpp", "src/libcamera/request.cpp", "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp", "src/libcamera/v4l2_videodevice.cpp", "src/libcamera/v4l2_device.cpp", "src/libcamera/camera.cpp", "src/libcamera/base/bound_method.cpp", "src/libcamera/base/signal.cpp", "Documentation/thread-safety.dox"],
      "missing": []
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "시각화 정확성",
      "claim": "「UVC 정지의 정상 경로와 실패 경계 그림」은 streamOff 분기 노드에서 releaseBuffers 노드로 직접 연결합니다.",
      "counterevidence": "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320은 streamOff가 반환된 후 releaseBuffers를 호출합니다. src/libcamera/v4l2_videodevice.cpp:2023에서는 그 반환 전에 STREAMOFF 오류 분기 또는 성공 시 버퍼 반환 루프를 거칩니다. 현재 그림에는 이 두 경로의 종료에서 releaseBuffers로 이어지는 연결이 없습니다.",
      "fix": "즉시 반환, STREAMOFF 오류 반환, 성공 반환 루프의 종료를 공통 streamOff 반환 노드로 연결한 후 releaseBuffers로 연결합니다."
    }
  ],
  "items": [
    {"anchor":"item-01","visual_status":"diagram","question":"제출부터 완료까지 어떻게 연결됩니까?","reason":"요청 단계 그림이 이 항목의 정상 경로를 표시합니다."},
    {"anchor":"item-02","visual_status":"diagram","question":"제출·준비·장치 처리·완료가 어떻게 연결됩니까?","reason":"단계와 정상 경로를 표시합니다."},
    {"anchor":"item-03","visual_status":"diagram","question":"접수 반환과 완료 알림은 어떻게 다릅니까?","reason":"반환과 별도 완료 통지 경로를 구분합니다."},
    {"anchor":"item-04","visual_status":"diagram","question":"언제 선두 요청을 전달합니까?","reason":"큐 한도와 준비 상태 분기를 표시합니다."},
    {"anchor":"item-05","visual_status":"diagram","question":"두 취소 경로는 어떻게 다릅니까?","reason":"사전 취소와 장치 제출 실패를 구분합니다."},
    {"anchor":"item-06","visual_status":"diagram","question":"버퍼 완료와 요청 완료는 어떻게 다릅니까?","reason":"반환값과 명시적 완료 의무를 표시합니다."},
    {"anchor":"item-07","visual_status":"diagram","question":"선두 상태가 반환 순서에 어떤 영향을 줍니까?","reason":"Pending 중단과 pop 후 통지를 표시합니다."},
    {"anchor":"item-08","visual_status":"diagram","question":"준비 대기와 재진입은 어디에서 조사합니까?","reason":"준비 완료 생산자와 재진입 전 pop을 연결합니다."},
    {"anchor":"item-09","visual_status":"diagram","question":"fence와 timeout 뒤 전달은 어떻게 진행됩니까?","reason":"준비 신호와 큐 검사 흐름을 표시합니다."},
    {"anchor":"item-10","visual_status":"diagram","question":"UVC 제출과 완료는 어디에서 갈라집니까?","reason":"제어, QBUF, 취소와 별도 완료 경로를 표시합니다."},
    {"anchor":"item-11","visual_status":"diagram","question":"제출 실패와 장치 완료를 어떻게 구분합니까?","reason":"UVC와 V4L2 경계의 분기를 표시합니다."},
    {"anchor":"item-12","visual_status":"diagram","question":"요청·버퍼·fence는 얼마나 유지합니까?","reason":"소유권과 fence 회수 그림이 각각의 수명 경계를 표시합니다."},
    {"anchor":"item-13","visual_status":"diagram","question":"요청과 버퍼를 누가 유지합니까?","reason":"호출자의 소유와 콜백 경계를 표시합니다."},
    {"anchor":"item-14","visual_status":"diagram","question":"시간 초과 뒤 fence를 어떻게 회수합니까?","reason":"잔존 fence와 재사용 전 회수 관계를 표시합니다."},
    {"anchor":"item-15","visual_status":"diagram","question":"ReuseBuffers와 fence 권고는 무엇입니까?","reason":"버퍼 재사용과 fence 권고를 구분합니다."},
    {"anchor":"item-16","visual_status":"diagram","question":"버퍼 신호와 내부 갱신은 어떤 순서입니까?","reason":"신호, pending 제거와 요청 반환을 연결합니다."},
    {"anchor":"item-17","visual_status":"diagram","question":"버퍼 알림 뒤 요청 반환까지 어떤 경계가 있습니까?","reason":"emit 반환, 내부 갱신과 선두 검사를 표시합니다."},
    {"anchor":"item-18","visual_status":"diagram","question":"콜백 스레드와 재진입은 어떻게 구분합니까?","reason":"연결 방식과 메시지 전달 경계 그림이 해당 질문을 다룹니다."},
    {"anchor":"item-19","visual_status":"diagram","question":"Auto는 Direct와 Queued를 어떻게 선택합니까?","reason":"현재 스레드와 수신 스레드 비교 분기를 표시합니다."},
    {"anchor":"item-20","visual_status":"diagram","question":"Queued 수신자의 포인터 수명은 누가 확인합니까?","reason":"발신자의 책임과 마지막 사용 확인 계획을 표시합니다."},
    {"anchor":"item-21","visual_status":"diagram","question":"Direct 중첩 호출과 Queued 수신은 어떻게 다릅니까?","reason":"동기 호출, 게시 및 내부 갱신 경계를 표시합니다."},
    {"anchor":"item-22","visual_status":"diagram","question":"정지와 연결 해제는 어떻게 다릅니까?","reason":"정지 순서와 연결 해제 TODO를 각각 표시합니다."},
    {"anchor":"item-23","visual_status":"diagram","question":"정지 중 대기 요청은 어떤 순서로 처리됩니까?","reason":"대기열 분리, 장치 정지와 취소 순서를 표시합니다."},
    {"anchor":"item-24","visual_status":"diagram","question":"정지 계약과 연결 해제 TODO는 무엇입니까?","reason":"계약과 TODO를 별도 경로로 표시합니다."},
    {"anchor":"item-25","visual_status":"diagram","question":"Camera::stop의 반환 분기는 무엇입니까?","reason":"미실행, 접근 오류와 정상 경로를 표시합니다."},
    {"anchor":"item-26","visual_status":"diagram","question":"stopDevice 호출에서 무엇을 관찰합니까?","reason":"호출 전, 구현 진입 및 복귀 관찰을 구분합니다."},
    {"anchor":"item-27","visual_status":"diagram","question":"완료 호출과 반환 뒤 의무는 무엇입니까?","reason":"호출 스레드, 반환 순서와 접근 금지 관계를 표시합니다."},
    {"anchor":"item-28","visual_status":"diagram","question":"UVC 정상 정지와 실패 경계는 무엇입니까?","reason":"해당 그림이 존재하지만 streamOff 반환과 releaseBuffers 연결에 수정이 필요합니다."},
    {"anchor":"item-29","visual_status":"diagram","question":"STREAMOFF 실패는 어떤 정리를 건너뜁니까?","reason":"실패와 버퍼 반환 루프를 표시하지만 releaseBuffers로 이어지는 반환 경계가 불완전합니다."},
    {"anchor":"item-30","visual_status":"diagram","question":"변경 전후 무엇을 검증합니까?","reason":"완료 불변조건과 실패 분기를 다루는 두 그림이 있습니다."},
    {"anchor":"item-31","visual_status":"diagram","question":"정상 완료와 일괄 취소의 검증 위치는 어디입니까?","reason":"서로 다른 pending 정리와 완료 검사를 표시합니다."},
    {"anchor":"item-32","visual_status":"diagram","question":"실패 주입 뒤 어느 분기를 확인합니까?","reason":"timeout, 제출, DQBUF와 STREAMOFF 사례를 표시합니다."},
    {"anchor":"item-33","visual_status":"diagram","question":"가상 콜백 관찰의 범위는 무엇입니까?","reason":"연결별 관찰과 반환 근처 표식의 한계를 표시합니다."},
    {"anchor":"item-34","visual_status":"diagram","question":"가상 프로브에서 취소 콜백 표식은 어디에 있었습니까?","reason":"세 실행의 연결별 표식 위치를 표시합니다."},
    {"anchor":"item-35","visual_status":"diagram","question":"반환 근처 표식으로 무엇을 알 수 있습니까?","reason":"후속 작업과 실제 반환 미추적을 표시합니다."},
    {"anchor":"item-36","visual_status":"omitted-with-reason","question":"인용한 소스 원문은 어디에서 확인합니까?","reason":"항목은 출처별 원문과 해시의 참조 목록이므로 별도 처리 그림이 필요하지 않습니다."}
  ],
  "unreviewed_scope": [
    "물리 UVC 촬영, DMA 정확성, 성능 및 내부 Camera HAL 검증은 범위 밖입니다.",
    "다른 파이프라인, IPA 처리와 커널 UVC 드라이버 구현은 범위 밖입니다.",
    "실제 비저자 독자 평가와 사람의 의미 검토는 수행되지 않았습니다."
  ]
}
