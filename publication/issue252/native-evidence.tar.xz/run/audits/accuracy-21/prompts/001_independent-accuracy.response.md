{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "‘제출에서 완료까지’, ‘준비 대기와 재진입을 좁히기’, ‘UVC의 장치 제출과 완료를 추적하기’",
      "diagnosis_values": "camera.cpp:1308의 게시 여부, pipeline_handler.cpp:435의 waitingRequests_ 선두·prepared_·queuedRequests_ 크기와 한도, request.cpp:192의 fence notifier·300ms timer·cancelled_, pipeline_handler.cpp:571의 선두 status를 확인합니다.",
      "next_branch": "메서드가 실행되지 않았다면 메시지 소비를 확인합니다. 실행되었다면 준비·한도 분기를 확인하고, 장치에 제출되었다면 QBUF와 DQBUF 및 완료 신호를 추적합니다.",
      "change_validation": "준비 취소와 재귀 호출에서 선두를 먼저 pop하는지, 요청이 중복 전달되지 않는지, 선두 Pending 때문에 후속 통지가 지연되는지 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/base/thread.cpp",
        "src/libcamera/base/event_dispatcher_poll.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q2",
      "answer_location": "‘UVC의 장치 제출과 완료를 추적하기’, ‘변경 검토와 실행 확인’",
      "diagnosis_values": "uvcvideo.cpp:427–470의 findBuffer·processControls·queueBuffer 반환값, v4l2_device.cpp:309의 error_idx, v4l2_videodevice.cpp:1648의 cache_·QBUF 결과와 index, pipeline_handler.cpp:483의 sequence를 확인합니다.",
      "next_branch": "버퍼가 없거나 제어 처리 또는 버퍼 큐잉이 음수를 반환하면 공통 cancelRequest로 이어집니다. cache_ 부재 Fatal은 정상적인 음수 반환과 구분합니다.",
      "change_validation": "개별 제어 변환 실패, 빈 제어 목록, 부분 제어 오류, 제어 적용 후 QBUF 실패를 각각 확인하고 제어 롤백을 가정하지 않습니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_device.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/pipeline_handler.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "‘UVC의 장치 제출과 완료를 추적하기’, ‘버퍼 알림과 요청 반환의 내부 경계’",
      "diagnosis_values": "pipeline_handler.cpp:547에서 bufferCompleted emit과 pending 제거 순서를, request.cpp:103에서 cancelled_와 status를, v4l2_videodevice.cpp:1814에서 DQBUF 결과·index·FrameError를 확인합니다.",
      "next_branch": "DQBUF 오류나 미등록 index는 bufferReady 없이 반환합니다. 유효 버퍼는 UVC의 completeBuffer 다음 completeRequest로 진행하며 선두 Pending이면 요청 통지가 대기합니다.",
      "change_validation": "FrameError와 RequestComplete가 함께 가능한 사례, 명시적 완료, pending 부재 및 제출 순서별 requestCompleted 신호를 각각 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/framebuffer.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "‘요청·버퍼·fence의 수명’, ‘버퍼 알림과 요청 반환의 내부 경계’, ‘Queued 수신과 해제 시점의 책임’",
      "diagnosis_values": "camera.cpp:1243의 요청 소유권, request.cpp:442–505의 버퍼 유효 기간·fence 소유권과 -EEXIST, request.cpp:103·139의 정상 완료와 일괄 취소 bookkeeping을 확인합니다.",
      "next_branch": "미신호 fence가 남으면 releaseFence로 회수합니다. 직접 버퍼 콜백의 재연결과 별도 Queued 수신자의 마지막 포인터 사용을 각각 확인합니다.",
      "change_validation": "요청 완료 전 재사용을 피하고, 각 지연 수신자의 마지막 사용과 버퍼 유효성을 동기화하며, completeRequest 반환 뒤 핸들러가 요청에 접근하지 않는지 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/framebuffer.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/base/object.cpp",
        "src/libcamera/base/signal.cpp"
      ],
      "missing": [
        "요청 소유권 그림은 재사용을 완료 콜백 경계에 연결하지 않습니다."
      ]
    },
    {
      "id": "Q5",
      "answer_location": "‘정지와 연결 해제를 구분하기’, ‘UVC 정지의 정상 경로와 실패 경계’",
      "diagnosis_values": "pipeline_handler.cpp:359의 대기 큐 swap·두 ASSERT, uvcvideo.cpp:320의 무시된 반환값, v4l2_videodevice.cpp:1616·2023의 STREAMOFF ret·state_·cache_·queuedBuffers_를 확인합니다.",
      "next_branch": "STREAMOFF 오류는 버퍼 반환 루프 전에 반환하지만 UVC는 releaseBuffers를 호출합니다. 잔존 notifier에서 DQBUF가 성공하면 index와 null cache 접근 조건을 확인합니다.",
      "change_validation": "정상 정지와 STREAMOFF·releaseBuffers 실패를 분리하여 콜백 횟수, 큐 잔존, ASSERT 도달, CameraStopping과 Configured 전이를 기록합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/camera.cpp",
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp"
      ],
      "missing": []
    },
    {
      "id": "Q6",
      "answer_location": "‘콜백의 스레드와 재진입을 구분하기’, ‘stop 반환과 별도 수신의 마지막 사용 확인’",
      "diagnosis_values": "bound_method.cpp:68의 연결 종류와 현재·수신 스레드, thread.cpp:613의 dispatch 필터와 재귀, camera.cpp:1431의 Blocking 호출 및 signal.cpp:73의 포인터 수명 계약을 확인합니다.",
      "next_branch": "Direct는 발신 스레드에서 동기 실행합니다. Queued는 게시 후 소비 여부를 확인하며, Blocking은 같은 스레드에서는 Direct이고 다른 스레드에서는 해당 호출의 세마포어를 기다립니다.",
      "change_validation": "콜백 진입·복귀와 별도 수신자의 마지막 사용을 stop 반환과 구분하고, 호출자 상태 동기화 및 허용되지 않은 중첩 호출을 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/base/bound_method.cpp",
        "src/libcamera/base/signal.cpp",
        "src/libcamera/base/thread.cpp",
        "src/libcamera/base/object.cpp",
        "src/libcamera/camera.cpp",
        "Documentation/thread-safety.dox"
      ],
      "missing": []
    },
    {
      "id": "Q7",
      "answer_location": "‘변경 검토와 실행 확인’, ‘준비 대기와 재진입을 좁히기’, ‘UVC 정지의 정상 경로와 실패 경계’",
      "diagnosis_values": "pipeline_handler.cpp:483–620의 pop·sequence·완료 순서, request.cpp:91–173의 erase 결과와 pending ASSERT, v4l2_videodevice.cpp:1648·1814·2023의 오류 분기를 확인합니다.",
      "next_branch": "준비 timeout, 제어 및 QBUF 실패, DQBUF 오류·예상 밖 index, FrameError, STREAMOFF·releaseBuffers 실패와 콜백 재진입을 분리합니다.",
      "change_validation": "버퍼별 단일 완료, 요청 완료 전 pending 없음, 완료 함수 반환 후 접근 금지, 정지 중 재투입 방지와 제출 순서 반환을 각 사례에서 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline_handler.cpp",
        "src/libcamera/request.cpp",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp",
        "src/libcamera/v4l2_videodevice.cpp",
        "src/libcamera/v4l2_device.cpp",
        "src/libcamera/camera.cpp"
      ],
      "missing": []
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q4",
      "claim": "‘요청과 버퍼를 유지할 기간’ 그림은 createRequest 소유자에서 Request 재사용으로 직접 연결하지만 완료 핸들러 경계를 연결하지 않습니다.",
      "counterevidence": "camera.cpp:1243–1263은 완료 핸들러에서 삭제하거나 상태를 초기화한 뒤 재사용하는 계약을 설명합니다. pipeline_handler.cpp:547–620은 완료 함수가 요청을 처리하는 동안의 경계를 제시합니다.",
      "fix": "완료 콜백에서 요청을 삭제하거나 reuse할 수 있도록 그림에 완료 경계를 연결하고, 별도 Queued 수신자의 마지막 사용이 남은 경우의 조건도 유지하세요."
    },
    {
      "blocking": true,
      "question": "Q2, Q7",
      "claim": "‘실패 주입별 다음 관찰 분기’ 그림의 영어 번역은 findBuffer 실패뿐 아니라 processControls 또는 queueBuffer의 음수 결과에도 -ENOENT를 반환한다고 읽힙니다.",
      "counterevidence": "uvcvideo.cpp:448–470은 findBuffer 실패에만 -ENOENT를 반환하며, 두 후속 함수의 음수 결과는 각각 원래 ret를 반환합니다. 한국어 그림 문구는 이 분기를 구분합니다.",
      "fix": "영어 번역에서 -ENOENT를 findBuffer 실패에만 한정하고, 나머지는 각 함수의 음수 반환값을 그대로 전달한다고 수정하세요."
    }
  ],
  "items": [
    {"anchor":"item-01","visual_status":"diagram","question":"제출에서 완료까지","reason":"요청 단계 그림이 정상 경로의 준비, 장치 처리 및 완료를 연결합니다."},
    {"anchor":"item-02","visual_status":"diagram","question":"제출·준비·장치 처리·완료의 연결","reason":"단계와 명시적 요청 완료를 흐름도로 표시합니다."},
    {"anchor":"item-03","visual_status":"diagram","question":"접수 반환과 완료 알림","reason":"0 반환과 완료 신호를 별도 경로로 표시합니다."},
    {"anchor":"item-04","visual_status":"diagram","question":"선두 요청을 전달하거나 반복을 멈추는 조건","reason":"준비 상태와 큐 한도의 분기를 표시합니다."},
    {"anchor":"item-05","visual_status":"diagram","question":"void 전달 함수의 두 취소 경로","reason":"기존 취소와 장치 제출 실패를 구분합니다."},
    {"anchor":"item-06","visual_status":"diagram","question":"버퍼 완료와 명시적 요청 완료의 경계","reason":"버퍼 완료 결과와 명시적 요청 완료를 구분합니다."},
    {"anchor":"item-07","visual_status":"diagram","question":"제출 큐의 선두 상태와 반환 순서","reason":"선두 상태 검사와 반환 반복을 표시합니다."},
    {"anchor":"item-08","visual_status":"diagram","question":"준비 대기와 재진입을 좁히기","reason":"준비 신호와 대기 큐 전달을 연결하는 그림이 있습니다."},
    {"anchor":"item-09","visual_status":"diagram","question":"준비 대기와 재진입을 좁히기 그림","reason":"fence·timeout·prepared 및 pop 전이를 표시합니다."},
    {"anchor":"item-10","visual_status":"diagram","question":"동시 제출의 순서를 관찰할 경계","reason":"호출 시작, 게시, 등록과 통지를 구분합니다."},
    {"anchor":"item-11","visual_status":"diagram","question":"같은 Poll 회차의 fence와 타이머 처리","reason":"notifier와 timer 처리의 조건부 순서를 표시합니다."},
    {"anchor":"item-12","visual_status":"diagram","question":"UVC의 장치 제출과 완료를 추적하기","reason":"UVC 제출·취소·장치 완료 그림이 질문에 대응합니다."},
    {"anchor":"item-13","visual_status":"diagram","question":"UVC의 장치 제출과 완료를 추적하기 그림","reason":"제어, QBUF, DQBUF와 완료 경로를 표시합니다."},
    {"anchor":"item-14","visual_status":"diagram","question":"요청·버퍼·fence의 수명","reason":"소유권과 완료 경계를 다루는 그림이 있으나 재사용 연결은 수정이 필요합니다."},
    {"anchor":"item-15","visual_status":"omitted-with-reason","question":"제출 성공 뒤에도 남는 수명 문제","reason":"게시 성공과 별도 완료 신호를 두 문장으로 구분하는 짧은 항목입니다."},
    {"anchor":"item-16","visual_status":"diagram","question":"소유권과 두 완료 경계","reason":"요청 소유자와 버퍼 유효성 및 핸들러 접근 경계를 표시하지만 재사용 시점 연결이 불완전합니다."},
    {"anchor":"item-17","visual_status":"diagram","question":"정상 완료와 다음 요청 준비","reason":"버퍼 알림, 내부 추적과 명시적 요청 완료 순서를 표시합니다."},
    {"anchor":"item-18","visual_status":"diagram","question":"알림 순서와 취소가 달라질 때","reason":"완료 상태와 선두 대기, fence 회수 및 재사용 권고를 별도 그림으로 설명합니다."},
    {"anchor":"item-19","visual_status":"diagram","question":"완료 책임을 변경하기 전에","reason":"호출 스레드, 반환 순서와 수명 계약의 확인 관계를 표시합니다."},
    {"anchor":"item-20","visual_status":"diagram","question":"버퍼 알림과 요청 반환의 내부 경계","reason":"신호부터 내부 갱신 및 요청 반환까지의 순서도가 있습니다."},
    {"anchor":"item-21","visual_status":"diagram","question":"버퍼 알림과 요청 반환의 내부 경계 그림","reason":"emit 반환, pending 제거, 상태 및 선두 검사를 표시합니다."},
    {"anchor":"item-22","visual_status":"diagram","question":"콜백의 스레드와 재진입을 구분하기","reason":"연결 종류와 별도 수신의 실행 경계를 질문별 그림으로 설명합니다."},
    {"anchor":"item-23","visual_status":"diagram","question":"콜백의 스레드와 재진입을 구분하기 그림","reason":"Auto의 Direct·Queued 선택을 표시합니다."},
    {"anchor":"item-24","visual_status":"diagram","question":"Queued 수신과 해제 시점의 책임","reason":"포인터 유효성과 별도 수신자의 마지막 사용 책임을 표시합니다."},
    {"anchor":"item-25","visual_status":"diagram","question":"직접 중첩 호출과 별도 Queued 수신의 경계","reason":"Direct 호출과 Queued 게시·dispatch 및 내부 갱신을 구분합니다."},
    {"anchor":"item-26","visual_status":"diagram","question":"stop 반환과 별도 수신의 마지막 사용 확인","reason":"Blocking 정지와 별도 수신자의 마지막 사용을 구분합니다."},
    {"anchor":"item-27","visual_status":"diagram","question":"정지와 연결 해제를 구분하기","reason":"정지 순서와 연결 해제 TODO를 각각 도식화합니다."},
    {"anchor":"item-28","visual_status":"diagram","question":"정지할 때 대기 요청을 처리하는 순서","reason":"대기 큐 분리, 장치 정지 및 취소 반복을 표시합니다."},
    {"anchor":"item-29","visual_status":"diagram","question":"정지 API 계약과 연결 해제 TODO","reason":"정지 계약과 연결 해제 TODO를 구분합니다."},
    {"anchor":"item-30","visual_status":"diagram","question":"Camera::stop의 미실행·오류·정상 경로","reason":"실행 상태와 접근 검사에 따른 반환 분기를 표시합니다."},
    {"anchor":"item-31","visual_status":"diagram","question":"stopDevice 호출 구간의 관찰 계획","reason":"호출 전, 구현 진입 및 복귀 관찰을 구분합니다."},
    {"anchor":"item-32","visual_status":"diagram","question":"완료 통지의 호출자 의무와 반환 뒤 경계","reason":"호출 스레드, 반환 순서와 반환 후 접근 금지를 연결합니다."},
    {"anchor":"item-33","visual_status":"diagram","question":"UVC 정지의 정상 경로와 실패 경계","reason":"STREAMOFF 성공·실패와 releaseBuffers 경로를 도식화합니다."},
    {"anchor":"item-34","visual_status":"diagram","question":"UVC 정지의 정상 경로와 실패 경계 그림","reason":"조기 반환, 오류, 버퍼 반환 및 UVC의 후속 호출을 표시합니다."},
    {"anchor":"item-35","visual_status":"diagram","question":"변경 검토와 실행 확인","reason":"완료 bookkeeping과 실패별 다음 분기를 각각 도식화합니다."},
    {"anchor":"item-36","visual_status":"diagram","question":"정상 완료와 bulk 취소의 검증 위치","reason":"두 경로의 pending 처리와 완료 ASSERT를 비교합니다."},
    {"anchor":"item-37","visual_status":"diagram","question":"실패 주입별 다음 관찰 분기","reason":"timeout, 제출, DQBUF 및 STREAMOFF 분기를 표시하지만 영어 번역에 반환값 오류가 있습니다."},
    {"anchor":"item-38","visual_status":"diagram","question":"공개 가상 카메라의 콜백 관찰","reason":"연결별 관찰 표식과 반환 근처 표식의 한계를 도식화합니다."},
    {"anchor":"item-39","visual_status":"diagram","question":"가상 CPU 프로브의 연결별 취소 콜백 표시","reason":"세 실행에서 관찰한 연결별 스레드와 표식 위치를 표시합니다."},
    {"anchor":"item-40","visual_status":"diagram","question":"반환 근처 표시로 알 수 있는 범위","reason":"표식 뒤 작업과 실제 C++ 반환 미추적을 구분합니다."},
    {"anchor":"item-41","visual_status":"omitted-with-reason","question":"소스 근거","reason":"출처별 원문과 해시를 제공하는 참조 목록이므로 별도 그림이 필요하지 않습니다."}
  ],
  "unreviewed_scope": [
    "물리 UVC 촬영, DMA 정확성, 성능 및 내부 Camera HAL 검증은 범위에서 제외되었습니다.",
    "실제 비저자 독자 평가와 사람 검토는 수행되지 않았습니다.",
    "보존된 가상 카메라 관찰과 별도 signal probe는 각각 기록된 과거 커밋과 제한된 시험 조건에만 적용됩니다."
  ]
}
