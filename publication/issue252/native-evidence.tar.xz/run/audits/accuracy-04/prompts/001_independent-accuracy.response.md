{
  "status": "needs-work",
  "human_review": "pending",
  "questions": [
    {
      "id": "Q1",
      "answer_location": "제출에서 완료까지; 준비 대기와 재진입을 좁히기; UVC의 장치 제출과 완료를 추적하기",
      "diagnosis_values": "queued 호출의 대상 스레드와 진입 여부, waitingRequests_ 선두의 prepared_와 notifiers_, 300ms 타이머, queuedRequests_ 크기와 한도 및 선두 상태",
      "next_branch": "준비 취소는 sequence 등록 후 공통 완료로, 준비 성공은 UVC 제출과 DQBUF 및 완료 신호로 추적합니다.",
      "change_validation": "fence timeout, 큐 한도, 선두 대기와 재귀 전달에서 pop 순서 및 중복 처리를 확인합니다. 정지와 교차하는 지연 제출도 별도로 확인해야 합니다.",
      "answerable": false,
      "source_windows": [
        "src/libcamera/camera.cpp:1-1491",
        "src/libcamera/pipeline_handler.cpp:1-1011",
        "src/libcamera/request.cpp:1-616",
        "src/libcamera/base/object.cpp:1-361"
      ],
      "missing": [
        "Camera::queueRequest의 메시지가 CameraStopping 설정 및 PipelineHandler::stop과 교차하는 경우의 상태와 후속 분기가 충분히 연결되지 않았습니다."
      ]
    },
    {
      "id": "Q2",
      "answer_location": "UVC의 장치 제출과 완료를 추적하기; 변경 검토와 실행 확인",
      "diagnosis_values": "findBuffer 결과, processControl 및 setControls 반환값과 error_idx, queueBuffer의 ret와 인덱스, sequence_ 및 queuedBuffers_",
      "next_branch": "음수 제출 결과는 cancelRequest로 이어집니다. 제어 적용 뒤 QBUF가 실패하면 제어 상태를 별도로 조사합니다.",
      "change_validation": "변환 오류 무시, 제어 쓰기 오류와 QBUF 실패를 구분하고 취소 및 순서별 통지를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:1-907",
        "src/libcamera/v4l2_device.cpp:1-1107",
        "src/libcamera/v4l2_videodevice.cpp:1-2257",
        "src/libcamera/pipeline_handler.cpp:1-1011"
      ],
      "missing": []
    },
    {
      "id": "Q3",
      "answer_location": "제출에서 완료까지; UVC의 장치 제출과 완료를 추적하기; 버퍼 알림과 요청 반환의 내부 경계",
      "diagnosis_values": "버퍼 metadata.status, pending_, request status, queuedRequests_ 선두 및 requestCompleted",
      "next_branch": "DQBUF 실패 또는 예상 밖 인덱스는 알림 없이 반환합니다. 유효 버퍼는 UVC의 completeBuffer와 completeRequest로 이어집니다.",
      "change_validation": "FrameError와 RequestComplete를 따로 기록하고 선두 대기, 버퍼별 완료 횟수 및 제출 순서를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/v4l2_videodevice.cpp:1-2257",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:1-907",
        "src/libcamera/request.cpp:1-616",
        "src/libcamera/pipeline_handler.cpp:1-1011",
        "src/libcamera/camera.cpp:1-1491"
      ],
      "missing": []
    },
    {
      "id": "Q4",
      "answer_location": "요청·버퍼·fence의 수명; 버퍼 알림과 요청 반환의 내부 경계; 콜백의 스레드와 재진입을 구분하기",
      "diagnosis_values": "요청과 버퍼 소유자, fence 잔존 여부, pending_과 버퍼의 request 연결, 연결 종류와 지연된 포인터 수명",
      "next_branch": "타임아웃 후 남은 fence는 releaseFence로 회수합니다. 직접 버퍼 콜백과 요청 완료 콜백의 경계를 구분합니다.",
      "change_validation": "직접 콜백에서의 재연결, 취소 경로 및 Queued 수신자의 포인터 수명을 각각 검사합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/request.cpp:1-616",
        "src/libcamera/framebuffer.cpp:1-451",
        "src/libcamera/pipeline_handler.cpp:1-1011",
        "src/libcamera/base/object.cpp:1-361",
        "src/libcamera/base/signal.cpp:1-205"
      ],
      "missing": []
    },
    {
      "id": "Q5",
      "answer_location": "정지와 연결 해제를 구분하기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "분리된 waitingRequests_, STREAMOFF ret, state_, queuedBuffers_, cache_, releaseBuffers 결과 및 각 ASSERT",
      "next_branch": "STREAMOFF 오류는 버퍼 반환 루프를 건너뛰지만 UVC는 releaseBuffers를 호출합니다. 남은 notifier와 큐의 후속 처리도 조사해야 합니다.",
      "change_validation": "정상 정지, STREAMOFF 실패와 REQBUFS 실패를 분리하고 큐 잔존, 알림 및 재투입을 확인합니다.",
      "answerable": false,
      "source_windows": [
        "src/libcamera/camera.cpp:1-1491",
        "src/libcamera/pipeline_handler.cpp:1-1011",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:1-907",
        "src/libcamera/v4l2_videodevice.cpp:1-2257"
      ],
      "missing": [
        "STREAMOFF 실패 후 cache_가 reset된 상태에서 남은 queuedBuffers_와 활성 notifier가 후속 DQBUF 경로에 미치는 구체적인 영향이 빠졌습니다."
      ]
    },
    {
      "id": "Q6",
      "answer_location": "콜백의 스레드와 재진입을 구분하기; 정지와 연결 해제를 구분하기; 공개 가상 카메라의 콜백 관찰",
      "diagnosis_values": "현재 및 수신 스레드, 연결 종류, 이벤트 루프 진행, 콜백 진입·복귀와 별도 수신자 처리 표식",
      "next_branch": "Auto는 스레드 비교로 Direct 또는 Queued를 선택합니다. Blocking 반환과 별도 Queued 콜백 처리를 구분합니다.",
      "change_validation": "호출자 동기화와 직접 재진입, 지연 포인터 수명 및 수신자별 처리 완료를 확인합니다.",
      "answerable": true,
      "source_windows": [
        "src/libcamera/base/bound_method.cpp:1-110",
        "include/libcamera/base/bound_method.h:1-209",
        "include/libcamera/base/signal.h:1-153",
        "src/libcamera/base/signal.cpp:1-205",
        "src/libcamera/base/object.cpp:1-361",
        "Documentation/thread-safety.dox:1-46",
        "src/libcamera/camera.cpp:1-1491"
      ],
      "missing": []
    },
    {
      "id": "Q7",
      "answer_location": "변경 검토와 실행 확인; 준비 대기와 재진입을 좁히기; UVC 정지의 정상 경로와 실패 경계",
      "diagnosis_values": "cookie, sequence, pop 순서, pending_, 버퍼별·요청별 신호 횟수, 큐 잔존 및 정지 후 재투입",
      "next_branch": "정상 완료와 bulk 취소를 구분하고 fence, 제어, QBUF, DQBUF 및 정지 실패를 각각 조사합니다.",
      "change_validation": "버퍼 중복 완료 부재, 완료 시 pending 부재, 완료 반환 후 접근 금지 및 정지 중 재투입 방지를 확인합니다. 지연 제출과 실패 후 DQBUF도 추가해야 합니다.",
      "answerable": false,
      "source_windows": [
        "src/libcamera/request.cpp:1-616",
        "src/libcamera/pipeline_handler.cpp:1-1011",
        "src/libcamera/camera.cpp:1-1491",
        "src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:1-907",
        "src/libcamera/v4l2_videodevice.cpp:1-2257",
        "src/libcamera/base/object.cpp:1-361"
      ],
      "missing": [
        "정지와 교차하는 queued 제출 및 STREAMOFF 실패 후 잔존 notifier의 DQBUF에 대한 검증 조건이 없습니다."
      ]
    }
  ],
  "findings": [
    {
      "blocking": true,
      "question": "Q1, Q5, Q7",
      "claim": "지연된 queueRequest 호출과 정지의 교차를 기록하도록 안내하지만, 정지 후 대상 메서드가 실행되는 구체적인 분기는 설명하지 않습니다.",
      "counterevidence": "src/libcamera/camera.cpp:1308-1383은 Running 검사 후 ConnectionTypeQueued로 포인터를 전달하며 상태가 함수 도중 변할 수 있다고 명시합니다. src/libcamera/pipeline_handler.cpp:435-480의 queueRequest는 CameraStopping을 다시 검사하지 않고 waitingRequests_에 추가해 prepare합니다. 같은 파일:359-402의 stop은 그 시점의 waitingRequests_만 분리합니다.",
      "fix": "queued 메시지의 게시·실행과 CameraStopping 및 stop의 상대 순서를 조사하고, stop 이후 전달되는 경우의 준비·장치 제출·완료 상태 검사를 별도 반례와 변경 검증 조건으로 추가하세요. 실행 순서나 성공을 보장하지 마세요."
    },
    {
      "blocking": true,
      "question": "Q5, Q7",
      "claim": "STREAMOFF 실패 후 큐와 알림 상태를 확인하라고만 하여, 남은 알림이 처리될 때 필요한 다음 분기를 제시하지 않습니다.",
      "counterevidence": "src/libcamera/v4l2_videodevice.cpp:2023-2059에서 STREAMOFF 실패는 queuedBuffers_ 정리와 notifier 비활성화 전에 반환합니다. src/libcamera/pipeline/uvcvideo/uvcvideo.cpp:320-325는 반환값을 무시하고 releaseBuffers를 호출하며, v4l2_videodevice.cpp:1616-1629는 cache_를 reset합니다. 같은 파일:1814-1987의 dequeueBuffer는 알려진 인덱스를 찾은 뒤 cache_->put을 호출합니다.",
      "fix": "실패 후 queuedBuffers_와 notifier가 남고 cache_가 제거될 수 있음을 명시하세요. 이후 알려진 인덱스의 DQBUF가 발생하면 null cache 접근 가능성을 조사 대상으로 연결하고, ASSERT나 장치 오류의 Camera::stop 반환 전파를 보장하지 않는 조건에서 검증하세요."
    }
  ],
  "items": [
    {
      "anchor": "제출에서 완료까지",
      "question": "제출부터 완료까지의 경로는 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "준비, 장치 제출, 버퍼 완료와 요청 반환을 연결합니다."
    },
    {
      "anchor": "제출·준비·장치 처리·완료의 연결",
      "question": "정상 경로의 단계는 어떻게 연결됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "정상 경로로 범위를 한정하고 명시적 요청 완료를 표시합니다."
    },
    {
      "anchor": "접수 반환과 완료 알림",
      "question": "0 반환과 완료 알림은 무엇이 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "호출 반환과 별도 완료 통지 계약을 구분합니다."
    },
    {
      "anchor": "선두 요청을 전달하거나 반복을 멈추는 조건",
      "question": "대기열 전달은 언제 멈춥니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "큐 한도, 선두 준비와 pop 순서를 표시합니다."
    },
    {
      "anchor": "void 전달 함수의 두 취소 경로",
      "question": "이미 취소된 요청과 제출 실패는 어떻게 처리됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "두 취소 분기와 함수 반환을 구분합니다."
    },
    {
      "anchor": "버퍼 완료와 명시적 요청 완료의 경계",
      "question": "마지막 버퍼 완료 뒤 무엇이 필요합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "completeBuffer 결과와 별도 completeRequest 호출을 구분합니다."
    },
    {
      "anchor": "제출 큐의 선두 상태와 반환 순서",
      "question": "완료 요청은 언제 반환됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "선두 Pending 분기, ASSERT 및 pop 후 통지를 표시합니다."
    },
    {
      "anchor": "준비 대기와 재진입을 좁히기",
      "question": "준비 생산자와 재귀 전달은 어떻게 연결됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "fence와 timeout에서 prepared 신호 및 pop 전후를 연결합니다."
    },
    {
      "anchor": "준비 대기와 재진입을 좁히기 그림",
      "question": "준비 완료는 어떻게 전달됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "fence와 timeout 경로 및 선두 전달 조건을 표시합니다."
    },
    {
      "anchor": "uvc의-장치-제출과-완료를-추적하기",
      "question": "UVC 제출 실패와 완료는 어떻게 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "제출 취소와 버퍼 알림에서 명시적 완료까지의 경로를 구분합니다."
    },
    {
      "anchor": "UVC의 장치 제출과 완료를 추적하기 그림",
      "question": "UVC 취소와 완료 경로는 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "장치 제출 결과와 bufferReady 후 완료 경로를 표시합니다."
    },
    {
      "anchor": "요청버퍼fence의-수명",
      "question": "요청, 버퍼와 fence는 누가 유지합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "소유권, fence 회수와 재사용 권고를 각각 다룹니다."
    },
    {
      "anchor": "요청과 버퍼를 유지할 기간",
      "question": "요청과 버퍼의 유지 책임은 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "호출자의 책임과 핸들러의 반환 후 접근 경계를 표시합니다."
    },
    {
      "anchor": "타임아웃 뒤 펜스 회수",
      "question": "타임아웃 후 fence는 어떻게 회수합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "남은 fence와 다른 요청에서 재사용하기 위한 회수 조건을 표시합니다."
    },
    {
      "anchor": "버퍼 재사용과 펜스 권고",
      "question": "ReuseBuffers와 fence 권고는 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "버퍼 재사용과 fence를 사용하지 말라는 권고의 수준을 구분합니다."
    },
    {
      "anchor": "버퍼 알림과 요청 반환의 내부 경계",
      "question": "버퍼 신호와 내부 정리는 어떤 순서입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "신호, pending 제거 및 요청 완료의 순서를 표시합니다."
    },
    {
      "anchor": "버퍼 알림과 요청 반환의 내부 경계 그림",
      "question": "버퍼 신호 뒤 요청 반환까지 어떤 검사가 있습니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "직접 신호 후 내부 추적 갱신과 선두 검사를 표시합니다."
    },
    {
      "anchor": "콜백의 스레드와 재진입을 구분하기",
      "question": "연결 종류에 따라 콜백은 어디서 실행됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "Auto의 Direct·Queued 선택을 표시하며 Blocking은 본문에서 구분합니다."
    },
    {
      "anchor": "콜백의 스레드와 재진입을 구분하기 그림",
      "question": "Auto는 어떤 연결 방식을 선택합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "현재 스레드와 수신 객체 스레드의 비교를 표시합니다."
    },
    {
      "anchor": "정지와 연결 해제를 구분하기",
      "question": "정지와 연결 해제의 계약은 무엇이 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "정상 정지 순서, API 분기와 연결 해제 TODO를 별도로 표시합니다."
    },
    {
      "anchor": "정지할 때 대기 요청을 처리하는 순서",
      "question": "정상 정지에서 요청은 어떤 순서로 처리됩니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "대기 큐 분리, 장치 정지, 취소와 ASSERT 위치를 표시합니다."
    },
    {
      "anchor": "정지 API 계약과 연결 해제 TODO",
      "question": "정지 계약과 연결 해제 TODO는 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "두 원문의 범위를 구분합니다."
    },
    {
      "anchor": "Camera::stop의 미실행·오류·정상 경로",
      "question": "Camera::stop은 어떤 경로로 반환합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "실행 상태, 접근 검사와 정상 경로를 구분합니다."
    },
    {
      "anchor": "stopDevice 호출 구간의 관찰 계획",
      "question": "장치 정지의 진입과 복귀는 어떻게 조사합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "호출 전 표식과 구현 진입·복귀 관찰을 구분합니다."
    },
    {
      "anchor": "완료 통지의 호출자 의무와 반환 뒤 경계",
      "question": "완료 호출자의 의무는 무엇입니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "호출 스레드, 제출 순서와 반환 후 접근 금지를 표시합니다."
    },
    {
      "anchor": "UVC 정지의 정상 경로와 실패 경계",
      "question": "STREAMOFF 실패는 정상 정지와 어떻게 다릅니까?",
      "visual_status": "보완 필요",
      "reason": "반환 루프 생략과 releaseBuffers 호출은 표시하지만 실패 후 남은 큐·notifier와 제거된 cache의 후속 DQBUF 경계는 빠졌습니다."
    },
    {
      "anchor": "UVC 정지의 정상 경로와 실패 경계 그림",
      "question": "STREAMOFF 오류 뒤 어느 경로를 건너뜁니까?",
      "visual_status": "보완 필요",
      "reason": "오류 후 releaseBuffers와 잔존 notifier의 후속 분기를 독립적으로 보여 주지 않습니다."
    },
    {
      "anchor": "변경 검토와 실행 확인",
      "question": "변경 전후 어떤 불변조건을 검사합니까?",
      "visual_status": "보완 필요",
      "reason": "정상 완료와 bulk 취소 그림은 있으나 정지와 교차하는 지연 제출 및 실패 후 DQBUF 반례는 검증 경로에 없습니다."
    },
    {
      "anchor": "정상 완료와 bulk 취소의 검증 위치",
      "question": "두 경로의 pending 정리는 어떻게 다릅니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "개별 erase와 bulk clear 및 완료 ASSERT를 구분합니다."
    },
    {
      "anchor": "공개 가상 카메라의 콜백 관찰",
      "question": "가상 프로브에서 무엇이 관찰되었습니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "연결별 표식과 반환 근처 표식의 한계를 별도로 표시합니다."
    },
    {
      "anchor": "가상 CPU 프로브의 연결별 취소 콜백 표시",
      "question": "취소 콜백 표식과 stop 표식은 어떻게 배치됐습니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "세 가상 실행에 한정된 연결별 표식 순서를 표시합니다."
    },
    {
      "anchor": "반환 근처 표시로 알 수 있는 범위",
      "question": "반환 근처 표식은 무엇을 증명합니까?",
      "visual_status": "적절한 그림 있음",
      "reason": "후속 작업과 실제 C++ 반환 미추적을 구분합니다."
    },
    {
      "anchor": "소스 근거",
      "question": "설명에 사용한 원문은 어디에 있습니까?",
      "visual_status": "생략 가능",
      "reason": "항목은 소스 발췌와 출처를 제공하며 별도의 처리 질문이 아닙니다."
    }
  ],
  "unreviewed_scope": [
    "다른 파이프라인, IPA 처리 및 커널 UVC 드라이버 구현",
    "물리 UVC 캡처, DMA 정확성, 성능 및 사내 Camera HAL 검증",
    "실제 비작성자 독자 평가와 사람의 의미 검토",
    "제공되지 않은 request-diagnosis.md의 내용과 링크 대상",
    "새 런타임 실행 및 전체 문서 집합의 수용 여부"
  ]
}
