"""Prewarm isolated normal contract audits and collect verified native checkpoints."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

import yaml

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
RUN = WORK / 'run'
sys.path.insert(0, str(ROOT / 'src'))
from sdd.cli_checkpoint import UnitStore
from sdd.config import load
from sdd.consistency import batches, groups, policy_hash, request, review_store
from sdd.execution_lock import alive
from sdd.facts.model import KnowledgeModel
from sdd.validation_stage import stage


def require_idle(cfg):
    lock = cfg.build_dir / 'execution-locks/consistency.json'
    if lock.is_file():
        record = json.loads(lock.read_bytes())
        if record.get('status') == 'running' and any(alive(record.get(key)) for key in ('owner_pid', 'worker_pid')):
            raise ValueError('The contract audit is still running: ' + str(cfg.root))


def copy_verified(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_file():
        if source.read_bytes() != destination.read_bytes():
            raise ValueError('Original native archive conflict: ' + str(destination))
    else:
        shutil.copyfile(source, destination)


def transfer(source, destination, names=None, retained=None):
    count = 0
    for path in (source.build_dir / 'cli-checkpoints').glob('*.json'):
        if names is not None and path.name not in names:
            continue
        identity = json.loads(path.read_bytes())['payload']['identity']
        if identity.get('purpose') != 'cross-document-consistency' or identity.get('policy') != policy_hash():
            continue
        store = UnitStore(source, identity)
        assert store.path == path
        saved, _ = store.read()
        origin, target = [cfg.build_dir / 'prompts' for cfg in (source, destination)]
        for name in saved['receipts']:
            receipt = origin / 'calls' / name
            provider = json.loads(receipt.read_bytes())['provider']
            stem = receipt.name.removesuffix('.receipt.json')
            for suffix in ('.receipt.json', '.request.json', '.response.txt'):
                file = receipt.with_name(stem + suffix)
                copy_verified(file, target / file.relative_to(origin))
            for key in ('stdout_path', 'stderr_path'):
                if relative := provider.get(key):
                    file = origin / relative
                    if file.is_file():
                        copy_verified(file, target / relative)
        target_checkpoint = destination.build_dir / 'cli-checkpoints' / path.name
        if retained is not None and target_checkpoint.is_file() and target_checkpoint.read_bytes() != path.read_bytes():
            existing_store = UnitStore(destination, identity)
            assert existing_store.path == target_checkpoint
            existing, _ = existing_store.read()
            verdicts = lambda value: [(row['claim_id'], row['status']) for row in value['statements']]
            assert existing['identity'] == saved['identity'] and verdicts(existing) == verdicts(saved), path.name
            retained.append(dict(key=path.name, existing_receipts=existing['receipts'],
                                 alternate_native_receipts=saved['receipts'], same_input_and_verdicts=True))
        else:
            copy_verified(path, target_checkpoint)
        count += 1
    return count


def execute(profile):
    folder = profile.parent
    cfg = load(profile)
    stdout = cfg.build_dir / 'prompts/cli'
    report = cfg.build_dir / 'consistency-review.json'
    print('Started', folder.name, flush=True)
    for attempt in range(1, 4):
        earlier = set(stdout.glob('*.stdout.txt'))
        output = folder / f'audit-attempt-{attempt}.log'
        with output.open('xb') as stream:
            result = subprocess.run([sys.executable, '-X', 'utf8', str(ROOT / 'tools/run_sdd.py'),
                                     '--config', str(profile), 'audit-consistency'], cwd=ROOT,
                                    stdout=stream, stderr=subprocess.STDOUT)
        if result.returncode == 0 or not report.is_file():
            break
        state = json.loads(report.read_bytes())
        if state['status'] != 'incomplete':
            break
        recent = set(stdout.glob('*.stdout.txt')) - earlier
        if not recent:
            break
        last = max(recent, key=lambda path: path.stat().st_mtime)
        failure = last.read_text(encoding='utf-8', errors='replace')
        if '403 Forbidden' not in failure or attempt == 3:
            break
        copy_verified(report, folder / f'interrupted-report-{attempt}.json')
        print('Retrying', folder.name, 'from saved checkpoints after transient CLI connection failure', flush=True)
        time.sleep(25 * attempt)
    print('Ended', folder.name, 'exit', result.returncode, flush=True)
    return result.returncode


def main():
    base_profile = RUN / 'contract-review.yaml'
    base = load(base_profile)
    require_idle(base)
    attempt = sys.argv[1] if len(sys.argv) == 2 else '07'
    assert len(attempt) == 2 and attempt.isdecimal()
    top = WORK / ('parallel-standard-audit-' + attempt)
    top.mkdir()
    raw = yaml.safe_load(base_profile.read_bytes())
    contracts = yaml.safe_load(base.paths['consistency_file'].read_bytes())
    required = {}
    with stage() as inputs:
        inputs.pin(base)
        model = KnowledgeModel.load(base.facts_path)
        for group in groups(base):
            payload = request(base, model, group)
            required[group['id']] = {review_store(base, batch)[0].path.name
                                     for batch in batches(payload, max_input_chars=base.agent.max_input_chars)}
    profiles = []
    for group in contracts['contracts']:
        folder = top / group['id']
        folder.mkdir()
        contract = folder / 'contracts.yaml'
        contract.write_text(yaml.safe_dump({'contracts': [group]}, allow_unicode=True, sort_keys=False), encoding='utf-8')
        settings = deepcopy(raw)
        settings['output'].update(facts_dir=str(base.facts_dir), sdd_dir=str(base.sdd_dir),
                                  diagrams_dir=str(base.diagrams_dir))
        settings['paths']['consistency_file'] = str(contract)
        settings['publication']['operation_id'] = 'issue252-current-standard-' + group['id']
        profile = folder / 'audit.yaml'
        profile.write_text(yaml.safe_dump(settings, allow_unicode=True, sort_keys=False), encoding='utf-8')
        worker = load(profile)
        assert worker.sdd_dir == base.sdd_dir and worker.facts_path == base.facts_path
        assert worker.agent.label == base.agent.label and worker.agent.args == base.agent.args
        seeded = transfer(base, worker, required[group['id']])
        print('Planned', group['id'], 'current batches', len(required[group['id']]),
              'verified exact checkpoints', seeded, flush=True)
        profiles.append(profile)

    profiles.sort(key=lambda profile: len(required[profile.parent.name]), reverse=True)
    exits = {}
    with ThreadPoolExecutor(max_workers=3 if int(attempt) >= 9 else 4) as pool:
        submitted = {pool.submit(execute, profile): profile for profile in profiles}
        for future in as_completed(submitted):
            exits[submitted[future]] = future.result()

    require_idle(base)
    rows = []
    for profile in profiles:
        worker = load(profile)
        require_idle(worker)
        report_path = worker.build_dir / 'consistency-review.json'
        report = json.loads(report_path.read_bytes()) if report_path.is_file() else {}
        rows.append(dict(group=profile.parent.name, exit_code=exits[profile], status=report.get('status'),
                         fresh=report.get('fresh_batches'), reused=report.get('reused_batches'),
                         unresolved=len(report.get('unresolved', [])),
                         checkpoint_count=transfer(worker, base),
                         audit_run=report.get('audit_run'), report_sha256=hashlib.sha256(report_path.read_bytes()).hexdigest()
                         if report_path.is_file() else None))
    (RUN / (top.name + '.json')).write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8')
    if any(row['status'] not in ('passed', 'failed') or not row['audit_run'] for row in rows):
        raise SystemExit('Some grouped audits are incomplete; original records and valid checkpoints are preserved.')
    print('Collected current-policy authenticated native checkpoints:', sum(row['checkpoint_count'] for row in rows), flush=True)


if __name__ == '__main__':
    main()
