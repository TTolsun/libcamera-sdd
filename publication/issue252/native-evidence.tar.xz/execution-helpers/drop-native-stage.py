from pathlib import Path
import re,yaml
for path in [Path('examples/libcamera/config/visuals.yaml'),Path('build/issue252/run/config/visuals.yaml'),Path('examples/libcamera/validation/issue252/visual-amendments.yaml')]:
 text=path.read_text(encoding='utf-8');updated,count=re.subn(r'(?m)^([ ]*)stage: principle\n(?=\1generation: llm)', '',text);assert count==1,path;yaml.safe_load(updated);path.write_text(updated,encoding='utf-8',newline='\n')
print('Removed the static-only stage property from the native ownership plan; no graph validation relaxed.')
