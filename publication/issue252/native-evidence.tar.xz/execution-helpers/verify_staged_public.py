"""Compare the staged public bytes to the reviewed site and evidence package."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def digest(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


work = Path(__file__).resolve().parent
repo = work / 'public'
site = Path(sys.argv[1]).resolve()
manifest_name = 'site-manifest.json'
manifest = json.loads((site / manifest_name).read_bytes())
old = json.loads((work / 'run/published-manifest-for-overlay.json').read_bytes())
expected = {f'docs/{name}': value for name, value in manifest['outputs'].items()}
expected['docs/' + manifest_name] = digest(site / manifest_name)
evidence = repo / 'publication/issue252'
expected.update({p.relative_to(repo).as_posix(): digest(p) for p in evidence.rglob('*') if p.is_file()})
expected['.gitattributes'] = digest(repo / '.gitattributes')
git = ['git', '-C', str(repo)]
staged = set(subprocess.check_output([*git, 'diff', '--cached', '--name-only', '-z']).decode().split('\0')) - {''}
removed = {f'docs/{name}' for name in old['outputs'].keys() - manifest['outputs'].keys()}
assert staged <= expected.keys() | removed, sorted(staged - expected.keys() - removed)
assert 'docs/' + manifest_name in staged and 'publication/issue252/package.json' in staged
with subprocess.Popen([*git, 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE) as process:
    for name, pinned in sorted(expected.items()):
        process.stdin.write((':' + name + '\n').encode())
        process.stdin.flush()
        header = process.stdout.readline().split()
        assert len(header) == 3 and header[1] == b'blob', name
        remaining = int(header[2])
        content = hashlib.sha256()
        while remaining:
            data = process.stdout.read(min(remaining, 1024 * 1024))
            assert data, name
            content.update(data)
            remaining -= len(data)
        assert process.stdout.read(1) == b'\n'
        assert content.hexdigest() == pinned, name
    process.stdin.close()
    assert process.wait() == 0
print(json.dumps(dict(build_id=manifest['build_id'], staged_paths=len(staged), verified_blobs=len(expected))))
