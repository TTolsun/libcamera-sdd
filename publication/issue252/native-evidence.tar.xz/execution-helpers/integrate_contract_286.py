from copy import deepcopy
from pathlib import Path
import hashlib,json,shutil,sys,yaml
root=Path.cwd();sys.path.insert(0,str(root/'src'))
from sdd.config import load,section_output
from sdd.document_metadata import split_frontmatter
from sdd.facts.model import KnowledgeModel
from sdd.render_profiles import paths
from sdd.visual_refresh import refresh

work=root/'build/issue252'
r=work/'run'
other=Path('C:/Users/baboe/.codex/worktrees/5dee/camera-hal-sdd-generator/build/contract-ambiguities')
incoming_profile=other/'base/publication.yaml'
incoming=load(incoming_profile)
pub=load(r/'publication.yaml')
before=load(Path(json.loads((r/'public-base-integration-clarity.json').read_bytes())['base_profile']))
manifest_path=other/'site/site-manifest.json'
manifest=json.loads(manifest_path.read_bytes())
sha=lambda data:hashlib.sha256(data).hexdigest()
hash_path=lambda path:sha(path.read_bytes())
assert manifest['build_id']=='155cbcab1db670d9394e5e6c458cf220621ce62bc923147d11e626b82d37836e'
assert hash_path(incoming.paths['consistency_file'])==hash_path(pub.paths['consistency_file'])
inputs={'facts':incoming.facts_path,'sections':incoming.sections_file,
        'visuals':incoming.root/incoming.visuals.file,'english_catalog':Path(incoming.site.english_catalog)}
assert all(hash_path(path)==manifest['inputs'][name] for name,path in inputs.items())
pages={'camera-requests.md','pipeline-requests.md','request-diagnosis.md'}
assert all(hash_path(incoming.sdd_dir/page)==manifest['inputs']['markdown/'+page] for page in pages)
assert hash_path(incoming.sdd_dir/'request-lifecycle.md')==hash_path(before.sdd_dir/'request-lifecycle.md')
old_model=KnowledgeModel.load(pub.facts_path)
new_model=KnowledgeModel.load(incoming.facts_path)
assert old_model.meta==new_model.meta
common=old_model.evidence.keys()&new_model.evidence.keys()
assert all(old_model.evidence[key]==new_model.evidence[key] for key in common)
added=new_model.evidence.keys()-old_model.evidence.keys()
assert added=={'pipeline-requests/completion/pending-cancel-code'},added
old_model.evidence.update({k:new_model.evidence[k] for k in added})
out=r/'before-contract-286'
out.mkdir()
for name,path in dict(sections=pub.sections_file,visuals=pub.root/pub.visuals.file,facts=pub.facts_path,
                      english=r/'english.json',publication=r/'publication.yaml',review=r/'contract-review.yaml').items():
    shutil.copyfile(path,out/(name+path.suffix))
for page in pages:shutil.copyfile(pub.sdd_dir/page,out/page)
shutil.copyfile(manifest_path,r/'incoming-contract-286-manifest.json')
def yaml_write(path,data):
    path.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8',newline='\n')
ids={s['id'] for s in incoming.sections() if section_output(s) in pages}
old_sections=yaml.safe_load(pub.sections_file.read_bytes())
new_sections=yaml.safe_load(incoming.sections_file.read_bytes())
replacements={s['id']:s for s in new_sections['sections'] if s['id'] in ids}
assert replacements.keys()==ids
old_sections['sections']=[replacements.get(s['id'],s) for s in old_sections['sections']]
stage_sections=out/'integrated-sections.yaml'
yaml_write(stage_sections,old_sections)
old_visuals=yaml.safe_load((pub.root/pub.visuals.file).read_bytes())
new_visuals=yaml.safe_load((incoming.root/incoming.visuals.file).read_bytes())
for sid in ids:
    assert sid in new_visuals['sections']
    old_visuals['sections'][sid]=new_visuals['sections'][sid]
stage_visuals=out/'integrated-visuals.yaml'
yaml_write(stage_visuals,old_visuals)
profiles={}
for name in ('publication.yaml','contract-review.yaml'):
    original=r/name
    raw=yaml.safe_load(original.read_bytes())
    for page in pages:
        raw['site']['manuscript_profiles'][page]=str(paths(incoming)[page])
    profiles[original]=raw
pending=deepcopy(pub)
pending.paths['sections_file']=stage_sections
pending.raw['visuals']['file']=str(stage_visuals)
pending.raw['site']['manuscript_profiles']=profiles[r/'publication.yaml']['site']['manuscript_profiles']
results={}
for page in sorted(pages):
    original=(incoming.sdd_dir/page).read_bytes()
    section=next(s for s in pending.sections() if section_output(s)==page)
    result=refresh(pending,old_model,section['id'],original,expected_sha256=manifest['inputs']['markdown/'+page])
    old_meta,_=split_frontmatter(original.decode('utf-8').replace('\r\n','\n'))
    new_meta,_=split_frontmatter(result.decode('utf-8').replace('\r\n','\n'))
    assert old_meta['generated_design']['answers']==new_meta['generated_design']['answers']
    (out/('incoming-'+page)).write_bytes(original)
    results[page]=(result,dict(incoming_sha256=sha(original),combined_sha256=sha(result),identical_authored_answers=True))
a,b,c=[json.loads(p.read_bytes()) for p in (Path(before.site.english_catalog),r/'english.json',Path(incoming.site.english_catalog))]
added_english={}
for field in ('strings','translation_contexts','source_contexts'):
    base,local,peer=[d.get(field,{}) for d in (a,b,c)]
    combined=deepcopy(local)
    copied=[]
    for key,value in peer.items():
        if value==base.get(key) or value==local.get(key):continue
        if key in local and local[key]!=base.get(key):
            if (field,key)==('strings','검토 상태 기록일: 2026-11-12 · 사람 검토 전'):
                continue
            assert (field,key)==('translation_contexts','소스 발췌 {{1}}개'),(field,key)
            combined[key]=[row for i,row in enumerate(local[key]+value) if row not in (local[key]+value)[:i]]
        else:
            combined[key]=value
        copied.append(sha(key.encode()))
    b[field]=combined
    added_english[field]=copied
pub.sections_file.write_bytes(stage_sections.read_bytes())
(pub.root/pub.visuals.file).write_bytes(stage_visuals.read_bytes())
old_model.save(pub.facts_path)
for profile,raw in profiles.items():yaml_write(profile,raw)
for page,(result,_) in results.items():(pub.sdd_dir/page).write_bytes(result)
(r/'english.json').write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=dict(incoming_generator_pr=286,incoming_build=manifest['build_id'],incoming_profile=str(incoming_profile),
    source_commit=old_model.meta['source_commit'],pages={p:result[1] for p,result in results.items()},
    evidence_additions=sorted(added),english_changed_keys_sha256=added_english,
    own_primary_sha256=hash_path(pub.sdd_dir/'request-lifecycle.md'),
    scope='Combined the reviewed adjacent pages with the selected issue252 primary. Original public baseline is tracked independently from these locally verified incoming artifacts.')
(r/'contract-286-integration.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:record[k] for k in ('incoming_build','pages','evidence_additions','own_primary_sha256')}))
