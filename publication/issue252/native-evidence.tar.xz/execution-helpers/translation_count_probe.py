from pathlib import Path
import sys,json,re,hashlib
root=Path.cwd();sys.path.insert(0,str(root/'src'))
from sdd.config import load
from sdd.llm import Agent
from sdd.generation_run import Execution
from sdd import translation
run=root/'build/issue252/run';out=run/'audits/translation-count-probe';out.mkdir()
cfg=load(run/'independent-review.yaml');cfg.publication['operation_id']='issue252-translation-count-prompt-probe';execution=Execution(cfg,Agent(cfg.agent,out/'prompts'))
source='조건 A에서는 {{0}}를 기록하고 조건 B에서는 {{0}}를 확인합니다. {{1}}은 조건 C에서 반환하며 조건 D에서는 신호를 냅니다.'
rows=[]
with execution.track('translation-prompt-contract-probe'):
 for name in ['single','single_retry','batch']:
  system=getattr(translation,'_'+name+'_system')({source:''})
  user=translation._payload({},dict(source=source),terms={}) if name!='batch' else translation._payload({},dict(test=source))
  schema=translation._single_schema() if name!='batch' else translation._batch_schema(dict(test=source))
  raw=execution.chat(system,user,tag='translation-policy-'+name,response_schema=schema);d=json.loads(raw);text=d['text'] if name!='batch' else d['translations']['test'];translation._validate_text(source,text);assert all(re.search(r'\b'+x+r'\b',text) for x in 'ABCD');rows.append(dict(prompt=name,status='passed',source=source,translation=text))
(out/'result.json').write_text(json.dumps(dict(status='passed',scope='Synthetic translation-prompt contract only: repeated source token and shared actor with separate conditions. Actual configured CLI calls; not a product/hardware/human outcome and not replacement manuscript prose.',human_review='pending',results=rows),ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Actual CLI prompt-contract cases passed:',len(rows))
