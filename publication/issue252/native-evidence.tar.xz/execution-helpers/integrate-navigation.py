from pathlib import Path
import sys,json,hashlib,shutil
from copy import deepcopy
import yaml
sys.path.insert(0,'src')
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd import evidence
root=Path.cwd();run=root/'build/issue252/run';public=run.parent/'public'
profile=Path('C:/Users/baboe/.codex/worktrees/c828/camera-hal-sdd-generator/build/issue248/final-readers/inherited-96/workspace/publication/publication.yaml');base=load(profile)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,d:p.write_text(yaml.safe_dump(d,allow_unicode=True,sort_keys=False),encoding='utf-8',newline='\n')
jwrite=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
m=json.loads((public/'docs/site-manifest.json').read_bytes())
for key,p in [('facts',base.facts_path),('sections',base.sections_file),('visuals',base.root/base.visuals.file),('english_catalog',Path(base.site.english_catalog))]:assert sha(p)==m['inputs'][key],key
for k,v in m['inputs'].items():
 if k.startswith('markdown/'):assert sha(base.sdd_dir/k[9:])==v,k
old=run/'before-navigation-public-base';old.mkdir()
for name in ['config','manuscripts','facts','published-base-manuscripts']:shutil.copytree(run/name,old/name)
for name in ['publication.yaml','contract-review.yaml','english.json','generation.yaml','scope.json']:shutil.copy2(run/name,old/name)
ours=yaml.safe_load((run/'config/sections.yaml').read_bytes());selected=deepcopy(next(s for s in ours['sections'] if s['id']=='request-lifecycle'));vis=deepcopy(yaml.safe_load((run/'config/visuals.yaml').read_bytes())['sections']['request-lifecycle'])
gloss=yaml.safe_load((run/'config/glossary.yaml').read_bytes());owncfg=yaml.safe_load((run/'publication.yaml').read_bytes());gen=yaml.safe_load((run/'generation.yaml').read_bytes())
assert sha(run/'published-base-manuscripts/request-lifecycle.md')==sha(base.sdd_dir/'request-lifecycle.md'),'Concurrent primary changed'
for key,name in [('sections_file','sections.yaml'),('scenarios_file','scenarios.yaml'),('glossary_file','glossary.yaml'),('products_file','products.yaml'),('consistency_file','contracts.yaml')]:shutil.copy2(base.raw['paths'][key],run/'config'/name)
shutil.copy2(base.root/base.visuals.file,run/'config/visuals.yaml');shutil.copy2(base.site.reader_paths,run/'config/reader-paths.yaml')
d=yaml.safe_load((run/'config/sections.yaml').read_bytes());d['sections']=[selected if s['id']=='request-lifecycle' else s for s in d['sections']];write(run/'config/sections.yaml',d)
d=yaml.safe_load((run/'config/visuals.yaml').read_bytes());d['sections']['request-lifecycle']=vis;write(run/'config/visuals.yaml',d)
d=yaml.safe_load((run/'config/glossary.yaml').read_bytes());known={t['term']:t for t in d['terms']}
for t in gloss['terms']:
 if t['term'] not in known:d['terms'].append(t)
 else:
  for a in t.get('aliases',[]):
   if a not in known[t['term']].setdefault('aliases',[]):known[t['term']]['aliases'].append(a)
write(run/'config/glossary.yaml',d)
rows=[]
for f in base.sdd_dir.rglob('*'):
 if not f.is_file():continue
 rel=f.relative_to(base.sdd_dir);prior=run/'published-base-manuscripts'/rel;target=run/'manuscripts'/rel
 if rel.as_posix()!='request-lifecycle.md' and (not prior.exists() or sha(prior)!=sha(f)):
  target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target);rows.append(dict(file=rel.as_posix(),sha256=sha(f)))
 prior.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,prior)
assert sha(run/'manuscripts/request-lifecycle.md')==sha(old/'manuscripts/request-lifecycle.md')
a=json.loads((run/'facts/facts.json').read_bytes());b=json.loads(base.facts_path.read_bytes());assert all(a[k]==b[k] for k in a if k!='evidence')
raw=deepcopy(base.raw);raw['source']=gen['source'];raw['output']=gen['output']
for k in ['config','sections_file','scenarios_file','glossary_file','products_file','consistency_file']:raw['paths'][k]=owncfg['paths'][k]
raw['visuals']['file']=owncfg['visuals']['file'];raw['products']['file']=owncfg['products']['file']
raw['paths'].update(translation_profile=str(run/'translation.yaml'),consistency_profile=str(run/'contract-review.yaml'),consistency_review_config=str(run/'contract-review.yaml'))
raw['site']['manuscript_profiles']['request-lifecycle.md']=str(run/'request-authentication.yaml')
raw['site'].update(enabled=False,english_catalog=str(run/'english.json'),mermaid_dir=str(public/'docs/assets/mermaid'),translation_batch_size=8,reader_paths=str(run/'config/reader-paths.yaml'))
for k,v in owncfg['site'].get('coverage_question_edits',{}).items():
 if k=='request-lifecycle.md':raw['site'].setdefault('coverage_question_edits',{})[k]=v
raw['publication'].update(operation_id='issue252-request-depth',baseline_config=str(profile))
for k,v in owncfg['publication'].get('allowed_contract_changes',{}).items():raw['publication'].setdefault('allowed_contract_changes',{}).setdefault(k,v)
reports=run/'inherited-navigation-reports';reports.mkdir()
for i,r in enumerate(raw['publication'].get('reports',[])):
 p=Path(r['path']);assert sha(p)==r['sha256'];q=reports/(str(i)+'-'+p.name);shutil.copy2(p,q);r['path']=str(q);r['producer']='inherited-historical/'+r['producer']
write(run/'publication.yaml',raw);review=deepcopy(raw);review['agent']=deepcopy(gen['agent']);review['agent']['max_input_chars']=1000000;write(run/'contract-review.yaml',review)
cat=json.loads(Path(base.site.english_catalog).read_bytes());ourcat=json.loads((old/'english.json').read_bytes())
for name in ['strings','translation_contexts','source_contexts']:
 for k,v in ourcat.get(name,{}).items():cat.setdefault(name,{}).setdefault(k,v)
jwrite(run/'english.json',cat)
restored=[]
for folder in ['calls','cli']:
 source=base.build_dir/'prompts'/folder
 for f in source.rglob('*'):
  if not f.is_file():continue
  q=run/'build/prompts'/folder/f.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True)
  if q.exists():assert sha(q)==sha(f),str(q)
  else:shutil.copy2(f,q)
  if q.name.endswith('.receipt.json'):restored.append(q.relative_to(run).as_posix())
jwrite(run/'historical-native-restoration-navigation.json',dict(receipt_paths=restored,scope='Imported immutable public-base calls; not new #252 inference.'))
model=KnowledgeModel.load(run/'facts/facts.json');evidence.collect(load(run/'generation.yaml'),model);model.save(run/'facts/facts.json')
shutil.copy2(public/'docs/site-manifest.json',run/'published-manifest-navigation.json')
jwrite(run/'public-base-integration-navigation.json',dict(base_build_id=m['build_id'],base_profile=str(profile),source_commit=a['meta']['source_commit'],replaced_nonselected_manuscripts=rows,selected_document_unchanged=True,structural_facts_unchanged=True,previous_run_snapshot=str(old)))
print('Integrated latest public navigation',m['build_id'],len(rows),'changed nonselected manuscripts')
