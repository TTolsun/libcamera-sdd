import json,hashlib,subprocess,sys
from pathlib import Path
root=Path.cwd();run=root/'build/issue252/run';report=run/'visual-revalidation.json';before=report.read_bytes();rows=json.loads(before);digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();files={row['page']:digest(run/'manuscripts'/row['page']) for row in rows}
result=subprocess.run([sys.executable,'-X','utf8','examples/libcamera/validation/issue252/revalidate_visuals.py'],capture_output=True,text=True,encoding='utf-8');(root/'build/issue252/visual-revalidation-current-04.log').write_text(result.stdout+'\n'+result.stderr,encoding='utf-8');assert result.returncode==0,result.stderr
assert report.read_bytes()==before,'Repeat run changed the first recorded identities.'
assert all(digest(run/'manuscripts'/page)==sha for page,sha in files.items())
proof=dict(status='passed',report_sha256=hashlib.sha256(before).hexdigest(),report_bytes_unchanged=True,manuscript_bytes_unchanged=files,lf_crlf_repeat_regression='metadata-repeat-tests.log',new_inference=False,human_review='pending')
(run/'visual-repeat-verification.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(proof,ensure_ascii=False))
