"""Package completed public-only evidence without changing original receipts."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import shutil
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'src'))
from sdd.config import load
from sdd.render_profiles import for_page

WORK = ROOT / 'build/issue252'
RUN = WORK / 'run'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--accuracy', required=True)
    parser.add_argument('--sufficiency', required=True)
    parser.add_argument('--bilingual', required=True)
    parser.add_argument('--site', required=True, type=Path)
    parser.add_argument('--generator-merge', required=True)
    args = parser.parse_args()
    reports = {}
    for phase in ('accuracy', 'sufficiency', 'bilingual'):
        path = RUN / 'audits' / getattr(args, phase) / 'review.json'
        report = json.loads(path.read_bytes())
        assert report['status'] == 'passed' and report['human_review'] == 'pending'
        assert not any(row['blocking'] for row in report['findings'])
        assert report['document_sha256'] == sha(RUN / 'manuscripts/request-lifecycle.md')
        reports[phase] = (path, report)
    native = RUN / 'native-call-verification.json'
    assert json.loads(native.read_bytes())['status'] == 'verified'
    cfg = load(RUN / 'publication.yaml')
    manifest = json.loads((args.site / 'site-manifest.json').read_bytes())
    out = WORK / 'public/publication/issue252'
    assert out.resolve().is_relative_to((WORK / 'public').resolve())
    out.mkdir()
    for name in ('config', 'manuscripts', 'facts'):
        shutil.copytree(RUN / name, out / name)
    profiles = out / 'profiles'
    profiles.mkdir()
    for path in RUN.glob('*.yaml'):
        shutil.copy2(path, profiles / path.name)
    for name in ('english.json', 'scope.json', 'source-window-index.json', 'native-call-verification.json',
                 'signal-probe.json', 'fresh-extraction-current-validation.json',
                 'public-base-integration-current.json', 'public-base-integration-navigation.json',
                 'published-manifest-navigation.json', 'published-manifest-clarity.json',
                 'public-base-integration-clarity.json', 'merge-issue253-preservation.json',
                 'upstream-final-recheck.json', 'upstream-2026-11-12.json', 'latest-issue.json',
                 'figure-render-refresh.json', 'timeout-figure-repair-plan.json', 'timeout-figure-repair-result.json',
                 'bilingual-observed-cli-limit.json', 'reader-question-labels.json',
                 'bilingual-figure-repair.json', 'contract-evidence-restoration.json',
                 'translation-catalog-refresh.json', 'translation-final-figure-rebind.json', 'generator-final-ci.json',
                 'bilingual-question-translation-repair.json',
                 'contract-286-integration.json', 'incoming-contract-286-manifest.json', 'parallel-standard-audit-07.json',
                 'parallel-standard-audit-08.json', 'standard-contract-repair-final.json',
                 'parallel-standard-audit-09.json',
                 'published-manifest-contract-286.json', 'contract-286-publication-equivalence.json',
                 'current-public-baseline-proof.json', 'generator-merge-runtime-proof.json',
                 'bilingual-timer-translation-repair.json', 'timer-translation-exact-batch-impact.json',
                 'corrected-stopping-audit-transfer.json',
                 'bilingual-scenario-translation-repair.json', 'scenario-translation-exact-batch-impact.json',
                 'corrected-scenario-batch-transfer.json', 'bilingual-projection-browser-proof.json',
                 'final-planes-unit-repair.json', 'final-planes-exact-batch-impact.json',
                 'final-planes-batch-transfer.json', 'final-bilingual-projection-context.json',
                 'final-planes-equivalent-checkpoints.json',
                 'standard-unresolved-disposition.json',
                 'source-review-refinement-23-20.json', 'source-review-refinement-24-21.json',
                 'source-review-refinement-25-22.json', 'visual-revalidation.json',
                 'submission-contract-consolidation.json', 'completion-contract-consolidation.json',
                 'baseline-contract-change-reasons.json', 'published-current-site-manifest.json'):
        shutil.copy2(RUN / name, out / name)
    for name, (path, report) in reports.items():
        shutil.copy2(path, out / ('independent-' + name + '.json'))
    for name in ('build-provenance-fresh.json', 'build-provenance-signal.json',
                 'build-provenance-current.json', 'upstream-sync.json'):
        shutil.copy2(WORK / name, out / name)
    shutil.copy2(WORK / 'uvc-extraction-current/verification.json', out / 'current-uvc-extraction.json')
    shutil.copy2(args.site / 'site-manifest.json', out / 'site-manifest.json')
    browser = RUN / 'browser-final/summary.json'
    assert json.loads(browser.read_bytes())['status'] == 'passed'
    shutil.copy2(browser, out / 'browser-verification.json')
    shutil.copy2(RUN / 'bilingual-peer.json', out / 'bilingual-peer.json')
    shutil.copy2(args.site / 'contract-consistency.json', out / 'contract-consistency.json')
    before = json.loads((RUN / 'audits/before-01/review.json').read_bytes())
    current_before_path = RUN / 'audits/before-current-03/review.json'
    current_before = json.loads(current_before_path.read_bytes())
    previous = {row['id']: row for row in current_before['questions']}
    final = reports['sufficiency'][1]
    write(out / 'answerability-comparison.json', dict(
        source_kind='independent-native-cli-review-not-human-reader-evaluation', human_review='pending',
        before_review_sha256=sha(current_before_path),
        initial_historical_before_review_sha256=sha(RUN / 'audits/before-01/review.json'),
        after_review_sha256=sha(reports['sufficiency'][0]),
        concurrent_current_before_review_sha256=sha(current_before_path),
        concurrent_current_before={row['id']:row for row in current_before['questions']},
        questions=[dict(id=row['id'], before=previous[row['id']], after=row) for row in final['questions']],
        criterion='Evidence, diagnostic location, next branch and change-validation conditions; not document length. Existing adequate ownership/FIFO answers are retained, not counted as wholly new.'))
    files = {}
    def tree(folder, prefix):
        for path in folder.rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts and 'execution-locks' not in path.parts:
                files[prefix + '/' + path.relative_to(folder).as_posix()] = path
    tree(RUN, 'run')
    tree(WORK / 'build-inputs-current', 'current-build-inputs')
    tree(WORK / 'uvc-extraction-current', 'current-uvc-extraction')
    tree(WORK / 'standard-repair-candidate-01', 'first-standard-repair-candidate')
    tree(WORK / 'parallel-standard-audit-06', 'isolated-standard-audits-failed-preflight')
    tree(WORK / 'parallel-standard-audit-07', 'isolated-standard-audits-first')
    tree(WORK / 'parallel-standard-audit-08', 'isolated-standard-audits-final')
    tree(WORK / 'parallel-standard-audit-09', 'isolated-standard-audits-resumed')
    tree(WORK / 'parallel-standard-audit-stop-final', 'isolated-corrected-stopping-audit')
    tree(WORK / 'scenario-translation-batch-audit', 'isolated-corrected-scenario-batches')
    tree(WORK / 'final-planes-batch-audit', 'isolated-final-plane-batches')
    tree(ROOT / 'src', 'generator-src')
    tree(ROOT / 'examples/libcamera/validation/issue252', 'validation-tools')
    tree(cfg.templates_dir, 'bound-resources/templates')
    tree(Path(cfg.paths['prompts']), 'bound-resources/prompts')
    resources = {}
    for page in ['default', *cfg.site.manuscript_profiles]:
        selected = cfg if page == 'default' else for_page(cfg, page)
        prefix = 'bound-resources/styles/' + page.replace('/', '-').replace('.md', '')
        tree(selected.style_dir, prefix)
        resources[str(selected.style_dir)] = prefix
    write(out / 'bound-resource-map.json', resources)
    from sdd.render_profiles import paths as profile_paths
    for page, path in profile_paths(cfg).items():
        files['bound-resources/profiles/' + page.replace('/', '-') + '.yaml'] = path
    for path in WORK.glob('*.log'):
        files['execution-logs/' + path.name] = path
    for path in WORK.glob('*.py'):
        files['execution-helpers/' + path.name] = path
    for name in ('pyproject.toml', 'uv.lock', 'AGENTS.md', 'DESIGN.md'):
        files['generator/' + name] = ROOT / name
    index = {}
    archive = out / 'native-evidence.tar.xz'
    with tarfile.open(archive, 'w:xz', preset=6) as bundle:
        for name, path in sorted(files.items()):
            raw = path.read_bytes()
            index[name] = hashlib.sha256(raw).hexdigest()
            entry = tarfile.TarInfo(name)
            entry.size = len(raw)
            entry.mode = 0o644
            bundle.addfile(entry, io.BytesIO(raw))
    verified = {}
    with tarfile.open(archive, 'r|xz') as bundle:
        for entry in bundle:
            assert entry.isfile() and entry.name not in verified
            with bundle.extractfile(entry) as member:
                verified[entry.name] = hashlib.file_digest(member, 'sha256').hexdigest()
    assert verified == index
    assert archive.stat().st_size < 100 * 1024 * 1024, 'Evidence archive exceeds the GitHub file limit'
    write(out / 'native-index.json', index)
    write(out / 'package.json', dict(
        schema=1, generator_merge=args.generator_merge, generator_pr=266,
        archive=archive.name, archive_sha256=sha(archive), archive_bytes=archive.stat().st_size,
        archive_files=len(index), index_sha256=sha(out / 'native-index.json'),
        build_id=manifest['build_id'], public_source_only=True, actual_human_evaluators=0,
        internal_hal='not validated', physical_camera_capture=False, human_review='pending'))
    print(json.dumps(dict(files=len(index), bytes=archive.stat().st_size, build_id=manifest['build_id'])))


if __name__ == '__main__':
    main()
