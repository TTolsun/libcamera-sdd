from pathlib import Path
import hashlib
import json
import shutil


run = Path(__file__).resolve().parent / 'run'
candidate = run / 'final-planes-candidate'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manuscript = candidate / 'manuscripts/request-lifecycle.md'
digest = sha(manuscript)
for audit in ('accuracy-35', 'sufficiency-31', 'bilingual-09'):
    report = json.loads((run / 'audits' / audit / 'review.json').read_bytes())
    assert report['status'] == 'passed' and report['document_sha256'] == digest, audit
    assert len(report['questions']) == 7 and all(row['answerable'] for row in report['questions']), audit
assert (run / 'facts/facts.json').read_bytes() == (candidate / 'facts/facts.json').read_bytes()
snapshot = run / 'before-final-planes-activation'
snapshot.mkdir()
files = {
    run / 'manuscripts/request-lifecycle.md': manuscript,
    run / 'config/sections.yaml': candidate / 'sections.yaml',
    run / 'english.json': candidate / 'english.json',
}
for path in (*files, run / 'build/consistency-review.json'):
    if path.is_file():
        shutil.copyfile(path, snapshot / path.name)
for path, replacement in files.items():
    shutil.copyfile(replacement, path)
    assert sha(path) == sha(replacement)
print('Activated the exact final native manuscript and reviewed catalog', digest)
