import sys,json,hashlib,shutil,subprocess,re
from pathlib import Path
from copy import deepcopy
import yaml
sys.path.insert(0,'src')
from sdd.config import load
from sdd.document_metadata import split_frontmatter
from sdd.facts.model import KnowledgeModel
from sdd import evidence
root=Path.cwd();work=root/'build/issue252';run=work/'run';public=work/'public'
profile=Path('C:/Users/baboe/.codex/worktrees/bb29/camera-hal-sdd-generator/build/remaining-evidence/publication/sdd.yaml');base=load(profile)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,d:p.write_text(yaml.safe_dump(d,allow_unicode=True,sort_keys=False),encoding='utf-8')
jwrite=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
m=json.loads((public/'docs/site-manifest.json').read_bytes())
for key,path in [('facts',base.facts_path),('sections',base.sections_file),('visuals',base.root/base.visuals.file),('english_catalog',Path(base.site.english_catalog))]:assert sha(path)==m['inputs'][key],key
for key,value in m['inputs'].items():
 if key.startswith('markdown/'):assert sha(base.sdd_dir/key[9:])==value,key
old=run/'before-current-public-base'
if not old.exists():
 old.mkdir()
 for name in ['config','manuscripts','facts','published-base-manuscripts']:shutil.copytree(run/name,old/name)
 for f in run.glob('*.yaml'):shutil.copy2(f,old/f.name)
 for name in ['english.json','scope.json','source-window-index.json']:shutil.copy2(run/name,old/name)
else:assert not (run/'public-base-integration-current.json').exists(), 'Already integrated; do not replay.'
ours=yaml.safe_load((old/'config/sections.yaml').read_bytes());selected=deepcopy(next(s for s in ours['sections'] if s['id']=='request-lifecycle'))
latest=deepcopy(next(s for s in base.sections() if s['id']=='request-lifecycle'))
# Preserve the concurrently accepted representative lifetime task and its figures.
resources=deepcopy(next(t for t in latest['design_topics'] if t['id']=='resources'))
selected['design_topics']=[resources if t['id']=='resources' else t for t in selected['design_topics']]
latest_req=next(r for r in latest['design_requirements'] if r['id']=='resources')
selected['design_requirements']=[deepcopy(latest_req) if r['id']=='resources' else r for r in selected['design_requirements']]
visuals=deepcopy(yaml.safe_load((old/'config/visuals.yaml').read_bytes())['sections']['request-lifecycle'])
theirs=yaml.safe_load((base.root/base.visuals.file).read_bytes())
resource_ids={v['id'] for v in theirs['sections']['request-lifecycle'] if v.get('topic')=='resources'}
visuals=[v for v in visuals if v.get('topic')!='resources' and v['id'] not in resource_ids]+[deepcopy(v) for v in theirs['sections']['request-lifecycle'] if v.get('topic')=='resources']
for f in base.config_dir.iterdir():
 if f.is_file():shutil.copy2(f,run/'config'/f.name)
for path,key in [('sections.yaml','sections_file'),('scenarios.yaml','scenarios_file'),('glossary.yaml','glossary_file'),('products.yaml','products_file'),('contracts.yaml','consistency_file')]:shutil.copy2(Path(base.raw['paths'][key]),run/'config'/path)
shutil.copy2(base.root/base.visuals.file,run/'config/visuals.yaml')
d=yaml.safe_load((run/'config/sections.yaml').read_bytes());d['sections']=[selected if s['id']=='request-lifecycle' else s for s in d['sections']];write(run/'config/sections.yaml',d)
theirs['sections']['request-lifecycle']=visuals;write(run/'config/visuals.yaml',theirs)
d=yaml.safe_load((run/'config/glossary.yaml').read_bytes());oldgloss=yaml.safe_load((old/'config/glossary.yaml').read_bytes());known={t['term'] for t in d['terms']};d['terms'] += [t for t in oldgloss['terms'] if t['term'] in ['QBUF','DQBUF','STREAMOFF'] and t['term'] not in known]
aliases=next(t for t in d['terms'] if t['term']=='errno')['aliases'];aliases.append('ENOENT') if 'ENOENT' not in aliases else None;write(run/'config/glossary.yaml',d)
for f in base.sdd_dir.rglob('*'):
 if not f.is_file():continue
 rel=f.relative_to(base.sdd_dir)
 for folder in ['published-base-manuscripts']+([] if rel.as_posix()=='request-lifecycle.md' else ['manuscripts']):
  target=run/folder/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target)
shutil.copy2(base.facts_path,run/'facts/facts.json')
gen=yaml.safe_load((run/'generation.yaml').read_bytes());raw=deepcopy(base.raw);raw['source']=gen['source'];raw['output']=gen['output']
for key in ['config','sections_file','scenarios_file','glossary_file','products_file','consistency_file']:
 raw['paths'][key]=str(run/'config') if key=='config' else str(run/'config'/dict(sections_file='sections.yaml',scenarios_file='scenarios.yaml',glossary_file='glossary.yaml',products_file='products.yaml',consistency_file='contracts.yaml')[key])
raw['products']['file']=str(run/'config/products.yaml');raw['visuals']['file']=str(run/'config/visuals.yaml')
raw['paths'].update(translation_profile=str(run/'translation.yaml'),consistency_review_config=str(run/'contract-review.yaml'))
raw['site']['manuscript_profiles']['request-lifecycle.md']=str(run/'request-authentication.yaml')
raw['site'].update(enabled=False,english_catalog=str(run/'english.json'),mermaid_dir=str(public/'docs/assets/mermaid'),translation_batch_size=8,reader_paths=str(run/'config/reader-paths.yaml'))
shutil.copy2(base.site.reader_paths,run/'config/reader-paths.yaml')
raw['publication'].update(operation_id='issue252-request-depth',baseline_config=str(profile))
reports=run/'inherited-current-reports';reports.mkdir(exist_ok=True)
for i,report in enumerate(raw['publication'].get('reports',[])):
 src=Path(report['path']);assert sha(src)==report['sha256'];target=reports/(str(i)+'-'+src.name);shutil.copy2(src,target);report['path']=str(target);report['producer']='inherited-historical/'+report['producer']
write(run/'publication.yaml',raw);review=deepcopy(raw);review['agent']=deepcopy(gen['agent']);review['agent']['max_input_chars']=1000000;write(run/'contract-review.yaml',review)
gen['documentation']=raw['documentation'];write(run/'generation.yaml',gen)
trans=yaml.safe_load((run/'translation.yaml').read_bytes());trans['documentation']=raw['documentation'];write(run/'translation.yaml',trans)
cat=json.loads(Path(base.site.english_catalog).read_bytes());ourcat=json.loads((run/'english.json').read_bytes())
for name in ['strings','translation_contexts','source_contexts']:
 for key,value in ourcat.get(name,{}).items():cat.setdefault(name,{}).setdefault(key,value)
jwrite(run/'english.json',cat)
commit='be7e83e91348250c015aad6d6f59f1468555bae8';git=lambda *args:subprocess.check_output(['git','-C',str(work/'source'),*args])
assert git('rev-parse','HEAD').decode().strip()==commit and not git('status','--porcelain','--untracked-files=all')
scope=json.loads((run/'scope.json').read_bytes());assert all(hashlib.sha256(git('show',commit+':'+r['file'])).hexdigest()==r['sha256'] for r in scope['source_windows'])
scope['source_commit']=commit;scope.setdefault('amendments',[]).append(dict(phase='before current-public-base regeneration',previous_scope_sha256=sha(old/'scope.json'),questions_unchanged=True,changes=['Adopt current public source commit be7e83e; all 26 complete selected source windows are byte-identical to original 293. Preserve #249 representative lifetime questions and three figures; preserve every other current public manuscript. Fresh be7 UVC build is bound separately before generation.']))
scope['previous_build_scope']='293d751a814e0d4c34e85ad457ccd9d5eefd1a61; retained fresh build/extraction and signal probe are historical, not relabelled.';jwrite(run/'scope.json',scope)
restored=[]
for folder in ['calls','cli']:
 source=base.build_dir/'prompts'/folder
 for f in source.rglob('*'):
  if not f.is_file():continue
  target=run/'build/prompts'/folder/f.relative_to(source);target.parent.mkdir(parents=True,exist_ok=True)
  if target.exists():assert sha(target)==sha(f),str(target)
  else:shutil.copy2(f,target)
  if target.name.endswith('.receipt.json'):restored.append(target.relative_to(run).as_posix())
jwrite(run/'historical-native-restoration-current.json',dict(receipt_paths=restored,scope='Immutable current-public-base receipts, not new #252 calls.'))
model=KnowledgeModel.load(run/'facts/facts.json');evidence.collect(load(run/'generation.yaml'),model);model.save(run/'facts/facts.json')
jwrite(run/'public-base-integration-current.json',dict(base_build_id=m['build_id'],base_profile=str(profile),source_commit=commit,preserved_nonselected_manuscripts=[dict(file=f.relative_to(base.sdd_dir).as_posix(),sha256=sha(f)) for f in base.sdd_dir.rglob('*.md') if f.name!='request-lifecycle.md'],selected_resource_contract='Current #249 topic and figures; actual re-generation required.',previous_run_snapshot=str(old)))
# Mirror only the accepted concurrent resource topic into the example contract.
p=root/'examples/libcamera/config/sections.yaml';text=p.read_text(encoding='utf-8');start=text.index('  - id: resources\n',text.index('- id: request-lifecycle\n'));end=start+5+re.search(r'^  - id: ',text[start+5:],re.M).start()
rendered=yaml.safe_dump([resources],allow_unicode=True,sort_keys=False,width=105);block=''.join(('  '+line).rstrip()+'\n' for line in rendered.splitlines());p.write_text(text[:start]+block+text[end:],encoding='utf-8',newline='\n')
print('Current public base integrated',m['build_id'],commit,flush=True)
