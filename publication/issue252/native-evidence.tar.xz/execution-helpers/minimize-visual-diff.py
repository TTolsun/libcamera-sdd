from pathlib import Path
import subprocess,re,yaml
root=Path.cwd();p=root/'examples/libcamera/config/visuals.yaml'
before=subprocess.check_output(['git','show','HEAD:examples/libcamera/config/visuals.yaml']).decode('utf-8');current=yaml.safe_load(before);desired=yaml.safe_load((root/'build/issue252/run/config/visuals.yaml').read_bytes())['sections']['request-lifecycle']
start=before.index('  request-lifecycle:\n');body_start=start+len('  request-lifecycle:\n');end=body_start+re.search(r'^  [a-z][^\n]*:\n',before[body_start:],re.M).start();body=before[body_start:end]
matches=list(re.finditer(r'^  - id: (\S+)\n',body,re.M));blocks={m[1]:body[m.start():(matches[i+1].start() if i+1<len(matches) else len(body))] for i,m in enumerate(matches)}
old=yaml.safe_load(before)['sections']['request-lifecycle'];old_ids={v['id'] for v in old if v.get('topic')=='resources'}
keep=''.join(block for key,block in blocks.items() if key not in old_ids)
class NoAliases(yaml.SafeDumper):
 def ignore_aliases(self,data):return True
resources=[v for v in desired if v.get('topic')=='resources'];rendered=yaml.dump(resources,Dumper=NoAliases,allow_unicode=True,sort_keys=False,width=105);new=''.join(('  '+line).rstrip()+'\n' for line in rendered.splitlines())
candidate=before[:body_start]+keep+new+before[end:];current['sections']['request-lifecycle']=[v for v in old if v.get('topic')!='resources']+resources
assert yaml.safe_load(candidate)==current
p.write_text(candidate,encoding='utf-8',newline='\n')
print('Preserved all unrelated visual plans byte-for-byte.')
