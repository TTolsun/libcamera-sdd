from pathlib import Path
import yaml,re,runpy,json
root=Path.cwd();run=root/'build/issue252/run';here=root/'examples/libcamera/validation/issue252';replace=runpy.run_path(str(here/'refine.py'))['replace_topic']
for p in [run/'config/sections.yaml',root/'examples/libcamera/config/sections.yaml',here/'topics.yaml']:
 text=p.read_text(encoding='utf-8');d=yaml.safe_load(text);topics=d.get('topics') or next(s for s in d['sections'] if s['id']=='request-lifecycle')['design_topics'];t=next(t for t in topics if t['id']=='callback-order');part=next(p for p in t['parts'] if p['id']=='request-delivery');part['question']+=' 상태 선택의 상세는 앞 resources/normal 항목이 소유합니다. 이 항목에서는 completeRequest가 Request::Private::complete를 호출하는 순서만 연결하고 enum 판정식을 되풀이하지 마세요. 취소된 버퍼의 유무를 cancelled_와 동치로 바꾸지 마세요. 실제 complete는 cancelled_만 검사하고 doCancelRequest는 pending_이 비어 있어도 true를 설정할 수 있습니다.';t['sources'].append(dict(id='request-state',file='src/libcamera/request.cpp',start='void Request::Private::complete()',end='bool Request::Private::completeBuffer('));part['sources'].append('request-state');updated=replace(text,t) if 'sections' in d else yaml.safe_dump(d,allow_unicode=True,sort_keys=False,width=105);assert yaml.safe_load(updated)==d;p.write_text(updated,encoding='utf-8',newline='\n')
for p in [run/'config/visuals.yaml',root/'examples/libcamera/config/visuals.yaml',here/'visual-amendments.yaml']:
 text=p.read_text(encoding='utf-8');d=yaml.safe_load(text)
 if 'overrides' in d:v=d['overrides']['callback-order-flow']
 else:v=next(v for v in d['sections']['request-lifecycle'] if v['id']=='callback-order-flow')
 v['prompt']+=' complete의 상태 분기는 실제 cancelled_를 기준으로 true이면 RequestCancelled, false이면 RequestComplete라고 한영 모두 명시하세요. 취소된 버퍼 존재 여부로 이 조건을 바꾸지 마세요. doCancelRequest는 pending_이 비어 있어도 cancelled_를 true로 설정합니다. 실제 complete 정의와 bulk 취소가 별도 근거로 제공됩니다.'
 if 'overrides' in d:
  source=next(v for v in yaml.safe_load((run/'config/visuals.yaml').read_bytes())['sections']['request-lifecycle'] if v['id']=='callback-order-flow');v['sources']=[*source['sources'],'request-state','bulk'];v['whole_sources']=[*source['whole_sources'],'request-state','bulk'];updated=yaml.safe_dump(d,allow_unicode=True,sort_keys=False,width=105)
 else:
  v['sources']+=['request-state','bulk'];v['whole_sources']+=['request-state','bulk'];start=text.index('  - id: callback-order-flow\n',text.index('  request-lifecycle:\n'));m=re.search(r'^  (?:- id: |[a-z][^\n]*:\n)',text[start+3:],re.M);end=start+3+m.start();block=yaml.safe_dump([v],allow_unicode=True,sort_keys=False,width=105);updated=text[:start]+''.join(('  '+line).rstrip()+'\n' for line in block.splitlines())+text[end:]
 assert yaml.safe_load(updated)==d;p.write_text(updated,encoding='utf-8',newline='\n')
(run/'source-review-refinement-29.json').write_text(json.dumps(dict(source_windows_unchanged=27,change='Add exact Private::complete definition to writer and figure context. Keep detailed state selection in existing resources/normal owner; callback order does not derive cancelled_ from cancelled-buffer existence.'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
