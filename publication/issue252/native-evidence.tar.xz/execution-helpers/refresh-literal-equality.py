from pathlib import Path
import json,hashlib,yaml
from sdd.config import load,section_output
from sdd.facts.model import KnowledgeModel
from sdd.generated_design import enabled
from sdd.visual_refresh import refresh
from sdd.document_metadata import split_frontmatter
root=Path.cwd();run=root/'build/issue252/run';cfg=load(run/'publication.yaml');model=KnowledgeModel.load(cfg.facts_path);sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((run/'published-manifest-clarity.json').read_bytes());pinned={k[9:]:v for k,v in manifest['inputs'].items() if k.startswith('markdown/')}
for row in json.loads((run/'visual-revalidation.json').read_bytes()):pinned[row['page']]=row['updated_sha256']
a=json.loads((run/'audits/accuracy-30/review.json').read_bytes());s=json.loads((run/'audits/sufficiency-26/review.json').read_bytes());assert a['document_sha256']==s['document_sha256'];pinned['request-lifecycle.md']=a['document_sha256'];planned=[]
for section in cfg.sections():
 if not enabled(section):continue
 rel=section_output(section);p=cfg.sdd_dir/rel
 if not p.exists():continue
 original=p.read_bytes();assert sha(original)==pinned[rel],('Unpinned manuscript',rel)
 updated=refresh(cfg,model,section['id'],original,expected_sha256=pinned[rel])
 if updated==original:continue
 before=split_frontmatter(original.decode('utf-8').replace('\r\n','\n'))[0];after=split_frontmatter(updated.decode('utf-8').replace('\r\n','\n'))[0]
 assert before['generated_design']['answers']==after['generated_design']['answers'];assert before.get('generated_visuals',{}).get('records')==after.get('generated_visuals',{}).get('records');planned.append((p,rel,original,updated,after['managed_visual_refresh'][-1]))
for p,rel,original,updated,event in planned:
 assert p.read_bytes()==original
 snapshot=run/'render-escape-originals'/sha(original)/rel;snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(original);p.write_bytes(updated)
report=dict(change='Literal equality encoding prevents a standalone equality line from becoming a Mermaid Markdown heading.',new_inference=False,source_commit=model.meta['source_commit'],changed=[dict(page=rel,original_sha256=sha(original),updated_sha256=sha(updated),original_file=('render-escape-originals/'+sha(original)+'/'+rel),event=event) for p,rel,original,updated,event in planned]);(run/'figure-render-refresh.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Verified managed figure refresh pages:',len(planned));print([row[1] for row in planned])
