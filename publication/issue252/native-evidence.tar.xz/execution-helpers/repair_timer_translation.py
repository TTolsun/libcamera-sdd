from pathlib import Path
import hashlib,json,sys
root=Path.cwd();sys.path.insert(0,str(root/'src'))
from sdd.config import load
from sdd.generation_run import Execution
from sdd.llm import Agent
from sdd.state_io import save
from sdd.translation import _payload,_single_schema,_single_system,_single_value,_validate_text
from sdd.translation_checkpoint import TranslationCall
r=root/'build/issue252/run'
out=r/'bilingual-timer-translation-repair'
out.mkdir()
path=r/'english.json'
original=path.read_bytes()
catalog=json.loads(original)
keys=[key for key in catalog['strings'] if '같은 회차에서' in key and '반환값이 양수' in key and '기한 경과만으로' in key]
assert len(keys)==1
source=keys[0]
prior=catalog['strings'][source]
assert 'and then calls {{7}} if' in prior
(out/'original-english.json').write_bytes(original)
cfg=load(r/'publication.yaml')
cfg.agent=load(cfg.paths['translation_profile']).agent
assert (cfg.agent.kind,cfg.agent.runner,cfg.agent.model,cfg.agent.args)==('cli','codex','gpt-6.1-terra',['-c','model_reasoning_effort="high"'])
system=_single_system(catalog['strings'])+(
    ' For the first sentence, scope the positive poll result ({{3}}) only to processing notifiers ({{5}}). '
    'Use a separate sentence for the subsequent timer step {{7}} and state that it is called regardless of the poll result. '
    'This is the exact source control flow: processTimers is after the ret > 0 block. '
    'Preserve the remaining branches, statements, actor distinctions, and every original placeholder occurrence. '
    'Do not use the timer reset as the actor of emitting the prepared signal.')
schema=_single_schema()
payload=_payload(catalog,{'source':source},terms={})
execution=Execution(cfg,Agent(cfg.agent,out/'prompts'))
execution.path=out/'execution.json'
with execution.track('native-bilingual-timer-translation-repair'),execution.document('timer-conditional-translation',[source]):
    call=TranslationCall(cfg,execution,system,payload,schema,fresh=True,units=[source])
    assert call.saved is None
    text=_validate_text(source,_single_value(call.chat('translation_timer_conditional_scope')))
    first,sep,rest=text.partition('. ')
    assert sep and '{{3}}' in first and '{{5}}' in first and '{{7}}' not in first
    assert '{{7}}' in rest.split('. ',1)[0] and 'regardless' in rest.split('. ',1)[0].lower()
    call.validated(dict(text=text))
    assert call.capture.receipts
    receipt=call.capture.receipts[-1]
assert path.read_bytes()==original
catalog['strings'][source]=text
pending=out/'corrected-english.json'
save(pending,catalog)
record=dict(source=source,prior_translation=prior,validated_native_translation=text,
    old_catalog_sha256=hashlib.sha256(original).hexdigest(),corrected_catalog_sha256=hashlib.sha256(pending.read_bytes()).hexdigest(),
    reviewed='audits/bilingual-05/review.json',receipt=receipt.resolve().relative_to(r).as_posix(),human_review='pending')
(r/'bilingual-timer-translation-repair.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(text)
