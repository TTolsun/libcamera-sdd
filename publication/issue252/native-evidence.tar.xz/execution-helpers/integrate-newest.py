import sys,json,hashlib,shutil
from pathlib import Path
from copy import deepcopy
import yaml
sys.path.insert(0,'src')
from sdd.config import load
from sdd.document_metadata import split_frontmatter
from sdd.facts.model import KnowledgeModel
from sdd import evidence
root=Path.cwd();run=root/'build/issue252/run';public=run.parent/'public'
profile=Path('C:/Users/baboe/.codex/worktrees/5dee/camera-hal-sdd-generator/build/issue250/baseline/publication.yaml');base=load(profile)
m=json.loads((public/'docs/site-manifest.json').read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for key,path in [('facts',base.facts_path),('sections',base.sections_file),('visuals',base.root/base.visuals.file),('english_catalog',Path(base.site.english_catalog))]: assert sha(path)==m['inputs'][key],key
for key,value in m['inputs'].items():
 if key.startswith('markdown/'):assert sha(base.sdd_dir/key[9:])==value,key
old=run/'before-newest-public-base';old.mkdir()
for name in ['config','manuscripts','facts','published-base-manuscripts']:shutil.copytree(run/name,old/name)
for name in ['publication.yaml','contract-review.yaml','english.json','generation.yaml']:shutil.copy2(run/name,old/name)
sec=yaml.safe_load((run/'config/sections.yaml').read_bytes());selected=next(s for s in sec['sections'] if s['id']=='request-lifecycle')
vis=yaml.safe_load((run/'config/visuals.yaml').read_bytes())['sections']['request-lifecycle']
gloss=yaml.safe_load((run/'config/glossary.yaml').read_bytes());added=[t for t in gloss['terms'] if t['term'] in ['QBUF','STREAMOFF','DQBUF']]
for f in base.config_dir.iterdir():
 if f.is_file():shutil.copy2(f,run/'config'/f.name)
write=lambda p,d:p.write_text(yaml.safe_dump(d,allow_unicode=True,sort_keys=False),encoding='utf-8')
d=yaml.safe_load((run/'config/sections.yaml').read_bytes());d['sections']=[selected if s['id']=='request-lifecycle' else s for s in d['sections']];write(run/'config/sections.yaml',d)
d=yaml.safe_load((run/'config/visuals.yaml').read_bytes());d['sections']['request-lifecycle']=vis;write(run/'config/visuals.yaml',d)
d=yaml.safe_load((run/'config/glossary.yaml').read_bytes());assert not {t['term'] for t in added}&{t['term'] for t in d['terms']};d['terms']+=added
aliases=next(t for t in d['terms'] if t['term']=='errno')['aliases'];aliases.append('ENOENT') if 'ENOENT' not in aliases else None;write(run/'config/glossary.yaml',d)
assert split_frontmatter((run/'published-base-manuscripts/request-lifecycle.md').read_text(encoding='utf-8'))[1]==split_frontmatter((base.sdd_dir/'request-lifecycle.md').read_text(encoding='utf-8'))[1]
rows=[]
for f in base.sdd_dir.rglob('*'):
 if not f.is_file():continue
 rel=f.relative_to(base.sdd_dir); target=run/'published-base-manuscripts'/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target)
 if rel.as_posix()=='request-lifecycle.md':continue
 target=run/'manuscripts'/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target);rows.append(dict(file=rel.as_posix(),sha256=sha(f)))
ours=json.loads((run/'facts/facts.json').read_bytes());theirs=json.loads(base.facts_path.read_bytes());assert all(ours[k]==theirs[k] for k in ours if k!='evidence')
shutil.copy2(base.facts_path,run/'facts/facts.json')
gen=yaml.safe_load((run/'generation.yaml').read_bytes());raw=deepcopy(base.raw);raw['source']=gen['source'];raw['output']=gen['output']
for key in ['config','sections_file','scenarios_file','glossary_file','products_file','consistency_file']:
 if key in raw['paths']:raw['paths'][key]=str(run/'config'/Path(raw['paths'][key]).name) if key!='config' else str(run/'config')
raw['visuals']['file']=str(run/'config/visuals.yaml');raw['products']['file']=str(run/'config/products.yaml')
raw['paths']['translation_profile']=str(run/'translation.yaml');raw['paths']['consistency_review_config']=str(run/'contract-review.yaml')
raw['site']['manuscript_profiles']['request-lifecycle.md']=str(run/'request-authentication.yaml')
raw['site'].update(enabled=False,english_catalog=str(run/'english.json'),mermaid_dir=str(public/'docs/assets/mermaid'),translation_batch_size=8)
raw['publication']['operation_id']='issue252-request-depth';raw['publication']['baseline_config']=str(profile)
reports=run/'inherited-newest-reports';reports.mkdir()
for report in raw['publication'].get('reports',[]):
 src=Path(report['path']);assert sha(src)==report['sha256'];target=reports/src.name;shutil.copy2(src,target);report['path']=str(target);report['producer']='inherited-historical/'+report['producer']
oldcfg=yaml.safe_load((run/'publication.yaml').read_bytes());oldedits=oldcfg['site']['coverage_question_edits'];raw['site'].setdefault('coverage_question_edits',{}).update({k:v for k,v in oldedits.items() if k=='request-lifecycle.md'})
write(run/'publication.yaml',raw);review=deepcopy(raw);review['agent']=gen['agent'];review['agent']['max_input_chars']=180000;write(run/'contract-review.yaml',review)
gen['documentation']=raw['documentation'];write(run/'generation.yaml',gen)
trans=yaml.safe_load((run/'translation.yaml').read_bytes());trans['documentation']=raw['documentation'];write(run/'translation.yaml',trans)
cat=json.loads(Path(base.site.english_catalog).read_bytes());ourcat=json.loads((run/'english.json').read_bytes())
for name in ['strings','translation_contexts','source_contexts']:
 for key,value in ourcat.get(name,{}).items():cat.setdefault(name,{}).setdefault(key,value)
(run/'english.json').write_text(json.dumps(cat,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
model=KnowledgeModel.load(run/'facts/facts.json');evidence.collect(load(run/'generation.yaml'),model);model.save(run/'facts/facts.json')
restored=[]
for folder in ['calls','cli']:
 source=base.build_dir/'prompts'/folder
 for f in source.rglob('*'):
  if not f.is_file():continue
  target=run/'build/prompts'/folder/f.relative_to(source);target.parent.mkdir(parents=True,exist_ok=True)
  if target.exists():assert sha(target)==sha(f),str(target)
  else:shutil.copy2(f,target)
  if target.suffix=='.json' and target.name.endswith('.receipt.json'):restored.append(str(target.relative_to(run)))
(run/'historical-native-restoration-newest.json').write_text(json.dumps(dict(receipt_paths=restored,scope='Imported original public issue250 receipts; no new calls.'),indent=2),encoding='utf-8')
(run/'public-base-integration-newest.json').write_text(json.dumps(dict(base_build_id=m['build_id'],base_profile=str(profile),preserved_manuscripts=rows,original_request_prose_unchanged=True,structural_facts_unchanged=True,source_commit=ours['meta']['source_commit'],scope='Latest other pages and reader paths preserved; selected request generated/reviewed independently.'),ensure_ascii=False,indent=2),encoding='utf-8')
print('Newest manifest-bound base integrated:',m['build_id'],len(rows),'non-selected files')
