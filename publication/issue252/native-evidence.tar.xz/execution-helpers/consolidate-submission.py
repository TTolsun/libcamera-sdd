from pathlib import Path
import yaml,json,re,shutil,hashlib
root=Path.cwd();run=root/'build/issue252/run';snapshot=run/'before-submission-consolidation';snapshot.mkdir()
for name in ['sections.yaml']:shutil.copy2(run/'config'/name,snapshot/name)
for p in [run/'config/sections.yaml',root/'examples/libcamera/config/sections.yaml']:
 text=p.read_text(encoding='utf-8');data=yaml.safe_load(text);section=next(s for s in data['sections'] if s['id']=='request-lifecycle');journey=next(t for t in section['design_topics'] if t['id']=='journey');old=next(p for p in journey['parts'] if p['id']=='submission');journey['parts']=[p for p in journey['parts'] if p['id']!='submission']
 start=text.index('  - id: journey\n',text.index('- id: request-lifecycle\n'));end=start+1+re.search(r'^  - id: ',text[start+1:],re.M).start()
 class NoAliases(yaml.SafeDumper):
  def ignore_aliases(self,data):return True
 rendered=yaml.dump([journey],Dumper=NoAliases,allow_unicode=True,sort_keys=False,width=105);replacement=''.join(('  '+line).rstrip()+'\n' for line in rendered.splitlines());candidate=text[:start]+replacement+text[end:];assert yaml.safe_load(candidate)==data;p.write_text(candidate,encoding='utf-8',newline='\n')
reason='Consolidate the duplicate queued-invoke/zero-return/separate-requestCompleted explanation into current resources/problem. Preserve all four technical terms and successful-input condition there; journey retains the concrete message/preparation path. Actual generation18 rejected the duplicate; no validation gate is disabled.'
for name in ['publication.yaml','contract-review.yaml']:
 p=run/name;data=yaml.safe_load(p.read_bytes());data['publication']['allowed_contract_changes']['request-lifecycle/journey/submission/terms']=reason;p.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
(run/'submission-contract-consolidation.json').write_text(json.dumps(dict(reason=reason,from_unit='journey/submission',to_unit='resources/problem',preserved_contract=old,prechange_config_sha256=hashlib.sha256((snapshot/'sections.yaml').read_bytes()).hexdigest(),source_and_questions_Q1_Q7_unchanged=True,human_review='pending'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(reason)
