"""Run the published review with an execution journal local to its attempt."""
from pathlib import Path
import runpy
import sys

from sdd import generation_run


root = Path(__file__).resolve().parents[2]
phase = sys.argv[1]
attempt = sys.argv[sys.argv.index('--attempt') + 1]
assert phase in ('accuracy', 'sufficiency', 'bilingual') and attempt.isdecimal()
folder = root / 'build/issue252/run/audits' / (phase + '-' + attempt)
script = root / 'examples/libcamera/validation/issue252/audit.py'


class AttemptExecution(generation_run.Execution):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.path = folder / 'execution.json'


generation_run.Execution = AttemptExecution
sys.argv[0] = str(script)
runpy.run_path(str(script), run_name='__main__')
