import sys,json
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'src'))
from sdd.config import load
from sdd.llm import Agent
from sdd.generation_run import Execution
run=root/'build/issue252/run';out=run/'audits/code-31';out.mkdir();payload=json.loads((run/'audits/code-30/payload.json').read_bytes())
payload.update(purpose='Follow up the concrete repeat-run provenance defect from code30; semantic source review22/sufficiency19 and publication are separate pending gates.',prior_code=json.loads((run/'audits/code-30/review.json').read_bytes()),actual_test_log=(root/'build/issue252/metadata-repeat-tests.log').read_text(encoding='utf-8'),actual_repeat_proof=json.loads((run/'visual-repeat-verification.json').read_bytes()),correction='Repeat checks hash raw snapshot/current bytes, compare literal body bytes and preserve the original report row. Original snapshots and prior report versions are retained. Primary request-lifecycle is deliberately owned by real generation and independent source reviews, not this historical-carryover helper. A new native ownership plan has no static stage key; static nodes/edges are discarded by replacement.')
payload['complete_helpers']={p:(root/p).read_text(encoding='utf-8') for p in payload['complete_helpers']}
payload['native_question_and_figure_amendments']=(root/'examples/libcamera/validation/issue252/visual-amendments.yaml').read_text(encoding='utf-8')
request=json.loads(next((run/'audits/code-30/prompts/calls').glob('*/*.request.json')).read_bytes());(out/'payload.json').write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8');cfg=load(run/'independent-review.yaml');cfg.publication['operation_id']='issue252-code-repeat-followup-31';execution=Execution(cfg,Agent(cfg.agent,out/'prompts'))
with execution.track('independent-code-repeat-followup'):
 raw=execution.chat('Independently review the concrete fix for the prior code defect and its real repeat-run evidence. No tools or delegation. JSON only. Human approval pending. Code-only verdict does not approve the still-pending manuscript/source/site/deployment gates.',json.dumps(payload,ensure_ascii=False),tag='independent-code-repeat-followup',response_schema=request['response_schema'])
result=json.loads(raw);(out/'review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
