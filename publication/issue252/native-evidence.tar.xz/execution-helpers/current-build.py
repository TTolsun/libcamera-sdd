import importlib.util,sys,json,hashlib
from pathlib import Path
root=Path('/mnt/c/Users/baboe/.codex/worktrees/d2e8/camera-hal-sdd-generator')
p=root/'examples/libcamera/validation/issue252/capture_build.py'
spec=importlib.util.spec_from_file_location('capture_current',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.COMMIT='be7e83e91348250c015aad6d6f59f1468555bae8'
# Keep the audited build implementation; only the declared immutable source/destinations differ.
text=p.read_text().replace("Path.home()/'work/issue252-libcamera'", "Path.home()/'work/issue252-libcamera-current'")
text=text.replace("COMMIT = '293d751a814e0d4c34e85ad457ccd9d5eefd1a61'", "COMMIT = 'be7e83e91348250c015aad6d6f59f1468555bae8'")
ns={'__file__':str(p),'__name__':'__main__'};sys.argv=[str(p),'--attempt','current'];exec(compile(text,str(p),'exec'),ns)
