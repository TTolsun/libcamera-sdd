from pathlib import Path
import yaml,json
run=Path('build/issue252/run')
reasons={
 'request-lifecycle/journey/buffer/terms':'Preserve the stream concept with explicit C++ Stream/stream aliases and add the source-bound -EINVAL/-EEXIST diagnostic branches; no baseline behavior removed.',
 'request-lifecycle/journey/waiting/terms':'Preserve every baseline queue/limit/prepared term and require completeRequest/doQueueRequests to connect the waiting producer and completion-triggered consumer.',
 'request-lifecycle/journey/device-result/terms':'Preserve queueRequestDevice, zero and negative outcomes; add separate parameters and buffers to require their distinct submission responsibilities without inventing parameter-to-stream association.',
 'request-lifecycle/stopping/pending/terms':'Preserve doQueueRequest and strengthen the observation-plan wording with request identity and recording; not a new runtime observation.',
 'request-lifecycle/stopping/disconnect-signal/terms':'The old disconnected-signal unit is split into source-bound disconnect and disconnect-todo parts. Preserve actual signal/state and outstanding-request TODO boundaries in those owners, independently checked by Q5/Q6 reviews.',
 'request-lifecycle/review/completion-record/terms':'Strengthen generic status to the exact req->status() observation and retain recording. Actual logging must remain before pointer lifetime ends; Q4/Q7 independent reviews check that scope.'}
for name in ['publication.yaml','contract-review.yaml']:
 p=run/name;d=yaml.safe_load(p.read_bytes());d['publication']['allowed_contract_changes'].update(reasons);p.write_text(yaml.safe_dump(d,allow_unicode=True,sort_keys=False),encoding='utf-8')
(run/'baseline-contract-change-reasons.json').write_text(json.dumps(reasons,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Six concrete baseline differences retained with per-key reasons; no gate disabled.')
