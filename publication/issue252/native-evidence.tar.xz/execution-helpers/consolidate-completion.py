from pathlib import Path
import yaml,json,re,shutil
root=Path.cwd();run=root/'build/issue252/run';snapshot=run/'before-completion-consolidation';snapshot.mkdir();shutil.copy2(run/'config/sections.yaml',snapshot/'sections.yaml')
removed=['buffer-notification','buffer-complete','request-complete'];preserved=[]
class NoAliases(yaml.SafeDumper):
 def ignore_aliases(self,data):return True
def replace(text,topic):
 start=text.index('  - id: '+topic['id']+'\n',text.index('- id: request-lifecycle\n'));end=start+1+re.search(r'^  (?:- id: |design_requirements:)',text[start+1:],re.M).start();rendered=yaml.dump([topic],Dumper=NoAliases,allow_unicode=True,sort_keys=False,width=105);return text[:start]+''.join(('  '+line).rstrip()+'\n' for line in rendered.splitlines())+text[end:]
for path in [run/'config/sections.yaml',root/'examples/libcamera/config/sections.yaml']:
 text=path.read_text(encoding='utf-8');d=yaml.safe_load(text);section=next(s for s in d['sections'] if s['id']=='request-lifecycle');journey=next(t for t in section['design_topics'] if t['id']=='journey');preserved=[p for p in journey['parts'] if p['id'] in removed];assert len(preserved)==3;journey['parts']=[p for p in journey['parts'] if p['id'] not in removed]
 resources=next(t for t in section['design_topics'] if t['id']=='resources');normal=next(p for p in resources['parts'] if p['id']=='normal')
 normal['question'] += ' 이 항목으로 통합한 기존 completeBuffer 반환 계약도 보존하세요. 요청의 모든 버퍼가 완료되면 true, 남은 버퍼가 있으면 false를 반환하며 true만으로 요청의 명시 완료를 대신하지 않는다는 뜻을 첫 문단에 연결하세요. 별도 원리·기한 의무 문장을 반복하지 마세요.'
 normal['answer_contract']['required_terms'] += [['모든'],['true'],['false']]
 text=replace(replace(text,journey),resources);assert yaml.safe_load(text)==d;path.write_text(text,encoding='utf-8',newline='\n')
reasons={f'request-lifecycle/journey/{part}/terms':('Move duplicate completion API detail to resources/normal (signal then tracking; all buffers true, otherwise false; explicit completeRequest and CameraManager caller duty), with head-queue RequestPending delivery retained in callback-order/request-delivery and resources/out-of-order. Preserve the original technical contract, not duplicate paragraphs. Actual generation19 rejected overlapping detail; no duplicate checker bypass.') for part in removed}
for name in ['publication.yaml','contract-review.yaml']:
 p=run/name;d=yaml.safe_load(p.read_bytes());d['publication']['allowed_contract_changes'].update(reasons);p.write_text(yaml.safe_dump(d,allow_unicode=True,sort_keys=False),encoding='utf-8')
(run/'completion-contract-consolidation.json').write_text(json.dumps(dict(removed_units=preserved,reasons=reasons,source_and_questions_Q1_Q7_unchanged=True,human_review='pending'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Completion contract consolidated without losing true/false or caller/thread obligations.')
