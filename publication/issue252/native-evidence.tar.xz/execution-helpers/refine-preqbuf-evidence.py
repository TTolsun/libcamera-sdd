from pathlib import Path
from copy import deepcopy
import yaml,runpy
root=Path.cwd();replace=runpy.run_path('examples/libcamera/validation/issue252/refine.py')['replace_topic']
for p in [root/'build/issue252/run/config/sections.yaml',root/'examples/libcamera/config/sections.yaml',root/'examples/libcamera/validation/issue252/verification-parts.yaml']:
 text=p.read_text(encoding='utf-8');d=yaml.safe_load(text)
 if 'sections' in d:
  topics={t['id']:t for s in d['sections'] if s['id']=='request-lifecycle' for t in s['design_topics']};topic=topics['review'];part=next(x for x in topic['parts'] if x['id']=='pre-qbuf-case');source=deepcopy(next(x for x in topics['uvc-depth']['sources'] if x['id']=='control-conversion'));assert not any(x['id']=='control-conversion' for x in topic['sources']);topic['sources'].append(source)
 else:part=next(x for x in d['parts'] if x['id']=='pre-qbuf-case')
 part['sources'] += ['request-invariant','control-conversion']
 part['question']=part['question'].replace('UVC processControls 반환 0에 도달한 제어 처리 선행과 부분·무적용 가능성을 구분하고,','UVC에서 processControls가 0을 반환한 제어 처리 선행을 기록합니다. 개별 processControl 반환값·구성된 ControlList·setControls 반환값으로 실제 요청 제어의 적용 범위를 구분하며 성공한 처리에도 전체 요청 제어 적용이나 롤백을 단정하지 않습니다. 이어 ')
 part['prompt'] += ' 정상 경로의 setRequest(nullptr)는 request-invariant 원문에 제공됩니다. 제어 적용 범위의 근거는 반환을 무시한 processControl 호출과 실제 변환 함수·구성된 목록이며, 여기서 processControls가 0을 반환한 전제와 setControls 쓰기 실패의 일반 계약을 혼합하지 마세요. 앞 항목의 제어 세부를 반복하지 말고 이 실패 시험에서 기록할 입력·변환 결과와 기대 분기를 연결합니다.'
 updated=replace(text,topic) if 'sections' in d else yaml.safe_dump(d,allow_unicode=True,sort_keys=False,width=105);assert yaml.safe_load(updated)==d;p.write_text(updated,encoding='utf-8',newline='\n')
print('Supplied actual normal bookkeeping and control-conversion callees; retained the queueBuffer reachability precondition.')
