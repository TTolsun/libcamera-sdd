"""Promote the verified selected native output into the release input set."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import shutil

from sdd.document_metadata import split_frontmatter


work = Path(__file__).resolve().parent
run = work / 'run'
candidate = run / 'standard-repair-candidate-04'
page = 'request-lifecycle.md'
original = run / 'manuscripts' / page
latest = candidate / 'manuscripts' / page
sha = lambda raw: hashlib.sha256(raw).hexdigest()
before, after = [split_frontmatter(path.read_text(encoding='utf-8'))[0] for path in (original, latest)]
assert before['source_commit'] == after['source_commit']
assert {key: value['graph'] for key, value in before['generated_visuals']['records'].items()} == {
    key: value['graph'] for key, value in after['generated_visuals']['records'].items()}


def units(meta):
    result = defaultdict(list)
    for topic, rows in meta['generated_design']['answers'].items():
        for row in rows:
            result[topic, row.get('part_id')].append(row)
    return result


a, b = units(before), units(after)
assert a.keys() == b.keys()
changed = {key for key in a if a[key] != b[key]}
assert changed == {('preparation-depth', 'stop-crossing'), ('preparation-depth', 'fence-timer-tie'),
                   ('uvc-depth', 'completion'), ('review', 'pre-qbuf-case')}, changed
text = lambda key: ' '.join(row['text'] for row in b[key])
assert all(word in text(('preparation-depth', 'stop-crossing')) for word in ('CameraConfigured', '-EACCES', 'allowDisconnected'))
assert all(word in text(('preparation-depth', 'fence-timer-tie')) for word in ('notifierActivated', 'emitPrepareCompleted'))
assert all(word in text(('uvc-depth', 'completion')) for word in ('출력', '캡처', 'remaining', 'FrameError'))
assert all(word in text(('review', 'pre-qbuf-case')) for word in ('-ESHUTDOWN', '-ENOENT', 'Stopping'))
facts_path = run / 'facts/facts.json'
current_facts, new_facts = [json.loads(path.read_bytes()) for path in (facts_path, candidate / 'facts/facts.json')]
assert {key: val for key, val in current_facts.items() if key != 'evidence'} == {
    key: val for key, val in new_facts.items() if key != 'evidence'}
a_evidence, b_evidence = [data['evidence'] for data in (current_facts, new_facts)]
assert all(a_evidence[key] == b_evidence[key] for key in a_evidence.keys() & b_evidence.keys())
new_sources = b_evidence.keys() - a_evidence.keys()
assert new_sources == {'request-lifecycle/preparation-depth/camera-completion-access',
                       'request-lifecycle/preparation-depth/camera-completion-states'}
snapshot = run / 'before-final-standard-repair'
snapshot.mkdir()
for path in (original, run / 'config/sections.yaml', facts_path, run / 'english.json'):
    shutil.copyfile(path, snapshot / path.name)
raw = latest.read_bytes()
original.write_bytes(raw)
shutil.copyfile(candidate / 'sections.yaml', run / 'config/sections.yaml')
a_evidence.update({key: b_evidence[key] for key in new_sources})
facts_path.write_text(json.dumps(current_facts, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
report = dict(before_sha256=sha((snapshot / page).read_bytes()), after_sha256=sha(raw),
              selected_units=sorted(changed), same_native_graphs=True, source_commit=before['source_commit'],
              added_evidence=sorted(new_sources),
              previous_wrapper_failure='Candidate 01 wrote validated native output then failed to format a path outside its profile root. Candidate 03 used a contained output path; its new native DQBUF reply was validated.',
              final_partial='standard-repair-candidate-04/partial-repair/result.json')
(run / 'standard-contract-repair-final.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report))
