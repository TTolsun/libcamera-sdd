"""Bind completed independent review reports before the normal export."""
import argparse
import hashlib
import json
from pathlib import Path

import yaml


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for phase in ('accuracy', 'sufficiency', 'bilingual'):
        parser.add_argument('--' + phase, required=True)
    args = parser.parse_args()
    run = Path(__file__).resolve().parent / 'run'
    profile = run / 'publication.yaml'
    config = yaml.safe_load(profile.read_bytes())
    reports = config['publication']['reports']
    source = json.loads((run / 'scope.json').read_bytes())['source_commit']
    document = hashlib.sha256((run / 'manuscripts/request-lifecycle.md').read_bytes()).hexdigest()

    def append(path, producer, bindings):
        raw = path.read_bytes()
        actual = json.loads(raw)
        assert all(actual.get(key) == value for key, value in bindings.items())
        assert not any(row['path'] == str(path) for row in reports)
        reports.append(dict(path=str(path), gate='before-export', producer=producer,
                            sha256=hashlib.sha256(raw).hexdigest(), bindings=bindings))

    for phase in ('accuracy', 'sufficiency', 'bilingual'):
        name = getattr(args, phase)
        assert name.startswith(phase + '-') and '/' not in name and '\\' not in name
        append(run / 'audits' / name / 'review.json', 'issue252/independent-native-' + phase,
               dict(status='passed', phase=phase, human_review='pending', source_commit=source,
                    document_sha256=document))
    append(run / 'native-call-verification.json', 'issue252/native-call-verification',
           dict(status='verified', human_review='pending'))
    append(run / 'build/consistency-review.json', 'issue252/independent-native-standard-contract-audit',
           dict(status='passed', human_review='pending', source_commit=source))
    snapshot = run / 'publication-before-final-review-bindings.yaml'
    with snapshot.open('xb') as original:
        original.write(profile.read_bytes())
    profile.write_text(yaml.safe_dump(config, allow_unicode=True, sort_keys=False), encoding='utf-8', newline='\n')
    print('Bound five current reports to the normal export gate.')


if __name__ == '__main__':
    main()
