from copy import deepcopy
from pathlib import Path
import hashlib,json,shutil,sys
import yaml
root=Path.cwd()
sys.path.insert(0,str(root/'src'))
from sdd.config import load
from sdd.document_metadata import split_frontmatter
from sdd.facts.model import KnowledgeModel
from sdd.generated_visuals import generate,resolve
from sdd.generation_run import Execution
from sdd.llm import Agent
from sdd.render_profiles import for_page
from sdd.validation_stage import stage
from sdd.visual_refresh import refresh

work=root/'build/issue252'
run=work/'run'
out=run/'bilingual-figure-repair'
out.mkdir()
selected='request-lifecycle'
page=selected+'.md'
changed={'preparation-depth-flow','failure-investigation-flow','submission-order-flow'}
path=run/'manuscripts'/page
raw=path.read_bytes()
sha=lambda value:hashlib.sha256(value).hexdigest()
digest=sha(raw)
review=json.loads((run/'audits/bilingual-02/review.json').read_bytes())
assert review['status']=='needs-work' and review['document_sha256']==digest
text=path.read_text(encoding='utf-8')
original_cfg=load(run/'publication.yaml')
generation_cfg=load(run/'generation.yaml')
visual_path=original_cfg.root/original_cfg.visuals.file
raw_visuals=visual_path.read_bytes()
(out/'original-visuals.yaml').write_bytes(raw_visuals)
(out/'original-manuscript.md').write_bytes(raw)
shutil.copyfile(run/'english.json',out/'original-english.json')
plan=yaml.safe_load(raw_visuals)
example=yaml.safe_load((root/'examples/libcamera/config/visuals.yaml').read_bytes())
prompts={row['id']:row['prompt'] for row in example['sections'][selected] if row['id'] in changed}
assert prompts.keys()==changed
for row in plan['sections'][selected]:
    if row['id'] in prompts:
        assert row['prompt']!=prompts[row['id']]
        row['prompt']=prompts[row['id']]
pending=out/'new-visuals.yaml'
pending.write_text(yaml.safe_dump(plan,allow_unicode=True,sort_keys=False),encoding='utf-8',newline='\n')
replacement_cfg=deepcopy(original_cfg)
for cfg in (generation_cfg,replacement_cfg):
    cfg.raw['visuals']['file']=str(pending)
assert generation_cfg.agent.label==for_page(replacement_cfg,page).agent.label
section=next(section for section in generation_cfg.sections() if section['id']==selected)
model=KnowledgeModel.load(generation_cfg.facts_path)
meta,_=split_frontmatter(text)
before=meta['generated_visuals']['records']
execution=Execution(generation_cfg,Agent(generation_cfg.agent,out/'prompts'),model=model)
with stage() as state:
    state.pin(generation_cfg)
    with execution.track('native-bilingual-figure-repair'):
        artifact=generate(generation_cfg,model,section,execution,previous=text)
    after=artifact['records']
    assert before.keys()==after.keys()
    differences={key for key in before if before[key]['graph']!=after[key]['graph']}
    assert differences==changed,differences
    for key in before.keys()-changed:
        assert before[key]['input_fingerprint']==after[key]['input_fingerprint']
        after[key]=before[key]
    assert all(not after[key]['reused'] for key in changed)
    resolve(generation_cfg,model,section,artifact)
    (out/'native-artifact.json').write_text(json.dumps(artifact,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    updated=refresh(replacement_cfg,model,selected,raw,expected_sha256=digest,
                    original_cfg=original_cfg,visual_artifact=artifact)
new_meta,_=split_frontmatter(updated.decode('utf-8').replace('\r\n','\n'))
assert new_meta['generated_design']['answers']==meta['generated_design']['answers']
assert path.read_bytes()==raw and visual_path.read_bytes()==raw_visuals
(out/'derived-manuscript.md').write_bytes(updated)
visual_path.write_bytes(pending.read_bytes())
path.write_bytes(updated)
receipt=dict(original_sha256=digest,updated_sha256=sha(updated),original_visuals_sha256=sha(raw_visuals),
    updated_visuals_sha256=sha(pending.read_bytes()),confirmed_finding='audits/bilingual-02/review.json',
    generated_figures=sorted(changed),retained_native_figures=len(before)-len(changed),
    unchanged_design_answers=True,source_commit=model.meta['source_commit'],
    execution=execution.path.relative_to(run).as_posix(),
    managed_refresh=new_meta['managed_visual_refresh'][-1])
(run/'bilingual-figure-repair.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(new_native_figures=sorted(changed),unchanged=len(before)-len(changed),manuscript_sha256=sha(updated))))
