from pathlib import Path
import sys,json,subprocess
root=Path.cwd();sys.path.insert(0,str(root/'src'))
from sdd.config import load
from sdd.llm import Agent
from sdd.generation_run import Execution
run=root/'build/issue252/run';out=run/'audits/code-34';out.mkdir()
paths=['examples/libcamera/validation/issue252/audit.py','examples/libcamera/validation/issue252/verify_native_calls.py','examples/libcamera/validation/issue252/browser_test.cjs']
payload=dict(purpose='Final small validation-tool follow-up after code33. Full selected-source/manuscript/bilingual/export/browser/merge/Pages remain independent gates, not code-pass claims.',prior_review=json.loads((run/'audits/code-33/review.json').read_bytes()),complete_code={p:(root/p).read_text(encoding='utf-8') for p in paths},delta=subprocess.check_output(['git','diff','a413d70','--',*paths],encoding='utf-8'),core_unchanged_from_prior_review=subprocess.check_output(['git','diff','a413d70','--','src/sdd/generated_visuals.py','src/sdd/visuals.py','src/sdd/visual_refresh.py'],encoding='utf-8'),actual_selected_validation_regression=(root/'build/issue252/guard-message-config-tests.log').read_text(encoding='utf-8'),actual_post_main_role_regression=(root/'build/issue252/main-role-integration-tests.log').read_text(encoding='utf-8'),scope='Prior report is source-review data, never inherited approval. Current full sources/document and all mandatory questions are rechecked. New imported public receipts are excluded only via immutable import map. Browser wait timeout uses Playwright third argument. No invented human approvals or physical tests.')
request=json.loads(next((run/'audits/code-33/prompts/calls').glob('*/*.request.json')).read_bytes());(out/'payload.json').write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8');cfg=load(run/'independent-review.yaml');cfg.publication['operation_id']='issue252-final-validation-code-34';execution=Execution(cfg,Agent(cfg.agent,out/'prompts'))
with execution.track('independent-final-validation-code'):
 raw=execution.chat('Independently review the concrete final validation-tool changes and their consumers. No tools or delegation. JSON only. Human approval pending. Do not approve source/manuscript/bilingual/site/merge/deployment gates by this code-only result.',json.dumps(payload,ensure_ascii=False),tag='independent-final-validation-code',response_schema=request['response_schema'])
result=json.loads(raw);(out/'review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
