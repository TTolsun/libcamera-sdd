from collections import defaultdict
import hashlib
import json
from pathlib import Path
import shutil

import yaml
from sdd.document_metadata import split_frontmatter

work = Path(__file__).resolve().parent
run = work / 'run'
candidate = run / 'final-planes-candidate'
relative = 'request-lifecycle.md'
old = run / 'manuscripts' / relative
new = candidate / 'manuscripts' / relative
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
a, b = [split_frontmatter(path.read_text(encoding='utf-8'))[0] for path in (old, new)]


def units(meta):
    out = defaultdict(list)
    for name, rows in meta['generated_design']['answers'].items():
        for row in rows:
            out[name, row.get('part_id')].append(row)
    return out


first, second = units(a), units(b)
assert first.keys() == second.keys()
changed = [key for key in first if first[key] != second[key]]
assert changed == [('uvc-depth', 'pre-qbuf-planes')], changed
assert a['generated_visuals']['records'] == b['generated_visuals']['records']
words = ' '.join(row['text'] for row in second[changed[0]])
assert all(word in words for word in ('-EINVAL', 'planes', 'numV4l2Planes'))
assert '수만으로 오류를 반환하지' not in words
catalog = candidate / 'english.json'
shutil.copyfile(run / 'bilingual-scenario-translation-repair/corrected-english.json', catalog)
for name in ('publication.yaml', 'contract-review.yaml'):
    profile = yaml.safe_load((run / name).read_bytes())
    profile['paths']['sections_file'] = str(candidate / 'sections.yaml')
    profile['site']['english_catalog'] = str(catalog)
    profile['output'].update(facts_dir=str(candidate / 'facts'), sdd_dir=str(candidate / 'manuscripts'),
                             diagrams_dir=str(candidate / 'manuscripts/diagrams'))
    (candidate / name).write_text(yaml.safe_dump(profile, allow_unicode=True, sort_keys=False),
                                 encoding='utf-8', newline='\n')
report = dict(before_sha256=sha(old), after_sha256=sha(new), selected_units=changed,
              source_commit=b['source_commit'], same_native_graphs=True,
              raw_generation='final-planes-candidate/partial-repair/result.json')
(run / 'final-planes-unit-repair.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report))
