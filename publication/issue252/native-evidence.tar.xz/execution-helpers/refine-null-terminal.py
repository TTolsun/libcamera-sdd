from pathlib import Path
import yaml,re,json
root=Path.cwd();run=root/'build/issue252/run';here=root/'examples/libcamera/validation/issue252'
for p in [run/'config/visuals.yaml',root/'examples/libcamera/config/visuals.yaml',here/'visual-amendments.yaml']:
 text=p.read_text(encoding='utf-8');d=yaml.safe_load(text);plans=d.get('additions') or d['sections']['request-lifecycle'];v=next(v for v in plans if v['id']=='failure-investigation-flow');v['max_nodes']=10;v['prompt']=v['prompt'].replace('9노드를 사용합니다.','10노드를 사용합니다.').replace('bufferAvailable→dequeueBuffer는 호출, dequeueBuffer→bufferAvailable은 nullptr 반환 화살표로 구별하고 검사 이전에 무알림 반환으로 가지 마세요.','bufferAvailable 진입→dequeueBuffer는 호출입니다. dequeueBuffer의 오류·예상 밖 index에서 nullptr이면 별도의 bufferAvailable 반환 상태 노드로 연결하고 그 종료 노드는 bufferReady 없이 반환하며 나가는 화살표가 없습니다. 함수 진입과 반환 상태에 각각 별도 노드를 사용하세요. nullptr 화살표를 진입 노드로 되돌리거나 이번 호출 안의 반복·재시도 순환을 만들지 마세요. 다른 장치 이벤트의 후속 호출은 이 그림의 실행 순서에 넣지 마세요.')
 if 'additions' in d:updated=yaml.safe_dump(d,allow_unicode=True,sort_keys=False,width=105)
 else:
  start=text.index('  - id: failure-investigation-flow\n',text.index('  request-lifecycle:\n'));m=re.search(r'^  (?:- id: |[a-z][^\n]*:\n)',text[start+3:],re.M);end=start+3+m.start();block=yaml.safe_dump([v],allow_unicode=True,sort_keys=False,width=105);updated=text[:start]+''.join(('  '+line).rstrip()+'\n' for line in block.splitlines())+text[end:]
 assert yaml.safe_load(updated)==d;p.write_text(updated,encoding='utf-8',newline='\n')
p=here/'browser_test.cjs';s=p.read_text(encoding='utf-8');s=s.replace("id==='callback-order-flow'?11:9","id==='callback-order-flow'?11:id==='failure-investigation-flow'?10:9");p.write_text(s,encoding='utf-8',newline='\n')
(run/'source-review-refinement-27-24.json').write_text(json.dumps(dict(source_windows_unchanged=27,change='Native failure figure needs a separate terminal return state, not a call/return cycle.',explicit_node_limit=dict(previous=9,current=10,configured_global=12,reason='Distinct entry, device-return check and no-bufferReady terminal states; no relaxed overflow acceptance.')),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
