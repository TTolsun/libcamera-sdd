import json,hashlib,shutil,re,yaml
from pathlib import Path
root=Path.cwd();work=root/'build/issue252';run=work/'run'
p=work/'build-provenance-current.json';build=json.loads(p.read_bytes());assert build['status']=='passed' and build['source_commit']=='be7e83e91348250c015aad6d6f59f1468555bae8'
for row in build['inputs'].values():assert hashlib.sha256((work/row['file']).read_bytes()).hexdigest()==row['sha256']
scope_path=run/'scope.json';scope=json.loads(scope_path.read_bytes());scope['historical_build']=scope['build'];scope['build']=dict(status='passed',record='../build-provenance-current.json',record_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),source_commit=build['source_commit'],fresh_configuration=True,full_rebuild=True)
scope['public_base']=json.loads((run/'public-base-integration-current.json').read_bytes());scope['generator_base']='5513808c7a999a9ce1c41456459e02877511a9c3'
scope_path.write_text(json.dumps(scope,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
shutil.copy2(work/'build-inputs-current/compile_commands.json',run/'uvc-current-compile_commands.json')
for name in ['generation.yaml','publication.yaml','translation.yaml','contract-review.yaml','independent-review.yaml']:
 p=run/name;d=yaml.safe_load(p.read_bytes());d['source']['compile_commands']=str(run/'uvc-current-compile_commands.json');p.write_text(yaml.safe_dump(d,allow_unicode=True,sort_keys=False),encoding='utf-8')
# Keep the example's per-item lifetime figure plans in sync with the current public contract.
p=root/'examples/libcamera/config/visuals.yaml';text=p.read_text(encoding='utf-8');d=yaml.safe_load(text);current=yaml.safe_load((run/'config/visuals.yaml').read_bytes());plans=current['sections']['request-lifecycle'];resources=[v for v in plans if v.get('topic')=='resources'];existing=d['sections']['request-lifecycle'];ids={v['id'] for v in resources};result=[v for v in existing if v.get('topic')!='resources' and v['id'] not in ids]+resources
start=text.index('  request-lifecycle:\n');end=start+len('  request-lifecycle:\n')+re.search(r'^  [a-z][^\n]*:\n',text[start+len('  request-lifecycle:\n'):],re.M).start()
rendered=yaml.safe_dump({'request-lifecycle':result},allow_unicode=True,sort_keys=False,width=105);block=''.join(('  '+line).rstrip()+'\n' for line in rendered.splitlines());p.write_text(text[:start]+block+text[end:],encoding='utf-8',newline='\n')
p=root/'examples/libcamera/reader-paths.yaml';text=p.read_text(encoding='utf-8');old='section: request-lifecycle, topic: resources, part: summary';assert old in text;p.write_text(text.replace(old,'section: request-lifecycle, topic: resources, part: ownership'),encoding='utf-8',newline='\n')
print('Current build frozen before generation; retained historical source/build/probe scope unchanged.')
