import sys,json,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'src'))
from sdd.config import load
from sdd.llm import Agent
from sdd.generation_run import Execution
run=root/'build/issue252/run';out=run/'audits/code-29';out.mkdir()
previous=json.loads((run/'audits/code-28/review.json').read_bytes())
payload=dict(purpose='Final code-only follow-up to code28. Its semantic/source-review pending finding remains OPEN and is not being resolved by this code review; full native accuracy and sufficiency are separate later gates. Assess the two concrete helper defects and their corrections, not whole issue acceptance.',prior_review=previous,source_audit_state='pending-final-regenerated-manuscript; do not report source sufficiency complete',complete_code={p:(root/p).read_text(encoding='utf-8') for p in ['examples/libcamera/validation/issue252/refine.py','examples/libcamera/validation/issue252/browser_test.cjs','examples/libcamera/validation/issue252/verify_native_calls.py','tests/test_issue252_validation.py']},actual_tests=(root/'build/issue252/refine-preservation-tests.log').read_text(encoding='utf-8'),scope=json.loads((run/'scope.json').read_bytes()))
request=json.loads(next((run/'audits/code-28/prompts/calls').glob('*/*.request.json')).read_bytes());(out/'payload.json').write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8')
cfg=load(run/'independent-review.yaml');cfg.publication['operation_id']='issue252-code-followup-29';execution=Execution(cfg,Agent(cfg.agent,out/'prompts'))
with execution.track('independent-code-followup'):
 raw=execution.chat('Independently review the concrete helper fixes and regression test. No tools, no delegation, JSON only. Human review pending. A code-only pass does not approve source sufficiency, manuscript, browser or deployment. Report real defects in this delta.',json.dumps(payload,ensure_ascii=False),tag='independent-code-followup',response_schema=request['response_schema'])
result=json.loads(raw);(out/'review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
