"""Install only reviewed manifest-owned output into the public worktree."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil


def digest(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def owned(root, name):
    result = (root / name).resolve()
    if not result.is_relative_to(root) or result == root or result.relative_to(root).as_posix() != name:
        raise ValueError(f'Invalid manifest-owned path {name!r}')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('site', type=Path)
    args = parser.parse_args()
    work = Path(__file__).resolve().parent
    public = (work / 'public/docs').resolve()
    site = args.site.resolve()
    assert site.is_relative_to(work) and not site.is_relative_to(public.parent)
    name = 'site-manifest.json'
    public_manifest, reviewed_manifest = public / name, site / name
    baseline = json.loads((work / 'run/published-manifest-for-overlay.json').read_bytes())
    current = json.loads(public_manifest.read_bytes())
    reviewed = json.loads(reviewed_manifest.read_bytes())
    if current != baseline:
        raise ValueError('Public manifest baseline moved; integrate the new baseline before overlay')
    previous, updated = current['outputs'], reviewed['outputs']
    for rel, expected in previous.items():
        if digest(owned(public, rel)) != expected:
            raise ValueError(f'Public baseline bytes differ for {rel}')
    changes = []
    for rel, expected in updated.items():
        source, target = owned(site, rel), owned(public, rel)
        if digest(source) != expected:
            raise ValueError(f'Reviewed output differs for {rel}')
        if rel not in previous and target.exists():
            raise ValueError(f'New owned output would overwrite an unowned path {rel}')
        if previous.get(rel) != expected:
            changes.append((source, target))
    stale = [owned(public, rel) for rel in sorted(previous.keys() - updated.keys())]
    for source, target in changes:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    for path in stale:
        path.unlink()
    shutil.copyfile(reviewed_manifest, public_manifest)
    assert all(digest(owned(public, rel)) == expected for rel, expected in updated.items())
    print(json.dumps(dict(build_id=reviewed['build_id'], changed=len(changes), removed=len(stale),
                          verified_outputs=len(updated))))


if __name__ == '__main__':
    main()
