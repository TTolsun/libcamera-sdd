from pathlib import Path
import hashlib,json,re,sys
root=Path.cwd()
sys.path.insert(0,str(root/'src'))
from sdd.config import load
from sdd.generation_run import Execution
from sdd.llm import Agent
from sdd.state_io import save
from sdd.translation import _input_size, _payload, _single_schema, _single_system, _single_value, _validate_text
from sdd.translation_checkpoint import TranslationCall

r=root/'build/issue252/run'
out=r/'bilingual-question-translation-repair'
out.mkdir()
path=r/'english.json'
original=path.read_bytes()
catalog=json.loads(original)
review=json.loads((r/'audits/bilingual-03/review.json').read_bytes())
source='callback-return 표시는 어떤 후속 작업보다 앞서며, 무엇의 완료를 추적하지 않습니까?'
prior=catalog['strings'][source]
assert 'any follow-up work' in prior and any(prior[:60] in f['claim'] or 'any follow-up work' in f['claim'] for f in review['findings'])
(out/'original-english.json').write_bytes(original)
cfg=load(r/'publication.yaml')
cfg.agent=load(cfg.paths['translation_profile']).agent
assert cfg.agent.kind=='cli' and cfg.agent.runner=='codex' and cfg.agent.model=='gpt-6.1-terra'
assert cfg.agent.args==['-c','model_reasoning_effort="high"']
system=_single_system(catalog['strings'])+(
 ' This source is an information-seeking two-part heading. Translate 어떤 as the interrogative '
 'which or what, never the universal any/all. Preserve a natural question asking the reader to identify '
 'specific subsequent operations and the completion that the marker does not track. The observed marker '
 'precedes the counter increment and local destruction in the bounded probe; do not generalize to every '
 'possible follow-up or imply that the exact C++ return was traced. Keep the heading a question.')
payload=_payload(catalog,{'source':source},terms={})
schema=_single_schema()
assert _input_size(cfg,system,payload,schema)<=cfg.agent.max_input_chars
agent=Execution(cfg,Agent(cfg.agent,out/'prompts'))
with agent.track('native-bilingual-question-translation-repair'),agent.document('callback-return-question',[source]):
    call=TranslationCall(cfg,agent,system,payload,schema,fresh=True,units=[source])
    assert call.saved is None
    text=_validate_text(source,_single_value(call.chat('translation_callback_return_question_semantics')))
    if not re.match(r'^(Which|What)\b',text) or not text.endswith('?') or re.search(r'\b(?:any|all|every)\b',text,re.I):
        raise ValueError('Fresh translation must preserve the interrogative scope; previous catalog retained.')
    call.validated(dict(text=text))
    assert call.capture.receipts
    receipt=call.capture.receipts[-1]
assert path.read_bytes()==original
catalog['strings'][source]=text
save(path,catalog)
before=json.loads(original)
actual=json.loads(path.read_bytes())
assert {k:v for k,v in before.items() if k!='strings'}=={k:v for k,v in actual.items() if k!='strings'}
assert [k for k,v in actual['strings'].items() if v!=before['strings'][k]]==[source]
summary=dict(source=source,prior_translation=prior,validated_native_translation=text,
    receipt=receipt.resolve().relative_to(r).as_posix(),review='audits/bilingual-03/review.json',
    original_catalog_sha256=hashlib.sha256(original).hexdigest(),
    new_catalog_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),human_review='pending')
(r/'bilingual-question-translation-repair.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False))
