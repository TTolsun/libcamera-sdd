from pathlib import Path
from copy import deepcopy
import yaml,json,subprocess,hashlib,runpy,shutil,re
root=Path.cwd();run=root/'build/issue252/run';here=root/'examples/libcamera/validation/issue252';replace=runpy.run_path(str(here/'refine.py'))['replace_topic'];source='include/libcamera/base/utils.h';commit='be7e83e91348250c015aad6d6f59f1468555bae8'
scope=run/'scope.json';index=run/'source-window-index.json';shutil.copy2(scope,run/'scope-before-utils.json');shutil.copy2(index,run/'source-window-index-before-utils.json')
git=lambda ref:subprocess.check_output(['git','-C',str(run.parent/'source'),'show',ref+':'+source]);raw=git(commit);assert raw==git('293d751a814e0d4c34e85ad457ccd9d5eefd1a61');assert (run.parent/'source'/source).read_bytes().replace(b'\r\n',b'\n')==raw
target=run/'source-windows'/source;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);row=dict(file=source,line=1,end_line=len(raw.splitlines()),sha256=hashlib.sha256(raw).hexdigest(),latest_blob_equal=True)
d=json.loads(scope.read_bytes());assert len(d['source_windows'])==26;d['source_windows'].append(row);d['amendments'].append(dict(phase='before corrected scope-exit generation',questions_unchanged=True,previous_scope_sha256=hashlib.sha256((run/'scope-before-utils.json').read_bytes()).hexdigest(),changes=['Add complete utils.h to verify actual scope_exit destructor/active/release semantics used by pre-QBUF cache cleanup. Same fixed source/build; not a new hardware run.']));scope.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');index.write_text(json.dumps(d['source_windows'],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
selector=dict(id='scope-exit',file=source,start='template<typename EF>\nclass scope_exit',end='scope_exit(EF) -> scope_exit<EF>;')
for p in [run/'config/sections.yaml',root/'examples/libcamera/config/sections.yaml',here/'topics.yaml',here/'verification-parts.yaml']:
 text=p.read_text(encoding='utf-8');data=yaml.safe_load(text)
 if 'sections' in data:
  topics={t['id']:t for s in data['sections'] if s['id']=='request-lifecycle' for t in s['design_topics']};topics['uvc-depth']['sources'].append(deepcopy(selector));topics['review']['sources'].append(deepcopy(selector));next(p for p in topics['uvc-depth']['parts'] if p['id']=='pre-qbuf-planes')['sources'].append('scope-exit');next(p for p in topics['review']['parts'] if p['id']=='pre-qbuf-case')['sources'].append('scope-exit');updated=replace(replace(text,topics['uvc-depth']),topics['review'])
 elif 'topics' in data:
  topic=next(t for t in data['topics'] if t['id']=='uvc-depth');topic['sources'].append(deepcopy(selector));next(p for p in topic['parts'] if p['id']=='pre-qbuf-planes')['sources'].append('scope-exit');updated=yaml.safe_dump(data,allow_unicode=True,sort_keys=False,width=105)
 else:
  next(p for p in data['parts'] if p['id']=='pre-qbuf-case')['sources'].append('scope-exit');updated=yaml.safe_dump(data,allow_unicode=True,sort_keys=False,width=105)
 assert yaml.safe_load(updated)==data;p.write_text(updated,encoding='utf-8',newline='\n')
for p in [run/'config/visuals.yaml',root/'examples/libcamera/config/visuals.yaml',here/'visual-amendments.yaml']:
 text=p.read_text(encoding='utf-8');data=yaml.safe_load(text);plans=data['additions'] if 'additions' in data else data['sections']['request-lifecycle'];plan=next(v for v in plans if v['id']=='pre-qbuf-failure-flow');plan['sources'].append('scope-exit');plan['whole_sources'].append('scope-exit')
 if 'additions' in data:updated=yaml.safe_dump(data,allow_unicode=True,sort_keys=False,width=105)
 else:
  start=text.index('  - id: pre-qbuf-failure-flow\n',text.index('  request-lifecycle:\n'));m=re.search(r'^  (?:- id: |[a-z][^\n]*:\n)',text[start+3:],re.M);end=start+3+m.start();rendered=yaml.safe_dump([plan],allow_unicode=True,sort_keys=False,width=105);updated=text[:start]+''.join(('  '+line).rstrip()+'\n' for line in rendered.splitlines())+text[end:]
 assert yaml.safe_load(updated)==data;p.write_text(updated,encoding='utf-8',newline='\n')
print('27 complete frozen source files; actual scope_exit semantics supplied without changing source/build or Q1–Q7.')
