from pathlib import Path
from copy import deepcopy
import yaml,json,re,runpy
root=Path.cwd();run=root/'build/issue252/run';here=root/'examples/libcamera/validation/issue252';replace_topic=runpy.run_path(str(here/'refine.py'))['replace_topic']
class NoAliases(yaml.SafeDumper):
 def ignore_aliases(self,data):return True
def dump(d):return yaml.dump(d,Dumper=NoAliases,allow_unicode=True,sort_keys=False,width=105)
bulk=dict(id='bulk-cancel',file='src/libcamera/request.cpp',start='void Request::Private::doCancelRequest()',end='\n}')
frame=dict(id='framebuffer-cancel',file='include/libcamera/internal/framebuffer.h',start='void cancel() { metadata_.status = FrameMetadata::FrameCancelled; }',end='void cancel() { metadata_.status = FrameMetadata::FrameCancelled; }')
cancel_prompt='제공된 cancellation-flow·bulk-cancel·framebuffer-cancel·completion-flow로 확인된 취소 동작을 미확인이라고 쓰지 마세요. 각 pending 버퍼의 cancel과 bufferCompleted 발생, 이후 pending_.clear와 cancelled_ 설정, 이어지는 completeRequest의 상태·선두 반환을 소스에서 확인한 시험 기대 분기로 연결하세요. 정상 completeBuffer의 setRequest(nullptr) 경로와 bulk 취소의 차이도 유지합니다. 실제 주입 실행·장치 동작·별도 Queued 수신 완료는 미실시이며 정적 분기와 구분합니다. 명사절 질문 나열 없이 기록합니다·대조합니다로 두 짧은 문단을 완성하세요.'
for p in [run/'config/sections.yaml',root/'examples/libcamera/config/sections.yaml']:
 text=p.read_text(encoding='utf-8');d=yaml.safe_load(text);s=next(s for s in d['sections'] if s['id']=='request-lifecycle');topics={t['id']:t for t in s['design_topics']};review=topics['review'];review['sources'] += [deepcopy(bulk),deepcopy(frame)];part=next(p for p in review['parts'] if p['id']=='pre-qbuf-case');part['sources'] += ['cancellation-flow','bulk-cancel','framebuffer-cancel'];part['prompt']=cancel_prompt
 plane=next(p for p in topics['uvc-depth']['parts'] if p['id']=='pre-qbuf-planes');plane['question']=plane['question'].replace('일반 OUTPUT 전용 bytesused 합치기 검사는 이 capture 사례의 실패라고 확대하지 마세요.','위 두 공통 검사에 집중하고 다른 형식의 bytesused 합치기 세부 검사를 이 사례로 확대하지 마세요.')
 stopping=topics['stopping'];extra=[]
 for source,newid in [('common-stop','stop-implementation'),('uvc-stop','uvc-stop-implementation'),('streamoff','streamoff-implementation')]:
  item=deepcopy(next(x for x in topics['stop-depth']['sources'] if x['id']==source));item['id']=newid;stopping['sources'].append(item);extra.append(newid)
 summary=next(p for p in stopping['parts'] if p['id']=='summary');summary['sources'] += extra;summary['max_statements']=2
 summary['question']='첫 문장을 PipelineHandler::stop의 문서 계약이라고 명시하고 모든 미완료 요청의 취소·즉시 오류 완료를 요구하는 내용을 설명하세요. Camera::disconnect의 Running 중 연결 해제에서 대기 요청 처리가 TODO라는 점을 둘째 문장으로 비교합니다. 다음 짧은 문단은 선택 UVC 구현의 실패 범위입니다. STREAMOFF가 장치 버퍼 반환 전에 실패하면 UVC stopDevice는 음수를 검사하지 않고 releaseBuffers를 계속 호출하므로 위 계약이 모든 실패에서 자동 충족되거나 모든 요청이 반환된다고 보장하지 않는다는 한계를 바로 연결하세요. 남은 queuedRequests_는 공통 stop의 ASSERT 경계가 될 수 있으므로 정상 반환 0도 무조건 보장하지 마세요. 실제 실패 관측이나 다른 파이프라인의 지원 보장으로 쓰지 마세요.'
 summary['prompt']='계약은 계약으로, 선택 UVC의 오류 경로는 구현의 조건부 한계로 구분하세요. 첫 문장에 문서 계약이라는 한정을 넣고 일반 동작의 무조건 보장처럼 쓰지 마세요. 기존 즉시 오류 완료·연결 해제 TODO를 보존하고 두 짧은 문단으로 연결합니다.'
 summary['answer_contract']['required_terms'].append(['계약'])
 updated=text
 for topic in [review,stopping,topics['uvc-depth']]:updated=replace_topic(updated,topic)
 assert yaml.safe_load(updated)==d;p.write_text(updated,encoding='utf-8',newline='\n')
saved_summary=deepcopy(summary)
p=here/'verification-parts.yaml';d=yaml.safe_load(p.read_bytes());part=next(p for p in d['parts'] if p['id']=='pre-qbuf-case');part['sources'] += ['cancellation-flow','bulk-cancel','framebuffer-cancel'];part['prompt']=cancel_prompt;p.write_text(dump(d),encoding='utf-8',newline='\n')
p=here/'topics.yaml';d=yaml.safe_load(p.read_bytes());part=next(p for t in d['topics'] if t['id']=='uvc-depth' for p in t['parts'] if p['id']=='pre-qbuf-planes');part['question']=plane['question'];p.write_text(dump(d),encoding='utf-8',newline='\n')
errno_prompt=' UVC의 findBuffer 실패 분기는 함수 안에서 직접 상수 -ENOENT를 반환합니다. processControls와 queueBuffer의 음수는 원래 ret를 그대로 전달합니다. queueBuffer의 cache get도 -ENOENT를 반환할 수 있으므로 findBuffer 실패에만 -ENOENT라는 배타적 표현은 한영 모두 금지합니다. 같은 errno라도 발생 위치를 구분하세요.'
flow_prompt='cache_가 존재하고 Stopping이 아닌 queueBuffer 진입에서 QBUF 이전 두 오류를 비교합니다. 9개 고정 심볼은 함수·검증·호출자 반환 역할입니다. queueBuffer 진입→get을 연결하고 get의 음수 반환은 queueBuffer 진입으로 되돌리지 말고 UVC queueRequestDevice의 원래 ret 전달→doQueueRequest의 비0 검사→cancelRequest로 이어집니다. get 성공은 planes와 isContiguous 공통 검사로 진행하고 실패하면 scope_exit의 put→UVC 원래 ret 전달→doQueueRequest→cancelRequest로 이어집니다. put 오류 경로를 고립된 노드로 남기지 마세요. 검증 성공만 VIDIOC_QBUF 진입으로 연결하며 ioctl 이후 상세는 별도 본문 범위입니다. get 실패는 아직 guard·예약 index가 없고 plane 실패는 확보 index를 put합니다. 두 오류에서 이번 버퍼의 신규 queuedBuffers_ 등록은 없으며 다른 요청까지 큐가 비었다고 그리지 마세요. 제어 처리는 선행하지만 모두 적용됐다는 보장이나 롤백은 없습니다. 오류 반환을 함수 진입으로 되돌리는 순환이나 복구 화살표를 만들지 마세요. 실제 주입 실행 결과가 아닌 소스의 정적 분기이며 한영 같은 ret·정리·취소 경계를 유지합니다.'
def replace_visual(text,plan):
 start=text.index('  request-lifecycle:\n');body=start+len('  request-lifecycle:\n');end=body+re.search(r'^  [a-z][^\n]*:\n',text[body:],re.M).start();segment=text[body:end];m=re.search(r'^  - id: '+re.escape(plan['id'])+r'\n',segment,re.M);assert m;next_m=re.search(r'^  - id: ',segment[m.end():],re.M);finish=m.end()+next_m.start() if next_m else len(segment);rendered=''.join(('  '+line).rstrip()+'\n' for line in dump([plan]).splitlines());return text[:body]+segment[:m.start()]+rendered+segment[finish:]+text[end:]
for path in [run/'config/visuals.yaml',root/'examples/libcamera/config/visuals.yaml']:
 text=path.read_text(encoding='utf-8');d=yaml.safe_load(text);plans=d['sections']['request-lifecycle'];ownership=next(v for v in plans if v['id']=='request-ownership');ownership['stage']='principle';failure=next(v for v in plans if v['id']=='failure-investigation-flow');failure['prompt']=failure['prompt'].split(' 영어에서도 -ENOENT는')[0].replace('제어 적용 뒤 QBUF 음수','제어 처리 뒤 QBUF 음수')+errno_prompt;failure['sources'].append('cache-get');failure['whole_sources'].append('cache-get');flow=next(v for v in plans if v['id']=='pre-qbuf-failure-flow');flow.update(prompt=flow_prompt,required_symbols=['queueBuffer','get','planes','isContiguous','put','VIDIOC_QBUF','queueRequestDevice','doQueueRequest','cancelRequest'],require_connected=True)
 updated=text
 for plan in [ownership,failure,flow]:updated=replace_visual(updated,plan)
 assert yaml.safe_load(updated)==d;path.write_text(updated,encoding='utf-8',newline='\n')
p=here/'visual-amendments.yaml';d=yaml.safe_load(p.read_bytes());d['replacements']['request-ownership']=ownership
for i,v in enumerate(d['additions']):
 if v['id']=='failure-investigation-flow':d['additions'][i]=deepcopy(failure)
 if v['id']=='pre-qbuf-failure-flow':d['additions'][i]=deepcopy(flow)
p.write_text(dump(d),encoding='utf-8',newline='\n')
for p in [run/'config/glossary.yaml',root/'examples/libcamera/config/glossary.yaml']:
 d=yaml.safe_load(p.read_bytes());aliases=next(t for t in d['terms'] if t['term']=='errno')['aliases'];assert 'EIO' not in aliases;aliases.append('EIO');p.write_text(dump(d),encoding='utf-8',newline='\n')
for name in ['publication.yaml','contract-review.yaml']:
 p=run/name;d=yaml.safe_load(p.read_bytes());d['publication']['allowed_contract_changes']['request-lifecycle/stopping/summary/summary']='Retain the documented immediate-error-completion and disconnect TODO contracts, explicitly qualify the first as a contract and connect the selected UVC STREAMOFF-failure limitation; do not claim unconditional failure-path fulfillment.';d['publication']['allowed_contract_changes']['request-lifecycle/stopping/summary/terms']='Retain all baseline terms and require an explicit contract qualifier to distinguish API obligations from UVC failure-path implementation.';p.write_text(dump(d),encoding='utf-8',newline='\n')
(run/'source-review-refinement-22-19.json').write_text(json.dumps(dict(basis=['accuracy-22','sufficiency-19'],source_windows_unchanged=26,changes=['Distinguish direct -ENOENT from propagated cache error without an exclusive only condition.','Supply actual bulk cancel and FrameBuffer cancel callees instead of unknown cancellation details.','Connect both pre-QBUF error branches to UVC ret propagation and common cancellation.','Qualify stop documentation contract versus UVC failed cleanup.','Place the native ownership figure in its own principle H3 using the generic validated stage option.'],human_review='pending'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Refined actual review22/19 findings and glossary alias; native regeneration required.')
