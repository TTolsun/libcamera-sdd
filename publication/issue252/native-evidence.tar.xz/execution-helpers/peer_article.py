"""Extract actual bilingual article text/diagrams; verify unchanged C++ excerpts."""
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import sys


class Article(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.inside = False
        self.skip = 0
        self.pre = None
        self.parts = []
        self.sources = []

    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes)
        if tag == 'article':
            self.inside = True
        if not self.inside:
            return
        if tag == 'details':
            if self.skip:
                self.skip += 1
            elif 'source-excerpts' in attrs.get('class', '').split():
                self.skip = 1
        if self.skip:
            if tag == 'pre':
                self.pre = []
            return
        if tag in ('h1', 'h2', 'h3', 'p', 'li', 'tr', 'summary', 'pre'):
            self.parts.append('\n\n[' + tag + '] ')
        if tag == 'a':
            self.parts.append('[link ' + attrs.get('href', '') + '] ')
        elif tag in ('td', 'th'):
            self.parts.append(' | ')

    def handle_endtag(self, tag):
        if self.skip:
            if tag == 'pre' and self.pre is not None:
                self.sources.append(''.join(self.pre))
                self.pre = None
            if tag == 'details':
                self.skip -= 1
            return
        if tag == 'article':
            self.inside = False

    def handle_data(self, data):
        if self.inside and not self.skip:
            self.parts.append(data)
        if self.pre is not None:
            self.pre.append(data)


def main():
    site = Path(sys.argv[1])
    out = Path(sys.argv[2])
    ko = site / 'request-lifecycle.html'
    en = site / 'en/request-lifecycle.html'
    parsed = []
    for path in (ko, en):
        article = Article()
        article.feed(path.read_text(encoding='utf-8'))
        parsed.append(article)
    assert parsed[0].sources and parsed[0].sources == parsed[1].sources
    text = ''.join(parsed[1].parts)
    assert 'flowchart' in text and 'SensorTimestamp' in text and 'dispatchMessages' in text
    out.write_text(text, encoding='utf-8', newline='\n')
    record = dict(
        scope='Actual exported English article, including every Mermaid source and link. C++ excerpt duplication omitted from peer text only after equality check; all complete frozen source windows are supplied separately to the native bilingual audit.',
        korean_html_sha256=hashlib.sha256(ko.read_bytes()).hexdigest(),
        english_html_sha256=hashlib.sha256(en.read_bytes()).hexdigest(),
        peer_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),
        source_code_blocks=len(parsed[0].sources),
        identical_cpp_excerpts=True,
        cpp_sha256=[hashlib.sha256(text.encode()).hexdigest() for text in parsed[0].sources])
    out.with_suffix('.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps(dict(characters=len(text), source_blocks=record['source_code_blocks'])))


if __name__ == '__main__':
    main()
