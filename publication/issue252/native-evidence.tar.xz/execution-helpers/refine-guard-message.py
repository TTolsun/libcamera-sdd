from pathlib import Path
import yaml,re,json
root=Path.cwd();run=root/'build/issue252/run';here=root/'examples/libcamera/validation/issue252'
fixes={'preparation-depth-flow':' 실제 queuedRequests_.size() == maxQueuedRequestsDevice_ 비교만 한도 분기로 표시합니다. true면 break이고 false면 그 동등 조건으로는 중단하지 않습니다. false를 size < max 또는 미만이라고 바꾸지 마세요. 크기가 한도를 넘는 상태를 이 비교가 막는다고 보장하지 말고 불변조건 별도 검증과 구분하세요.','callback-boundaries-flow':' Queued 메시지의 전달은 dispatch 시 메시지가 큐에 남아 있고 수신 Object가 유효하며 type·receiver 필터와 일치하는 경우로 한정합니다. Object 소멸자는 남은 메시지를 제거할 수 있으므로 게시만으로 미래 전달을 보장하지 않습니다. 이 조건을 한영 전달 화살표에 명시하세요.'}
for p in [run/'config/visuals.yaml',root/'examples/libcamera/config/visuals.yaml',here/'visual-amendments.yaml']:
 text=p.read_text(encoding='utf-8');d=yaml.safe_load(text);plans=d.get('additions') or d['sections']['request-lifecycle']
 for id,suffix in fixes.items():
  plan=next(v for v in plans if v['id']==id);plan['prompt']+=suffix
  if 'additions' not in d:
   start=text.index('  - id: '+id+'\n',text.index('  request-lifecycle:\n'));m=re.search(r'^  (?:- id: |[a-z][^\n]*:\n)',text[start+3:],re.M);end=start+3+m.start();block=yaml.safe_dump([plan],allow_unicode=True,sort_keys=False,width=105);text=text[:start]+''.join(('  '+line).rstrip()+'\n' for line in block.splitlines())+text[end:]
 if 'additions' in d:text=yaml.safe_dump(d,allow_unicode=True,sort_keys=False,width=105)
 assert yaml.safe_load(text)==d;p.write_text(text,encoding='utf-8',newline='\n')
(run/'source-review-refinement-25-22.json').write_text(json.dumps(dict(accuracy='Two native figure condition corrections; preserve prior failed review.',sufficiency='22 passed; next manuscript hash requires new review.',source_windows_unchanged=27),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
