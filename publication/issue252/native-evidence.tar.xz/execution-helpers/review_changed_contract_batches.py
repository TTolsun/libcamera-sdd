"""Generate native receipts for changed batch inputs using the normal audit engine."""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
import time

import yaml

from run_standard_contract_groups import ROOT, RUN, WORK, copy_verified, require_idle, transfer
from sdd.config import load
from sdd.consistency import _audit_prepared, batches, groups, request, review_store
from sdd.facts.model import KnowledgeModel
from sdd.generation_run import Execution
from sdd.llm import Agent
from sdd.validation_stage import stage


planes = sys.argv[1].endswith('-planes')
top = WORK / ('final-planes-batch-audit' if planes else 'scenario-translation-batch-audit')
base_profile = RUN / 'contract-review.yaml'
input_profile = RUN / 'final-planes-candidate/contract-review.yaml' if planes else base_profile
current_catalog = RUN / ('final-planes-candidate/english.json' if planes else
                         'bilingual-scenario-translation-repair/corrected-english.json')


def review(profile, wanted):
    cfg = load(profile)
    with stage() as inputs:
        inputs.pin(cfg)
        model = KnowledgeModel.load(cfg.facts_path)
        found, prepared = set(), []
        for group in groups(cfg):
            payload = request(cfg, model, group)
            selected = []
            for batch in batches(payload, max_input_chars=cfg.agent.max_input_chars):
                key = review_store(cfg, batch)[0].path.name
                if key in wanted:
                    found.add(key)
                    selected.append(batch)
            if selected:
                prepared.append((group, payload, selected))
        assert found == wanted, 'The worker batch inputs differ from the frozen normal request keys'
        keys = [f"consistency_{group['id']}_{index}" for group, _, units in prepared for index in range(len(units))]
        execution = Execution(cfg, Agent(cfg.agent, cfg.build_dir / 'prompts'), model=model)
        with execution.track('contract-batch-prewarm'), execution.document('consistency', keys):
            report = _audit_prepared(cfg, model, execution, prepared)
        print(json.dumps(dict(status=report['status'], verified_exact_batches=len(found),
                              fresh=report['fresh_batches'], reused=report['reused_batches'])))


def run_worker(folder):
    profile = folder / 'audit.yaml'
    cfg = load(profile)
    logs = cfg.build_dir / 'prompts/cli'
    print('Started corrected batch shard', folder.name, flush=True)
    for attempt in range(1, 4):
        earlier = set(logs.glob('*.stdout.txt'))
        with (folder / f'attempt-{attempt}.log').open('xb') as out:
            result = subprocess.run([sys.executable, '-X', 'utf8', str(Path(__file__).resolve()),
                                     'worker', str(profile), str(folder / 'keys.json')],
                                    cwd=ROOT, stdout=out, stderr=subprocess.STDOUT)
        if result.returncode == 0:
            break
        recent = set(logs.glob('*.stdout.txt')) - earlier
        latest = max(recent, key=lambda path: path.stat().st_mtime) if recent else None
        if not latest or '403 Forbidden' not in latest.read_text(encoding='utf-8', errors='replace') or attempt == 3:
            break
        copy_verified(cfg.build_dir / 'consistency-review.json', folder / f'interrupted-report-{attempt}.json')
        print('Retrying corrected batch shard', folder.name, flush=True)
        time.sleep(25 * attempt)
    print('Ended corrected batch shard', folder.name, 'exit', result.returncode, flush=True)
    return result.returncode


def start():
    top.mkdir()
    impact_name = 'final-planes-exact-batch-impact.json' if planes else 'scenario-translation-exact-batch-impact.json'
    impact = json.loads((RUN / impact_name).read_bytes())
    keys = [key for group in impact for key in group['new_keys']]
    assert keys and len(set(keys)) == len(keys)
    base = load(input_profile)
    raw = yaml.safe_load(input_profile.read_bytes())
    folders = []
    for index in range(3):
        folder = top / f'shard-{index+1}'
        folder.mkdir()
        data = deepcopy(raw)
        data['site']['english_catalog'] = str(current_catalog)
        data['output'].update(facts_dir=str(base.facts_dir), sdd_dir=str(base.sdd_dir), diagrams_dir=str(base.diagrams_dir))
        data['publication']['operation_id'] = 'issue252-' + top.name + '-' + folder.name
        (folder / 'audit.yaml').write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding='utf-8')
        (folder / 'keys.json').write_text(json.dumps(keys[index::3]), encoding='utf-8')
        folders.append(folder)
    print('Prepared', len(keys), 'exact changed batches across three independent receipt folders.', flush=True)
    with ThreadPoolExecutor(max_workers=3) as pool:
        outcomes = list(pool.map(run_worker, folders))
    (top / 'outcomes.json').write_text(json.dumps(outcomes), encoding='utf-8')
    raise SystemExit(int(any(outcomes)))


def collect():
    base = load(base_profile)
    require_idle(base)
    results = []
    retained = []
    for folder in sorted(top.glob('shard-*')):
        cfg = load(folder / 'audit.yaml')
        expected = set(json.loads((folder / 'keys.json').read_bytes()))
        count = transfer(cfg, base, expected, retained=retained if planes else None)
        report = json.loads((cfg.build_dir / 'consistency-review.json').read_bytes())
        last_log = sorted(folder.glob('attempt-*.log'))[-1]
        outcome = json.loads(last_log.read_text(encoding='utf-8').splitlines()[-1])
        expected_status = ('failed' if any(item['status'] == 'contradiction' for contract in report['contracts']
                                           for item in contract['findings']) else 'passed')
        assert outcome['verified_exact_batches'] == len(expected) and outcome['status'] == expected_status
        results.append(dict(shard=folder.name, expected=len(expected), verified=count,
                            status=outcome['status'], fresh=report.get('fresh_batches'), reused=report.get('reused_batches')))
    transfer_name = 'final-planes-batch-transfer.json' if planes else 'corrected-scenario-batch-transfer.json'
    (RUN / transfer_name).write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
    if planes:
        (RUN / 'final-planes-equivalent-checkpoints.json').write_text(json.dumps(retained, indent=2) + '\n', encoding='utf-8')
    assert all(row['verified'] == row['expected'] and row['status'] == 'passed' for row in results), results
    print('Copied authenticated receipts for all', sum(row['verified'] for row in results), 'changed batches.')


if __name__ == '__main__':
    if sys.argv[1] == 'worker':
        review(Path(sys.argv[2]), set(json.loads(Path(sys.argv[3]).read_bytes())))
    elif sys.argv[1] in ('collect', 'collect-planes'):
        collect()
    else:
        start()
