from pathlib import Path
import hashlib
import json

from sdd.config import load
from sdd.generation_run import Execution
from sdd.llm import Agent
from sdd.state_io import save
from sdd.translation import _payload, _batch_schema, _batch_system, _batch_values, _validate_text
from sdd.translation_checkpoint import TranslationCall

r = Path(__file__).resolve().parent / 'run'
out = r / 'bilingual-scenario-translation-repair'
out.mkdir()
path = r / 'english.json'
original = path.read_bytes()
catalog = json.loads(original)
prefixes = {'plan': 'The investigation records entry', 'connections': 'Member functions of receivers other than'}
sources = {}
for ident, prefix in prefixes.items():
    keys = [key for key, value in catalog['strings'].items() if value.startswith(prefix)]
    assert len(keys) == 1
    sources[ident] = keys[0]
(out / 'original-english.json').write_bytes(original)
cfg = load(r / 'publication.yaml')
cfg.agent = load(cfg.paths['translation_profile']).agent
assert (cfg.agent.kind, cfg.agent.runner, cfg.agent.model, cfg.agent.args) == (
    'cli', 'codex', 'gpt-6.1-terra', ['-c', 'model_reasoning_effort="high"'])
system = _batch_system(catalog['strings']) + (
    ' For plan, explicitly state that this is the proposed investigation plan and that it calls for recording the stated values. '
    'Do not claim that any event was observed or recorded. For connections, scope the non-Object receiver qualifier {{2}} to '
    'both member functions and functors. Static function connections are a separate category. The source does not say '
    'Object-bound functors always execute immediately. Preserve all later lifetime, dispatch, and synchronization conditions, '
    'and preserve each original placeholder count. Do not add new claims.')
schema = _batch_schema(sources)
execution = Execution(cfg, Agent(cfg.agent, out / 'prompts'))
execution.path = out / 'execution.json'
with execution.track('native-bilingual-scenario-translation-repair'), execution.document('scenario-scope-translation', list(sources.values())):
    call = TranslationCall(cfg, execution, system, _payload(catalog, sources), schema, fresh=True, units=list(sources.values()))
    assert call.saved is None
    values = {key: _validate_text(sources[key], value) for key, value in
              _batch_values(call.chat('translation_scenario_plan_and_connection_scope'), sources).items()}
    assert 'investigation plan' in values['plan'].lower()
    assert all(term in values['connections'].split('.', 1)[0] for term in ('functors', '{{2}}'))
    call.validated(dict(translations=values))
    receipt = call.capture.receipts[-1]
assert path.read_bytes() == original
for ident, key in sources.items():
    catalog['strings'][key] = values[ident]
pending = out / 'corrected-english.json'
save(pending, catalog)
proof = dict(old_catalog_sha256=hashlib.sha256(original).hexdigest(),
             corrected_catalog_sha256=hashlib.sha256(pending.read_bytes()).hexdigest(),
             target_units=sources, validated_native_translations=values,
             receipt=receipt.resolve().relative_to(r).as_posix())
(r / 'bilingual-scenario-translation-repair.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(values, ensure_ascii=False))
