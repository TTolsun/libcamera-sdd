from pathlib import Path
import yaml,runpy,json
root=Path.cwd();run=root/'build/issue252/run';here=root/'examples/libcamera/validation/issue252';replace=runpy.run_path(str(here/'refine.py'))['replace_topic']
prompt='검증 계획을 직접 수행 동사로 쓰세요. 첫 문장은 호출자의 stop 동기화 의무를 유지합니다. 다음 문장은 각 경계의 상대 순서를 기록합니다. 마지막 문장은 요청·버퍼의 유지 기한, 중복 완료·재투입 횟수와 ASSERT 전제의 대조 동작을 설명합니다. ~인지·~있는지·~되는지·~유효한지 같은 명사절을 나열하거나 무엇을 확인할지 제안한다는 문장으로 우회하지 마세요. 기록합니다·대조합니다·분류합니다로 평서문을 완성하세요. 정지 뒤 실제 메서드가 실행된다는 실험 결과나 복구 보장을 만들지 말고, 그 조건을 별도 시험 경우로 분류하세요. 두 짧은 문단까지 허용하되 공통 계약을 다시 길게 나열하지 마세요.'
for path in [here/'verification-parts.yaml',run/'config/sections.yaml',root/'examples/libcamera/config/sections.yaml']:
 text=path.read_text(encoding='utf-8');d=yaml.safe_load(text)
 if 'sections' in d:
  topic=next(t for s in d['sections'] if s['id']=='request-lifecycle' for t in s['design_topics'] if t['id']=='review');part=next(p for p in topic['parts'] if p['id']=='stop-crossing-case')
 else:part=next(p for p in d['parts'] if p['id']=='stop-crossing-case')
 part['prompt']=prompt;part['answer_contract']=dict(basis='investigation')
 updated=replace(text,topic) if 'sections' in d else yaml.safe_dump(d,allow_unicode=True,sort_keys=False,width=105);assert yaml.safe_load(updated)==d;path.write_text(updated,encoding='utf-8',newline='\n')
(run/'stop-style-refinement.json').write_text(json.dumps(dict(basis='Generation22 style-question-form rejection; original response retained.',changes='Only declarative investigation wording and classification, not source, fixed reader question or validation-rule relaxation.',human_review='pending'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Refined declarative wording for the stop/submission investigation plan.')
