from copy import deepcopy
import json
from pathlib import Path

from sdd.config import load
from sdd.consistency import batches, groups, request, review_store
from sdd.facts.model import KnowledgeModel
from sdd.validation_stage import stage

r = Path(__file__).resolve().parent / 'run'
before = load(r / 'contract-review.yaml')
before.raw['site']['english_catalog'] = str(r / 'bilingual-scenario-translation-repair/corrected-english.json')
after = load(r / 'final-planes-candidate/contract-review.yaml')
model = KnowledgeModel.load(before.facts_path)
assert before.facts_path.read_bytes() == after.facts_path.read_bytes()
assert groups(before) == groups(after)


def keys(cfg, group):
    payload = request(cfg, model, group)
    return {review_store(cfg, batch)[0].path.name
            for batch in batches(payload, max_input_chars=cfg.agent.max_input_chars)}


rows = []
with stage():
    for group in groups(before):
        old, new = keys(before, group), keys(after, group)
        row = dict(group=group['id'], total=len(new), identical=len(new & old), new_keys=sorted(new - old))
        rows.append(row)
        print(row['group'], row['identical'], 'unchanged;', len(row['new_keys']), 'changed', flush=True)
(r / 'final-planes-exact-batch-impact.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8')
