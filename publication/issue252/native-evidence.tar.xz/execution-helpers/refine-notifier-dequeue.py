from pathlib import Path
import yaml,runpy,re,json
root=Path.cwd();run=root/'build/issue252/run';here=root/'examples/libcamera/validation/issue252';replace=runpy.run_path(str(here/'refine.py'))['replace_topic']
suffix=' 성공 대조군의 다음 DQBUF는 정적 예상 분기로 분리합니다. DQBUF 성공과 queuedBuffers_에 존재하는 index일 때만 cache_->put 뒤 항목 erase가 실행되므로 put 횟수와 큐 상태를 대조합니다. DQBUF 오류와 예상 밖 index는 그 전에 nullptr로 반환하므로 이번 dequeue의 put·erase가 없다는 분기를 대조합니다. 이 소스 분기를 미확인이라고 쓰지 말고 실행 결과나 실제 put 관측값을 만들지도 마세요.'
for p in [run/'config/sections.yaml',root/'examples/libcamera/config/sections.yaml',here/'topics.yaml',here/'verification-parts.yaml']:
 text=p.read_text(encoding='utf-8');d=yaml.safe_load(text)
 if 'sections' in d:
  topics={t['id']:t for s in d['sections'] if s['id']=='request-lifecycle' for t in s['design_topics']};part=next(p for p in topics['review']['parts'] if p['id']=='control-qbuf-case');part['question']+=suffix;part['sources'].append('dequeue-flow');expiry=next(x for x in topics['resources']['sources'] if x['id']=='fence-expiry').copy();topics['preparation-depth']['sources'].append(expiry);updated=replace(replace(text,topics['review']),topics['preparation-depth'])
 elif 'topics' in d:
  topics={t['id']:t for t in d['topics']};expiry=dict(id='fence-expiry',file='src/libcamera/request.cpp',start="If the \\a fence associated with \\a buffer isn't signalled, the request will",end='be reused in another request.',scope=dict(start='\\brief Add a FrameBuffer with its associated Stream to the Request',end='int Request::addBuffer(const Stream *stream, FrameBuffer *buffer,'));topics['preparation-depth']['sources'].append(expiry);updated=yaml.safe_dump(d,allow_unicode=True,sort_keys=False,width=105)
 else:
  part=next(p for p in d['parts'] if p['id']=='control-qbuf-case');part['question']+=suffix;part['sources'].append('dequeue-flow');updated=yaml.safe_dump(d,allow_unicode=True,sort_keys=False,width=105)
 assert yaml.safe_load(updated)==d;p.write_text(updated,encoding='utf-8',newline='\n')
suffix=' timeout()이 지우는 것은 notifiers_이며 버퍼에 남은 미신호 Fence를 지우지 않습니다. timeout 전이는 남은 notifier 제거·요청 취소로 표시하고 미신호 fence는 버퍼에 남아 재사용 전 releaseFence가 필요하다는 조건을 유지하세요. notifier와 fence를 같은 소유 자원으로 쓰지 마세요.'
for p in [run/'config/visuals.yaml',root/'examples/libcamera/config/visuals.yaml',here/'visual-amendments.yaml']:
 text=p.read_text(encoding='utf-8');d=yaml.safe_load(text);plans=d.get('additions') or d['sections']['request-lifecycle'];plan=next(v for v in plans if v['id']=='fence-timer-order-flow');plan['prompt']+=suffix;plan['sources'].append('fence-expiry');plan['whole_sources'].append('fence-expiry')
 if 'additions' in d:updated=yaml.safe_dump(d,allow_unicode=True,sort_keys=False,width=105)
 else:
  start=text.index('  - id: fence-timer-order-flow\n',text.index('  request-lifecycle:\n'));m=re.search(r'^  (?:- id: |[a-z][^\n]*:\n)',text[start+3:],re.M);end=start+3+m.start();block=yaml.safe_dump([plan],allow_unicode=True,sort_keys=False,width=105);updated=text[:start]+''.join(('  '+line).rstrip()+'\n' for line in block.splitlines())+text[end:]
 assert yaml.safe_load(updated)==d;p.write_text(updated,encoding='utf-8',newline='\n')
(run/'source-review-refinement-24-21.json').write_text(json.dumps(dict(source_windows_unchanged=27,findings=['Correct timeout notifier removal vs retained buffer fence in native diagram.','Bind success-control DQBUF get/put/erase static branches to actual dequeue evidence, not unconfirmed.'],human_review='pending'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Source review24/21 corrections bound to existing full windows')
