import sys
from pathlib import Path
root=Path('/mnt/c/Users/baboe/.codex/worktrees/d2e8/camera-hal-sdd-generator');here=root/'examples/libcamera/validation/issue252';sys.path.insert(0,str(here))
import capture_build
capture_build.COMMIT='be7e83e91348250c015aad6d6f59f1468555bae8'
p=here/'extract_uvc.py';text=p.read_text()
text=text.replace("Path.home()/'work/issue252-libcamera'","Path.home()/'work/issue252-libcamera-current'").replace('293d751a814e0d4c34e85ad457ccd9d5eefd1a61','be7e83e91348250c015aad6d6f59f1468555bae8').replace('build-provenance-fresh.json','build-provenance-current.json').replace("'uvc-extraction-'+args.attempt","'uvc-extraction-current'")
sys.argv=[str(p),'--attempt','final'];exec(compile(text,str(p),'exec'),{'__name__':'__main__','__file__':str(p)})
