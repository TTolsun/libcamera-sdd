"""Run normal export, compare the reviewed article, and verify repeatable bytes."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys


work = Path(__file__).resolve().parent
root = work.parents[1]
run = work / 'run'
profile = run / 'publication.yaml'
site = work / 'site'
repeat = work / 'site-repeat'
accuracy, sufficiency, bilingual, reviewed = sys.argv[1:]
if (run / 'bilingual-scenario-translation-repair.json').is_file() and bilingual == 'bilingual-07':
    raise SystemExit('This English preview has a later, native-corrected translation candidate.')
python = [sys.executable, '-X', 'utf8']
cli = [*python, str(root / 'tools/run_sdd.py'), '--config', str(profile)]


def checked(label, command):
    path = work / (label + '.log')
    with path.open('xb') as output:
        result = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT)
    if result.returncode:
        print(path.read_text(encoding='utf-8', errors='replace')[-1800:])
        raise SystemExit(result.returncode)
    print(label, 'passed', flush=True)


checked('native-call-verification-final', [*python, 'examples/libcamera/validation/issue252/verify_native_calls.py'])
checked('bind-current-publication-reports', [*python, str(work / 'bind_publication_reviews.py'),
        '--accuracy', accuracy, '--sufficiency', sufficiency, '--bilingual', bilingual])
checked('normal-export-final', [*cli, 'export-site', '--out', str(site)])
checked('normal-verify-final', [*cli, 'verify-site', '--out', str(site)])
peer = run / 'bilingual-final-rendered-peer.txt'
checked('final-rendered-peer', [*python, str(work / 'peer_article.py'), str(site), str(peer)])
original = run / reviewed
assert peer.read_bytes() == original.read_bytes(), 'Actual final English article differs from reviewed input'
final = json.loads(peer.with_suffix('.json').read_bytes())
final['reviewed_peer_sha256'] = hashlib.sha256(original.read_bytes()).hexdigest()
final['reviewed_preview'] = json.loads(original.with_suffix('.json').read_bytes())
final['identical_reviewed_english_article'] = True
(run / 'bilingual-peer.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
checked('normal-export-repeat', [*cli, 'export-site', '--out', str(repeat)])
checked('normal-verify-repeat', [*cli, 'verify-site', '--out', str(repeat)])
manifest = (site / 'site-manifest.json').read_bytes()
assert manifest == (repeat / 'site-manifest.json').read_bytes(), 'Repeat build manifest differs'
data = json.loads(manifest)
print(json.dumps(dict(build_id=data['build_id'], outputs=len(data['outputs']),
                      manifest_sha256=hashlib.sha256(manifest).hexdigest(), repeat_identical=True)))
