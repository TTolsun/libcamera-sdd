from pathlib import Path
import json,hashlib,subprocess
run=Path('build/issue252/run');public=Path('build/issue252/public');lookup=json.loads((run/'public-receipt-digest-lookup.json').read_bytes());p=public/'publication/issue248/fresh-automatic/public96-merge/native-verification.json'
for row in json.loads(p.read_bytes())['calls']:
 key='/'.join(row['path'].split('/')[-2:]);lookup.setdefault(key,{}).setdefault(row['receipt_sha256'],[]).append(p.as_posix())
latest_path=run/'historical-native-restoration-latest.json';latest_raw=latest_path.read_bytes();latest=json.loads(latest_raw);old_bound={r['receipt']:r['sha256'] for r in latest['receipts']};planned=[]
for name in ['latest','newest','current','navigation','clarity']:
 p=run/f'historical-native-restoration-{name}.json';raw=p.read_bytes();data=json.loads(raw);assert data.get('schema')!=2,'Do not silently replace an existing bound map';old_rows={r['receipt'].replace(chr(92),'/'):r for r in data.get('receipts',[])};paths=set(x.replace(chr(92),'/') for x in data.get('receipt_paths',[])) | set(old_rows);rows=[]
 for rel in sorted(paths):
  actual=hashlib.sha256((run/rel).read_bytes()).hexdigest();proofs=lookup.get('/'.join(rel.split('/')[-2:]),{}).get(actual,[])
  if proofs:
   proof=Path(sorted(proofs)[0]);binding=dict(kind='published-public-receipt-digest',path=proof.relative_to(public).as_posix(),sha256=hashlib.sha256(proof.read_bytes()).hexdigest())
  else:
   assert old_bound.get(rel)==actual,'No immutable published/prior digest for '+rel;binding=dict(kind='prior-digest-bound-import-map',path='historical-native-restoration-latest.json',sha256=hashlib.sha256(latest_raw).hexdigest())
  row=dict(old_rows.get(rel,{}));row.update(receipt=rel,sha256=actual,digest_source=binding);rows.append(row)
 data.update(schema=2,receipts=rows);planned.append((p,raw,data))
changes=[]
for p,raw,data in planned:
 digest=hashlib.sha256(raw).hexdigest();original=run/'historical-import-map-originals'/digest/p.name;original.parent.mkdir(parents=True,exist_ok=True);original.write_bytes(raw);p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');changes.append(dict(map=p.name,original_file=original.relative_to(run).as_posix(),original_sha256=digest,bound_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),receipts=len(data['receipts'])))
(run/'historical-import-digest-migration.json').write_text(json.dumps(dict(source_public_commit=subprocess.check_output(['git','-C',str(public),'rev-parse','HEAD'],text=True).strip(),source_scope='Existing published receipt indexes/native verification and the original digest-bound latest import map; never trust an unbound current receipt to establish its own expected hash.',changes=changes,new_inference=False),indent=2)+'\n',encoding='utf-8');print('Historical import maps bound:',len(changes),'entries:',sum(x['receipts'] for x in changes))
