"""Wait for in-flight current reviews, assemble their verified checkpoints, and build."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

from sdd.config import load
from run_standard_contract_groups import require_idle, transfer


work = Path(__file__).resolve().parent
root = work.parents[1]
run = work / 'run'
profile = run / 'contract-review.yaml'
stopping_profile = work / 'parallel-standard-audit-stop-final/audit.yaml'
groups_file = run / 'parallel-standard-audit-08.json'
bilingual_file = run / 'audits/bilingual-06/review.json'
stopping_file = stopping_profile.parent / 'build/consistency-review.json'


def completed(path):
    try:
        return json.loads(path.read_bytes())
    except (FileNotFoundError, PermissionError, json.JSONDecodeError):
        return None


def command(label, argv):
    output = work / (label + '.log')
    with output.open('xb') as stream:
        result = subprocess.run(argv, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
    if result.returncode:
        print(output.read_text(encoding='utf-8', errors='replace')[-1800:], flush=True)
        raise SystemExit(result.returncode)
    print(label, 'passed', flush=True)


while True:
    grouped, bilingual, stopping = (completed(path) for path in (groups_file, bilingual_file, stopping_file))
    if bilingual and bilingual['status'] != 'passed':
        raise SystemExit('The latest independent bilingual review has findings to assess.')
    if stopping and stopping.get('status') in ('failed', 'incomplete'):
        raise SystemExit('The corrected stopping audit needs recovery; the original checkpoints remain.')
    if grouped and bilingual and stopping and stopping.get('audit_run') and stopping.get('status') == 'passed':
        break
    time.sleep(5)

remaining = [row for row in grouped if row['group'] != 'stopping-cancellation']
assert len(remaining) == 5 and all(row['status'] == 'passed' for row in remaining), remaining
base = load(profile)
stop = load(stopping_profile)
require_idle(base)
require_idle(stop)
number = transfer(stop, base)
assert number == len(stopping['contracts'][0]['batches'])
receipt = dict(copied_current_checkpoints=number, report_sha256=hashlib.sha256(stopping_file.read_bytes()).hexdigest(),
               isolated_run=stopping['audit_run'], source_commit=stopping['source_commit'])
(run / 'corrected-stopping-audit-transfer.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
catalog = run / 'english.json'
repair = completed(run / 'bilingual-timer-translation-repair.json')
new_catalog = run / 'bilingual-timer-translation-repair/corrected-english.json'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(catalog) == repair['old_catalog_sha256']
assert digest(new_catalog) == repair['corrected_catalog_sha256']
assert digest(run / 'manuscripts/request-lifecycle.md') == bilingual['document_sha256']
shutil.copyfile(new_catalog, catalog)
previous = base.build_dir / 'consistency-review.json'
if previous.is_file():
    snapshot = run / 'consistency-review-before-current-policy.json'
    with snapshot.open('xb') as output:
        output.write(previous.read_bytes())
python = [sys.executable, '-X', 'utf8']
command('final-consistency-09', [*python, 'tools/run_sdd.py', '--config', str(profile), 'audit-consistency'])
result = completed(previous)
print('Current standard contract audit:', result['status'], 'fresh batches:', result['fresh_batches'],
      'reused batches:', result['reused_batches'], 'unresolved:', len(result['unresolved']), flush=True)
command('finish-local-site', [*python, str(work / 'finish_local_site.py'), 'accuracy-34', 'sufficiency-30',
        'bilingual-06', 'bilingual-reviewed-peer-v8.txt'])
command('browser-final-check', ['node', 'examples/libcamera/validation/issue252/browser_test.cjs',
        'http://127.0.0.1:8252/site/', str(run / 'browser-final')])
