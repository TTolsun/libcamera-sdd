"""Validate contract configuration without reading evidence or rendering pages."""
from .reader_profiles import profile_errors
from .answer_contracts import configuration_errors as answer_contract_errors

def configuration_errors(section: dict) -> list[str]:
    errors = []
    if 'reader_family' in section and (not isinstance(section['reader_family'], str)
                                       or not section['reader_family'].strip()
                                       or not section.get('reader_profile')):
        errors.append('reader_family에는 명시적인 reader_profile과 비어 있지 않은 문서 묶음 id가 필요합니다.')
    if 'design_grounding' in section and type(section['design_grounding']) is not bool:
        errors.append('design_grounding은 boolean이어야 합니다.')
    for field in ('design_requirements', 'design_topics'):
        values = section.get(field, [])
        if not isinstance(values, list) or any(not isinstance(v, dict) for v in values):
            return [f'{field}는 객체 목록이어야 합니다.']
        if any(not isinstance(v.get('id'), str) or not v['id'].strip() for v in values):
            return [f'{field}의 id는 비어 있지 않은 문자열이어야 합니다.']
    for topic in section.get('design_topics', []):
        from .explanation import configuration_errors as explanation_errors
        errors.extend(explanation_errors(topic))
        if 'prompt' in topic and (not isinstance(topic['prompt'], str) or not topic['prompt'].strip()):
            errors.append(f"{topic['id']}: prompt는 비어 있지 않은 문자열이어야 합니다.")
        if topic.get('narration') == 'facts' and (section.get('design_requirements') or section.get('reader_profile')):
            errors.append('Source-question views cannot replace required design answers or reader profiles.')
        errors.extend(answer_contract_errors(topic))
        for field in ('sources', 'statements'):
            values = topic.get(field, [])
            if not isinstance(values, list) or any(not isinstance(v, dict) for v in values):
                return [f"{topic['id']}/{field}는 객체 목록이어야 합니다."]
        if any(not isinstance(s.get('id'), str) or not s['id'].strip() for s in topic.get('sources', [])):
            return [f"{topic['id']}: 소스 id가 비었거나 문자열이 아닙니다."]
        for source in topic.get('sources', []):
            for field in ('file', 'start', 'end'):
                if not isinstance(source.get(field), str) or not source[field].strip():
                    errors.append(f"{topic['id']}/{source['id']}: {field}는 비어 있지 않은 문자열이어야 합니다.")
            if 'scope' in source:
                scope = source['scope']
                if (not isinstance(scope, dict) or set(scope) != {'start', 'end'}
                        or any(not isinstance(v, str) or not v.strip() for v in scope.values())):
                    errors.append(f"{topic['id']}/{source['id']}: scope에는 비어 있지 않은 start와 end 문자열이 필요합니다.")
        for st in topic.get('statements', []):
            for field in ('covers', 'evidence'):
                values = st.get(field, [])
                if not isinstance(values, list) or any(not isinstance(v, str) for v in values):
                    errors.append(f"{topic['id']}/{field}는 문자열 목록이어야 합니다.")
    from .reader_scope import configuration_errors as scope_errors
    return errors + profile_errors(section) + generated_errors(section) + scope_errors(section)


def generated_errors(section):
    if section.get('design_generation') not in (None, 'llm'):
        return ['design_generation은 llm이어야 합니다.']
    if section.get('design_generation') != 'llm':
        return []
    errors = []
    requirements = section.get('design_requirements', [])
    topics = section.get('design_topics', [])
    if section.get('kind', 'prose') != 'prose' or not requirements or not topics:
        errors.append('LLM 설계 생성에는 prose, design_requirements와 design_topics가 필요합니다.')
    ids = [r['id'] for r in requirements]
    covered = []
    for topic in topics:
        covers = topic.get('covers')
        if not isinstance(covers, list) or not covers or any(not isinstance(c, str) for c in covers):
            errors.append(f"{topic['id']}: covers는 비어 있지 않은 문자열 목록이어야 합니다.")
        else:
            covered.extend(covers)
        if 'statements' in topic:
            errors.append(f"{topic['id']}: LLM 모드에서는 statements를 미리 작성할 수 없습니다.")
        if any('sha256' in source for source in topic.get('sources', [])):
            errors.append(f"{topic['id']}: LLM 모드의 근거 해시는 현재 커밋에서 수집합니다.")
        if 'parts' in topic:
            parts = topic['parts']
            if not isinstance(parts, list) or not parts or any(not isinstance(p, dict) for p in parts):
                errors.append(f"{topic['id']}: parts는 비어 있지 않은 객체 목록이어야 합니다.")
                continue
            seen, used = set(), set()
            source_ids = {s['id'] for s in topic.get('sources', [])}
            for part in parts:
                if 'prompt' in part and (not isinstance(part['prompt'], str) or not part['prompt'].strip()):
                    errors.append(f"{topic['id']}: parts prompt는 비어 있지 않은 문자열이어야 합니다.")
                errors.extend(answer_contract_errors(part))
                pid = part.get('id')
                if not isinstance(pid, str) or not pid or pid in seen:
                    errors.append(f"{topic['id']}: parts id는 비어 있지 않고 고유해야 합니다.")
                else:
                    seen.add(pid)
                if not isinstance(part.get('question'), str) or not part['question'].strip():
                    errors.append(f"{topic['id']}: parts question이 필요합니다.")
                refs = part.get('sources')
                if not isinstance(refs, list) or not refs or any(not isinstance(r, str) or r not in source_ids for r in refs):
                    errors.append(f"{topic['id']}: parts sources는 현재 주제의 근거 id 목록이어야 합니다.")
                else:
                    used.update(refs)
                maximum = part.get('max_statements', 1 if part.get('answer_contract') else 2)
                if isinstance(maximum, bool) or not isinstance(maximum, int) or not 1 <= maximum <= 8:
                    errors.append(f"{topic['id']}: max_statements는 1부터 8까지의 정수여야 합니다.")
                subquestions = part.get('subquestions', [])
                if (not isinstance(subquestions, list) or (subquestions and not 2 <= len(subquestions) <= 4)
                        or any(not isinstance(q, str) or not q.strip() or len(q) > 800 for q in subquestions)
                        or (isinstance(subquestions, list) and all(isinstance(q, str) for q in subquestions)
                            and len(set(subquestions)) != len(subquestions))):
                    errors.append(f"{topic['id']}: subquestions에는 중복 없는 짧은 질문 2~4개가 필요합니다.")
                if 'statement_kind' in part and (part['statement_kind'] != 'limitation' or 'answer_contract' in part):
                    errors.append(f"{topic['id']}: statement_kind는 limitation만 쓸 수 있고 answer_contract와 함께 쓸 수 없습니다.")
                if 'role' in part:
                    # 요약은 주제의 첫 문단이다. 상세 답변보다 앞에 하나만 두고, 실행 확인 항목이나 세부 질문으로 나누지 않는다.
                    if (part['role'] != 'summary' or part is not parts[0]
                            or part.get('subquestions') or 'statement_kind' in part
                            or part.get('max_statements', 1) not in (1, 2) or len(parts) < 2):
                        errors.append(f"{topic['id']}: role: summary는 상세 part가 뒤에 있는 첫 part에만 쓰며 "
                                      "max_statements는 1 또는 2, subquestions·statement_kind는 쓸 수 없습니다.")
                if set(part) - {'id', 'question', 'sources', 'answer_contract', 'subquestions', 'max_statements',
                                'statement_kind', 'role', 'prompt'}:
                    errors.append(f"{topic['id']}: 지원하지 않는 parts 필드입니다.")
            if all(part.get('statement_kind') == 'limitation' for part in parts if isinstance(part, dict)):
                # 실행 확인 항목만으로는 필수 질문에 답한 것이 아니다. 모델을 부르기 전에 설정 오류로 막는다.
                errors.append(f"{topic['id']}: 모든 parts가 statement_kind: limitation이면 필수 질문의 사실 답변이 없습니다.")
            if used != source_ids:
                errors.append(f"{topic['id']}: parts가 모든 소스 근거를 다뤄야 합니다.")
    if sorted(covered) != sorted(ids) or len(ids) != len(set(ids)):
        errors.append('각 필수 질문은 정확히 한 주제의 covers에 연결해야 합니다.')
    return errors


