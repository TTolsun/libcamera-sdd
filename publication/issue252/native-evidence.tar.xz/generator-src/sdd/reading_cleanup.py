"""Compact generated reading aids while preserving their unique information."""
from __future__ import annotations

import html
import hashlib
import posixpath
import re
from html.parser import HTMLParser
from urllib.parse import quote


def fold_scope_notices(document: str) -> str:
    """Retain generated virtual-test scope once, with links to every scoped H2.

    Manuscripts and their verification stay intact. Code examples, custom
    warnings and notices without an identifiable section keep their placement.
    """
    from .product_context import SIMULATION_NOTICE
    if '<details class="note scope-notices">' in document:
        return document
    notice = '<p><strong>' + html.escape(SIMULATION_NOTICE.strip('*')) + '</strong></p>'
    current = None
    sections = {}

    def move(match):
        nonlocal current
        if match[1] is not None:
            current = (match[1], match[2])
        elif match[0] == notice and current is not None:
            sections[current[0]] = current[1]
            return ''
        return match[0]

    pattern = (r'<pre\b[^>]*>.*?</pre>|<code\b[^>]*>.*?</code>|'
               r'<h2 id="([^"]+)">(.*?)</h2>|' + re.escape(notice))
    result = re.sub(pattern, move, document, flags=re.S)
    if not sections:
        return document
    links = ''.join('<li><a href="#' + html.escape(anchor, quote=True) + '">'
                    + html.escape(html.unescape(re.sub(r'<[^>]+>', '', title))) + '</a></li>'
                    for anchor, title in sections.items())
    details = ('<details class="note scope-notices"><summary>가상 시험의 검증 범위</summary>'
               + notice + '<ul>' + links + '</ul></details>\n')
    # Keep the generated next step last and place scope beside source evidence.
    target = re.search(r'<h2 id="소스-근거(?:-\d+)?">|<p>다음 단계:', result)
    position = target.start() if target else len(result)
    return result[:position] + details + result[position:]


def cells(row: str, tag: str = 'td') -> tuple[str, ...]:
    return tuple(cell.strip() for cell in re.findall(rf'<{tag}\b[^>]*>(.*?)</{tag}>', row, re.S))


def reference_cells(row: str) -> tuple[str, ...]:
    return tuple(re.findall(r'<td\b[^>]*>.*?</td>', row, re.S))


def simple_table(table: str, *, labeled: bool = False) -> bool:
    """Reject captions, extra text/sections and custom structural attributes."""
    parts = re.fullmatch(r'<table>\s*<thead>\s*<tr>(.*?)</tr>\s*</thead>\s*<tbody>(.*?)</tbody>\s*</table>', table, re.S)
    if not parts or table.count('<table>') != 1:
        return False
    head, body = parts.groups()
    if not re.findall(r'<th>.*?</th>', head, re.S) or re.sub(r'<th>.*?</th>', '', head, flags=re.S).strip():
        return False
    rows = re.findall(r'<tr>(.*?)</tr>', body, re.S)
    if not rows or re.sub(r'<tr>.*?</tr>', '', body, flags=re.S).strip():
        return False
    cell = r'<td(?: data-label="[^"]*")?>.*?</td>' if labeled else r'<td>.*?</td>'
    return all(re.findall(cell, row, re.S) and not re.sub(cell, '', row, flags=re.S).strip() for row in rows)


def compact_tables(document: str, *, question_edits=None) -> str:
    """Only recognized coverage blocks and one-row call tables change form."""
    intro = '질문별 답변과 근거 연결을 검사했습니다. 의미와 실행 결과는 사람 검토가 필요합니다.'
    common = '코드 근거와 설명 연결'

    # Project-specific, reviewed removals bind the COMPLETE original question.
    # There is no default phrase classifier: the same sentence may be a real
    # requirement in another question. Historical manuscripts remain intact.
    specifications = question_edits if question_edits is not None else {}
    def valid_edit(value):
        if isinstance(value, dict):
            label = value.get('label')
            return (set(value) == {'label'} and isinstance(label, str)
                    and any(char.isalnum() for char in label))
        return (isinstance(value, list) and bool(value)
                and all(isinstance(item, str) and item.strip() for item in value)
                and len(value) == len(set(value)))
    if not isinstance(specifications, dict) or any(
            not isinstance(key, str) or not re.fullmatch(r'[0-9a-f]{64}', key) or not valid_edit(value)
            for key, value in specifications.items()):
        raise ValueError('Question edits require complete-question SHA-256 keys and a reader label or unique nonempty sentences.')
    seen = set()

    def reader_question(question):
        key = hashlib.sha256(question.encode('utf-8')).hexdigest()
        if key not in specifications:
            return question
        if key in seen:
            raise ValueError('Configured question edit matches more than one requirement.')
        seen.add(key)
        if isinstance(specifications[key], dict):
            # A navigation question is authored separately from the complete
            # generation requirement; never render configured HTML or Markdown.
            return html.escape(specifications[key]['label'].strip(), quote=False)
        editorial_directions = specifications[key]
        if any(question.count(direction) != 1 for direction in editorial_directions):
            raise ValueError('Configured editorial sentence is missing or ambiguous.')
        # Match whole plain sentences only; code and linked text stay intact.
        offsets, total = [], 0
        for line in question.splitlines(keepends=True):
            offsets.append(total)
            total += len(line)
        edits = []
        visible = []

        class Text(HTMLParser):
            void = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}

            def __init__(self):
                super().__init__(convert_charrefs=False)
                self.stack = []
                self.invisible = set()

            def handle_starttag(self, tag, attrs):
                if tag not in self.void:
                    self.stack.append(tag)
                    attributes = dict(attrs)
                    if (tag in ('script', 'style', 'template', 'noscript', 'head', 'title') or 'hidden' in attributes
                            or re.search(r'(?:display\s*:\s*none|visibility\s*:\s*hidden)', attributes.get('style') or '', re.I)):
                        self.invisible.add(len(self.stack))

            def handle_endtag(self, tag):
                if tag not in self.void and tag in self.stack:
                    index = len(self.stack) - 1 - self.stack[::-1].index(tag)
                    del self.stack[index:]
                    self.invisible = {depth for depth in self.invisible if depth <= index}

            def handle_entityref(self, name):
                if not self.invisible:
                    visible.append(html.unescape('&' + name + ';'))

            def handle_charref(self, name):
                if not self.invisible:
                    visible.append(html.unescape('&#' + name + ';'))

            def handle_data(self, data):
                # Quoted text can itself be a requirement or example. Prefer
                # retaining a direction over deleting any quoted content.
                if self.stack or any(mark in data for mark in ('"', "'", '“', '”', '‘', '’', '«', '»')):
                    if not self.invisible:
                        visible.append(data)
                    return
                updated = data
                for direction in editorial_directions:
                    updated = re.sub(r'(^\s*|(?<=[.!?])\s+)' + re.escape(direction) + r'(?=\s|$)',
                                     lambda match: match[1], updated)
                visible.append(updated)
                if updated != data:
                    line, column = self.getpos()
                    edits.append((offsets[line - 1] + column, len(data), updated))

        Text().feed(question)
        for start, length, updated in reversed(edits):
            question = question[:start] + updated + question[start + length:]
        if any(direction in question for direction in editorial_directions) or not any(char.isalnum() for char in ''.join(visible)):
            raise ValueError('Configured edit would change protected content or empty a question.')
        return question.strip()

    def coverage(match):
        prefix, table, suffix = match.groups()
        if not simple_table(table) or re.search(r'\bid=', table):
            return match[0]
        if cells(table, 'th') != ('설계 질문', '설명 위치', '확인 범위'):
            return match[0]
        # Validate the whole table before applying/acknowledging any edit.
        # A later custom row must not roll back an earlier configured edit
        # while leaving its fingerprint marked as successfully applied.
        rows = [cells(row) for row in re.findall(r'<tr>(.*?)</tr>', table, re.S)]
        if any(len(row) != 3 or row[2] not in (common, common + ' · 실행 확인 항목 별도')
               for row in rows if row):
            return match[0]
        items = []
        for row in re.findall(r'<tr>(.*?)</tr>', table, re.S):
            values = cells(row)
            if not values:
                continue
            if len(values) != 3 or values[2] not in (common, common + ' · 실행 확인 항목 별도'):
                return match[0]
            question, links, scope = values
            question = reader_question(question)
            if not question:
                # No reader-facing question remains; retain the original rather
                # than silently dropping a requirement or inventing a label.
                return match[0]
            qualifier = '<p>실행 확인 항목 별도</p>' if scope != common else ''
            items.append('<li><p>' + question + '</p><p>' + links + '</p>' + qualifier + '</li>')
        if not items or re.search(r'\bid=', table):
            return match[0]
        return (prefix + '<ul class="coverage-links">' + ''.join(items) + '</ul>'
                + '<p><span>확인 범위</span>: <span>' + common + '</span></p>' + suffix)

    # Full generated context keeps unrelated/custom tables untouched.
    coverage_pattern = (r'(<details class="note">\s*<summary>설계 질문과 검증 범위</summary>\s*<p>'
                        + re.escape(intro) + r'</p>\s*)(<table>.*?</table>)(\s*</details>)')
    headers = {('확인할 내용', '호출 측과 대상', '구분', '근거'),
               ('호출 지점', '후보 또는 예약 대상', '확인할 경계', '근거')}
    converted = set()

    def single_call(match):
        table = match[0]
        if not simple_table(table):
            return table
        labels = cells(table, 'th')
        rows = [cells(row) for row in re.findall(r'<tr>(.*?)</tr>', table, re.S)]
        rows = [row for row in rows if row]
        if labels not in headers or len(rows) != 1 or len(rows[0]) != len(labels) or re.search(r'\bid=', table):
            return table
        converted.add(labels[0])
        return '<dl class="call-checkpoint">' + ''.join('<dt>' + key + '</dt><dd>' + value + '</dd>'
                                                       for key, value in zip(labels, rows[0])) + '</dl>'

    chunks = re.split(r'(<pre\b[^>]*>.*?</pre>)', document, flags=re.S)
    chunks = [chunk if i % 2 else re.sub(r'<table>.*?</table>', single_call,
                                        re.sub(coverage_pattern, coverage, chunk, flags=re.S), flags=re.S)
              for i, chunk in enumerate(chunks)]
    for i in range(0, len(chunks), 2):
        if '확인할 내용' in converted:
            chunks[i] = chunks[i].replace('주요 확인 지점 1개를 아래 표와 관계도에 표시합니다.',
                                          '주요 확인 지점 1개를 아래 목록과 관계도에 표시합니다.')
        if '호출 지점' in converted:
            chunks[i] = chunks[i].replace('추적 범위와 경계 표에서 후보를 구분한 뒤',
                                          '추적 범위와 경계 항목에서 후보를 구분한 뒤')
    if set(specifications) != seen:
        raise ValueError('Configured question changed or is absent; review the complete question again.')
    return ''.join(chunks)


def promote_coverage(document: str) -> str:
    """Move the generated question guide after the lead, before page terms.

    Leave examples and custom notes intact. This is presentation only;
    manuscript review records and the guide's contents stay unchanged.
    """
    pattern = (r'<pre\b[^>]*>.*?</pre>|<code\b[^>]*>.*?</code>|'
               r'(<details class="note">\s*<summary>설계 질문과 검증 범위</summary>\s*'
               r'<p>질문별 답변과 근거 연결을 검사했습니다\. 의미와 실행 결과는 사람 검토가 필요합니다\.</p>\s*'
               r'<ul class="coverage-links">.*?</ul>\s*'
               r'<p><span>확인 범위</span>: <span>코드 근거와 설명 연결</span></p>\s*</details>)')
    matches = [match for match in re.finditer(pattern, document, re.S) if match[1]]
    if len(matches) != 1:
        return document
    guide = matches[0]
    remaining = document[:guide.start()] + document[guide.end():]
    lead = re.match(r'\s*<p>.*?</p>', remaining, re.S)
    position = lead.end() if lead else 0
    return remaining[:position] + guide[0] + remaining[position:]


def class_targets(indexes: dict[str, str]) -> dict[tuple[str, ...], str]:
    """Only an unambiguous, byte-equal index row can replace a local reference."""
    targets = {}
    for page, document in indexes.items():
        for anchor, row in re.findall(r'<tr id="(symbol-[0-9a-f]{16}(?:-\d+)?)" tabindex="-1" data-symbol-kind="class">(.*?)</tr>', document, re.S):
            key = reference_cells(row)
            targets.setdefault(key, []).append(page + '#' + anchor)
    return {key: values[0] for key, values in targets.items() if len(values) == 1}


def link_related_classes(document: str, page: str, targets: dict[tuple[str, ...], str]) -> str:
    def related(match):
        heading, table = match.groups()
        if cells(table, 'th') != ('클래스', '선언 위치', '상속', '책임 (주석)') or re.search(r'\bid=', table):
            return match[0]
        if not simple_table(table, labeled=True):
            return match[0]
        if any(not re.fullmatch(r'<td(?: data-label="[^"]*")?>', tag) for tag in re.findall(r'<td\b[^>]*>', table)):
            return match[0]
        rows = [reference_cells(row) for row in re.findall(r'<tr>(.*?)</tr>', table, re.S)]
        rows = [row for row in rows if row]
        if not rows or any(row not in targets for row in rows):
            return match[0]
        links = []
        for row in rows:
            label = cells(row[0])[0]
            if re.search(r'<a\b', label):
                return match[0]
            path, anchor = targets[row].split('#', 1)
            target = quote(posixpath.relpath(path, posixpath.dirname(page) or '.'), safe='/.-') + '#' + anchor
            links.append('<li><a href="' + html.escape(target, quote=True) + '">' + label + '</a></li>')
        return (heading + '<p>선언·상속·주석은 각 클래스 링크에서 확인하세요.</p>'
                + '<ul class="related-symbols">' + ''.join(links) + '</ul>')

    return re.sub(r'(<h2 id="관련-클래스">관련 클래스</h2>\s*)<div class="table-scroll stack" tabindex="0" role="region" aria-label="표">(<table>.*?</table>)</div>',
                  related, document, flags=re.S)


def collect_manuscript_records(document: str, current: dict[str, str]) -> tuple[str, str]:
    """Move generated review lists into the page's unified evidence section.

    Only byte-equivalent plain rows with the same page-wide scope are redundant.
    Historical differences, links, package-specific records and custom notes
    remain inspectable. Manuscripts and approval ledgers are never edited.
    """
    records = []
    pattern = (r'<pre\b[^>]*>.*?</pre>|<code\b[^>]*>.*?</code>|'
               r'(<details class="note">\s*<summary>근거와 검토 정보(?P<scope>: [^<>]+)?</summary>'
               r'\s*<ul>(?P<rows>.*?)</ul>\s*</details>)')

    def collect(match):
        if not match[1]:
            return match[0]
        rows = match['rows']
        items = re.findall(r'<li>.*?</li>', rows, re.S)
        if not items or re.sub(r'<li>.*?</li>', '', rows, flags=re.S).strip() or '<ul' in rows:
            return match[0]
        if not match['scope']:
            duplicates = {f'<li>{html.escape(key)}: {html.escape(value)}</li>' for key, value in current.items()}
            items = [item for item in items if item not in duplicates]
        if items:
            records.append('<details class="note manuscript-record"><summary>원고 작성 당시 기록'
                           + (match['scope'] or '') + '</summary>'
                           + '<p>원고에 저장된 당시 기록입니다. 현재 문서의 기준과 다를 수 있습니다.</p>'
                           + '<ul>' + ''.join(items) + '</ul></details>')
        return ''

    return re.sub(pattern, collect, document, flags=re.S), ''.join(records)


def merge_next_step(document: str, following: str) -> tuple[str, str]:
    """Merge the exact generated tail only; retain different destinations/hints."""
    tail = re.search(r'<p>다음 단계: <a href="([^"]+)">([^<>]+)</a></p>\s*$', document)
    control = re.fullmatch(r'(<a class="next" href="([^"]+)">)<small>다음</small>([^<>]+) →</a>', following)
    if not tail or not control or html.unescape(tail[1]) != html.unescape(control[2]):
        return document, following
    if tail[2] != control[3]:
        following = (control[1] + '<small><span>다음</span> · <span>' + control[3] + '</span></small>'
                     + '<span>' + tail[2] + '</span> →</a>')
    return document[:tail.start()], following
