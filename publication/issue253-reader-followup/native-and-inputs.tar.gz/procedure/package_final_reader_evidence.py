import pathlib,json,yaml,hashlib,tarfile,gzip,io,datetime
r=pathlib.Path(__file__).resolve().parents[2];w=r/'build/issue253/reader-current249/run-05';out=r/'build/issue253/publication-final/publication/issue253-reader-followup';out.mkdir(parents=True,exist_ok=True);entries={};bindings=[];seen=set();configs=set();sha=lambda b:hashlib.sha256(b).hexdigest()
def add(n,p,kind):
 p=p.resolve(strict=True);assert p.is_file() and not p.is_symlink() and p.is_relative_to(r);data=p.read_bytes();assert n not in entries;entries[n]=(data,dict(sha256=sha(data),bytes=len(data),original_path=str(p),kind=kind))
for p in sorted(w.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(w)
 if rel.parts[0] in ['site','preview-ui-01'] and p.name!='site-manifest.json':continue
 if rel.parts[0].startswith('browser') and p.suffix=='.png':continue
 if '__pycache__' in rel.parts:continue
 add('run-05/'+rel.as_posix(),p,'actual-run-including-explicitly-inherited-receipts')
def snap(p):
 p=p.resolve(strict=True)
 if p.is_relative_to(w):return
 assert p.is_relative_to(r),'Unexpected outside-workspace input '+str(p)
 if p.is_dir():
  for f in sorted(p.rglob('*')):
   if f.is_file() and not any(k in f.parts for k in ['.git','__pycache__']):snap(f)
  return
 if p in seen:return
 seen.add(p);n='resolved-inputs/'+str(len(seen)).zfill(4)+'/'+p.name;add(n,p,'public-immutable-input');bindings.append(dict(original_path=str(p),snapshot=n,sha256=sha(p.read_bytes())))
 if p.suffix in ['.yaml','.yml']:
  a=yaml.safe_load(p.read_bytes())
  if isinstance(a,dict) and any(k in a for k in ['agent','paths','site','publication']):config(p,a)
def config(p,a=None):
 p=p.resolve(strict=True)
 if p in configs:return
 configs.add(p);a=yaml.safe_load(p.read_bytes()) if a is None else a
 def walk(v,keys):
  if isinstance(v,dict):
   for k,x in v.items():
    if not keys and k in ['source','output','agent']:continue
    walk(x,keys+[k])
  elif isinstance(v,list):
   for x in v:walk(x,keys)
  elif isinstance(v,str):
   q=pathlib.Path(v)
   if q.is_absolute() and q.exists():
    if keys==['publication','baseline_config']:
     if not q.is_relative_to(w):
      n='resolved-inputs/baseline-'+str(len(entries))+'.yaml';add(n,q,'baseline-configuration-reference-only')
     base=yaml.safe_load(q.read_bytes())
     for key in ['sections_file','glossary_file']:
      z=base.get('paths',{}).get(key)
      if z:snap(pathlib.Path(z))
    elif q.is_relative_to(w):
     if q.suffix in ['.yaml','.yml'] and q.is_file():config(q)
    else:snap(q)
 walk(a,[])
config(w/'publication-v12.yaml');config(w/'generation-v7.yaml');config(w/'review-v11.yaml')
for name in ['freeze_final_reader_trials.py','integrate_public94.py','finalize_public94_reports.py','finalize_current_reader_reports.py','run_followup_reader_stage.py','restore_followup_shared_source.py','parallel_standard_audit.py','review_current249_bilingual.py','run_retention249_reading.py','run_retention249_followup.py','verify_current249_native.py','run_current_browser_core.py','run_final_retention_browser.py','package_final_reader_evidence.py']:
 add('procedure/'+name,r/'build/issue253'/name,'recorded-procedure')
for old in ['run-01','run-03','run-04']:
 folder=w.parent/old
 for p in folder.glob('*execution.json'):add('prior-attempts/'+old+'/'+p.name,p,'preserved-prior-attempt-ledger')
 for pat in ['bilingual-review-01/result.json','build/consistency-review.json','return-scope-source-review-01/result.json','return-scope-helper-preflight-failures.json','bilingual-review-combined.json']:
  p=folder/pat
  if p.is_file():add('prior-attempts/'+old+'/'+pat,p,'preserved-prior-finding-not-fresh-inference')
payload=json.dumps(bindings,ensure_ascii=False,indent=2).encode();entries['resolved-inputs/index.json']=(payload,dict(sha256=sha(payload),bytes=len(payload),kind='path-relocation-bindings'))
archive=out/'native-and-inputs.tar.gz';assert not archive.exists()
with archive.open('wb') as f:
 with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w') as t:
   for n,(data,meta) in sorted(entries.items()):
    i=tarfile.TarInfo(n);i.size=len(data);i.mtime=0;i.mode=0o644;t.addfile(i,io.BytesIO(data))
index={k:v[1] for k,v in sorted(entries.items())};(out/'archive-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding='utf8');package=dict(schema=1,archive=archive.name,archive_sha256=sha(archive.read_bytes()),index_sha256=sha((out/'archive-index.json').read_bytes()),files=len(entries),compressed_bytes=archive.stat().st_size,created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Public libcamera only; run05 actual normal pipeline, original CLI receipts, earlier finding summaries and immutable input snapshots. Imported1296 and current91 native calls separated by native-call-verification-final.json. Stored outputs are historical proof, never fresh execution.',source_commit='be7e83e91348250c015aad6d6f59f1468555bae8',execution_runtime='0e848b5450898b9d89f16569307795cf93123600',generator_merge='9d05f3063747a9463fcded98c52e12a507949fa2',input_public='caaec64aeaa43dd1cea1dae1ee05a97cc77650a1',artifact_git='499465da2dc50feded066ee956de1ee166e7667f',build_id=json.loads((w/'site/site-manifest.json').read_bytes())['build_id'],reproduction='Verify archive/index, restore files, relocate absolute paths using bindings and original public archives; run pinned generator. Runtime code supplied by pinned Git, no saved response treated as fresh CLI.',excluded='Rendered duplicate site/preview assets except manifests; browser PNGs; Git and pinned runtime implementation. Current Git docs contain all final owned outputs. Source supplied by pinned public libcamera Git.',human_participants=0,human_review='pending');(out/'package.json').write_text(json.dumps(package,ensure_ascii=False,indent=2),encoding='utf8');print({k:package[k] for k in ['files','compressed_bytes','archive_sha256']})

