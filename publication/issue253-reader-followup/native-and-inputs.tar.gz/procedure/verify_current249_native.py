"""Verify new CLI receipts; retain inherited copies as a separate population."""
import collections,datetime,hashlib,json,pathlib,sys
from sdd.config import load
from sdd.call_records import load_record
from sdd.cli_provenance import verify_cli_receipt
from sdd.cli_agent import build_prompt
root=pathlib.Path(__file__).resolve().parents[2];w=root/'build/issue253/reader-current249'/sys.argv[1];target=w/sys.argv[2];assert not target.exists()
lock=json.loads((w/'input-lock.json').read_bytes());boundary=lock['frozen_at'];expected=load(w/(sys.argv[3] if len(sys.argv)>3 else 'review-v3.yaml')).agent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[];inherited=[];duplicates=[];failed=[];seen={}
for p in sorted(w.rglob('*.receipt.json')):
 # Preview, browser, source snapshots and pytest data have no model receipts.
 receipt=json.loads(p.read_bytes());identity=sha(p)
 if identity in seen:duplicates.append(dict(path=p.relative_to(w).as_posix(),original=seen[identity],sha256=identity));continue
 seen[identity]=p.relative_to(w).as_posix()
 if receipt.get('completed_at','')<boundary:
  inherited.append(dict(path=p.relative_to(w).as_posix(),receipt_sha256=identity,completed_at=receipt.get('completed_at')));continue
 record=load_record(p,root=p.parent)
 if receipt.get('provider',{}).get('exit_code')!=0:
  failed.append(dict(path=p.relative_to(w).as_posix(),sha256=identity));continue
 calls=next(parent for parent in p.parents if parent.name=='calls');proof=verify_cli_receipt(record.request,record.raw,receipt,calls,expected)
 rows.append(dict(path=p.relative_to(w).as_posix(),receipt_sha256=identity,completed_at=receipt['completed_at'],tag=receipt['tag'],prompt_characters=len(build_prompt(record.request['system'],record.request['user'],record.request['response_schema'])),**proof))
assert rows
report=dict(status='verified',stage='after-independent-review',source_commit=lock['source_commit'],boundary_at=boundary,scope='New completed original CLI receipts in this candidate workspace, distinguished by pre-generation input-lock time and deduplicated by complete receipt bytes. Imported historical calls and byte-identical archive copies are counted separately. Archive verification is not semantic acceptance.',completed_new_original_receipts=len(rows),new_tag_counts=dict(collections.Counter(r['tag'] for r in rows)),records=rows,inherited_original_receipts=inherited,duplicate_archive_copies=duplicates,failed_receipts=failed,human_review='pending',human_active_review_seconds=None)
target.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(dict(new_original=len(rows),inherited=len(inherited),copies=len(duplicates),failed=len(failed))))
