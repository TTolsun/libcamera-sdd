import datetime,hashlib,json,pathlib,subprocess,sys,time,yaml
root=pathlib.Path(__file__).resolve().parents[2];runtime=root/'build/issue253/clarity-latest';w=root/'build/issue253/reader-current249'/(sys.argv[3] if len(sys.argv)>3 else 'run-03');name=sys.argv[1];action=name.split('-')[0];cfg=w/(sys.argv[2] if len(sys.argv)>2 else 'generation-v5.yaml' if action=='generate' else 'review-v5.yaml' if action=='review' else 'publication-v5.yaml');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
catalog=yaml.safe_load(cfg.read_text(encoding='utf-8'))['site']['english_catalog'];commands={'generate':['generate','--sections','vendor-overview,request-lifecycle'], 'translate':['-m','sdd.site_localization','--config',str(cfg),'--out',catalog,'--translate'], 'review':['audit-consistency'],'site':['export-site','--out',str(w/'site')],'verify':['verify-site','--out',str(w/'site')]}
argv=[sys.executable,*commands[action]] if action=='translate' else [sys.executable,str(runtime/'tools/run_sdd.py'),'--config',str(cfg),*commands[action]];path=w/(name+'-execution.json');assert not path.exists();row=dict(stage=name,argv=argv,status='running',generator_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=runtime,text=True).strip(),runtime_files={p:sha(runtime/p) for p in ['src/sdd/site_build.py','src/sdd/next_steps.py','examples/libcamera/config/sections.yaml']},config_sha256=sha(cfg),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),human_active_review_seconds=None,cpu_seconds=None,server_wait_seconds=None);path.write_text(json.dumps(row,indent=2),encoding='utf-8');t=time.perf_counter()
try:
 with (w/(name+'.log')).open('w',encoding='utf-8') as f:p=subprocess.run(argv,cwd=runtime,stdout=f,stderr=subprocess.STDOUT,timeout=15000)
 row.update(status='completed' if p.returncode==0 else 'failed',returncode=p.returncode)
except Exception as exc:row.update(status='failed',error=repr(exc))
finally:
 row.update(ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.perf_counter()-t);path.write_text(json.dumps(row,indent=2),encoding='utf-8');print(json.dumps(row))
sys.exit(0 if row['status']=='completed' else 1)
