"""Existing #249 method: isolated actual CLI units, then normal CLI re-audit."""
from concurrent.futures import ThreadPoolExecutor,as_completed
import datetime,hashlib,json,pathlib,sys,time
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.consistency import groups,request,batches,review_store,validate,schema,SYSTEM,policy_hash
from sdd.cli_checkpoint import Capture
from sdd.llm import Agent
from sdd.validation_stage import stage
from sdd.state_io import save
root=pathlib.Path(__file__).resolve().parents[2];w=root/'build/issue253/reader-current249'/sys.argv[1];profile=w/sys.argv[2];out=w/('parallel-standard-audit-'+(sys.argv[3] if len(sys.argv)>3 else '01'));out.mkdir(exist_ok=False);cfg=load(profile);model=KnowledgeModel.load(cfg.facts_path);assert cfg.agent.kind=='cli' and cfg.agent.runner=='codex' and cfg.agent.model=='gpt-6.1-terra' and cfg.agent.args==['-c','model_reasoning_effort="high"'];units=[];policy=policy_hash();t=time.perf_counter()
with stage() as inputs:
 inputs.pin(cfg,model)
 for group in groups(cfg):
  payload=request(cfg,model,group)
  for index,batch in enumerate(batches(payload,max_input_chars=cfg.agent.max_input_chars)):
   store,wire=review_store(cfg,batch);cached=store.read()
   if cached is not None:
    saved,_=cached;assert validate(batch,saved['raw'])==saved['statements']
   units.append((group['id'],index,batch,cached is not None))
rows=[];report=dict(status='running',started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=model.meta['source_commit'],profile_sha256=hashlib.sha256(profile.read_bytes()).hexdigest(),policy_sha256=policy,concurrency=4,planned_units=len(units),planned_original_checkpoint_reuses=sum(u[3] for u in units),units=rows,human_review='pending',human_active_review_seconds=None,scope='Same standard source payloads, schema, validation and receipt-bound UnitStore as normal audit. Four isolated actual selected-CLI calls at most; no archived response promoted to a new call. Normal CLI audit must still assemble and verify the final report. Not a reader or human evaluation; not pooled with the sequential qcam benchmark.')
save(out/'input-plan.json',{k:v for k,v in report.items() if k!='units'});save(out/'result.json',report)
def run(unit):
 group,index,batch,cached=unit
 if cached:return dict(group=group,index=index,status='completed-original-checkpoint-revalidated')
 with stage() as inputs:
  inputs.pin(cfg,model);assert policy_hash()==policy;store,wire=review_store(cfg,batch);assert store.read() is None
  capture=Capture(Agent(cfg.agent,cfg.build_dir/'prompts'));raw=capture.chat(SYSTEM,wire['user'],tag=f'consistency_{group}_{index}',response_schema=schema(batch));findings=validate(batch,raw);store.write(raw,findings,capture);checked=store.read();assert checked is not None and checked[0]['statements']==findings
  return dict(group=group,index=index,status='new-original-cli-completed',receipts=[str(p) for p in capture.receipts])
with ThreadPoolExecutor(max_workers=4) as pool:
 futures={pool.submit(run,u):u for u in units}
 for future in as_completed(futures):
  group,index,_,_=futures[future]
  try:row=future.result()
  except Exception as exc:row=dict(group=group,index=index,status='failed',error=str(exc))
  rows.append(row);save(out/'result.json',report);print(group,index,row['status'],flush=True)
report.update(status='failed' if any(r['status']=='failed' for r in rows) else 'completed-awaiting-normal-cli-audit',elapsed_seconds=time.perf_counter()-t,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),new_original_units=sum(r['status']=='new-original-cli-completed' for r in rows),reused_original_units=sum(r['status']=='completed-original-checkpoint-revalidated' for r in rows));save(out/'result.json',report);assert report['status']!='failed'
