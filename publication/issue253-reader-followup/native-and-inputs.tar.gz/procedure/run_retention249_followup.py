"""Grade the isolated answers or ground the actual retained representative topic."""
import datetime,hashlib,json,pathlib,re,subprocess,sys,time,yaml
from sdd.document_metadata import split_frontmatter
root=pathlib.Path(__file__).resolve().parents[2];run=sys.argv[2] if len(sys.argv)>2 else 'run-01';runtime=root/('build/issue253/clarity-integration' if run=='run-01' else 'build/issue253/clarity-latest');w=root/'build/issue253/reader-current249'/run;mode=sys.argv[1];document=w/'manuscripts/request-lifecycle.md';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();lock=json.loads((w/'retention249-reading-lock.json').read_text(encoding='utf-8'));assert sha(document)==lock['candidate_document_sha256']
if mode=='grading':argv=[sys.executable,str(runtime/'examples/libcamera/validation/issue249/grade.py'),'--document',str(document),'--answers',str(w/'retention249-reading/result.json'),'--out',str(w/'retention249-grading')]
elif mode=='grounding':
 cfg=yaml.safe_load((w/'config/sections.yaml').read_text(encoding='utf-8'));topic=next(t for s in cfg['sections'] if s['id']=='request-lifecycle' for t in s['design_topics'] if t['id']=='resources');_,body=split_frontmatter(document.read_text(encoding='utf-8'));heads=list(re.finditer(r'^## ([^\n]+)\n',body,re.M));i=next(i for i,h in enumerate(heads) if h[1]==topic['title']);text=body[heads[i].start():heads[i+1].start() if i+1<len(heads) else len(body)];fragment=w/'retention249-resources.md';assert not fragment.exists();fragment.write_text(text,encoding='utf-8')
 facts=json.loads((w/'facts/facts.json').read_text(encoding='utf-8'));sources={k:v for k,v in facts['evidence'].items() if k.startswith('request-lifecycle/resources/')};assert len(sources)==len(topic['sources']);source_file=w/'retention249-sources.json';source_file.write_text(json.dumps({'source_commit':lock['source_commit'],'evidence':sources},ensure_ascii=False,indent=2),encoding='utf-8')
 (w/'retention249-grounding-lock.json').write_text(json.dumps(dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),whole_document_sha256=sha(document),fragment_sha256=sha(fragment),sources_sha256=sha(source_file),source_windows=len(sources),scope='Exact generated resources H2 including its six configured diagrams. Other page topics have separate whole-corpus contract audit; this selected-topic review is automatic, never human approval.'),indent=2),encoding='utf-8')
 argv=[sys.executable,str(runtime/'examples/libcamera/validation/issue249/evaluate.py'),'--document',str(fragment),'--mode','grounding','--sources',str(source_file),'--out',str(w/'retention249-grounding')]
else:raise SystemExit('Choose grading or grounding')
path=w/('retention249-'+mode+'-execution.json');assert not path.exists();row=dict(stage='retention249-'+mode,status='running',argv=argv,started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),human_active_review_seconds=None);path.write_text(json.dumps(row,indent=2),encoding='utf-8');t=time.perf_counter()
try:
 with (w/('retention249-'+mode+'.log')).open('w',encoding='utf-8') as f:p=subprocess.run(argv,cwd=runtime,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
 row.update(status='completed' if p.returncode==0 else 'failed',returncode=p.returncode)
except Exception as exc:row.update(status='failed',error=repr(exc))
finally:row.update(ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.perf_counter()-t);path.write_text(json.dumps(row,indent=2),encoding='utf-8');print(json.dumps(row))
sys.exit(0 if row['status']=='completed' else 1)
