"""Freeze two historical issue243 findings and their current public peers."""
from pathlib import Path
import hashlib, json, subprocess, sys
import yaml
from sdd.config import load
from sdd.site_localization import display_pairs

ROOT = Path.cwd()
WORK = ROOT / 'build/remaining-evidence'
PUBLIC = ROOT / 'build/issue243/public-sdd'
SOURCE = ROOT / 'build/issue243/libcamera293'
OLD_PUBLIC = '0f8e6e433fb64abf85432ae2c166971a465e1b8e'
CURRENT_PUBLIC = 'c3c9fbe'
OLD_SOURCE = '293d751a814e0d4c34e85ad457ccd9d5eefd1a61'
CURRENT_SOURCE = 'be7e83e91348250c015aad6d6f59f1468555bae8'

def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def save(name, value):
    path = WORK / name
    if path.exists():
        if json.loads(path.read_bytes()) != value: raise ValueError('Preserve differing existing input: '+str(path))
        return
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def blob(commit, path): return git(PUBLIC,'show',commit+':'+path)

CURRENT_PUBLIC = git(PUBLIC,'rev-parse',CURRENT_PUBLIC).decode().strip()
assert git(PUBLIC,'rev-parse','HEAD').decode().strip() == CURRENT_PUBLIC
old_raw = blob(OLD_PUBLIC,'docs/contract-consistency.json')
current_raw = blob(CURRENT_PUBLIC,'docs/contract-consistency.json')
old = json.loads(old_raw); current = json.loads(current_raw)
assert old['source_commit']==OLD_SOURCE and current['source_commit']==CURRENT_SOURCE
save('original-report.json',old)
save('current-report.json',current)
targets=[('callbacks-synchronization','catalog/1627ee523ce59b5e/en'),('scenario-analysis','catalog/6786e86300a109c3')]
historical=[next(x for x in old['unresolved'] if (x['contract'],x['claim_id'])==key) for key in targets]
assert len(old['unresolved'])==2

cases=[]
catalog=json.loads(blob(CURRENT_PUBLIC,'publication/issue249/english.json'))
for (contract,claim), previous in zip(targets,historical):
    group=next(c for c in current['contracts'] if c['id']==contract)
    ko_id=claim.removesuffix('/en'); en_id=ko_id+'/en'
    ko=next(f for f in group['findings'] if f['claim_id']==ko_id)
    en=next(f for f in group['findings'] if f['claim_id']==en_id)
    mdpath='docs/vendor-integration.md' if contract=='callbacks-synchronization' else 'docs/scenarios/queue_request.md'
    htmlpath='docs/en/vendor-integration.html' if contract=='callbacks-synchronization' else 'docs/en/scenarios/queue_request.html'
    md=blob(CURRENT_PUBLIC,mdpath)
    # The report uses rendered paragraph units with protected inline code.
    # Bind through the existing display-pair parser rather than equating a
    # visible statement to raw Markdown or a placeholder-bearing catalog key.
    kohtml=mdpath.removesuffix('.md')+'.html'
    pairs=display_pairs(blob(CURRENT_PUBLIC,kohtml).decode('utf-8'),catalog['strings'])
    pair=next(x for x in pairs if ' '.join(x['source'].split())==ko['claim_quote'])
    assert ' '.join(pair['translated'].split())==en['claim_quote']
    document=mdpath.removeprefix('docs/')
    assert 'catalog/'+sha((document+'\n'+pair['source']).encode())[:16]==ko_id
    cases.append(dict(id=contract,original_finding=previous,current_ko=ko['claim_quote'],current_en=en['claim_quote'],
        current_automatic_statuses=dict(ko=ko['status'],en=en['status']),
        public_files={p:sha(blob(CURRENT_PUBLIC,p)) for p in [mdpath,kohtml,htmlpath]},
        proposed_action='Retain current text only if the independent source comparison supports it; never rewrite the old verdict.'))

files=['include/libcamera/internal/camera.h','include/libcamera/request.h','src/libcamera/request.cpp','src/libcamera/camera.cpp','src/libcamera/pipeline_handler.cpp']
raws={}; equality={}
for name in files:
    a=git(SOURCE,'show',OLD_SOURCE+':./'+name)
    b=git(SOURCE,'show',CURRENT_SOURCE+':./'+name)
    assert a==b,name
    raws[name]=b.decode('utf-8'); equality[name]=dict(old_sha256=sha(a),current_sha256=sha(b),identical=True)

windows={}
def window(key,file,start,end):
    lines=raws[file].splitlines(keepends=True)
    text=''.join(lines[start-1:end])
    windows[key]=dict(file=file,line=start,end_line=end,text=text,sha256=sha(text.encode()),
        whole_file_sha256=equality[file]['current_sha256'],source_commit=CURRENT_SOURCE,
        historical_source_commit=OLD_SOURCE,historical_file_identical=True)
def block(key,file,marker,end_marker,offset=0):
    raw=raws[file];begin=raw.index(marker);end=raw.index(end_marker,begin)+len(end_marker)+offset
    startline=raw[:begin].count('\n')+1;endline=raw[:end].count('\n')+1
    window(key,file,startline,endline)

block('device-contract','src/libcamera/pipeline_handler.cpp',r' * \fn PipelineHandler::queueRequestDevice()',' */')
block('request-controls-contract','src/libcamera/request.cpp',r' * \fn Request::controls()',' */')
block('request-buffers-contract','src/libcamera/request.cpp',r' * \fn Request::buffers()',' */')
window('request-api-and-storage','include/libcamera/request.h',35,112)
window('access-declarations-and-overloads','include/libcamera/internal/camera.h',24,68)
block('access-state-implementation','src/libcamera/camera.cpp','int Camera::Private::isAccessAllowed(State state, bool allowDisconnected,','\n}')
block('queue-call-and-propagation','src/libcamera/camera.cpp',r' * \brief Queue a request to the camera','\n}')

profile=yaml.safe_load((ROOT/'build/issue243/public-current/independent-review.yaml').read_bytes())['agent']
assert profile['kind']=='cli' and profile['runner']=='codex' and profile['model']=='gpt-6.1-terra'
assert profile['args']==['-c','model_reasoning_effort="high"']
config=dict(agent=profile,source=dict(root=str(SOURCE)),publication=dict(operation_id='issue243-two-remaining-evidence'),
    output=dict(facts_dir='run/facts',sdd_dir='run/manuscripts',diagrams_dir='run/diagrams'),paths=dict(style=str(ROOT/'style')))
config_path=WORK/'independent-review.yaml'
if config_path.exists():raise ValueError('Keep original review profile')
config_path.write_text(yaml.safe_dump(config,allow_unicode=True,sort_keys=False),encoding='utf-8')
effective=load(config_path)
save('plan.json',dict(schema=1,source_commit=CURRENT_SOURCE,historical_source_commit=OLD_SOURCE,
    generator_commit=git(ROOT,'rev-parse','HEAD').decode().strip(),public_commit=CURRENT_PUBLIC,
    original_public_commit=OLD_PUBLIC,original_report_sha256=sha(old_raw),current_report_sha256=sha(current_raw),
    profiles=dict(review={k:getattr(effective.agent,k) for k in ['kind','runner','command','model','args']}),
    cases=cases,source_windows=windows,source_file_equality=equality,
    required_checks=['device-association-and-obligation','access-overload-default-and-order','bilingual-current-fidelity','historical-gaps-and-current-disposition'],
    prior_supplemental_review='publication/review-followup-242/independent-review.json',
    new_call_reason='Bind the two original issue243 findings to the current c3c9fbe/be7e83e publication, compare the original changed English and source coverage, and inspect the exact omitted default overload. Prior followup review used source293; this call is not an unchanged retry of a rejected draft.',
    scope='Only the two original issue243 findings. The latest whole-document report has other unresolved findings; do not mark it resolved or edit it.',
    excluded=['human approval','runtime or physical-device tests','other current report findings','whole-site reader or visualization evaluation'],
    completion=['actual designated native CLI review with verified original receipt','preserve previous reports/failures and human state','revise via designated CLI only if needed, then common publication/deployment; otherwise record evidence without generated-doc rebuild'],
    human_review='pending'))
print(json.dumps({'prepared':str(WORK),'cases':len(cases),'source_windows':len(windows),'other_current_unresolved':len(current['unresolved']),'profile':config['agent']['model'],'public_commit':CURRENT_PUBLIC}))
