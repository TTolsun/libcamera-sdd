"""Restore authenticated current public inputs; preserve every original byte."""
from pathlib import Path
import hashlib,json,subprocess,tarfile,shutil
import yaml
root=Path.cwd();w=root/'build/remaining-evidence';public=root/'build/issue243/public-sdd';pkg=public/'publication/issue249'
digest=lambda b:hashlib.sha256(b).hexdigest()
bundle=pkg/'native-and-operation-evidence.tar.xz';info=json.loads((pkg/'package.json').read_bytes());index=json.loads((pkg/'archive-index.json').read_bytes())
assert digest(bundle.read_bytes())==info['archive_sha256'];assert digest((pkg/'archive-index.json').read_bytes())==info['index_sha256']
original=w/'inherited-original';original.mkdir(exist_ok=False)
with tarfile.open(bundle) as a:
    for m in a:
        if not m.isfile():continue
        dest=(original/m.name).resolve();assert dest.is_relative_to(original.resolve())
        raw=a.extractfile(m).read();assert digest(raw)==index[m.name],m.name
        dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
assert len([p for p in original.rglob('*') if p.is_file()])==info['files']
out=w/'publication';shutil.copytree(original/'integration',out)
inputs=w/'publication-inputs';shutil.copytree(original/'evidence/inputs',inputs)
source=w/'sourcebe7'
subprocess.run(['git','-C',str(root/'build/issue243/libcamera293'),'worktree','add','--detach',str(source),'be7e83e91348250c015aad6d6f59f1468555bae8'],check=True)

cfg=yaml.safe_load((out/'sdd.yaml').read_bytes())
old_integration='C:/Users/baboe/.codex/worktrees/304e/camera-hal-sdd-generator/build/issue249/integration'
norm=lambda p:str(p).replace('\\','/').rstrip('/')
exact={};folders={}
for item in json.loads((inputs/'index.json').read_bytes()):
    target=inputs/item['snapshot'];assert digest(target.read_bytes())==item['sha256']
    key=norm(item['original_path']);exact[key]=target
    folders.setdefault(key.rsplit('/',1)[0],target.parent)
# Current mutable inputs are local working copies, separate from the original
# archival snapshots. Per-page authentication profiles retain original agent
# and style content; only their path references are relocated.
exact[norm(cfg['paths']['sections_file'])]=out/'sections.yaml'
exact[norm(cfg['paths']['consistency_review_config'])]=out/'independent-review.yaml'
folders[old_integration]=out
folders[norm(cfg['source']['root'])]=source
folders['C:/Users/baboe/.codex/worktrees/304e/camera-hal-sdd-generator/build/issue249']=w/'inherited-original'
folders['C:/Users/baboe/.codex/worktrees/304e/camera-hal-sdd-generator/build/issue249/public']=public
folders['C:/Users/baboe/.codex/worktrees/304e/camera-hal-sdd-generator']=root
def relocate(value):
    if isinstance(value,dict):return {k:relocate(v) for k,v in value.items()}
    if isinstance(value,list):return [relocate(v) for v in value]
    if isinstance(value,str):
        path=norm(value)
        if path in exact:return str(exact[path])
        for prefix in sorted(folders,key=len,reverse=True):
            if path==prefix or path.startswith(prefix+'/'):return str(folders[prefix]/path[len(prefix):].lstrip('/'))
    return value

for name in ['sdd.yaml','independent-review.yaml']:
    c=relocate(yaml.safe_load((out/name).read_bytes()))
    c['publication']['operation_id']='issue243-two-remaining-evidence'
    c['site']['mermaid_dir']=str(public/'docs/assets/mermaid')
    (out/name).write_text(yaml.safe_dump(c,allow_unicode=True,sort_keys=False),encoding='utf-8')
for p in sorted(inputs.rglob('*.yaml')):
    # JSON native receipts and original archived YAML are never rewritten.
    p.write_text(yaml.safe_dump(relocate(yaml.safe_load(p.read_bytes())),allow_unicode=True,sort_keys=False),encoding='utf-8')
manifest=json.loads((public/'docs/site-manifest.json').read_bytes())
for name in manifest['outputs']:
    if name.endswith('.md'):
        dst=out/'manuscripts'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(public/'docs'/name,dst)
shutil.copyfile(public/'publication/issue249/english.json',out/'english.json')
assert digest((out/'facts/facts.json').read_bytes())==manifest['inputs']['facts']
assert digest((out/'build/consistency-review.json').read_bytes())==manifest['inputs']['consistency_review']
result=dict(status='restored',original_files_verified=len(index),archive_sha256=info['archive_sha256'],
    baseline_manifest_build_id=manifest['build_id'],original_native_files={p.relative_to(out).as_posix():digest(p.read_bytes()) for p in out.rglob('*') if p.is_file() and '/prompts/' in p.as_posix()},
    baseline_manuscripts={p.relative_to(out/'manuscripts').as_posix():digest(p.read_bytes()) for p in (out/'manuscripts').rglob('*.md')},
    path_changes='Local working configuration only; originals retained in inherited-original and original public archive.',human_review='pending')
(w/'restoration.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if not isinstance(v,dict)}),flush=True)
