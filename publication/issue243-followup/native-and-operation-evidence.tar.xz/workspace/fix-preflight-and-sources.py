from pathlib import Path
import json,yaml,copy,hashlib
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.evidence import collect
from sdd.contract_schema import configuration_errors
w=Path.cwd()/'build/remaining-evidence';cfg=load(w/'publication/sdd.yaml')
p=w/'publication/sections.yaml';d=yaml.safe_load(p.read_bytes());s=next(x for x in d['sections'] if x['id']=='vendor-integration');t=next(x for x in s['design_topics'] if x['id']=='request');part=next(x for x in t['parts'] if x['id']=='device')
part['answer_contract']['reject_patterns']=[dict(pattern='스트림에 연결된 버퍼 집합과 파라미터 집합',message='버퍼와 스트림의 연결 관계, 요청에 파라미터가 포함된다는 관계를 각각 주어와 서술어가 있는 별도 문장으로 구분하세요. 파라미터와 스트림 연결 금지라는 제품 보장은 만들지 마세요.')]
assert not configuration_errors(s),configuration_errors(s)
p.write_text(yaml.safe_dump(d,allow_unicode=True,sort_keys=False),encoding='utf-8')
(w/'scoped-repair-03/configuration-disposition.json').write_text(json.dumps(dict(status='configuration-failed-not-semantic-judgement',cause='The local recipe supplied reject_patterns as a string rather than the existing pattern/message object schema. Existing bounded retries consumed calls before configuration validation; no such output is accepted.',correction='Use the existing object schema and run common configuration_errors before any next native call.',human_review='pending'),indent=2)+'\n')
source=dict(id='declarations',file='include/libcamera/internal/camera.h',start='int isAccessAllowed(State state, bool allowDisconnected = false,',end='void disconnect();')
sources=dict(sections=[dict(id='contract-evidence',design_topics=[dict(id='access-default',question='Literal default arguments and overload declarations for source-grounded contract review.',sources=[source])])])
selection=w/'audit-source-selection.yaml';selection.write_text(yaml.safe_dump(sources,sort_keys=False),encoding='utf-8')
profile=copy.deepcopy(cfg);profile.paths['sections_file']=selection;profile.raw['documentation']={'enabled':False}
m=KnowledgeModel.load(cfg.facts_path);before=json.loads(cfg.facts_path.read_bytes());backup=w/'facts-before-source-addition.json';backup.write_bytes(cfg.facts_path.read_bytes())
selected=copy.deepcopy(m);collect(profile,selected);assert len(selected.evidence)==1
sid,record=next(iter(selected.evidence.items()));assert record['status']=='available'
assert sid not in m.evidence;m.evidence[sid]=record;m.save(cfg.facts_path)
after=json.loads(cfg.facts_path.read_bytes());oldkeys=copy.deepcopy(before);newkeys=copy.deepcopy(after);oldkeys.pop('evidence');newkeys.pop('evidence');assert oldkeys==newkeys
assert {k:v for k,v in after['evidence'].items() if k!=sid}==before['evidence']
contracts=cfg.paths['consistency_file'];raw=yaml.safe_load(contracts.read_bytes());(w/'contracts-before-source-addition.yaml').write_bytes(contracts.read_bytes())
for group in raw['contracts']:
    if group['id'] in ['scenario-analysis','submission-checks']:group.setdefault('evidence',[]).append(sid)
contracts.write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
(w/'source-augmentation.json').write_text(json.dumps(dict(status='source-window-added',source_commit=m.meta['source_commit'],source_id=sid,record=record,groups=['scenario-analysis','submission-checks'],other_facts_and_original_evidence_identical=True,new_compile_or_class_extraction=False,human_review='pending'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(configuration_preflight='passed',new_source=sid,line=record['line'],end_line=record['end_line'],groups=['scenario-analysis','submission-checks'])))
