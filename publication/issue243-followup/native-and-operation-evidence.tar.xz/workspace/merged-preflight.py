from pathlib import Path
import json,hashlib,shutil,time
from sdd.config import load
from sdd.localization_cli import prepare_catalog
w=Path.cwd()/'build/remaining-evidence';cfg=load(w/'publication/sdd.yaml');original=w/'publication/english.json';trial=w/'merged-preflight-catalog.json'
assert not trial.exists();shutil.copyfile(original,trial);before=hashlib.sha256(original.read_bytes()).hexdigest();started=time.monotonic()
try:
    result=prepare_catalog(cfg,trial,translate=False)
    assert json.loads(trial.read_bytes())['strings']==json.loads(original.read_bytes())['strings']
    assert hashlib.sha256(original.read_bytes()).hexdigest()==before
    record=dict(status='passed',stage='merged-translation-preflight-without-inference',new_model_calls=0,original_catalog_unchanged=before,all_translation_values_identical=True,prepared=result,wall_seconds=time.monotonic()-started,human_review='pending',limitation='This newly merged preflight was run after the earlier native calls. It is not retroactively presented as a precondition of those calls.')
    (w/'merged-preflight.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(record,ensure_ascii=False),flush=True)
except BaseException as exc:
    (w/'merged-preflight-failure.json').write_text(json.dumps(dict(type=type(exc).__name__,error=str(exc),wall_seconds=time.monotonic()-started,human_review='pending'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8');raise
