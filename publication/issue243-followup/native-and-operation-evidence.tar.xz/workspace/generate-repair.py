from pathlib import Path
import hashlib,json,time,uuid
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.generate import Generator
from sdd.impact import ImpactReport
from sdd.llm import Agent
root=Path.cwd();w=root/'build/remaining-evidence';cfg=load(w/'publication/sdd.yaml');m=KnowledgeModel.load(cfg.facts_path)
out=w/'generation-attempts'/uuid.uuid4().hex;out.mkdir(parents=True)
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={p.relative_to(cfg.sdd_dir).as_posix():digest(p) for p in cfg.sdd_dir.rglob('*.md')}
(out/'before.json').write_text(json.dumps(before,indent=2)+'\n')
a=Agent(cfg.agent,dump_dir=cfg.build_dir/'prompts');a._counter=max((int(p.name.split('_',1)[0]) for p in a.dump_dir.glob('*_*.md') if p.name.split('_',1)[0].isdigit()),default=0)
started=time.monotonic()
try:
    written=Generator(cfg,m,a).run(section_ids=['vendor-integration'],impact=ImpactReport.load(cfg.build_dir/'impact.json'))
    after={p.relative_to(cfg.sdd_dir).as_posix():digest(p) for p in cfg.sdd_dir.rglob('*.md')}
    changed=[name for name in before.keys()|after.keys() if before.get(name)!=after.get(name)]
    assert changed==['vendor-integration.md'],changed
    result=dict(status='generated',written=[str(x) for x in written],changed=changed,unchanged_manuscripts=len(before)-1,human_review='pending')
except BaseException as e:
    result=dict(status='failed',type=type(e).__name__,error=str(e),human_review='pending');raise
finally:
    result['wall_seconds']=time.monotonic()-started
    (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False),flush=True)
