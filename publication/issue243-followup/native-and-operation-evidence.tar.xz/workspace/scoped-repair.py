"""Use the existing one-unit draft/grounding and common page assembler.

Retained topic input identities are deliberately NOT promoted to the current
generation profile. Future ordinary generation must still make its own reuse
decision. This recipe supplies no authored replacement statement.
"""
from pathlib import Path
import copy,hashlib,json,time,sys
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.document_metadata import split_frontmatter
from sdd.design_request import prepare_requests,_design_units
from sdd.design_execution import _request_unit
from sdd.generated_design import _assemble_generation
from sdd.generation_run import Execution
from sdd.llm import Agent
from sdd.generate import Generator
from sdd.grounding import policy_hash
from sdd.cli_provenance import verify_cli_receipt
from sdd.contract_schema import configuration_errors

root=Path.cwd();w=root/'build/remaining-evidence';cfg=load(w/'publication/sdd.yaml');m=KnowledgeModel.load(cfg.facts_path)
section=next(s for s in cfg.sections() if s['id']=='vendor-integration');path=cfg.sdd_dir/'vendor-integration.md'
errors=configuration_errors(section)
if errors:raise ValueError('Configuration preflight: '+' / '.join(errors))
before=path.read_bytes();meta,body=split_frontmatter(before.decode('utf-8'));old=meta['generated_design']
restored=json.loads((w/'restoration.json').read_bytes())
attempt=sys.argv[1] if len(sys.argv)>1 else 'scoped-repair-02'
if attempt=='scoped-repair-02':
    assert hashlib.sha256(before).hexdigest()==restored['baseline_manuscripts']['vendor-integration.md'],'The interrupted broad run must not have replaced the original page'
assert old['grounding_policy']==policy_hash() and old['grounding_review']=='passed'
out=w/attempt;out.mkdir(exist_ok=False);(out/'before.md').write_bytes(before)
plan=prepare_requests(cfg,m,section,before.decode('utf-8'))
unit=next(x for x in _design_units(section,{}) if x['id']=='request' and x.get('_part_id')=='device')
answers=copy.deepcopy(old['answers']);old_list=answers['request'];at=[i for i,x in enumerate(old_list) if x.get('part_id')=='device'];assert len(at)==1
original_statement=old_list[at[0]];answers['request']=[x for x in old_list if x.get('part_id')!='device']
dump=cfg.build_dir/'prompts';receipts_before={str(p) for p in (dump/'calls').rglob('*.receipt.json')}
a=Agent(cfg.agent,dump_dir=dump);a._counter=max((int(p.name.split('_',1)[0]) for p in dump.glob('*_*.md') if p.name.split('_',1)[0].isdigit()),default=0)
e=Execution(cfg,a,model=m);e.path=out/'generation-run.json';started=time.monotonic()
try:
    with e.track('single-question-source-repair'):
        statements,record=_request_unit(cfg,m,e,section,unit,plan.prompts['request'],plan.policy['design_grounding'],None,answers)
        assert len(statements)==1 and statements[0].get('part_id')=='device'
        answers['request']=old_list[:at[0]]+statements+old_list[at[0]+1:]
        # Preserve historical topic identities, including the partly repaired
        # topic. They cannot be mistaken for a full fresh current-profile run.
        result=_assemble_generation(cfg,m,section,answers,copy.deepcopy(old['topic_inputs']),
            [x for x in answers if x!='request'],[],copy.deepcopy(old['topic_agents']),plan.policy)
        result.artifact['partial_revision']=dict(topic='request',part='device',old_statement=original_statement,
            native_record=record,retained_statement_count=sum(len(x) for x in answers.values())-1,
            prior_manuscript_sha256=hashlib.sha256(before).hexdigest(),
            retained_topic_identities='Historical identities retained; no current-profile reuse promotion',human_review='pending')
        gen=Generator(cfg,m,e);gen.generated_designs[section['id']]=result
        written=gen._prose(section)
    now,_=split_frontmatter(written.read_text(encoding='utf-8'))
    changed=[(tid,i) for tid,rows in old['answers'].items() for i,row in enumerate(rows) if now['generated_design']['answers'][tid][i]!=row]
    assert changed==[('request',at[0])],changed
    proof=[]
    for p in sorted((dump/'calls').rglob('*.receipt.json')):
        if str(p) in receipts_before:continue
        prefix=str(p).removesuffix('.receipt.json');req=json.loads(Path(prefix+'.request.json').read_bytes());response=Path(prefix+'.response.txt').read_text(encoding='utf-8');receipt=json.loads(p.read_bytes())
        proof.append(dict(receipt=str(p),verification=verify_cli_receipt(req,response,receipt,dump/'calls',cfg.agent)))
    result=dict(status='single-unit-repaired',changed_statements=changed,new_native_receipts=len(proof),provenance=proof,
        replacement=statements,retained_statement_count=sum(len(x) for x in answers.values())-1,
        wall_seconds=time.monotonic()-started,human_review='pending')
    (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False),flush=True)
except BaseException as exc:
    (out/'failure.json').write_text(json.dumps(dict(type=type(exc).__name__,error=str(exc),wall_seconds=time.monotonic()-started,human_review='pending'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8');raise
