from pathlib import Path
import json,copy,hashlib
from sdd.config import load
from sdd.export_site import _render_site
from sdd.site_localization import display_pairs
from sdd.facts.model import KnowledgeModel
w=Path.cwd()/'build/remaining-evidence';cfg=load(w/'publication/sdd.yaml');catalog=json.loads((w/'publication/english.json').read_bytes())
cfg.raw['site'].pop('english_catalog',None)
site=_render_site(cfg,w/'private-source-review-site',check_consistency=False)
pairs=display_pairs((site/'vendor-integration.html').read_text(encoding='utf-8'),catalog['strings'])
plan=json.loads((w/'plan.json').read_bytes());case=next(x for x in plan['cases'] if x['id']=='callbacks-synchronization')
changed=[x for x in pairs if ('요청에는 버퍼 집합이 들어 있으며' in x['source'] or x['source'].startswith('PipelineHandler::queueRequestDevice()는 CameraManager'))]
assert len(changed)==2,changed
case['before_repair_ko']=case['current_ko'];case['current_ko']='\n\n'.join(x['source'] for x in changed);case['current_en']='\n\n'.join(x['translated'] for x in changed)
case['current_automatic_statuses']={'initial_supplemental':'Korean ambiguity found; raw native-review-01 preserved','final':'unjudged until this new native review'}
case['proposed_action']='Retain only if the separated subjects resolve the specific modifier ambiguity and all translated clauses preserve the exact source API scope. Do not report retained preexisting limitations as newly introduced or resolved.'
model=KnowledgeModel.load(cfg.facts_path);record=model.evidence['vendor-integration/request/completion-context'];context=record['context'];plan['source_windows']['complete-buffer-contract']=dict(file=record['file'],source_commit=model.meta['source_commit'],**context)
plan['changed_display_pairs']=changed
plan['manuscript_sha256']=hashlib.sha256((cfg.sdd_dir/'vendor-integration.md').read_bytes()).hexdigest();plan['catalog_sha256']=hashlib.sha256((w/'publication/english.json').read_bytes()).hexdigest()
plan['previous_review_sha256']=hashlib.sha256((w/'native-review-01/review.json').read_bytes()).hexdigest()
plan['review_task']='Review after the native single-question correction and native translation. Check both complete changed display units, including faithful retained thread/completion clauses in their stated source API scope. Report concrete errors or missing evidence; do not certify broader stopping/cancellation behavior or previously unresolved whole-site findings.'
plan['new_call_reason']='The Korean device statement was actually changed by the selected native CLI after repeated-phrase and configuration failures; two complete display units were translated. Source declaration is now also attached to the standard contract groups. This is a changed-input final review, not an unchanged retry.'
(w/'final-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(status='prepared',changed_pairs=len(changed),manuscript_sha256=plan['manuscript_sha256'],catalog_sha256=plan['catalog_sha256'])))
