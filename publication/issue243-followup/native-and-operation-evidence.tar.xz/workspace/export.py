from pathlib import Path
import json,hashlib,yaml,time,sys
from sdd.config import load
from sdd.export_site import export_site
from sdd.site_build import verify_site
w=Path.cwd()/'build/remaining-evidence';cfg=load(w/'publication/sdd.yaml');audit=json.loads((w/'audit-result.json').read_bytes());assert audit['status']=='passed'
report=cfg.build_dir/'consistency-review.json';raw=json.loads(report.read_bytes());assert raw['human_review']=='pending'
fresh=dict(path=str(report),gate='before-export',producer='current-native-codex-contract-audit',sha256=hashlib.sha256(report.read_bytes()).hexdigest(),bindings=dict(status='passed',source_commit=raw['source_commit'],human_review='pending'))
for name in ['sdd.yaml','independent-review.yaml']:
    p=w/'publication'/name;data=yaml.safe_load(p.read_bytes());same=[r for r in data['publication']['reports'] if r['path']==fresh['path']]
    if same:assert same==[fresh]
    else:
        data['publication']['reports'].append(fresh);p.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
cfg=load(w/'publication/sdd.yaml');started=time.monotonic()
revision=sys.argv[1] if len(sys.argv)>1 else ''
prefix='site-'+revision+'-' if revision else 'site-'
try:
    one=export_site(cfg,w/(prefix+'first'));check1=verify_site(one);two=export_site(cfg,w/(prefix+'final'));check2=verify_site(two)
    a=(one/'site-manifest.json').read_bytes();b=(two/'site-manifest.json').read_bytes();assert a==b
    manifest=json.loads(a)
    for rel,digest in manifest['outputs'].items():assert hashlib.sha256((one/rel).read_bytes()).hexdigest()==hashlib.sha256((two/rel).read_bytes()).hexdigest()==digest
    result=dict(status='verified',build_id=manifest['build_id'],manifest_sha256=hashlib.sha256(a).hexdigest(),owned_outputs=len(manifest['outputs']),two_identical_exports=True,first=check1,final=check2,wall_seconds=time.monotonic()-started,human_review='pending')
    (w/('two-exports-'+revision+'.json' if revision else 'two-exports.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False),flush=True)
except BaseException as exc:
    (w/('export-failure-'+revision+'.json' if revision else 'export-failure.json')).write_text(json.dumps(dict(type=type(exc).__name__,error=str(exc),wall_seconds=time.monotonic()-started,human_review='pending'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8');raise
