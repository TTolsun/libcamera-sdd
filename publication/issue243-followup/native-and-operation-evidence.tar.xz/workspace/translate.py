from pathlib import Path
import json,yaml,time,shutil
from sdd.config import load
from sdd.localization_cli import prepare_catalog
root=Path.cwd();w=root/'build/remaining-evidence';src=w/'publication/sdd.yaml';directory=w/'translation';directory.mkdir(exist_ok=False)
raw=yaml.safe_load(src.read_bytes());profile=directory/'sdd.yaml';profile.write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
cfg=load(profile);destination=w/'publication/english.json';shutil.copyfile(destination,directory/'before-catalog.json')
started=time.monotonic()
try:
    result=prepare_catalog(cfg,destination,translate=True)
    old=json.loads((directory/'before-catalog.json').read_bytes())['strings'];now=json.loads(destination.read_bytes())['strings']
    delta={k:v for k,v in now.items() if old.get(k)!=v}
    report=dict(status='translated',changed=delta,removed_keys=[k for k in old if k not in now],wall_seconds=time.monotonic()-started,human_review='pending')
    (directory/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False),flush=True)
except BaseException as exc:
    (directory/'failure.json').write_text(json.dumps(dict(type=type(exc).__name__,error=str(exc),wall_seconds=time.monotonic()-started,human_review='pending'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8');raise
