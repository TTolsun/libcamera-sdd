from pathlib import Path
import json,yaml
w=Path.cwd()/'build/remaining-evidence'
rejected=json.loads((w/'scoped-repair-02/result.json').read_bytes())['replacement'][0]['text']
bad='스트림에 연결된 버퍼 집합과 파라미터 집합'
assert bad in rejected
(w/'scoped-repair-02/semantic-disposition.json').write_text(json.dumps(dict(status='known-ambiguity-recurred',resolved=False,
    reason='The deterministic source/contract validation passed, but the same confirmed joint modifier remains. Do not count the source-bound draft as a successful semantic repair.',
    unchanged_problem_phrase=bad,next_action='Change the unit question to require independent subject/predicate sentences for buffer-stream association and request-parameter containment, and reject this precise known ambiguous phrase using the existing answer_contract reject_patterns.',human_review='pending'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=w/'publication/sections.yaml';d=yaml.safe_load(p.read_bytes());s=next(x for x in d['sections'] if x['id']=='vendor-integration');t=next(x for x in s['design_topics'] if x['id']=='request');part=next(x for x in t['parts'] if x['id']=='device')
part['question']+=' 이전 초안의 "'+bad+'"는 수식 범위가 여전히 모호합니다. 버퍼가 스트림과 연결된다는 관계와 요청에 파라미터가 포함된다는 관계를 각각 주어와 서술어가 있는 별도의 문장으로 설명하세요. 여러 문장을 한 text에 담을 수 있습니다. 같은 공동 수식 구문을 다시 쓰지 마세요.'
part['answer_contract']['reject_patterns']=[bad]
p.write_text(yaml.safe_dump(d,allow_unicode=True,sort_keys=False),encoding='utf-8')
print('Recorded recurrence and changed the existing unit contract before the next call.')
