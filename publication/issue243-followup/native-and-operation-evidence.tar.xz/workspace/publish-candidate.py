"""Package an authenticated delta and synchronize only manifest-owned output."""
from pathlib import Path
import hashlib,json,subprocess,tarfile,io,shutil
from sdd.publication import copy_site
from sdd.site_build import verify_site

root=Path.cwd();w=root/'build/remaining-evidence';public=root/'build/issue243/public-sdd';dest=public/'publication/issue243-followup'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
verification=json.loads((w/'native-verification.json').read_bytes());assert verification['status']=='verified'
quality=json.loads((w/'two-exports-merged.json').read_bytes());assert quality['status']=='verified'
integration=json.loads((w/'merged-integration.json').read_bytes());assert integration['source_and_language_review_policies_unchanged']
assert json.loads((w/'merged-preflight.json').read_bytes())['new_model_calls']==0
assert not subprocess.check_output(['git','status','--porcelain'],cwd=public,text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=public,text=True).strip()=='adde653b0310dfeb4a6120bf838f9df840b00dee'
preserved=json.loads((w/'concurrent-public-preservation.json').read_bytes())
assert all(sha(public/name)==value for name,value in preserved['concurrent_subsite'].items())

dest.mkdir(exist_ok=False)
candidate=w/'site-merged-final';verify_site(candidate)
copy_site(candidate,public/'docs',scratch=public/'.git/sdd-followup-sync')
assert all(sha(public/name)==value for name,value in preserved['concurrent_subsite'].items())

files={}
def add(path,name):
    assert path.is_file() and not path.is_symlink();raw=path.read_bytes()
    assert name not in files;files[name]=raw
for p in sorted(w.iterdir()):
    if p.is_file() and p.suffix in ['.py','.json','.yaml','.log']:add(p,'workspace/'+p.name)
for directory in ['native-review-01','native-review-02','config-review','generation-attempts','scoped-repair-02','scoped-repair-03','scoped-repair-04','translation','publication-inputs']:
    for p in sorted((w/directory).rglob('*')):
        if p.is_file() and not any(x in p.parts for x in ['execution-locks','__pycache__']):add(p,'workspace/'+p.relative_to(w).as_posix())
original_index=json.loads((public/'publication/issue249/archive-index.json').read_bytes())
for p in sorted((w/'publication').rglob('*')):
    if not p.is_file() or any(x in p.parts for x in ['execution-locks','__pycache__']):continue
    rel=p.relative_to(w/'publication').as_posix();original='integration/'+rel
    if original_index.get(original)==sha(p):continue
    add(p,'workspace/publication/'+rel)
tracked=subprocess.check_output(['git','ls-files','-z','src/sdd','examples/libcamera/validation/issue243','examples/libcamera/config/sections.yaml','examples/libcamera/config/contracts.yaml','examples/libcamera/sdd.yaml','pyproject.toml','uv.lock'],cwd=root).decode('utf-8').split('\0')
for name in filter(None,tracked):
    p=root/name
    if p.is_file():add(p,'generator/'+name)

archive=dest/'native-and-operation-evidence.tar.xz'
with tarfile.open(archive,'w:xz') as tar:
    for name,raw in sorted(files.items()):
        member=tarfile.TarInfo(name);member.size=len(raw);member.mtime=0;tar.addfile(member,io.BytesIO(raw))
index={name:hashlib.sha256(raw).hexdigest() for name,raw in sorted(files.items())}
(dest/'archive-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
summary=dict(status='local-candidate-verified-generator-merged',source_commit='be7e83e91348250c015aad6d6f59f1468555bae8',
    original_findings='Original issue243 report at0f8e6e4 retained unchanged; this is a later source/translation disposition.',
    selected_cases=dict(parameter_association='supported after actual Korean repair and native translation; English was already corrected by earlier public main',access_precedence='supported after declaration/overload evidence; text retained'),
    actual_new_completed_native_receipts=verification['new_completed_native_receipts'],completed_receipts_total=sum(verification['new_completed_native_receipts'].values()),
    receipt_count_is_not_successful_repairs=True,retained_answers=33,other_manuscripts_unchanged=28,original_archive_files_preserved=4123,working_original_native_files_preserved=1527,
    contract_audit=json.loads((w/'audit-result.json').read_bytes()),generator=json.loads((w/'generator-merge.json').read_bytes()),merged_execution=integration,
    exports=quality,concurrent_public_subsite_files_preserved=len(preserved['concurrent_subsite']),
    limitations=['The original four out-of-scope ambiguous/insufficient findings remain in the current standard report. Changes in other automatic verdicts are not counted as confirmed repairs.',
        'Human review remains pending; no camera runtime, physical-device, whole-site reader evaluation or in-house HAL validation.',
        'Completed receipts include four unused completed calls from a broad attempt, the first recurring draft/grounding and two local-configuration-rejected drafts. One broad call was interrupted before completion; no substitute CLI/API/manual manuscript was used.',
        'Parallel stage durations are not added as end-to-end wall time, and no call-reduction or speedup is claimed.',
        'Native semantic calls ran before the later pretranslation guard was merged. The merged guard was then run with zero model calls and unchanged translations; final exports use the actual CI-equivalent merged tree.'],
    publication_evidence='Actual public PR merge, Pages and remote output/browser confirmation are recorded in the issue243 followup publication comment after this candidate is deployed.',human_review='pending')
(dest/'resolution.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['plan.json','final-plan.json','attempts.json','retained-origin.json','source-augmentation.json','audit-source-selection.yaml','native-verification.json','generator-merge.json','merged-integration.json','merged-preflight.json','two-exports-merged.json']:
    shutil.copyfile(w/name,dest/name)
shutil.copyfile(candidate/'site-manifest.json',dest/'site-manifest.json')
package=dict(schema=1,files=len(files),archive_sha256=sha(archive),index_sha256=sha(dest/'archive-index.json'),
    original_inherited_archive='../issue249/native-and-operation-evidence.tar.xz',original_inherited_archive_sha256='32fdf06972545e13e2b4e6ae142fab436130193b5ef46a88916003e1ea8c9ccc',
    reconstruction='Restore original issue249 archive integration and evidence/inputs; apply workspace publication overlay and publication-inputs. Config paths are execution records and must be explicitly relocated without rewriting native receipts. Source is immutable Git be7e83e. Generator snapshot is the merged CI-equivalent tree.',
    excluded='Immutable inherited-original duplicate, source Git worktree, rendered sites, pytest doubles, OS locks and caches; original inherited archive remains unchanged.',human_review='pending')
(dest/'package.json').write_text(json.dumps(package,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
readme='''# #243 후속: 버퍼·파라미터 구분과 접근 검사 선언 근거

원래 남은 두 판정을 추가 근거와 실제 지정 CLI로 대조했습니다. 최종 별도 검토는 두 대상과 변경된 한영 표시를 지지했습니다. [생성기 PR #273](https://github.com/TTolsun/camera-hal-sdd-generator/pull/273)은 `efbf6cb`로 병합됐습니다. 이 패키지는 배포 전 검증한 입력·원본·후보입니다. 공개 SDD 병합·Pages·실제 URL 확인은 [#243의 후속 발행 댓글](https://github.com/TTolsun/camera-hal-sdd-generator/issues/243)에서 확인하세요. 사람 검토는 계속 대기 상태입니다.

| 대상 | 원인과 필요한 소스 | 처리 |
|---|---|---|
| 버퍼·파라미터 연결 | `pipeline_handler.cpp:530–544`는 스트림에 연결된 버퍼 집합과 별도의 파라미터 집합을 말합니다. `request.cpp:407–420,432–439`와 `request.h:35–112`도 대조했습니다. | 과거 영어 수식은 이전 main에서 이미 고쳐졌습니다. 새 검토가 발견한 한국어 공동 수식은 지정 CLI로 분리했고 파라미터 적용 의무를 보존했습니다. 파라미터와 스트림 연결 금지라는 새 제품 보장은 만들지 않았습니다. |
| 연결·상태 오류 우선순위 | `camera.h:59–65`의 두 선언, `camera.cpp:690–707`의 helper, `camera.cpp:1308–1380`의 호출부가 필요합니다. 독립 검토에는 헤더의 클래스 문맥도 제공했습니다. | 한 인자는 단일 State 오버로드를 선택하고 기본값은 false입니다. 연결 오류가 상태 비교보다 먼저 반환되며 queueRequest는 음수 결과를 그대로 돌려줍니다. 올바른 원고는 유지하고 선언 창을 두 공통 계약에 추가했습니다. |

현재 소스 be7e83e와 원래293의 참조 다섯 파일은 전체 바이트가 같습니다. 새 클래스 추출·장치 실행을 했다는 뜻이 아닙니다. 공개 예제의 다음 정상 수집에서는 두 질문의 `access-declaration`을 읽습니다. 이번 동결된 발행 입력은 기존 `collect`로 만든 `contract-evidence/access-default/declarations`를 사용하며 그 선택 설정과 재현 절차를 보관합니다.

실제 단위 보정은 답변34개 중 하나만 바꾸고33개를 유지했습니다. 다른 원고28개도 바이트가 같습니다. 문단 경계 때문에 바뀐 영어 표시 두 단위는 기존 번역 경로로 처리했습니다. ID1583의 `{{3}}` 중복은 해당 텍스트만 다시 요청했습니다. 최종 독립 검토는 두 완성 표시 단위의 소스·한영 대응을 확인했습니다. 짧은 두 계약은 문장과 조건 순서로 충분하다는 그림 생략 사유도 남겼습니다.

실패를 지우지 않았습니다. 최초 전체 문서 실행은 범위가 넓어 저장 전에 중단했습니다. 첫 단위 보정은 같은 모호 구문을 남겼으므로 해결이 아닙니다. 이후 로컬 reject_patterns 형식 오류도 보존하고 공통 설정 검사를 호출 앞으로 옮겼습니다. 올바른 객체 형식과 서로 다른 주어·서술어 지시로 다시 보정한 뒤 실제 독립 검토에서 해결을 확인했습니다. `attempts.json`은 입력·변경·지적·상태·다음 조치를 연결합니다. 보존된 원고·영수증을 새 CLI 성공으로 바꾸지 않았습니다.

검증된 신규 완료 CLI 영수증은54개입니다. 독립 소스 검토2, 예제 설정 리뷰1, 생성/근거 대조10, 번역2, 공통 계약39로 구분합니다. 이 수치는 성공한 수정54건이 아닙니다. 생성10에는 중단한 넓은 실행의 미사용 완료4회, 재발 초안/근거 대조2회, 설정 오류로 거절된 초안2회와 최종 단위 생성/근거 대조2회가 포함됩니다. 완료 전 중단한 호출 하나는 완료 영수증으로 세지 않습니다. 테스트 대역57개와 CI의 CLI 프로세스 대역도 이 신규 모델 호출 수에 넣지 않았습니다.

공통 감사는39개 새 배치·51개 기존 배치 재검증으로 통과했습니다. 다른 범위의 모호함·근거 부족4개는 그대로 보고하며, 다른 자동 판정의 변화나 사라진 문단 ID를 실제 오류 해결로 세지 않습니다. 실행 시간은 원본 기록에 있고 병렬 시간을 합쳐 전체 속도 절감률로 만들지 않습니다. 호출 감소도 주장하지 않습니다.

원본 archive4123개 항목과 작업 복사본의 원래 네이티브1527개 파일을 검증했습니다. 과거 주제 입력 식별자는 현재 프로필에서 새로 생성한 것으로 승격하지 않았습니다. `retained-origin.json`과 새 원고의 partial_revision은 이전 원고 해시에 연결됩니다. 기존 근거 부족 응답·체크포인트·생성자와 날짜·사람 상태의 원본은 archive에 남습니다.

최종 CI는 Linux3.11/3.14 각각2980통과, Windows3.11/3.14 각각2979통과·1생략입니다. 선행 통합29검사는 전체 시험에도 포함되어 있으므로 더해서 세지 않습니다. 실제 CI 체크아웃6a0d876과 병합efbf6cb의 전체 Git 트리가 같습니다. 동시 병합된 번역 전 검사도 호출0회로 실행해1945개 번역 값을 보존한 뒤, 병합 코드로 두 번 정상 export했습니다. 이전 native 실행이 나중에 생긴 선행 검사를 거쳤다고 바꾸지 않았습니다.

두 정상 export의 manifest와350개 산출물이 같고66페이지·내부 링크 오류0개입니다. 동시 공개 main에 추가된 publication-preflight 하위 사이트89개 파일도 보존합니다. HTML 직접 수정·다른 CLI·직접 API·수동 원고 대체는 하지 않았습니다. 전체 사이트 독자 평가·새 카메라 실행·사내 HAL 검증과 사람 승인은 이 결과의 범위가 아닙니다.

`resolution.json`·`native-verification.json`·`two-exports-merged.json`에서 범위와 수치를 확인하세요. `native-and-operation-evidence.tar.xz`는 원래 issue249 archive 위의 변경 입력·원본 요청/응답/stdout/영수증·실패·현재 생성기 코드 스냅샷입니다. `archive-index.json`과 `package.json`이 실제 바이트를 고정합니다. 원래 archive는 교체하지 않았습니다. 이 짧은 원인 비교와 실행 수치는 표·원본 기록으로 대조할 수 있으므로 별도 장식 그림을 추가하지 않았습니다.
'''
(dest/'README.md').write_text(readme,encoding='utf-8',newline='\n')
attrs=public/'.gitattributes';text=attrs.read_text(encoding='utf-8');rule='publication/issue243-followup/** -text -whitespace'
assert rule not in text;attrs.write_text(text.rstrip()+'\n'+rule+'\n',encoding='utf-8')
readme=public/'README.md';text=readme.read_text(encoding='utf-8');text+='\n- [Issue243 followup: parameter association and access-default evidence](publication/issue243-followup/README.md)\n';readme.write_text(text,encoding='utf-8')
print(json.dumps(dict(status='candidate-synchronized-and-packaged',files=len(files),archive_bytes=archive.stat().st_size,archive_sha256=package['archive_sha256'],build_id=quality['build_id'],concurrent_subsite_files_preserved=89),ensure_ascii=False),flush=True)
