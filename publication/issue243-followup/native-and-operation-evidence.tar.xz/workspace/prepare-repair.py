from pathlib import Path
import hashlib,json,shutil
import yaml
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.generated_design import _prepare_generation
from sdd.impact import ImpactReport
from sdd.publication_plan import prepare

root=Path.cwd();w=root/'build/remaining-evidence';out=w/'publication';inputs=w/'publication-inputs'
products=inputs/'paths/products_file/products.yaml';raw=yaml.safe_load(products.read_bytes())
original_product=next(x['original_path'] for x in json.loads((inputs/'index.json').read_bytes()) if x['snapshot']=='paths/products_file/products.yaml')
for doc in raw['evidence']:
    target=products.parent/doc['file']
    if target.exists():continue
    choices=[Path(original_product).parent/doc['file'],root/'build/issue243/public-current/config'/doc['file']]
    candidate=next((p for p in choices if p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==doc['sha256']),None)
    if candidate is None:raise ValueError('Missing exact public product evidence: '+doc['file'])
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(candidate,target)

sections=out/'sections.yaml';original=sections.read_bytes()
backup=w/'sections-before-repair.yaml'
if not backup.exists():backup.write_bytes(original)
data=yaml.safe_load(original);section=next(x for x in data['sections'] if x['id']=='vendor-integration');topic=next(x for x in section['design_topics'] if x['id']=='request');part=next(x for x in topic['parts'] if x['id']=='device')
part['question']='queueRequestDevice 구현자는 요청 파라미터를 어느 버퍼의 프레임에 적용해야 합니까? 요청에 버퍼 집합과 파라미터 집합이 들어 있다는 점과, 스트림에 연결되는 대상이 버퍼라는 점을 문법적으로 명확히 구분해 설명하세요. 소스가 파라미터와 스트림의 연결을 금지한다고 단정하지 말고, 파라미터 적용 의무를 보존하세요.'
sections.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
cfg=load(out/'sdd.yaml');model=KnowledgeModel.load(cfg.facts_path)
report=ImpactReport(base=model.meta['source_commit'],head=model.meta['source_commit'],sections={'vendor-integration':['User-requested evidence closure: native-review-01 found a Korean modifier-scope ambiguity in request/device; no source change is claimed.']})
report.save(cfg.build_dir/'impact.json')
selected=next(s for s in cfg.sections() if s['id']=='vendor-integration')
plan,answers,origins=_prepare_generation(cfg,model,selected,(cfg.sdd_dir/'vendor-integration.md').read_text(encoding='utf-8'))
preview=prepare(cfg,model,['vendor-integration'],report)
(w/'repair-plan.json').write_text(json.dumps(dict(source_commit=model.meta['source_commit'],changed_question='vendor-integration/request/device',reason='native-review-01 Korean modifier ambiguity',reused_topics=list(answers),all_topics=[x['id'] for x in selected['design_topics']],human_review='pending'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(reused_topics=list(answers),all_topics=[x['id'] for x in selected['design_topics']],publication_plan=str(cfg.build_dir/'publication-plan.json')),ensure_ascii=False),flush=True)
