from pathlib import Path
import json,time
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.llm import Agent
from sdd.consistency import audit
w=Path.cwd()/'build/remaining-evidence';cfg=load(w/'publication/independent-review.yaml');m=KnowledgeModel.load(cfg.facts_path)
dump=cfg.build_dir/'prompts';a=Agent(cfg.agent,dump_dir=dump);a._counter=max((int(p.name.split('_',1)[0]) for p in dump.glob('*_*.md') if p.name.split('_',1)[0].isdigit()),default=0)
started=time.monotonic()
try:
    r=audit(cfg,m,a)
    result=dict(status=r['status'],fresh_batches=r['fresh_batches'],reused_batches=r['reused_batches'],unresolved=[{k:x[k] for k in ['contract','claim_id','status','reason']} for x in r['unresolved']],wall_seconds=time.monotonic()-started,human_review='pending')
    (w/'audit-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False),flush=True)
except BaseException as exc:
    (w/'audit-failure.json').write_text(json.dumps(dict(type=type(exc).__name__,error=str(exc),wall_seconds=time.monotonic()-started,human_review='pending'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8');raise
