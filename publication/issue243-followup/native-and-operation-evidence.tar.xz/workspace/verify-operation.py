"""Verify completed native calls and immutable inherited material, without calls."""
from pathlib import Path
import json,hashlib,collections
from sdd.config import load
from sdd.cli_provenance import verify_cli_receipt
from sdd.document_metadata import split_frontmatter
w=Path.cwd()/'build/remaining-evidence';cfg=load(w/'publication/sdd.yaml');root=Path.cwd();public=root/'build/issue243/public-sdd'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
restored=json.loads((w/'restoration.json').read_bytes());index=json.loads((public/'publication/issue249/archive-index.json').read_bytes())
assert all(sha(w/'inherited-original'/n)==h for n,h in index.items())
changed=[n for n,h in restored['baseline_manuscripts'].items() if sha(cfg.sdd_dir/n)!=h];assert changed==['vendor-integration.md'],changed
old,_=split_frontmatter((w/'scoped-repair-02/before.md').read_text(encoding='utf-8'));new,_=split_frontmatter((cfg.sdd_dir/'vendor-integration.md').read_text(encoding='utf-8'))
old_answers=old['generated_design']['answers'];new_answers=new['generated_design']['answers'];delta=[(tid,i) for tid,rows in old_answers.items() for i,st in enumerate(rows) if new_answers[tid][i]!=st];assert delta==[('request',0)]
assert old['semantic_review']==new['semantic_review']=='human-review-required'
assert old['generated_design']['topic_inputs']==new['generated_design']['topic_inputs']
review=json.loads((w/'native-review-02/review.json').read_bytes());assert not review['new_findings'];assert all(x['current_status']=='supported' and x['action']=='retain' for x in review['cases']);assert all(x['status']=='supported' for x in review['checks'])
binding=json.loads((w/'final-plan.json').read_bytes());assert sha(cfg.sdd_dir/'vendor-integration.md')==binding['manuscript_sha256'];assert sha(w/'publication/english.json')==binding['catalog_sha256']
groups=[('supplemental-initial',w/'native-review-01/prompts',w/'independent-review.yaml'),('supplemental-final',w/'native-review-02/prompts',w/'independent-review.yaml'),('config-review',w/'config-review/prompts',w/'independent-review.yaml'),('generation-and-contract',w/'publication/build/prompts',w/'publication/independent-review.yaml'),('translation',w/'translation/build/translation-prompts',w/'publication-inputs/paths/translation_profile/independent-review.yaml')]
proofs=[];counts=collections.Counter()
for group,directory,profile in groups:
    agent=load(profile).agent
    for p in sorted((directory/'calls').rglob('*.receipt.json')):
        if group=='generation-and-contract':
            relative=p.relative_to(w/'publication').as_posix()
            if relative in restored['original_native_files']:
                assert sha(p)==restored['original_native_files'][relative];continue
        prefix=str(p).removesuffix('.receipt.json');request=json.loads(Path(prefix+'.request.json').read_bytes());response=Path(prefix+'.response.txt').read_text(encoding='utf-8');receipt=json.loads(p.read_bytes())
        check=verify_cli_receipt(request,response,receipt,directory/'calls',agent)
        kind='contract-audit' if receipt['tag'].startswith('consistency_') else group
        counts[kind]+=1;proofs.append(dict(stage=kind,receipt=p.relative_to(w).as_posix(),sha256=sha(p),tag=receipt['tag'],proof=check))
preserved=sum(sha(w/'publication'/n)==h for n,h in restored['original_native_files'].items());assert preserved==len(restored['original_native_files'])
result=dict(status='verified',original_archived_files_preserved=len(index),working_original_native_files_preserved=preserved,unchanged_manuscripts=len(restored['baseline_manuscripts'])-1,retained_answers=sum(len(x) for x in old_answers.values())-1,changed_answers=delta,new_completed_native_receipts=dict(counts),proofs=proofs,historical_topic_identities_preserved=True,human_review='pending',limitations='Completed receipts include rejected/unused drafts and an interrupted broad attempt; they are not all successful repairs. Original failed/incomplete attempts remain separately recorded.')
(w/'native-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k!='proofs'},ensure_ascii=False))
