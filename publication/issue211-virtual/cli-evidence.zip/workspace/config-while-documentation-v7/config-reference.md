## `while_conditions` (LLM 시각화 계획 플래그)

**결론:** 기본값은 `false`다. `true`일 때만 `while` 조건을 `if`/`if constexpr`과 함께 추출한다.

1. **기본값:** 키가 없으면 `false`로 처리한다.
2. **값 검사:** YAML boolean만 허용한다. `1`, `0`, `"true"`, `null`은 `Visual while_conditions must be boolean` 오류가 된다.
3. **`true` 동작:** 조건 추출 패턴에 `while (`이 추가된다. 괄호 균형 추적과 공백 정규화 방식은 그대로다.
4. **적용 범위:** 조건 카탈로그(`c0`, `c1`...), `condition_ref` 스키마, 라벨 가드 검사에 같은 값이 쓰인다.

**주의:**
- 괄호 균형과 공백 정규화는 어휘(lexical) 처리다. C++ 의미를 평가하지 않는다.
- `do ... while (...);`의 `while`도 같은 패턴으로 잡힌다.
- 조건 ID는 정렬된 텍스트 순서로 붙으므로 `true`로 바꾸면 기존 `cN` 번호가 달라질 수 있다.
- 이 값은 입력 지문에 포함되므로 바꾸면 재생성이 필요하다.

**다음 행동:** 아래 항목을 계획에 추가한 뒤 `generate`를 다시 실행한다.

```yaml
- id: example-flow
  topic: example-topic
  kind: flow
  title: Example flow
  question: Example question?
  generation: llm
  while_conditions: true
```