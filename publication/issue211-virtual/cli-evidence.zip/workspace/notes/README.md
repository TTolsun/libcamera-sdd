# Official cam validation: virtual principle

This publication adds a virtual-principle section and a source-bound diagram to the Korean and English official-cam-validation pages.

The diagram connects software Virtual2 lines-pattern generation, DMA-BUF buffers with queued requests, CPU NV12 writes, and buffer and request completion to the cam callback.

The existing allocator conclusion, callback follow-up, and four reproduction steps remain unchanged. Baseline and freshly fetched official upstream both equal 293d751a814e0d4c34e85ad457ccd9d5eefd1a61.

This update is source inspection and documentation only. It is not a new camera or kernel trial and adds no new debugger observation. The records publication/issue211 and publication/issue211-reader are unchanged.

Fresh native writing, translation, and diagram calls used Claude CLI with claude-haiku-5-5, --effort high, and --setting-sources project,local. Independent grounding used Codex CLI with gpt-6.1-terra at high reasoning effort.

The evidence package is publication/issue211-virtual/. It contains config, manuscripts, profiles, reviews, native-call-verification.json, evidence-index.json, and the indexed cli-evidence.zip.

Korean page: https://ttolsun.github.io/libcamera-sdd/official-cam-validation.html

English page: https://ttolsun.github.io/libcamera-sdd/en/official-cam-validation.html

Final review and post-merge Pages and live hash proof will be recorded in the publication PR. Automatic checks do not confer human approval. Hardware, sensor, ISP, physical DMA, product-app, and internal-HAL validation is not established.