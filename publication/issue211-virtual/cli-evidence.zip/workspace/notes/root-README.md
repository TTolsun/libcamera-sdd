# libcamera developer SDD

This repository publishes generated developer design documents for libcamera. This addition covers the virtual principle on the official-cam-validation pages.

Korean page: https://ttolsun.github.io/libcamera-sdd/official-cam-validation.html

English page: https://ttolsun.github.io/libcamera-sdd/en/official-cam-validation.html

The evidence package is at publication/issue211-virtual/. The previous root README, run, and receipts are preserved in the previous-release directory.

This publication makes no scheduling, app, global-default, or default-profile changes. It uses no alternate-model, API, or manual prose fallback.

Final review and post-merge Pages and live hash proof will be recorded in the publication PR. Automatic checks do not confer human approval.