## `while_conditions` (선택 항목)

`while_conditions`는 `generation: llm`인 시각화 계획에 둘 수 있는 불리언 옵션입니다. 기본값은 `false`이며, `true`로 지정한 계획만 `while` 조건을 추출합니다.

```yaml
- id: example-flow
  topic: example-topic
  kind: flow
  title: 예시 흐름
  question: 예시 질문
  generation: llm
  while_conditions: true
```

### 동작

1. 값은 YAML 불리언 `true` 또는 `false`만 허용합니다. 문자열, 숫자, `null`은 설정 오류입니다.
2. 생략하거나 `false`이면 기존과 같이 `if` 조건만 추출합니다. 이 키를 추가하지 않은 기존 계획은 조건 카탈로그가 바뀌지 않습니다.
3. `true`이면 `if` 조건에 더해 `while (` 뒤의 조건도 추출합니다. 괄호 쌍이 맞는 텍스트를 가져오며, 연속 공백은 한 칸으로 정규화합니다. 이 추출은 어휘 기반입니다. C++ 구문을 해석하거나 조건식을 평가하지 않으며, 주석과 문자열 안의 텍스트도 검색 대상이 됩니다.
4. 조건 참조는 추출된 각 조건 ID에 대해 `cN:true` 또는 `cN:false`를 사용하고, 무조건 간선은 `always`를 사용합니다.
5. 간선이 선택한 조건은 그 간선의 `quote_ids`가 가리키는 구절들을 이어 붙인 본문 안에 있어야 합니다. 개별 구절 하나 안에 있을 필요는 없습니다. 다른 간선이 인용한 조건은 쓸 수 없습니다.
6. `always`가 아닌 참조는 간선의 한국어·영어 라벨 끝에 `· 조건 [true]` 형태로 조건을 덧붙입니다. 라벨에 같은 조건이 이미 있어도 다시 붙습니다. `always`는 아무것도 덧붙이지 않습니다.

### 주의

`while_conditions` 값을 바꾸면 계획 입력이 달라집니다. 기존 생성 결과와 맞지 않으므로 `generate`로 다시 생성해야 합니다.