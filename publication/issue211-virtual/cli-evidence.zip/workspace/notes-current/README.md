# Official Cam Validation: Virtual Principle

This publication adds a virtual-principle section and a source-bound diagram to the Korean and English official-cam-validation pages. The section covers software Virtual2 lines-pattern generation, DMA-BUF buffers, queued requests, CPU NV12 writes, and completion connected to the cam callback.

The cam processing name is now `CameraSession::processRequest`, distinct from `VirtualCameraData::processRequest`. Existing sections are retained, but their wording is not claimed unchanged. The allocator conclusion, callback follow-up, and four reproduction steps remain; the allocator outcome and original runtime evidence are unchanged.

This update is source inspection and documentation only, with no new camera, kernel, or debugger trial. Hardware, sensor, ISP, physical DMA, product-app, and internal-HAL validation is not established.

Baseline and freshly fetched official upstream both equal `293d751a814e0d4c34e85ad457ccd9d5eefd1a61`.

Fresh native writing, translation, and diagram calls used Claude CLI `claude-haiku-5-5` with `--effort high --setting-sources project,local`. Independent grounding used Codex CLI `gpt-6.1-terra` with `-c model_reasoning_effort="high"`. No alternate-model, API, or manual prose fallback is used.

The evidence package is `publication/issue211-virtual/`, including indexed `cli-evidence.zip`. The original `publication/issue211` and `publication/issue211-reader` records are unchanged.

Korean: https://ttolsun.github.io/libcamera-sdd/official-cam-validation.html
English: https://ttolsun.github.io/libcamera-sdd/en/official-cam-validation.html

Automatic checks do not confer human approval. Final review and post-merge Pages and live hash proof will be recorded in the publication PR, not claimed here.