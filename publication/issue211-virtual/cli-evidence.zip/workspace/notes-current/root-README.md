# camera-hal-sdd-generator

This repository generates reviewable software design documents (SDD) from Camera HAL source. Its public libcamera developer SDD is published on GitHub Pages.

## Latest addition: official cam validation virtual principle

The latest update adds a virtual-principle section and a source-bound diagram to the Korean and English official-cam-validation pages.

- Korean: https://ttolsun.github.io/libcamera-sdd/official-cam-validation.html
- English: https://ttolsun.github.io/libcamera-sdd/en/official-cam-validation.html

The evidence package is `publication/issue211-virtual/`. The previous root README, run, and receipts are preserved in the previous-release directory.

Baseline and official upstream both equal `293d751a814e0d4c34e85ad457ccd9d5eefd1a61`. This update is source inspection and documentation only. Hardware, sensor, ISP, physical DMA, product-app, and internal-HAL validation is not established.

Automatic checks do not confer human approval. Final review and post-merge Pages proof will be recorded in the publication PR.