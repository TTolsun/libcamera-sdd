# libcamera-sdd

This repository publishes software design documents (SDD) generated from public libcamera source history. Each page ties design explanations to source locations, and publication records name the upstream baseline commit.

The official-cam-validation pages are available in Korean and English:

- https://ttolsun.github.io/libcamera-sdd/official-cam-validation.html
- https://ttolsun.github.io/libcamera-sdd/en/official-cam-validation.html

Publication records and evidence packages live under `publication/`. Earlier root README, run, and receipt files are kept in previous-release directories.

Automatic checks do not confer human approval. Pages do not establish hardware, sensor, ISP, or product validation.

The generator that produces these documents is a separate repository, TTolsun/camera-hal-sdd-generator. This repository holds the published libcamera output and its evidence.