# Virtual Principle Publication Notes

This update adds a virtual-principle section and a source-bound diagram to the official-cam-validation pages in Korean and English. It covers Virtual2 lines-pattern generation, DMA-BUF buffers with queued requests, CPU NV12 writes, and buffer and request completion connected to the cam callback.

The cam processing name is now qualified as `CameraSession::processRequest` to distinguish it from `VirtualCameraData::processRequest`. Existing sections are retained with changed wording. The allocator conclusion, callback follow-up, and four reproduction steps remain. The allocator outcome and original runtime evidence are unchanged.

Baseline and fresh upstream both equal `293d751a814e0d4c34e85ad457ccd9d5eefd1a61`. This is source inspection and documentation only, not a new camera, kernel, or debugger trial. Hardware, sensor, ISP, physical DMA, product-app, and internal-HAL validation is not established.

Evidence is in `publication/issue211-virtual/`. The original `publication/issue211` and `publication/issue211-reader` records are unchanged. Previous root README, run, and receipts are kept in its previous-release directory.

Fresh native calls used Claude CLI `claude-haiku-5-5` and Codex CLI `gpt-6.1-terra` at high reasoning effort.

Final review and post-merge Pages and live hash proof will be recorded in the publication PR. Automatic checks do not confer human approval. No scheduling, app, global, or default-profile changes were made. No alternate-model, API, or manual prose fallback was used.

Korean: https://ttolsun.github.io/libcamera-sdd/official-cam-validation.html
English: https://ttolsun.github.io/libcamera-sdd/en/official-cam-validation.html