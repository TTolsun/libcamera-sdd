# Publication Notes

This update adds a virtual-principle section and source-bound diagram to the Korean and English official-cam-validation pages, covering Virtual2 buffer generation, DMA-BUF requests, CPU NV12 writes, and completion-to-callback connection.

The allocator conclusion and callback follow-up are retained. Reproduction conditions are split into investigation, prerequisite-checking, and observed-execution tasks, with no fixed step count. CameraSession::processRequest is distinct from VirtualCameraData::processRequest. Section wording is not claimed unchanged; the allocator outcome and original runtime evidence are unchanged.

Baseline and fresh upstream both equal 293d751a814e0d4c34e85ad457ccd9d5eefd1a61. Work is source inspection and documentation only.

Evidence is in publication/issue211-virtual/ (config, manuscripts, profiles, reviews, native-call-verification.json, evidence-index.json, cli-evidence.zip). The previous root README, run, and receipts are preserved in previous-release. Original publication/issue211 and publication/issue211-reader records are unchanged.

Fresh native calls used Claude CLI claude-haiku-5-5 (--effort high, --setting-sources project,local); independent grounding used Codex CLI gpt-6.1-terra (-c model_reasoning_effort="high").

Pages: Korean https://ttolsun.github.io/libcamera-sdd/official-cam-validation.html; English https://ttolsun.github.io/libcamera-sdd/en/official-cam-validation.html

Automatic checks do not confer human approval. Hardware, sensor, ISP, physical DMA, product-app, and internal HAL validation is not established. No scheduling, app, global, default-profile, alternate-model, API, or manual prose fallback changes are included. Final review and post-merge Pages and live hash proof will be recorded in the publication PR.