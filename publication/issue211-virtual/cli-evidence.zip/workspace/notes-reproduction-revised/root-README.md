# libcamera-sdd

This repository publishes public libcamera source-history and software design document (SDD) output. It tracks official upstream libcamera source and the SDD pages generated from it, served through GitHub Pages.

The SDD generator is a separate project, TTolsun/camera-hal-sdd-generator. This repository does not contain the generator, and internal Camera HAL sources and derived artifacts are not published here.

Current publication: Korean https://ttolsun.github.io/libcamera-sdd/official-cam-validation.html and English https://ttolsun.github.io/libcamera-sdd/en/official-cam-validation.html.

The latest evidence package is publication/issue211-virtual/. The previous root README, run, and receipts are kept in its previous-release directory.

Automatic checks do not confer human approval. Hardware, sensor, ISP, physical DMA, product-app, and internal HAL validation is not established.