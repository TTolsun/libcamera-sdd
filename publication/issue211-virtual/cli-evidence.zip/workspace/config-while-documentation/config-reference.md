## `while_conditions`

생성 시각화 계획의 선택 옵션 `while_conditions`는 기본값이 `false`다. 생략하면 `if` 조건만 사용하고, `true`로 설정하면 `while (...)` 조건도 `c0`, `c1` 같은 조건 ID 후보에 포함된다.

```yaml
- id: <plan-id>
  generation: llm
  while_conditions: true
```

모델은 조건 ID와 true/false 분기만 고르고, 생성기가 원본 소스의 정확한 식으로 확장한다. 이 옵션은 C++ 식을 평가하거나 의미를 승인하지 않는다.

키를 추가하거나 값을 바꾸면 입력 지문(`input_fingerprint`)이 달라지므로 `generate`를 다시 실행해야 게시할 수 있다. 기존 계획을 그대로 두면 `if` 전용 조건 목록이 유지되어 이전 기록도 그대로 검증된다.