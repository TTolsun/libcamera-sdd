from pathlib import Path
import json
from sdd.config import load
from sdd.llm import Agent
from sdd.runtime_evidence import sha256
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';out=w/'config-connected-documentation';out.mkdir(exist_ok=False);source=r/'src/sdd/generated_visuals.py';code=source.read_text(encoding='utf-8')
schema=dict(type='object',additionalProperties=False,required=['markdown'],properties=dict(markdown=dict(type='string',maxLength=1200)))
writer=Agent(load(w/'generation.yaml').agent,out/'writer/prompts')
result=json.loads(writer.chat('Write a short Korean configuration reference from the supplied code. No tools. JSON only.','Document ONLY the new optional require_connected boolean field on generation: llm visual plans. Explain default false/backward compatibility, true checks that every node belongs to one connected component ignoring edge direction, disconnected node ID errors, and that this does not prove correct control flow/branch coverage/meaning. Strict boolean types. Keep under 450 Korean characters plus a minimal YAML example. No diagram is needed for one short flag; the libcamera application has its own source-grounded diagrams. Do not claim human approval or automatically regenerated output.\nCODE\n'+code,tag='connected-config-reference',response_schema=schema))
(out/'config-reference.md').write_text(result['markdown'],encoding='utf-8')
reviewer=Agent(load(w/'new-document-review.yaml').agent,w/'reviews/config-connected/prompts')
rs=dict(type='object',additionalProperties=False,required=['verdict','findings','scope'],properties=dict(verdict=dict(enum=['pass','needs-revision']),findings=dict(type='array',items=dict(type='string')),scope=dict(type='string')))
old=(w/'config-while-documentation-v7/config-reference.md').read_text(encoding='utf-8')
review=json.loads(reviewer.chat('Independent automatic code grounding, never human approval. No tools. JSON only.','Check the new require_connected fragment and retained while_conditions fragment against the actual current implementation. Check precisely the claimed defaults/types, direction-agnostic reachability, failure behavior and limits; do not demand unrelated documentation. Both are short configuration flags, so an extra diagram is not needed.\nNEW\n'+result['markdown']+'\nRETAINED\n'+old+'\nCODE\n'+code,tag='connected-config-grounding',response_schema=rs))
record=dict(review=review,document_sha256=sha256(out/'config-reference.md'),retained_fragment_sha256=sha256(w/'config-while-documentation-v7/config-reference.md'),source_sha256=sha256(source),receipt=str(reviewer.last_receipt));(w/'reviews/config-connected/review.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
if review['verdict']!='pass' or review['findings']:raise ValueError(review)
with (r/'docs/reference/config.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\n'+result['markdown']+'\n')
print('Native configuration writing and independent grounding passed')
