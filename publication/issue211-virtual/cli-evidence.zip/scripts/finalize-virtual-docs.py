from pathlib import Path
from sdd.runtime_evidence import run_recorded,require_success
import json,subprocess,sys
root=Path(__file__).resolve().parent.parent;work=root/'build/issue211-virtual';site=root/'build/libcamera-sdd-issue211/docs';helper=root/'examples/libcamera/validation/issue211-reader';prefix=[sys.executable,'-X','utf8']
require_success(work/'executions/generate-core-simplification')
early='korean-core';final='final02';window=work/'windows'/early
stages=[('render-'+early,[str(helper/'render_window.py'),'--work',str(work),'--out',str(window)]),('review-'+early,[str(helper/'review.py'),'--work',str(work),'--review-config',str(work/'new-document-review.yaml'),'--korean',str(window/'ko.txt'),'--inventory',str(window/'inventory.json'),'--notes',str(work/json.loads((work/'notes-selection.json').read_text())['directory']/'documents.json'),'--out',str(work/'reviews'/early)])]
for name,argv in stages:
 out=work/'executions'/name;run_recorded(out,prefix+argv,timeout=1800,cwd=root);require_success(out)
r=json.loads((work/'reviews'/early/'review.json').read_text())['review']
if r['verdict']!='pass' or r['findings']:raise ValueError(r)
for stage in ['translate','export','render','review']:
 subprocess.run(prefix+[str(root/'examples/libcamera/validation/issue211-virtual/execute.py'),stage,'--work',str(work),'--site',str(site),'--tag',final],check=True,cwd=root)
r=json.loads((work/'reviews'/final/'review.json').read_text())['review']
if r['verdict']!='pass' or r['findings']:raise ValueError(r)
print('Actual final Korean/English/diagram Terra review passed',final)
