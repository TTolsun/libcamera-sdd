from pathlib import Path
import shutil,yaml
w=Path('build/issue211-virtual');shutil.copytree(w/'run/manuscripts',w/'before-concise-labels')
v=yaml.safe_load(Path('examples/libcamera/validation/issue211-virtual/visual.yaml').read_text(encoding='utf-8'));p=w/'config/visuals.yaml';d=yaml.safe_load(p.read_text(encoding='utf-8'));d['sections']['official-cam-validation']=[v if x['id']==v['id'] else x for x in d['sections']['official-cam-validation']];p.write_text(yaml.safe_dump(d,allow_unicode=True,sort_keys=False,width=120),encoding='utf-8')

items=yaml.safe_load(Path('examples/libcamera/validation/issue211-virtual/retained-visual-overrides.yaml').read_text(encoding='utf-8'));overrides={x['id']:x for x in items};d['sections']['official-cam-validation']=[overrides.get(x['id'],x) for x in d['sections']['official-cam-validation']];p.write_text(yaml.safe_dump(d,allow_unicode=True,sort_keys=False,width=120),encoding='utf-8')
