from pathlib import Path
import sys,subprocess,json
from sdd.runtime_evidence import run_recorded,require_success
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';site=r/'build/libcamera-sdd-issue211/docs';prefix=[sys.executable,'-X','utf8'];tag='resume02'
require_success(w/'executions/generate-resume-corrections')
out=w/'executions/translate-'+tag if False else w/'executions'/('translate-'+tag)
run_recorded(out,prefix+[str(r/'examples/libcamera/validation/issue211-reader/translate.py'),'--work',str(w),'--out',str(w/'translations'/tag),'--feedback',str(w/'translation-resume-feedback.json')],timeout=1800,cwd=r);require_success(out)
for stage in ['export','render','review']:
 subprocess.run(prefix+[str(r/'examples/libcamera/validation/issue211-virtual/execute.py'),stage,'--work',str(w),'--site',str(site),'--tag',tag],check=True,cwd=r)
d=json.loads((w/'reviews'/tag/'review.json').read_text())['review']
if d['verdict']!='pass' or d['findings']:raise ValueError(d)
print('Final native Terra bilingual review passed',tag)
