from pathlib import Path
import sys,subprocess,json,shutil,re,html
from sdd.runtime_evidence import run_recorded,require_success
from sdd.config import load
from sdd.localization_cli import prepare_catalog
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';site=r/'build/libcamera-sdd-issue211/docs';tag='finite-order-final';prefix=[sys.executable,'-X','utf8']
require_success(w/'executions/generate-finite-submission-order')
candidate=w/'finite-order-prepared.json'
if candidate.exists():raise ValueError('Preserve earlier catalog preparation')
shutil.copyfile(w/'run/english.json',candidate);prepare_catalog(load(w/'publication.yaml'),candidate,translate=False);catalog=json.loads(candidate.read_text(encoding='utf-8'))
def norm(s):return ''.join(re.sub(r'<br\s*/?>',' ',html.unescape(s)).split())
processing=[k for k in catalog['strings'] if '프레임정보' in norm(k) and '싱크' in norm(k) and any(t in norm(k) for t in ['개수','증가','늘립']) and len(k)>100]
if len(processing)!=1:raise ValueError(('Processing translation scope',len(processing)))
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'));label=next(n['label'] for n in m['generated_visuals']['records']['virtual-frame-path']['graph']['nodes'] if n['id']=='n9')
notification=[label] if label in catalog['strings'] else [k for k in catalog['strings'] if norm(label) in norm(k)]
if len(notification)!=1:raise ValueError(('Notification translation scope',notification))
feedback=dict(reset_sources=processing+notification,instructions='Ground the translation in the current Korean source and pinned implementation. Only optional sink handling depends on a sink existing; output and counting happen regardless of sink presence when the entry limit does not return. Distinguish processed-frame limit from submission-attempt count using the same configured limit; a submission attempt may return without queueing when the latter limit is reached. Request notifications preserve submission/queue order, never completion-time order. Preserve all placeholders and other correct clauses.',required_phrases=[dict(source_all=processing,english_any=['regardless','whether or not','with or without','independent of','even without']),dict(source_all=notification,english_any=['submission order','queue order','order of submission','order they were submitted','as submitted'],english_none=['completion order'])])
fp=w/'translation-finite-order-feedback.json';fp.write_text(json.dumps(feedback,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
out=w/'executions'/('translate-'+tag);run_recorded(out,prefix+[str(r/'examples/libcamera/validation/issue211-reader/translate.py'),'--work',str(w),'--out',str(w/'translations'/tag),'--feedback',str(fp)],timeout=1800,cwd=r);require_success(out)
for stage in ['export','render','review']:
 subprocess.run(prefix+[str(r/'examples/libcamera/validation/issue211-virtual/execute.py'),stage,'--work',str(w),'--site',str(site),'--tag',tag],check=True,cwd=r)
d=json.loads((w/'reviews'/tag/'review.json').read_text())['review']
if d['verdict']!='pass' or d['findings']:raise ValueError(d)
print('Final grounded bilingual review passed',tag)
