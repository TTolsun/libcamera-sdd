"""Package the accepted virtual-principle addition; preserve earlier publications."""
from pathlib import Path
import gzip,json,shutil,sys,zipfile,yaml
from sdd.runtime_evidence import sha256
from sdd.site_build import verify_site
root=Path(__file__).resolve().parent.parent;work=root/'build/issue211-virtual';previous=root/'build/issue211-reader';repo=root/'build/libcamera-sdd-issue211';site=repo/'docs'
notes=work/json.loads((work/'notes-selection.json').read_text(encoding='utf-8'))['directory']
tag=sys.argv[1];valid=verify_site(site);manifest=json.loads((site/'site-manifest.json').read_text(encoding='utf-8'))
review=json.loads((work/'reviews'/tag/'review.json').read_text(encoding='utf-8'))
if review['review']['verdict']!='pass' or review['review']['findings']:raise ValueError('Final bilingual review has unresolved findings')
inventory=json.loads((work/'windows'/tag/'inventory.json').read_text(encoding='utf-8'))
for lang,path in [('ko','official-cam-validation.html'),('en','en/official-cam-validation.html')]:
 if sha256(site/path)!=inventory[lang]['html_sha256']:raise ValueError('Reviewed HTML changed')
merge=json.loads((work/'generator-merge.json').read_text(encoding='utf-8'))
if not merge['merged']:raise ValueError('Generator PR must be merged before publication')
native=json.loads((work/'native-call-verification.json').read_text(encoding='utf-8'))
if {r['runner'] for r in native['new_completed_calls']}!={'claude','codex'}:raise ValueError('Missing selected native CLI receipts')
connected_review=json.loads((work/'reviews/config-connected-v2/review.json').read_text(encoding='utf-8'))
if connected_review['review']['verdict']!='pass' or connected_review['review']['findings'] or connected_review['source_sha256']!=sha256(root/'src/sdd/generated_visuals.py'):raise ValueError('Current configuration grounding is incomplete')
package=repo/'publication/issue211-virtual';package.mkdir(exist_ok=False)
(package/'previous-release').mkdir()
for name in ['README.md','run.json','generation-receipts.json']:shutil.copyfile(repo/name,package/'previous-release'/name)
for src,dst in [('config','config'),('run/manuscripts','manuscripts'),('historical-style','historical-style'),('reviews','reviews'),('windows/'+tag,'rendered-review-window')]:shutil.copytree(work/src,package/dst)
shutil.copytree(root/'style',package/'current-style')
(package/'profiles').mkdir()
for name in ['generation.yaml','publication.yaml','reader-verification.yaml','historical-contract-review.yaml','new-document-review.yaml']:shutil.copyfile(work/name,package/'profiles'/name)
roles=dict(schema=1,new_topic='Fresh selected native Claude writing and diagrams; independent selected native Terra review',retained_topics='Existing runtime conclusion unchanged; callback and reproduction answers source-revalidated and their diagrams freshly revised by the selected native Claude; historical outputs and identities retained in publication/issue211-reader',unchanged_pages='Historical style and original visual identity authentication only; no new whole-site policy review',profiles='Execution-specific paths preserved as evidence; not relocatable or global defaults',human_review='pending')
(package/'profiles/roles.json').write_text(json.dumps(roles,indent=2)+'\n',encoding='utf-8')
for name in ['native-call-verification.json','retained-receipts.json','upstream-sync.json','upstream-final-sync.json','upstream-resume-sync.json','upstream-resume-assessment.json','upstream-source-sync.json','aborted-executions.json','generator-merge.json','notes-selection.json','profile-input-boundary.json','resume-constraint-abort.json']:shutil.copyfile(work/name,package/name)
shutil.copyfile(work/'run/english.json',package/'english.json');shutil.copyfile(work/'site-intro.md',package/'site-intro.md')
(package/'facts293.json.gz').write_bytes(gzip.compress((work/'run/facts/facts.json').read_bytes(),mtime=0))
shutil.copyfile(notes/'README.md',package/'README.md');shutil.copyfile(notes/'root-README.md',repo/'README.md')
(package/'reviews/acceptance.json').write_text(json.dumps(dict(accepted=tag+'/review.json',rule='Only final bilingual review bound to identical published HTML hashes is acceptance; earlier drafts and interrupted runs remain unaccepted',human_review='pending'),indent=2)+'\n',encoding='utf-8')
shutil.copyfile(work/'topic-visual-review.json',package/'topic-visual-review.json')
shutil.copyfile(work/'ui-verification.json',package/'ui-verification.json')
config_review=json.loads((work/'reviews/config-while-v7/review.json').read_text(encoding='utf-8'))
if config_review['review']['verdict']!='pass' or config_review['review']['findings']:raise ValueError('Configuration reference review is unresolved')
sources=[]
for parent in [work/'build',*work.glob('notes*'),work/'executions',work/'translations',work/'windows',*work.glob('before-*'),*work.glob('config-while-documentation*'),*work.glob('config-connected-documentation*')]:
 for p in parent.rglob('*') if parent.is_dir() else []:
  if not p.is_file() or any(part.startswith('call-') for part in p.parts[:-1]):continue
  rel=p.relative_to(work)
  old=previous/rel
  if old.is_file() and sha256(old)==sha256(p):continue
  sources.append((p,'workspace/'+rel.as_posix()))
for name in ['prepare.py','execute.py','notes.py','verify_calls.py','topic.yaml','visual.yaml','retained-visual-overrides.yaml']:
 p=root/'examples/libcamera/validation/issue211-virtual'/name;sources.append((p,'generator/'+p.relative_to(root).as_posix()))
for name in ['translate.py','review.py','render_window.py','section.yaml']:
 p=root/'examples/libcamera/validation/issue211-reader'/name;sources.append((p,'generator/'+p.relative_to(root).as_posix()))
for name in ['package-issue211-virtual.py','verify-package-issue211-virtual.py','verify-live-issue211-virtual.py','write-while-config-note.py','write-while-config-note-v2.py','write-while-config-note-v3.py','write-while-config-note-v4.py','write-while-config-note-v5.py','write-while-config-note-v6.py','write-while-config-note-v7.py','finalize-virtual-docs.py','publish-review-virtual-docs.py','apply-concise-virtual-plan.py','resume-virtual-publication.py','resume03-virtual-publication.py','make-virtual-topic-audit.py','connected-final-publication.py','write-connected-config-note.py','write-connected-config-note-v2.py','handoff-final-publication.py','mapped-conversion-publication.py','actor-sync-publication.py','finite-order-publication.py','resubmission-final-publication.py']:
 p=root/'build'/name;sources.append((p,'scripts/'+name))
p=root/'build/counter-signal-publication.py';sources.append((p,'scripts/'+p.name))
index={}
with zipfile.ZipFile(package/'cli-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p,name in sorted(sources,key=lambda row:row[1]):
  if name in index:raise ValueError('Duplicate evidence path')
  z.write(p,name);index[name]=sha256(p)
(package/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
writer=yaml.safe_load((work/'generation.yaml').read_text(encoding='utf-8'))['agent'];reviewer=yaml.safe_load((work/'new-document-review.yaml').read_text(encoding='utf-8'))['agent']
run=dict(schema=1,source_commit='293d751a814e0d4c34e85ad457ccd9d5eefd1a61',upstream_changed=True,observed_upstream='df8e348d64b4932a0676256ed24f0da3ee9438bc',upstream_source_sync='publication/issue211-virtual/upstream-source-sync.json',latest_runtime_execution=False,generator_merge=merge,native_writer=writer,native_reviewer=reviewer,new_runtime_execution=False,existing_runtime='publication/issue211',prior_reader='publication/issue211-reader',build_id=manifest['build_id'],manifest_sha256=sha256(site/'site-manifest.json'),manifest_outputs=len(manifest['outputs']),reader_page_html_sha256={l:inventory[l]['html_sha256'] for l in ['ko','en']},site_verification=valid,review='publication/issue211-virtual/reviews/'+tag+'/review.json',deployment='Predeployment record; actual Pages/live proof will be in the publication PR',human_review='pending')
receipts=dict(schema=1,scope='New completed native calls verified independently; copied historical calls retain identities. Failed drafts are not relabeled accepted.',writer=writer,reviewer=reviewer,index='publication/issue211-virtual/native-call-verification.json',archive='publication/issue211-virtual/cli-evidence.zip',inherited_archive='publication/issue211-reader/cli-evidence.zip',human_review='pending')
for name,data in [('run.json',run),('generation-receipts.json',receipts)]:
 for target in [repo/name,package/name]:target.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
files={p.relative_to(package).as_posix():sha256(p) for p in sorted(package.rglob('*')) if p.is_file()}
(package/'evidence-index.json').write_text(json.dumps(dict(schema=1,files=files,site_manifest=run['manifest_sha256'],site_outputs=manifest['outputs']),indent=2)+'\n',encoding='utf-8')
with (repo/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:f.write('\n# Preserve exact virtual-principle execution records.\npublication/issue211-virtual/** -text -whitespace\n')
print(dict(package_files=len(files),archive_files=len(index),zip_bytes=(package/'cli-evidence.zip').stat().st_size,build_id=manifest['build_id']))
