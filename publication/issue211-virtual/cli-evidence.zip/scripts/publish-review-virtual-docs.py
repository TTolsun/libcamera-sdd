from pathlib import Path
from sdd.runtime_evidence import run_recorded,require_success
import json,subprocess,sys
root=Path(__file__).resolve().parent.parent;work=root/'build/issue211-virtual';site=root/'build/libcamera-sdd-issue211/docs';helper=root/'examples/libcamera/validation/issue211-reader';prefix=[sys.executable,'-X','utf8']
require_success(work/'executions/generate-concise-labels')
final='final03'
for stage in ['translate','export','render','review']:
 subprocess.run(prefix+[str(root/'examples/libcamera/validation/issue211-virtual/execute.py'),stage,'--work',str(work),'--site',str(site),'--tag',final],check=True,cwd=root)
r=json.loads((work/'reviews'/final/'review.json').read_text())['review']
if r['verdict']!='pass' or r['findings']:raise ValueError(r)
print('Actual final Korean/English/diagram Terra review passed',final)
