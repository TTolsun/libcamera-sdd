from pathlib import Path
import json
from sdd.config import load
from sdd.llm import Agent
from sdd.runtime_evidence import sha256
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';out=w/'config-connected-documentation-v2';out.mkdir(exist_ok=False);source=r/'src/sdd/generated_visuals.py';code=source.read_text(encoding='utf-8')
schema=dict(type='object',additionalProperties=False,required=['markdown'],properties=dict(markdown=dict(type='string',maxLength=1200)))
writer=Agent(load(w/'generation.yaml').agent,out/'writer/prompts')
result=json.loads(writer.chat('Repair the supplied short Korean configuration fragment using the independent findings and actual implementation. No tools. JSON only.','Preserve correct statements. Repair the failure scope: invalid draft is rejected and retried up to cfg.max_retries additional attempts; generation fails with the last error only if retries are exhausted. disconnected IDs are sorted IDs unreachable from the first node ignoring direction, not necessarily isolated individual nodes. Keep concise.\nCURRENT FRAGMENT\n'+(w/'config-connected-documentation/config-reference.md').read_text(encoding='utf-8')+'\nFINDINGS\n'+(w/'reviews/config-connected/review.json').read_text(encoding='utf-8')+'\nCODE\n'+code,tag='connected-config-reference',response_schema=schema))
(out/'config-reference.md').write_text(result['markdown'],encoding='utf-8')
reviewer=Agent(load(w/'new-document-review.yaml').agent,w/'reviews/config-connected-v2/prompts')
rs=dict(type='object',additionalProperties=False,required=['verdict','findings','scope'],properties=dict(verdict=dict(enum=['pass','needs-revision']),findings=dict(type='array',items=dict(type='string')),scope=dict(type='string')))
old=(w/'config-while-documentation-v7/config-reference.md').read_text(encoding='utf-8')
review=json.loads(reviewer.chat('Independent automatic code grounding, never human approval. No tools. JSON only.','Check the new require_connected fragment and retained while_conditions fragment against the actual current implementation. Check precisely the claimed defaults/types, direction-agnostic reachability, failure behavior and limits; do not demand unrelated documentation. Both are short configuration flags, so an extra diagram is not needed.\nNEW\n'+result['markdown']+'\nRETAINED\n'+old+'\nCODE\n'+code,tag='connected-config-grounding',response_schema=rs))
record=dict(review=review,document_sha256=sha256(out/'config-reference.md'),retained_fragment_sha256=sha256(w/'config-while-documentation-v7/config-reference.md'),source_sha256=sha256(source),receipt=str(reviewer.last_receipt));(w/'reviews/config-connected-v2/review.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
if review['verdict']!='pass' or review['findings']:raise ValueError(review)
with (r/'docs/reference/config.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\n'+result['markdown']+'\n')
print('Native configuration writing and independent grounding passed')
