from pathlib import Path
import sys,subprocess,json
from sdd.runtime_evidence import require_success
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';site=r/'build/libcamera-sdd-issue211/docs';tag='branch-label-final'
require_success(w/'executions/generate-request-handoff-label')
for stage in ['translate','export','render','review']:
 subprocess.run([sys.executable,'-X','utf8',str(r/'examples/libcamera/validation/issue211-virtual/execute.py'),stage,'--work',str(w),'--site',str(site),'--tag',tag],check=True,cwd=r)
d=json.loads((w/'reviews'/tag/'review.json').read_text())['review']
if d['verdict']!='pass' or d['findings']:raise ValueError(d)
print('Connected final bilingual review passed')
