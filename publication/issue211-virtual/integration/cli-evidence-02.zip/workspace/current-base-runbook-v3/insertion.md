4-1. 실행 계획을 읽기 전용으로 먼저 확인합니다.

아래 명령은 cam을 실행하지 않고 호스트 상태를 바꾸지 않습니다. 5단계에서 전달될 인자 목록만 JSON으로 출력합니다.

```
python3 <generator>/examples/libcamera/runtime/preview_cam.py --build <its-debug-meson-build>
```

출력의 `cam_argv`는 `<its-debug-meson-build>`의 절대 경로 뒤에 `src/apps/cam/cam`을 붙인 실행 파일과 `--camera Virtual2`, `--capture=3`, `--stream role=video,width=400,height=300,pixelformat=NV12` 인자로 구성됩니다.

출력의 `executed: false`는 계획만 만들었다는 뜻입니다. 적용된 설정이나 캡처 성공을 뜻하지 않습니다. 이 미리보기는 `--build` 경로의 존재를 확인하지 않으므로, 실제 확인은 5단계 실행 기록으로 합니다.

5단계 실행 후 `<new-evidence-directory>/cam-1`, `cam-2`, `cam-3`을 각각 확인합니다.

1. `record.json`의 `argv`에서 `--args` 뒤 여섯 항목(실행 파일과 인자 다섯 개)이 위 `cam_argv`와 같은지 확인합니다.
2. `stdout`에 `Using camera Virtual2 as cam0`이 있고, `stderr`의 `configuring streams:` 줄이 정확히 하나이며 값이 `(0) 400x300-NV12/SMPTE170M`인지 확인합니다.
3. `events.jsonl`에서 콜백 3회와 처리 프레임 3회가 정상 완료 상태(status 1)로 기록되었는지 확인합니다.
4. `inferior-exit.json`이 `exit_code` 0과 빈 `observation_failures`인지 확인합니다.

위 네 가지만으로는 캡처 성공을 판단할 수 없습니다. 다음 검사까지 모두 통과해야 합니다.

5. 세 실행이 끝난 뒤 `<new-evidence-directory>/observation.json`의 `status`가 `observed-wsl-virtual-only`이고 `human_review`가 `pending`인지 확인합니다. `failure` 키가 없어야 하고, `results`는 3개이며 PID 3개가 서로 달라야 합니다.

`observation.json`에 기록되는 검증기 항목은 다음과 같습니다.

- 빌드 확인과 `293d751a` 소스 기준(추적 파일 변경 없음, build 경로 일치)
- 실행 파일, 라이브러리, 프로브의 해시가 `loaded.json`과 일치
- DMA 프로브가 `validate_dma`를 통과하고 cam의 DMA 할당이 udmabuf 제공자로 확인됨
- 프레임 이벤트와 `buffers.jsonl`의 버퍼 상태, 시퀀스 검증
- 위 1~4번의 실행 기록 검증

`physical_dma`는 `not-validated`, `physical_camera`, `production_application`, `internal_hal`은 `not-run`으로 남습니다. 이 결과는 WSL 가상 환경의 관찰 기록일 뿐이며, 사람 검토가 끝나기 전까지 성공으로 승격하지 않습니다.