5. 실행 전 계획 인자를 읽기 전용으로 미리 확인합니다. 기존 5번 단계는 6번으로 번호가 바뀝니다.

이 명령은 `cam`과 gdb를 실행하지 않고, `<new-evidence-directory>`도 만들지 않습니다. 계획된 인자만 JSON으로 출력합니다.

```
PYTHONPATH=<generator>/src python3 <generator>/examples/libcamera/runtime/preview_cam.py --build <its-debug-meson-build>
```

출력의 `cam_argv`는 다음 순서여야 합니다. 첫 항목은 `<its-debug-meson-build>/src/apps/cam/cam`을 절대 경로로 바꾼 값입니다.

```
<its-debug-meson-build 절대 경로>/src/apps/cam/cam --camera Virtual2 --capture=3 --stream role=video,width=400,height=300,pixelformat=NV12
```

`executed: false`는 계획만 출력했다는 뜻입니다. 설정이 실제로 적용되었다는 증거이거나 캡처가 성공했다는 증거가 아닙니다. 이 판단은 아래 실행 기록에서만 합니다.

실제 실행 후 `cam-1`, `cam-2`, `cam-3` 각각의 기록에서 다음을 확인합니다.

1. `record.json`의 `argv`에서 `--args` 뒤 항목 전체가 위 `cam_argv`와 같은지 확인합니다.
2. `stderr`에 `configuring streams:` 줄이 하나만 있고, 값이 `(0) 400x300-NV12/SMPTE170M`인지 확인합니다.
3. `events.jsonl`에 `callback-entry`와 `frame-processed`가 각각 3회 있고, `buffers.jsonl`의 3개 행이 모두 `status` 1, `buffer_status` 0인지 확인합니다.
4. `inferior-exit.json`의 `exit_code`가 0이고 `observation_failures`가 비어 있는지 확인합니다. `record.json`의 `exit_code`는 gdb 래퍼의 종료 코드이므로 cam 종료 확인으로 대신하지 않습니다.