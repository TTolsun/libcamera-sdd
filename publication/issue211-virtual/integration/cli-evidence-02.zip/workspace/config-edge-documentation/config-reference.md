## max_edge_label_chars

**결론:** 선택 항목입니다. 키를 생략하면 edge 전용 제한이 없습니다. 값을 주면 정수 8~240만 허용하며, edge의 한국어 `label`과 영어 `label_en` 모두에 추가로 적용됩니다.

```yaml
- id: example_flow
  topic: example_topic
  kind: flow
  title: 예시 흐름
  question: 예시 질문
  generation: llm
  max_label_chars: 120
  max_edge_label_chars: 60
```

1. **상한 결합:** node는 기존 `max_label_chars`만 따릅니다. edge는 두 값 중 작은 값이 실효 상한입니다. `max_label_chars`가 없으면 edge 값만 적용됩니다.
2. **검사 시점:** 모델이 작성한 원문 label을 먼저 검사합니다. 이후 `· 조건 [true]` 형태의 조건 표기가 덧붙으므로, 최종 표시 폭은 보장하지 않습니다.
3. **자르기 없음:** 초과한 label은 자르지 않고 거부합니다. 오류 내용을 포함해 최초 시도 뒤 `max_retries`회 재시도하며, 모두 실패하면 생성이 실패합니다. 새 결과를 만들지 않으므로 이전 유효 산출물을 유지하는 것이 기준입니다.
4. **이중 검사:** schema를 지원하는 에이전트에는 `maxLength`로 전달되지만, 최종 검사는 항상 로컬에서 수행합니다.

**다음 행동:** 실제 모델로 `generate`를 실행해 edge 초과가 재시도 후 실패로 보고되는지 확인합니다.