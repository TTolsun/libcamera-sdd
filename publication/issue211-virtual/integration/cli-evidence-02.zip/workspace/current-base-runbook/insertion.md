### 4-1. 읽기 전용 호출 계획 확인

실제 실행 전에 `preview_cam.py`로 `cam`에 전달될 인자를 미리 확인합니다. 이 명령은 `cam`과 gdb를 실행하지 않고 호스트 상태도 바꾸지 않으며, JSON 계획만 출력합니다.

```
PYTHONPATH=<generator>/src python3 <generator>/examples/libcamera/runtime/preview_cam.py --build <its-debug-meson-build>
```

출력된 `cam_argv`는 아래 값과 같아야 합니다. 실행 파일 경로는 `--build`를 절대 경로로 바꾼 값입니다.

```
<its-debug-meson-build 절대 경로>/src/apps/cam/cam --camera Virtual2 --capture=3 --stream role=video,width=400,height=300,pixelformat=NV12
```

`executed: false`는 계획만 출력했다는 뜻입니다. 설정이 적용되었다거나 캡처가 성공했다는 증거가 아닙니다. 적용된 구성과 성공 여부는 아래 실행 기록에서만 판단합니다.

실행 후 `cam-1`, `cam-2`, `cam-3` 각 디렉터리에서 다음을 모두 확인합니다.

1. 실행 명령 기록에서 `--args` 뒤 argv가 위 `cam_argv`와 같은지 확인합니다. 기록 파일 이름은 제공된 코드에 나오지 않으므로 `run_recorded`가 쓰는 기록에서 직접 찾습니다.
2. `stdout`에 `Using camera Virtual2 as cam0`이 있고, `stderr`에 `configuring streams: (0) 400x300-NV12/SMPTE170M` 줄이 정확히 한 번 있는지 확인합니다.
3. `events.jsonl`에 정상 콜백 3회(`callback-entry`)와 처리된 프레임 3개(`frame-processed`, 완료 상태 status 1)가 있는지 확인합니다. `buffers.jsonl`의 buffer_status는 모두 0이어야 합니다.
4. `inferior-exit.json`의 exit_code가 0이고 `observation_failures`가 빈 목록인지 확인합니다.

네 항목 중 하나라도 어긋나면 해당 실행을 성공으로 기록하지 않습니다.