## max_edge_label_chars

**결론:** `generation: llm` 시각화 계획 항목에 두는 선택 키입니다. 키를 생략하면 edge 전용 길이 제한이 없습니다. 값은 정수 8~240만 허용하며, edge의 한국어 `label`과 영어 `label_en`에 각각 적용됩니다.

```yaml
- id: example_flow
  topic: example_topic
  kind: flow
  title: 예시 흐름
  question: 예시 질문
  generation: llm
  max_label_chars: 120
  max_edge_label_chars: 60
```

1. **타입 검사:** 설정 단계에서 정수가 아닌 값(bool, 실수, 문자열)과 8 미만 또는 240 초과 값을 오류로 거부합니다.
2. **상한 결합:** edge 라벨의 실효 상한은 `max_edge_label_chars`와 `max_label_chars` 중 작은 값입니다. `max_label_chars`가 없으면 edge 값만 적용됩니다. node 라벨은 이 키의 영향을 받지 않고 기존 `max_label_chars`만 따릅니다.
3. **검사 시점:** 모델이 작성한 원문 label을 먼저 검사합니다. 이후 `· 조건 [true]` 형태의 조건 표기가 덧붙으므로, 이 키는 최종 표시 폭 상한이 아닙니다.
4. **자르기 없음:** 초과한 label은 자르지 않고 거부합니다.
5. **이중 검사:** schema를 지원하는 에이전트에는 `maxLength`로 전달되지만, 최종 검사는 항상 로컬에서 수행합니다.

**다음 행동:** 이 값을 바꾸면 계획 입력이 달라져 기존 생성 결과를 재사용할 수 없으므로, `generate`를 다시 실행합니다.