{"translations": {"0": "This material is provided separately from the source. Check the provider, version, and scope of application in the record below. Automatic checks are not human approval."}}
