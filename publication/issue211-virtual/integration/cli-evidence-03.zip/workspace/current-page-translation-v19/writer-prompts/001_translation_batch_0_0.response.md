{"translations": {"1433": "It is directly checked whether the arguments of the official cam command to be run include {{1}} and specify a request for 3 frames."}}
