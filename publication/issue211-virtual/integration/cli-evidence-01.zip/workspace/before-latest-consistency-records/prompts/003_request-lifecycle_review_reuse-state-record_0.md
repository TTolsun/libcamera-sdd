<!-- system -->
제공된 소스만 사용하여 한국어 기술 문서를 작성합니다. 질문의 각 조건에 답하세요. 원문에 없는 보장이나 이유를 추가하지 마세요. 의무(must/shall), 가능성(may), 부정을 그대로 유지하세요.
This question requests an optional source-based observation plan, not an existing test log. Propose record fields (기록 항목) using the shown variables and code points. Recording may be proposed even when the source does not mandate it. Preserve the proposed nature; never claim completed tests, invented commands, measurements, runtime guarantees or new API obligations.

<!-- user -->
근거:
{"record-status": [{"scope": {"start": "void Request::reuse(ReuseFlag flags)", "end": "\\fn Request::controls()"}, "text": "status_ = RequestPending;", "quote_id": "record-status:0", "enclosing_context": {"before": "void Request::reuse(ReuseFlag flags)\n{\n\tLIBCAMERA_TRACEPOINT(request_reuse, this);\n\n\t_d()->reset();\n\n\tif (flags & ReuseBuffers) {\n\t\tfor (const auto &[stream, buffer] : bufferMap_) {\n\t\t\tbuffer->_d()->setRequest(this);\n\t\t\t_d()->pending_.insert(buffer);\n\t\t}\n\t} else {\n\t\tbufferMap_.clear();\n\t}\n\n\t", "after": "\n\n\tcontrols_.clear();\n\t_d()->metadata_.clear();\n}\n\n/**\n * \\fn Request::controls()"}}], "record-controls": [{"scope": {"start": "void Request::reuse(ReuseFlag flags)", "end": "\\fn Request::controls()"}, "text": "controls_.clear();", "quote_id": "record-controls:0", "enclosing_context": {"before": "void Request::reuse(ReuseFlag flags)\n{\n\tLIBCAMERA_TRACEPOINT(request_reuse, this);\n\n\t_d()->reset();\n\n\tif (flags & ReuseBuffers) {\n\t\tfor (const auto &[stream, buffer] : bufferMap_) {\n\t\t\tbuffer->_d()->setRequest(this);\n\t\t\t_d()->pending_.insert(buffer);\n\t\t}\n\t} else {\n\t\tbufferMap_.clear();\n\t}\n\n\tstatus_ = RequestPending;\n\n\t", "after": "\n\t_d()->metadata_.clear();\n}\n\n/**\n * \\fn Request::controls()"}}], "record-metadata": [{"scope": {"start": "void Request::reuse(ReuseFlag flags)", "end": "\\fn Request::controls()"}, "text": "_d()->metadata_.clear();", "quote_id": "record-metadata:0", "enclosing_context": {"before": "void Request::reuse(ReuseFlag flags)\n{\n\tLIBCAMERA_TRACEPOINT(request_reuse, this);\n\n\t_d()->reset();\n\n\tif (flags & ReuseBuffers) {\n\t\tfor (const auto &[stream, buffer] : bufferMap_) {\n\t\t\tbuffer->_d()->setRequest(this);\n\t\t\t_d()->pending_.insert(buffer);\n\t\t}\n\t} else {\n\t\tbufferMap_.clear();\n\t}\n\n\tstatus_ = RequestPending;\n\n\tcontrols_.clear();\n\t", "after": "\n}\n\n/**\n * \\fn Request::controls()"}}]}
질문: 조사 기록 항목으로 Request::reuse 전후의 status_·controls_·metadata_ 값과 RequestPending 대입을 한 문장으로 제안하세요. 먼저 대입 대상 이름을 말한 뒤 같은 변수를 다시 기록하라고 되풀이하지 마세요.
집필 지시(제품 사실 아님):
이번 실행의 현재 집필 규칙 전체:
# 개발자 가이드 집필 규칙

이 시스템을 소개하는 문서와, 각 프로젝트에서 생성·배포하는 모든 페이지 및 원고에 적용합니다. 배포 플랫폼과 관계없이 아래 두 원문을 모두 읽고 적용합니다.

- [i-have-adhd 원문](i-have-adhd.md): ayghri/i-have-adhd, 커밋 `6f1f982d0a47c65899af3c5a7450b7098bc65325`에서 가져왔습니다. [MIT 라이선스](i-have-adhd.LICENSE)를 따릅니다.
- [fluent-korean 원문](fluent-korean.md): snflkd/fluent-korean, 커밋 `ce8683f0eba8cddb91de4dcd151425ff73e60498`에서 가져왔습니다. [MIT 라이선스](fluent-korean.LICENSE)를 따릅니다.

## 개발자 문서에 적용하는 방법

원문의 목적과 예시를 유지하되, 대화 응답에만 해당하는 지시는 다음 기준으로 문서에 적용합니다. 독자의 의학적 진단을 가정하지 않습니다.

1. 각 페이지는 독자가 먼저 할 일이나 알아야 할 결론으로 시작합니다. 절차는 번호를 붙이고, 한 단계에는 한 가지 작업을 씁니다.
2. 문단은 한 가지 주제를 설명합니다. 목록이 길면 주제별로 나누되, 조건·예외·미구현 사항을 삭제해서 길이를 줄이지 않습니다.
3. 조사와 서술어를 갖춘 한국어 문장을 씁니다. 제목·표의 열 이름·코드 식별자는 필요한 만큼 짧게 유지합니다. 코드, 주석, 로그 문자열, 인용문은 원문을 보존합니다.
4. 페이지 끝에는 관련 절차나 다음에 읽을 문서 하나를 연결합니다. 대화의 진행 상태나 작업 시간 추정은 문서에 넣지 않습니다. 관측 시간과 실패 횟수처럼 코드로 확인한 수치는 그대로 유지합니다.
5. 코드로 확인한 동작, 설계 결정, 기기 관찰 기록을 구분합니다. 설명이 부족한 부분은 무엇을 확인해야 하는지 적고, 근거가 없는 확신이나 설계 이유를 추가하지 않습니다.
6. 아이에게 설명하듯 쉬운 단어와 짧은 문장을 씁니다. 무엇이 무엇을 하는지 주어와 행동을 분명히 밝힙니다. 먼저 실제로 일어나는 일을 쉬운 말로 설명한 뒤 필요한 기술 용어와 코드 식별자를 연결합니다. 예: "요청을 보냈다고 사진 촬영이 끝난 것은 아닙니다. 촬영 완료는 별도의 알림으로 확인합니다."
7. 친근하고 가벼운 말투로 쓰되 웃기려고 다른 상황에 빗대지 않습니다. 접수증·그릇·주문서처럼 독자가 코드와의 관계를 다시 해석해야 하는 비유는 피합니다. 유머는 방금 설명한 동작에서 바로 이해할 수 있는 짧은 한마디로만 덧붙입니다. 예: "성공을 반환했지만, 사진은 아직 기다려야 합니다." 유머의 개수를 채우지 않으며, 설명이 더 어려워지면 넣지 않습니다.
8. 쉬운 설명에서도 조건·예외·인용·소유권·스레드·실행 순서의 차이는 빠뜨리지 않습니다. 유머를 빼도 기술 설명과 근거가 완전해야 합니다. 독자·동료·특정 조직을 비꼬거나 유치하게 대하지 않습니다. 오류·안전 경고·미구현 사항·검증 및 승인 상태는 담백하게 전달하고, 표·코드·인용 원문에는 농담을 넣지 않습니다. 이 프로젝트에서는 위 기준의 쉬운 설명과 가벼운 유머를 우선합니다.
9. 사용자가 요청하지 않아도 독립된 질문이나 주제를 설명하는 각 항목에 이해를 돕는 그림 하나를 기본으로 검토합니다. 긴 설명과 여러 상태·단계·분기·책임 주체·소유권을 다루는 설명은 그림을 우선 보완합니다. 짧고 단순하거나 간단한 표로 충분한 항목은 생략할 수 있으며, 생략 사유는 검토 기록에 남깁니다. 페이지에 그림이 있다는 이유로 다른 긴 항목의 시각화가 충분하다고 판단하지 않습니다.
10. 그림은 항목의 핵심 질문에 답해야 합니다. 구조·책임은 구성도, 처리 순서는 흐름도나 시퀀스, 상태·예외는 상태도나 분기, 소유권·수명은 주체별 유지·반환 관계로 설명하되 지원 형식과 소스 근거에 맞춰 선택합니다. 장식 이미지나 같은 그림 반복으로 개수를 채우지 않으며, 근거가 없는 연결·실행 순서·보장을 만들지 않습니다.
11. 최종 문서는 핵심 설명 한두 문장, 그림, 조건·예외 설명 순으로 구성합니다. 번호 절차는 그림 때문에 끊지 않으며, 그림의 핵심을 설명하는 짧은 문장을 둡니다. 모든 본문을 노드에 옮기지 않고 필수 조건·예외를 본문에 보존합니다. 그림은 기존 질문별 그림 생성·근거 검증 경로로 조립하며 문장 생성 JSON의 필드나 응답 형식을 임의로 바꾸지 않습니다.
12. 검토자는 최종 조립 문서의 항목별로 적절한 그림 있음, 보완 필요, 생략 가능, 근거 부족·미검토를 구분하고 사유를 남깁니다. 짧은 문장 단위 생성의 성공이나 그림 개수만으로 최종 문서의 가독성을 통과시키지 않습니다. 삭제되거나 오래된 근거 때문에 생략된 그림도 다시 확인하고, 필요한 그림의 미해결 누락은 발행 전에 보완하거나 미완료로 보고합니다. 자동 근거 검사를 사람의 의미 승인으로 취급하지 않습니다.

`brief.mjs`는 이 문서와 두 원문 전체를 집필 프롬프트에 포함합니다. `model.mjs`는 같은 파일을 원고 해시에 포함하므로 규칙이 바뀌면 원고를 다시 검토해야 합니다. 설치된 개인 스킬이 없는 CI나 다른 개발자의 환경에서도 저장소에 기록된 규칙을 사용합니다.
독립 검토의 관찰 시점 오류를 수정하세요. 관찰 시점은 Request::reuse 호출 전과 호출 완료 후입니다. status_ 대입 행 앞뒤만 보면 그 뒤의 controls_와 metadata_ 초기화를 놓칠 수 있습니다. 실제로 실행한 결과가 아닌 관찰 계획으로, Request::reuse를 추가로 호출하라는 지시 없이 변수와 RequestPending을 한 문장에 연결하세요.
작성 조건: {"_max_statements": 1, "answer_contract": {"basis": "investigation", "required_terms": [["status_"], ["기록"], ["controls_"], ["metadata_"], ["Request::reuse"]]}}
문장은 합니다·입니다 형태로 끝내세요. 한 문단은 600자·4문장 이내로 쓰고, 필수 용어의 각 묶음에서 하나 이상을 원래 표기대로 포함하세요. 질문 밖의 함수 내부나 추가 조사 과제를 덧붙이지 마세요. 질문에서 요구한 사항을 확인할 수 없을 때만 확인되지 않은 대상을 짧게 밝히세요. 제공된 코드·제공된 근거 같은 작성 과정 표현은 쓰지 말고, 같은 내용을 바꿔 말하지 마세요.
출력: {"statements": [{"text": "질문의 모든 조건에 답하는 한 문단. 여러 문장을 써도 됩니다.", "quote_id": "직접 근거의 구절 ID", "covers": ["review"], "kind": "behavior"}]} 형식의 JSON만 반환하세요.
