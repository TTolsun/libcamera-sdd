{"reviews": [{"index": 0, "supported": true, "reason": "type 'array', value ['auto'], choices 목록, auto·all 설명, 두 값 함께 선택 시 all 우선이 모두 description과 일치합니다. 추가 근거나 기기 적합성 추정은 없습니다."}]}
