{"reviews": [{"index": 0, "supported": true, "reason": "소스의 `if (request->buffers().empty())` 분기가 `Request contains no buffers`를 Error로 기록하고 `-EINVAL`을 반환합니다. 조건, 로그, 반환값이 모두 인용과 일치합니다."}]}
