{"reviews": [{"index": 0, "supported": true, "reason": "queueRequest의 루프가 request->buffers()의 stream을 d->activeStreams_.find()로 찾고, end()와 같으면 LOG 후 -EINVAL을 반환합니다. 문장의 조건과 반환값이 원문과 일치합니다."}]}
