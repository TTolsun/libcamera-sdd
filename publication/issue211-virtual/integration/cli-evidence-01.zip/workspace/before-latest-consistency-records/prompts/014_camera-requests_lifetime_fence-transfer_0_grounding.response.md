{"reviews": [{"index": 0, "supported": true, "reason": "원문이 유효한 fence가 제공되면 fence가 buffer로 이동하고, 소유권은 성공 시에만 가져간다고 명시합니다. 두 문장 모두 원문과 일치하며 실패 경로에 대한 주장은 없습니다."}]}
