from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='ordered-prefix'
b=w/('before-'+tag);b.mkdir()
for name in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());t=next(t for s in x['sections'] if s['id']=='official-cam-validation' for t in s['design_topics'] if t['id']=='virtual-principle')
 part=next(a for a in t['parts'] if a['id']=='completion')
 part['question']+=' completeBuffer가 true일 때 completeRequest를 호출한다는 문장의 한정 범위는 반드시 가상 파이프라인의 버퍼 완료 처리 경로라고 명시합니다. 취소 등 다른 호출 경로까지 이 조건이 적용된다는 일반 규칙으로 쓰지 마세요. 다른 기존 내용과 간결한 분량은 유지합니다.'
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='request-completion-order':
   v['max_nodes']=9
   v['question']='가상 버퍼 완료 경로의 모든 버퍼 완료 판정과, 완료 표시 뒤 제출 순서 큐의 연속 통지 및 반복 종료는 어떻게 연결됩니까?'
   v['prompt']='현재 일곱 노드의 가상 버퍼 완료 판정과 앞선 Pending 통지 보류 조건을 보존하며 큐 반복을 정확히 보완합니다. 기존 n3 완료 표시 뒤 새 n7 결정 노드로 큐에 요청이 남았는지 실제 while 조건을 검사합니다. n7 true는 n4 맨 앞 Pending 검사로, false는 새 n8 이번 통지 검사 종료로 연결합니다. n4 true는 기존 n6 뒤 요청 보류와 반복 중단입니다. n4 false는 n5로 맨 앞 요청 하나를 큐에서 꺼내 requestCompleted 신호와 cam requestComplete 콜백에 알립니다. n5에서 n7로 되돌아가 다음 맨 앞 요청을 다시 검사합니다. 통지 가능한 앞부분을 반복 처리하다 Pending 또는 빈 큐에서 멈춥니다. n5가 한 번에 모든 요청을 통지한다고 쓰지 마세요. 이후 doQueueRequests의 기다리던 요청 전달은 이 그림의 통지 검사 범위 밖이며 n8을 함수 전체 반환으로 쓰지 마세요. 실제 while !queuedRequests_.empty 조건의 true/false 두 분기를 인용하고, Pending 및 completeBuffer 두 분기도 모두 보존합니다. 새 n7/n8과 n5 반복에 맞춘 간선 외의 소스 바인딩과 노드는 보존합니다. 한영 라벨은 짧은 동작구/질문, 노드 최대56자, 간선20자입니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
  elif v['id']=='reproduction-flow':
   v['max_label_chars']=72
   v['prompt']='현재 열두 노드와 모든 간선·실제 조건·인용·검사 순서를 그대로 보존하고 한영 표시 라벨만 짧은 동작구/질문으로 줄입니다. 재현 본문에 이미 있는 도우미 사용시 인자 전달 설명은 긴 cam 검사 노드에서 반복하지 않습니다. cam 노드는 Virtual2, 400×300, NV12, cam 캡처 한도 3 / cam capture limit 3의 검사만 간결하게 나타내세요. 커널/장치 노드도 6–7, 기록된 커널/recorded kernel, root, /dev/udmabuf만 짧게 연결합니다. YAML 노드는 Virtual2 400×300 lines를 검사합니다. 호스트 승인은 실행 직전/immediately의 별도 승인임을 보존합니다. 한영 노드72자, 간선20자 이내입니다. 400과300은 × 또는 공백으로 구분해야 하며 x로 붙이지 않습니다. 값들을 무관한 노드로 옮기거나 의미 없는 키워드 목록을 쓰지 말고 실제 각 검사의 질문으로 표현합니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
  else:continue
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-phase-blocks.py').read_text().replace('phase-blocks',tag)
text='\n'.join(line for line in text.split('\n') if not line.startswith('exec('))
(r/'build/after-virtual-ordered-prefix.py').write_text(text,encoding='utf-8')
