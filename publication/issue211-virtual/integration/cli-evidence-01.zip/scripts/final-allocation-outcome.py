from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='allocation-outcome'
b=w/('before-'+tag);b.mkdir()
for name in ['config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='submission-gate':
   v['required_symbols'][0]='allocate'
   v['sources']=['cam-request-buffers','camera-queue','pipeline-dispatch']
   v['prompt']=v['prompt'].split('아래 초안')[0].replace('n0 exportFrameBuffers: DMA-BUF 할당 실패?','n0 allocate: cam의 allocator_->allocate 호출 결과가 실패인가?')
   v['prompt']+=' n0는 할당기 유효성만 보는 검사가 아니라 cam startCapture의 allocator_->allocate 반환 ret<0를 판정합니다. 할당기가 유효해도 할당 호출은 실패할 수 있습니다. 노드 라벨은 버퍼 할당 실패 여부만 짧게 질문합니다. 원시 호출식·ret 비교·할당기 유효성 검사는 화면에 쓰지 않습니다. 모든 노드·간선 인용은 현재 제공된 세 source 창에서 새로 선택하며 제거된 virtual-buffer-allocation, allocator-to-camera, camera-export 인용을 재사용하지 않습니다. n4는 카메라 큐 호출이라는 행동만, n7은 호출 내부에서 검증 통과 시 비동기 예약한다는 행동만 짧게 표시합니다. 검증 실패 분기는 이 그림 밖이라는 괄호 경고를 노드에 넣지 않습니다. '
   for key in ['answer_contract','answer_contract_en']:
    v[key]['reject_patterns'].append(dict(pattern=r'(?m)^[^·\n]*(?:isValid|할당기\s*(?:유효|무효)|allocator.{0,20}invalid|\bret\b)',message='The allocation gate tests the actual cam allocate() return, not allocator validity. Keep comparisons and raw calls in source evidence.'))
  if v['id']=='virtual-frame-path':
   v['prompt']='현재 유효한 아홉 노드·모든 인용·간선·guard의 두 결과를 보존하고 n3와 n0의 표면 라벨만 고칩니다. 선택한 virtual의 queueRequestDevice는 0을 반환하므로 n3에 일반 호출자의 실패 시 취소 분기를 추가하지 않습니다. n3는 가상 파이프라인의 queued 프레임 처리 예약만 짧게 한영으로 씁니다. n0는 PipelineHandler가 요청을 받아 준비를 시작한다는 한 행동으로 쓰고 prepare로 준비처럼 같은 뜻을 두 번 나열하지 않습니다. 나머지 정상적인 취소 상태 판정, 앞선 미완료 요청에 따른 취소 통지 보류, CPU 매핑·변환·쓰기 시도와 버퍼 오류 상태 조건은 바꾸지 않습니다. 특히 VirtualCameraData::processRequest라는 주체 이름과 source guard, 각 간선의 두 끝점 심볼을 포함한 인용을 모두 보존합니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
   for key in ['answer_contract','answer_contract_en']:
    v[key]['reject_patterns'].append(dict(pattern=r'(?m)^[^·\n]*(?:실패|\bfail(?:ed|s|ure)?\b|cancelRequest|\bprepare\b)',message='This selected virtual handler returns zero: omit generic failure cancellation. Keep the pre-cancelled request branch. Use plain preparation wording and error for frame-generation errors.'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-reader-actors.py').read_text().replace('reader-actors',tag)
(r/'build/after-virtual-allocation-outcome.py').write_text(text,encoding='utf-8')
