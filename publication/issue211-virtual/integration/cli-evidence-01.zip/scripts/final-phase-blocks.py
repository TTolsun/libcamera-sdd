from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='phase-blocks'
b=w/('before-'+tag);b.mkdir()
for name in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
groups={'environment':('1','준비 (1–3)'), 'approval':('4','호스트 변경 (4–5)'), 'kernel-check':('6','실행 전 검사 (6–11)'), 'execution':('12','실행·검증 (12–13)')}
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());t=next(t for s in x['sections'] if s['id']=='official-cam-validation' for t in s['design_topics'] if t['id']=='reproduce')
 for part in t['parts']:
  if part['id'] in groups:
   n,title=groups[part['id']];part['question']+=f' 이 단계의 statement.text는 {n}. 다음에 **{title}**라는 짧은 굵은 묶음 제목과 원래 행동을 이어 씁니다. 전체 번호 1–13은 끊지 않고 이 묶음 제목으로 절차의 네 구간을 시각적으로 구분합니다. 기존 필수 조건과 행동은 보존합니다.'
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());v=next(v for v in x['sections']['official-cam-validation'] if v['id']=='reproduction-flow')
 for key in ['answer_contract','answer_contract_en']:
  v[key]['required_terms']=[(['6–7','6-7','6~7','6 through 7','6 to 7'] if '6–11' in g else g) for g in v[key]['required_terms']]
 v['prompt']='현재 유효한 열두 노드·모든 source 인용·간선·검사값을 정확히 보존하고 device_verify(커널·권한 검사)의 범위 번호만 바로잡습니다. 이 노드는 실행 중인 커널이 기록된 커널과 일치하며 root가 /dev/udmabuf에 접근하는 6–7번 검사만 담당합니다. 따라서 한영 라벨에서 6–11을 6–7로 바꾸고 이 노드가 모든 입력 검사까지 담당한다고 쓰지 않습니다. 다음 YAML 검사는8번, cam 입력 검사는9–11번을 담당하는 기존 의미와 값들을 유지합니다. 다른 모든 표시와 인용은 바꾸지 않습니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-preflight-groups-v2.py').read_text().replace('preflight-groups-v2',tag).replace('translate-preflight-choice-steps.py','translate-phase-procedure.py')
(r/'build/after-virtual-phase-blocks.py').write_text(text,encoding='utf-8')
helper=(r/'build/translate-final-procedure.py').read_text().replace('initial-reproduction',tag)
start=helper.index("system='Translate these thirteen Korean reproduction instructions");end=helper.index('\nschema=',start)
helper=helper[:start]+"system='Translate these thirteen Korean reproduction instructions into concise imperative English. For a step with a phase-heading placeholder, keep that placeholder first and write the imperative action after it. Begin other actions with a verb. Preserve all source conditions, subjects, uncertainty, scope and opaque {{number}} tokens with exact counts. These instruct a future fresh execution, not completed facts. Do not add only or other restrictions absent from the Korean source. Preserve allocator choice before required-module checks, actual cam capture limit 3 and helper pass-through when used, and all checks before execution. Return JSON translations with thirteen strings in source order, no step numbers or new facts.'"+helper[end:]
(r/'build/translate-phase-procedure.py').write_text(helper,encoding='utf-8')
