from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='queue-error'
b=w/('before-'+tag);b.mkdir()
for name in ['config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());v=next(v for v in x['sections']['official-cam-validation'] if v['id']=='submission-gate');v['max_nodes']=12
 v['question']='初期 캡처에서 할당·요청 준비·카메라 시작·제출 한도와 실제 큐 호출, 큐 호출 오류 뒤 정리 및 초기 요청 순회는 어떻게 연결됩니까?'.replace('初期','초기')
 v['prompt']='현재 열 노드의 준비 실패, 카메라 시작, 제출 한도, 증가와 Camera::queueRequest 호출 내부의 검증 통과시 비동기 전달을 보존하며 startCapture의 큐 호출 오류 정리 경로를 보완합니다. 최대12노드를 지킵니다. 기존 n4 카메라 큐 호출에서 기존 n7로 가는 관계는 호출 내부의 검증 통과시 비동기 전달이며, 호출 반환 뒤에 전달되는 것으로 바꾸지 않습니다. 별도로 n4에서 새 n10의 도우미 반환값 오류 판정으로 이어갑니다. n10은 startCapture의 실제 ret < 0 판정이며 true는 새 n11의 카메라 중지, 출력 싱크가 있으면 중지, 오류 반환입니다. false는 초기 요청 순회를 계속하는 기존 n6으로 연결합니다. n6 표시는 오류 없는 이번 도우미 반환 뒤 초기 요청 순회 계속으로 고칩니다. 기존 n3 제출 한도 true도 도우미가0을 반환해 같은 n6으로 이어지되 간선에 제출 없이 반환임을 명시합니다. n3 false→증가→실제 카메라 호출은 보존합니다. n6의 이 공통 관계와 n10/n11을 cam-request-buffers의 실제 초기 요청 순회·도우미 반환·오류 정리 코드로 인용하고 기존 n6 symbol captureLimit_ 바인딩을 근거에서 유지합니다. n10의 true/false 모두 실제 같은 ret<0 guard를 사용하세요. 큐 오류 정리를 앞선 준비 실패의 공통 반환 노드와 혼동하지 않습니다. 모든 기존 실제 조건·인용·required_symbols와 한영 의미를 유지합니다. 노드는 짧은 동작구/질문72자, 간선20자입니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
(r/'build/after-virtual-queue-error.py').write_text((r/'build/after-virtual-signal-wording.py').read_text().replace('signal-wording',tag),encoding='utf-8')
