from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
from sdd.translation_context import for_source
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';b=w/'before-last-reader-boundaries';b.mkdir()
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
review=json.loads((w/'reviews/latest-main-final-v4/review.json').read_bytes());catalog=json.loads((d/'run/english.json').read_bytes())
keys=[k for k in catalog['strings'] if k.startswith('{{0}}') and '변경안' in k and any(c['inline_tokens'].get('{{0}}')=='호스트 변경 (4–5)' for c in for_source(catalog,k))]
assert len(keys)==1
(w/'phase-heading-native-findings.json').write_text(json.dumps({keys[0]:review['review']['findings'][0]+' Keep the leading phase-label placeholder at the start, outside the approval-plan sentence.'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for root in [w,d]:
 for rel in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
  target=b/root.name/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,target)
 path=root/'config/sections.yaml';data=yaml.safe_load(path.read_bytes());s=next(s for s in data['sections'] if s['id']=='official-cam-validation')
 p=next(p for t in s['design_topics'] if t['id']=='flow' for p in t['parts'] if p['id']=='reuse-request')
 p['question']='출력 옵션 미요청 범위는 앞 항목이 이미 밝혔으므로 그 선언을 반복하지 말고 앞서 정한 출력 조건이라는 짧은 연결 구절로만 참조합니다. 그 조건에서 처리 한도가 미설정이거나 처리 수가 아직 한도에 도달하지 않았으면 버퍼를 유지해 요청을 재사용하고 제출 도우미를 호출한다는 한 문장으로 마칩니다. 실제 제출 생략 조건·도우미의 반환값·내부 카운터는 반복하지 않습니다.'
 p['answer_contract']['reject_patterns'].append({'pattern':'기록된.{0,12}(명령|실행).{0,25}(출력|싱크)','message':'The preceding scope statement already identifies the recorded no-output invocation; refer to its condition without restating it.'})
 path.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
 path=root/'config/visuals.yaml';data=yaml.safe_load(path.read_bytes())
 for v in data['sections']['official-cam-validation']:
  if v['id']!='virtual-frame-path':continue
  v['prompt']='현재 아홉 노드·모든 간선·실제 조건·인용·간결한 한영 표시를 그대로 보존하고 버퍼 완료 신호 노드의 한영 라벨만 고칩니다. 성공·오류 모두 버퍼 완료 신호를 발생시키며 요청 완료 및 순서 검사는 별도 단계라는 경계를 간결하게 나타냅니다. 버퍼 하나의 완료가 즉시 cam에 요청 완료를 통지한다는 뜻으로 쓰지 않으며 cam 통지는 다음 그림/cam notify next 같은 편집 안내를 쓰지 않습니다. 한영 최대72자를 유지하고 나머지 라벨과 구조는 바꾸지 않습니다. 다음은 native 편집 대상 초안입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
  for field,pattern in [('answer_contract','cam.{0,12}통지|다음\\s*그림'),('answer_contract_en','cam.{0,12}notif|next\\s*(?:diagram|figure)')]:v[field].setdefault('reject_patterns',[]).append({'pattern':pattern,'message':'Buffer completion is not immediate cam request notification; keep separate request-completion/order checks explicit.'})
 path.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
