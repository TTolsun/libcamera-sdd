from pathlib import Path
import json,shutil
from sdd.runtime_evidence import sha256
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';old=w/'notes-final-upstream-v2';out=w/'notes-final-upstream-v3';shutil.copytree(old,out)
changes=[]
for name in ['README.md','root-README.md']:
 p=out/name;text=p.read_text(encoding='utf-8');fixed=text.replace('\\n','\n')
 assert fixed.replace('\n','\\n')==text.replace('\n','\\n')
 p.write_text(fixed,encoding='utf-8');changes.append(dict(path=name,native_draft_sha256=sha256(old/name),formatted_sha256=sha256(p),operation='Decode literal escaped newlines to Markdown line separators; wording unchanged'))
(out/'newline-normalization.json').write_text(json.dumps(changes,indent=2)+'\n',encoding='utf-8')
text=(r/'build/review-final-upstream-notes.py').read_text().replace("out=w/'reviews/final-upstream-notes'","out=w/'reviews/final-upstream-notes-v3'").replace("w/'notes-final-upstream/","w/'notes-final-upstream-v3/")
(r/'build/review-final-upstream-notes-v3.py').write_text(text,encoding='utf-8')
exec(compile(text,str(r/'build/review-final-upstream-notes-v3.py'),'exec'),{'__file__':str(r/'build/review-final-upstream-notes-v3.py'),'__name__':'__main__'})
