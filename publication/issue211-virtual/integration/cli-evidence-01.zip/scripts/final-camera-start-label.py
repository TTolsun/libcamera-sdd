from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='camera-start-label'
b=w/('before-'+tag);b.mkdir()
for name in ['config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='submission-gate':
   v['prompt']=v['prompt'].split('아래 초안')[0]+' 현재 유효한 열 노드와 모든 표시·인용·guard·간선을 정확히 보존하고 n9의 한국어 label과 영어 label_en만 고칩니다. n9는 camera_->start() 실패 여부이므로 더 넓은 카메라 세션 시작이라고 쓰지 않고 카메라 시작 실패 여부만 짧게 묻습니다. camera session이라는 영어와 카메라 세션이라는 한국어를 제거합니다. 다른 모든 필드를 바꾸지 않습니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
   for key in ['answer_contract','answer_contract_en']:v[key]['reject_patterns'].append(dict(pattern=r'(?m)^[^·\n]*(?:카메라 세션|camera session)',message='This gate checks camera_->start(), not all of CameraSession::startCapture.'))
  if v['id']=='reproduction-flow':
   v['prompt']='현재 유효한 열 노드·모든 인용·간선·조건을 정확히 보존하고 device_verify 한영 라벨만 고칩니다. 실행 전 검사 6–11번이 모두 통과해야 한다는 기존 명시적 참조를 유지하며, 그 중 실제 cam 명령에 전달할 캡처 한도 3의 확인을 짧게 같은 질문에 포함합니다. 모든 실행에서 한도 3이 필요하며 도우미를 쓸 때만 해당하는 조건이 아닙니다. 도우미 사용 시 인자 전달 경로 확인도 11번에 포함되어 있습니다. 원시 대입 연산자와 명령 문자열은 사용하지 않고 한국어 cam 캡처 한도 3, 영어 cam capture limit 3처럼 말로 씁니다. 긴 커널·권한·크기 목록은 6–11번 절차에 남겨 반복하지 않습니다. 하나라도 불일치하면 캡처하지 않는 두 간선과 나머지 표시를 정확히 보존합니다. 노드 96자 이내입니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
   v['answer_contract']['required_terms'].append(['cam 캡처 한도 3']);v['answer_contract_en']['required_terms'].append(['cam capture limit 3'])
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-start-gate.py').read_text().replace('start-gate',tag)
(r/'build/after-virtual-camera-start-label.py').write_text(text,encoding='utf-8')
