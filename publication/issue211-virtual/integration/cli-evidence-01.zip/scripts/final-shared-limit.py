from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='shared-limit'
b=w/('before-'+tag);b.mkdir()
for name in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());t=next(t for s in x['sections'] if s['id']=='official-cam-validation' for t in s['design_topics'] if t['id']=='flow')
 for part in t['parts']:
  if part['id']=='submission-limit':
   part['question']='처리 수와 제출 시도 수는 같은 캡처 한도 값과 각각 비교된다는 관계를 첫 짧은 문장으로 씁니다. 한도가 설정되어 있고 제출 시도 수가 그 한도에 이미 도달했으면 도우미가 이번 제출을 생략한다는 조건을 둘째 짧은 문장으로 씁니다. 한도 값이 둘이라고 쓰지 않습니다. 서로 다른 것은 카운터와 검사 시점이며 한도 값은 공유합니다. 내부 필드 이름·카운터 증가·반환값은 근거에 남깁니다.'
   part['answer_contract'].setdefault('reject_patterns',[]).append(dict(pattern='별개.{0,10}한도|서로 다른.{0,10}한도|별도.{0,10}한도 값',message='Both counters compare against the same capture limit value. Distinguish counters and check points, not two limit values.'))
  if part['id']=='frame-work':
   part['question']='processRequest를 명확한 주어로 삼아 프레임 정보를 출력하고 처리 수를 하나 늘린다는 첫 짧은 문장을 씁니다. 두 번째 짧은 문장도 processRequest를 주어로 명시하여, 설정된 한도에 도달하면 captureDone 신호를 내고 반환한다는 순서를 설명합니다. captureDone이 함수의 주어가 되거나 captureDone이 반환한다고 쓰지 마세요. 두 식별자는 backtick으로 표시하고 내부 카운터 필드 이름은 근거로 남깁니다.'
   part['answer_contract'].setdefault('required_terms',[]).extend([['processRequest'],['captureDone']])
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='reproduction-flow':
   v['max_label_chars']=96
   for key in ['answer_contract','answer_contract_en']:
    v[key]['required_terms']=[g for g in v[key].get('required_terms',[]) if g not in [['cam 캡처 한도 3'],['cam capture limit 3']]]
    v[key]['required_terms'].append(['6–11','6-11','6~11','6 through 11','6 to 11'])
   v['prompt']='현재 유효한 열 노드·모든 인용·간선·조건을 정확히 보존하고 device_verify 표시만 간결하게 고칩니다. 같은 페이지의 번호 절차 6–11번은 실행 커널, root 장치 접근, Virtual2 YAML 크기·패턴, cam 카메라·스트림·3프레임 한도와 도우미 전달 경로를 모두 확인합니다. 따라서 이 판정의 한국어·영어 라벨은 커널·장치·캡처 입력에 대한 실행 전 검사 6–11번을 모두 통과했는지 묻는 짧은 질문으로 씁니다. 단순히 모든 조건이라고 생략하지 말고 절차 번호 6–11을 명시합니다. 긴 값 목록은 번호 절차에 이미 있으므로 노드에 반복하지 않습니다. 모든 검사 통과 때만 실행하며 하나라도 다르면 캡처하지 않는 기존 두 간선은 그대로 유지합니다. 나머지 라벨과 토폴로지를 바꾸지 않습니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
  if v['id']=='submission-gate':
   v['prompt']=v['prompt'].split('아래 초안')[0]+' 현재 유효한 아홉 노드와 모든 인용·guard·간선을 보존하고 n7의 한영 라벨 및 n4→n7의 라벨에서 예약/reservation이라는 단어를 빼세요. 검증을 통과하면 Camera 호출 내부에서 요청 처리를 비동기로 전달한다는 의미를 짧게 표현합니다. 영어는 queue 또는 dispatch 동사를 사용하고 자원 예약으로 읽히는 명사를 쓰지 않습니다. 호출이 반환된 뒤 전달한다는 뜻으로 바꾸지 않습니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
   for key in ['answer_contract','answer_contract_en']:v[key]['reject_patterns'].append(dict(pattern=r'(?m)^[^·\n]*(?:reservation|예약)',message='Express queuing/dispatching request work asynchronously inside the validated camera call, not resource reservation.'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-concise-outcome.py').read_text().replace('concise-outcome',tag)
(r/'build/after-virtual-shared-limit.py').write_text(text,encoding='utf-8')
