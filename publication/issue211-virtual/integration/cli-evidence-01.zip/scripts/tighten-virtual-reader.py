from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='short-labels'
b=w/('before-'+tag);b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(s for s in x['sections'] if s['id']=='official-cam-validation')
 for t in s['design_topics']:
  for part in t['parts']:
   if t['id']=='virtual-principle' and part['id']=='purpose':
    part['question']='고정된 libcamera 소스를 분석한 virtual 파이프라인의 큰 흐름을 세 짧은 평서문으로 설명합니다. 첫 문장은 고정 소스의 분석임을 밝히고, virtual 기능이 실제 센서 대신 Virtual2 400x300 lines 패턴을 공급함을 설명합니다. 둘째 문장은 cam을 주어로 실제 DMA-BUF 버퍼를 확보해 요청에 붙여 제출하는 행동을 씁니다. 셋째 문장은 CPU를 주어로 패턴을 NV12로 변환해 매핑된 DMA-BUF 버퍼에 쓰기를 시도하는 행동을 씁니다. 완료 조건과 제출 순서 통지는 그림 뒤 완료 설명이 맡으므로 이 개요에서는 완료 조건을 새로 요약하지 않습니다.'
   if t['id']=='reproduce' and part['id']=='yaml-check':
    part['question']="statement.text를 '8. '로 시작하세요. 사용할 Virtual2 YAML에서 크기가 400x300이고 테스트 패턴 값이 lines인지 각각 확인하는 행동을 한 짧은 평서문으로 씁니다. 필드 경로를 만들거나 lines를 크기와 별도의 독립 패턴처럼 표현하지 않습니다."
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  ref=m['generated_visuals']['records'][v['id']]['draft'];ref=json.loads(json.dumps(ref))
  nodes=ref['nodes'].values() if isinstance(ref['nodes'],dict) else ref['nodes']
  for item in [*nodes,*ref['edges']]:
   item.pop('label',None);item.pop('label_en',None)
  v['max_edge_label_chars']=20;v['max_label_chars']=72 if v['id']=='reproduction-flow' else 52
  v['prompt']='현재 그래프의 구조·소스 인용을 유지하고 한영 라벨을 새로 간결하게 작성하세요. 노드는 한 행동 또는 한 질문, 간선은 1~3단어의 짧은 관계나 결과만 표시합니다. 노드의 전체 조건이나 행동을 간선에 반복하지 않습니다. 실제 조건은 condition_ref와 인용에서 유지하고 true/false는 자동 표시를 사용합니다. 함수·변수 이름은 source symbol과 근거에서 보존하며 화면은 쉬운 행동으로 설명합니다. 노드와 간선의 ID·shape·quote_ids, from·to·condition_ref 및 분기·반복·후속 처리 구조는 그대로 유지합니다. 한국어와 영어의 주체·조건·결과는 같습니다. 각 간선의 한영 authored 라벨은 20자 이하입니다. 실패를 성공으로 바꾸거나 호출을 제출 성공으로 강화하지 않습니다. '
  if v['id']=='virtual-frame-path':v['prompt']+='CPU가 Virtual2 lines 패턴을 NV12로 변환해 mapped buffer에 쓰기를 tries/attempts한다는 의미와 쓰기 동기화 범위를 보존합니다. 변환 오류의 FrameError/FrameSuccess 상태 구분, 상태와 무관한 버퍼 완료 신호를 유지합니다. n6는 버퍼 완료 신호만 설명합니다. '
  if v['id']=='request-completion-order':v['prompt']+='n1은 해당 요청의 모든 버퍼 완료 여부, n2는 그 요청의 남은 FrameBuffer 완료 대기입니다. n3은 현재 요청 완료 표시, n4는 제출 큐 비어 있지 않은지 반복 검사, n5는 맨 앞 요청의 RequestPending 검사입니다. n6는 완료된 큐 맨 앞을 꺼내 cam에 순서대로 통지하고 n4로 반복합니다. n7은 후속 대기 요청 처리이며 함수 종료라고 단정하지 않습니다. '
  if v['id']=='completion-flow':v['prompt']+='기록된 출력 싱크 미요청 경로입니다. 취소 시 requestComplete 반환, callLater 후 이벤트 루프 processRequest 진입, 한도 설정 AND 도달의 진입 검사와 증가 후 검사, 서로 다른 반환·captureDone 결과, Request::ReuseBuffers 후 제출 도우미 호출을 구분합니다. '
  if v['id']=='submission-gate':v['prompt']+='세 노드로 한도 설정 AND 제출 카운터 도달 판정, 제출 없는 반환, 카운터 증가 후 실제 카메라 제출 시도를 구분합니다. 도우미 진입 이전 재사용을 다시 그리지 않습니다. '
  if v['id']=='reproduction-flow':
   v['prompt']+='무영향 조사→계획→실행 직전 별도 호스트 승인→필요할 때만 Docker 중지→시험 커널 설치·부팅→조건 일치 검사→세 독립 cam 실행→새 결과 검증입니다. 조건 불일치 시 실행하지 않는 분기를 유지합니다. 조건 검사는 기록된 커널, root의 /dev/udmabuf 접근, YAML의 400x300 lines, cam Virtual2/400x300 NV12를 구분합니다. '
   for key in ['answer_contract','answer_contract_en']:v[key]['required_terms'].extend([['YAML'],['lines']])
  v['prompt']+='아래는 라벨을 제거한 기존 구조이며 실제 새 CLI가 라벨을 작성하고 모든 검사를 통과해야 합니다. 구조: '+json.dumps(ref,ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-bound-preflight.py').read_text().replace('bound-preflight',tag)
anchor="prefix=[sys.executable,'-X','utf8']"
text=text.replace(anchor,"exec(compile((r/'build/translate-virtual-procedure.py').read_text(encoding='utf-8'),str(r/'build/translate-virtual-procedure.py'),'exec'))\n"+anchor)
(r/'build/after-virtual-short-labels.py').write_text(text,encoding='utf-8')
