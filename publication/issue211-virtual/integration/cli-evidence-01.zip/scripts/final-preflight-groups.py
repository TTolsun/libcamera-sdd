from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='preflight-groups'
b=w/('before-'+tag);b.mkdir()
for name in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());t=next(t for s in x['sections'] if s['id']=='official-cam-validation' for t in s['design_topics'] if t['id']=='reproduce');parts=t['parts']
 module=next(p for p in parts if p['id']=='modules');provider=next(p for p in parts if p['id']=='providers');i=parts.index(module);j=parts.index(provider);assert j==i+1
 parts[i],parts[j]=provider,module;provider['question']=provider['question'].replace("'3. '","'2. '");module['question']=module['question'].replace("'2. '","'3. '")
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='reproduction-flow':
   v['max_nodes']=12;v['required_symbols']+=['YAML','cam']
   v['prompt']='기존 열 노드의 준비·승인·설치·실행·결과와 실제 source 인용을 보존하면서 긴 실행 전 검사 노드를 세 개의 짧은 decision으로 나눕니다. 기존 device_verify(udmabuf)는 6–11번 실행 전 검사 중 실행 중인 커널이 기록된 커널과 일치하고 root가 /dev/udmabuf에 접근할 수 있는지 묻습니다. 이 노드에 기록/recorded, root, /dev/udmabuf 및 6–11 참조를 짧고 완전한 질문으로 포함합니다. 새 yaml_check(YAML)는 Virtual2 YAML의 400x300 크기와 lines 패턴을 하나의 구성 조합으로 확인합니다. 새 cam_check(cam)는 실제 명령의 카메라 Virtual2, 스트림 400x300 NV12와 cam 캡처 한도 3/cam capture limit 3을 확인하며, 도우미 사용 시 인자 전달 경로도 확인한다는 뜻을 짧게 담습니다. 원시 대입 연산자는 쓰지 않습니다. device_verify 통과→yaml_check 통과→cam_check 통과→run_cam으로 이어지고 세 검사 중 하나라도 불일치하면 기존 mismatch_stop으로 갑니다. 기존 run_cam 이후 result_verify 및 다른 준비·승인·Docker 분기는 유지합니다. 각 새 간선은 두 끝점의 실제 source 인용을 포함합니다. 두 언어 모두 문장·질문으로 읽히게 쓰고 서로 다른 검사값을 키워드 나열 하나로 합치지 않습니다. 총12노드, 노드96자·간선20자 이내입니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
  if v['id']=='virtual-frame-path':
   v['prompt']='현재 유효한 아홉 노드·한영 라벨·source guard·인용·간선을 정확히 보존하고 n1에서 n2로 가는 취소 true 간선의 label/label_en만 고칩니다. 이 간선은 취소 요청을 완료 처리하는 분기로 진행한다는 뜻이며 즉시 통지한다는 뜻이 아닙니다. 통지 또는 보류는 다음 n2와 완료 순서 그림이 이미 정확히 설명합니다. 따라서 취소 완료 처리로 진행한다는 짧은 표현으로 쓰고 notify/통지라는 동사를 이 간선에서 제거합니다. 다른 모든 표시와 인용은 바꾸지 않습니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-camera-start-label.py').read_text().replace('camera-start-label',tag)
text=text.replace("prefix=[sys.executable,'-X','utf8']", "exec((r/'build/translate-preflight-choice-steps.py').read_text(encoding='utf-8'))\nprefix=[sys.executable,'-X','utf8']")
(r/'build/after-virtual-preflight-groups.py').write_text(text,encoding='utf-8')
helper=(r/'build/translate-connected-module-step.py').read_text().replace('connected-scope','preflight-groups').replace('row[0]==2','row[0] in [2,3]').replace("'minItems':1,'maxItems':1","'minItems':2,'maxItems':2").replace('assert len(values)==1','assert len(values)==2')
start=helper.index("system='Translate this one Korean module-preparation instruction")
end=helper.index('\nschema=',start)
helper=helper[:start]+"system='Translate these two Korean preparation instructions into concise imperative English in source order: select an allocator, then investigate only modules required by the selected kernel and allocator. Preserve the recorded built-in udmabuf/no separate module installation fact and every source condition and opaque {{number}} token with exact counts. Begin actions with verbs. Return JSON translations with exactly two strings. Add no facts, warnings or completed fresh-run claims.'"+helper[end:]
(r/'build/translate-preflight-choice-steps.py').write_text(helper,encoding='utf-8')
