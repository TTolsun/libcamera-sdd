from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,sys,shutil
from sdd.runtime_evidence import run_recorded,require_success,sha256
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-reader-release'
catalog=d/'run/english-latest-main-preview-v2.json';data=json.loads(catalog.read_bytes());missing=[k for k,v in data['strings'].items() if not v]
root=w/'latest-catalog-translation-v3';root.mkdir();chunks=[missing[i:i+96] for i in range(0,len(missing),96)]
def worker(item):
 n,values=item;part=root/f'part-{n:02d}';part.mkdir();sources=part/'sources.json';sources.write_text(json.dumps(values,ensure_ascii=False),encoding='utf-8');out=w/'executions'/f'latest-catalog-v3-part-{n:02d}'
 argv=[sys.executable,'-X','utf8',str(g/'examples/libcamera/validation/issue211-virtual/translate_partition.py'),'--config',str(w/'latest-translation-writer.yaml'),'--catalog',str(catalog),'--sources',str(sources),'--out',str(part/'result.json'),'--prompts',str(part/'prompts')]
 run_recorded(out,argv,timeout=1800,cwd=r,environment={'PYTHONPATH':str(g/'src'),'PYTHONIOENCODING':'utf-8'});require_success(out)
 return n,values,part
results=[]
with ThreadPoolExecutor(max_workers=3) as pool:
 tasks=[pool.submit(worker,item) for item in enumerate(chunks,1)]
 for task in as_completed(tasks):
  row=task.result();results.append(row);print('Partition completed',row[0],len(row[1]),flush=True)
for n,values,part in sorted(results):
 translated=json.loads((part/'result.json').read_bytes())
 for key in values:data['strings'][key]=translated['strings'][key]
 # Keep original native UUID folders and receipt bytes for core authentication.
 for calls in (part/'prompts').rglob('calls'):
  for source in calls.iterdir():
   if not source.is_dir():continue
   target=d/'build/translation-prompts/calls'/source.name
   if target.exists():raise ValueError('Native call UUID collision')
   shutil.copytree(source,target)
assert all(data['strings'].values());shutil.copyfile(d/'run/english.json',w/'before-latest-main-ff916/english-before-authenticated-migration.json')
(d/'run/english.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(w/'latest-catalog-translation-v3.json').write_text(json.dumps({'schema':1,'catalog_sha256':sha256(d/'run/english.json'),'translated_sources':len(missing),'partitions':len(chunks),'runner':'claude','model':'claude-haiku-5-5','human_review':'pending','independent_grounding':'required'},indent=2)+'\n',encoding='utf-8')
print('Native catalog translation complete; independent review remains required')
