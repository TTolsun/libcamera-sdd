from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='reader-copy'
b=w/('before-'+tag);b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
questions={
 'environment':"statement.text를 '1. '로 시작하고, 호스트를 바꾸지 않는 준비로 사용할 커널의 Kconfig와 의존 조건을 조사한다는 행동 하나만 짧은 한 문장으로 쓰세요. 심볼 이름 목록, bool 설명, 배포판 설명은 근거 영역에 있습니다.",
 'modules':"statement.text를 '2. '로 시작하여 사용할 커널이 지원하는 모듈을 조사하는 행동 하나를 쓰세요. WSL 배포판을 추가해도 커널은 공유된다는 조건만 짧은 둘째 문장으로 남기세요. UDMABUF bool과 의존 심볼 목록은 근거 영역에 있습니다.",
 'providers':"statement.text를 '3. '로 시작하여 조사 결과에 맞는 DMA-BUF 할당기를 선택한다고 짧게 쓰세요. 이 기록과 같은 조건으로 재현할 때는 udmabuf가 필요하다는 한정을 둘째 문장에 남기세요.",
 'approval':"statement.text를 '4. '로 시작하세요. 이미지·해시, 영향, 백업·복구 절차를 갖춘 호스트 변경 계획을 마련하고 실행 직전에 별도 승인을 받는다는 계획 과업을 짧게 쓰세요. Docker는 승인 계획에서 필요한 경우에만 중지한다고 짧은 둘째 문장에 남기세요. PR 승인이 호스트 승인을 대신할 수 없다는 조건은 그림과 연결된 근거에 이미 있습니다. 긴 경고나 다른 준비 과업을 반복하지 않습니다.",
 'stream-request':"statement.text를 '10. '로 시작하여 사용할 cam 스트림 인자가 400x300 NV12를 요청하는지 확인하는 행동을 한 짧은 문장으로 쓰세요. 둘째 짧은 문장은 지금까지의 모든 사전 확인 조건이 일치할 때만 캡처한다는 하나의 시작 조건입니다. all preceding checks의 범위이며 직전 카메라 선택 한 단계에 한정되지 않습니다. 조건 목록이나 과거 명령 해설을 다시 나열하지 마세요."
}
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(s for s in x['sections'] if s['id']=='official-cam-validation')
 purpose=next(p for t in s['design_topics'] if t['id']=='virtual-principle' for p in t['parts'] if p['id']=='purpose')
 purpose['question']+=' 최종 문장 편집: cam의 DMA-BUF 확보와 요청 제출은 cam을 주어로 하는 완결된 평서문으로 씁니다. CPU의 NV12 쓰기 시도와 조건부 완료 통지는 다음 문장으로 구분하세요. 문장 주어가 바뀔 때 조건절로 연결하지 마세요. virtual 기능·고정 소스 분석·Virtual2 400x300 lines 패턴과 큰 처리 순서는 그대로 유지합니다.'
 for t in s['design_topics']:
  if t['id']=='reproduce':
   for part in t['parts']:
    if part['id'] in questions:
     part['question']=questions[part['id']]
     part['prompt']='이 단계의 독자 행동과 필요한 조건만 짧게 직접 씁니다. 구현 심볼 목록, 다른 단계 설명, 반복 경고, 근거 자료 자체에 관한 해설을 덧붙이지 마세요.'
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='virtual-frame-path':
   edit='n6의 한영 라벨만 짧게 편집하세요. 프레임 상태와 무관하게 버퍼 완료 신호를 보낸다는 동작 하나만 표시하세요. 성공 여부의 설명은 다음 본문이 맡으므로 n6에서는 성공이라는 단어와 그 인과 설명을 빼세요. 다른 노드·간선의 올바른 라벨은 보존합니다.'
  elif v['id']=='request-completion-order':
   edit='모든 노드와 간선을 짧은 한영 동작 또는 질문으로 편집하세요. n0 버퍼 완료 신호 수신, n1 해당 요청의 모든 버퍼가 완료됐는가, n2 요청의 남은 FrameBuffer 완료 대기, n3 요청 완료 표시, n4 제출 큐에 요청이 남았는가, n5 맨 앞 요청이 아직 Pending인가, n6 완료된 큐 맨 앞을 꺼내 cam에 순서대로 통지, n7 후속 대기 요청 처리라는 역할을 유지합니다. 노드는 한 가지 질문·동작만, 간선은 대기·완료 처리·보류·다음 요청처럼 짧은 관계만 표시하여 노드의 조건을 반복하지 않습니다. true/false는 시스템 표시를 사용합니다. 긴 구현 함수·변수명은 source symbol과 근거에서 보존하고 화면 라벨에서는 꼭 필요한 FrameBuffer·Pending·cam 외에 나열하지 않습니다. 모든 기존 분기, 큐 비어 있음 검사, 큐 반복과 이어지는 후속 작업의 의미는 유지합니다.'
  else:continue
  v['prompt']=edit+' 현재 검증된 초안의 노드 ID·shape·quote_ids, 모든 간선 from·to·condition_ref·quote_ids를 그대로 보존하세요. 참고 초안은 실제 새 native CLI 응답의 편집 입력이며 저장 응답의 재생이나 새 실행 증거가 아닙니다. 참고 초안: '+json.dumps(m['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
(r/'build/after-virtual-reader-copy.py').write_text((r/'build/after-virtual-bound-preflight.py').read_text().replace('bound-preflight',tag),encoding='utf-8')
