from pathlib import Path
import json,sys,subprocess
from sdd.config import load
from sdd.generated_visuals import plans
from sdd.runtime_evidence import run_recorded,require_success
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';g=r/'build/generator-reader-release';suffix=sys.argv[1] if len(sys.argv)>1 else 'current-main';fresh=w/('fresh-reviewed-recipe-'+suffix);out=w/'executions'/('reviewed-recipe-prepare-'+suffix)
run_recorded(out,[sys.executable,'-X','utf8',str(g/'examples/libcamera/validation/issue211-virtual/prepare.py'),'--previous',str(r/'build/issue211-reader'),'--work',str(fresh)],timeout=600,cwd=g);require_success(out)
cfg=load(fresh/'generation.yaml');section=next(s for s in cfg.sections() if s['id']=='official-cam-validation');topics=section['design_topics'];assert [t['id'] for t in topics]==['conclusion','virtual-principle','initial-preparation','initial-submission','flow','reproduce']
for topic in topics:
 ids=[s['id'] for s in topic['sources']];assert len(ids)==len(set(ids))
 for part in topic.get('parts',[]):assert len(part['sources'])==len(set(part['sources'])) and set(part['sources'])<=set(ids)
figures=plans(cfg,section);assert len(figures)==6
assert (cfg.agent.runner,cfg.agent.model,cfg.agent.args)==('claude','claude-haiku-5-5',['--effort','high','--setting-sources','project,local'])
review=load(fresh/'new-document-review.yaml');assert (review.agent.runner,review.agent.model,review.agent.args)==('codex','gpt-6.1-terra',['-c','model_reasoning_effort="high"'])
assert review.agent.max_input_chars==160000
assert json.loads((fresh/'run/facts/facts.json').read_bytes())['meta']['source_commit']=='293d751a814e0d4c34e85ad457ccd9d5eefd1a61'
record={'schema':1,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=g,text=True).strip(),'topic_order':[t['id'] for t in topics],'figures':[{k:p[k] for k in ['id','topic','max_nodes']} for p in figures],'unique_bound_part_sources':True,'scope':'Fresh source-recipe preparation and actual configuration loading, not new generation calls or runtime capture; copied receipts remain historical.'}
(w/'final-recipe-preparation.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps(record))
