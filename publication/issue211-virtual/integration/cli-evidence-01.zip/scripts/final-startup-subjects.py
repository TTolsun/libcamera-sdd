from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='startup-subjects'
b=w/('before-'+tag);b.mkdir()
for name in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());t=next(t for s in x['sections'] if s['id']=='official-cam-validation' for t in s['design_topics'] if t['id']=='initial-requests');a=t['parts'][0]
 a['question']+=' 제출 한도를 검사한 뒤 모든 요청을 무조건 카메라 큐 호출로 넘긴다고 쓰지 마세요. 한도가 이미 찼으면 도우미가 카메라 큐 호출 없이0을 반환해 제출을 생략하고, 한도가 미설정이거나 아직 미달일 때에만 카메라 큐 호출로 진행한다는 분기를 명시합니다. 이 조건은 영어에서도 보존합니다. 범위·전체 준비 뒤 시작·검증 결과·오류 중지를 짧은 한 문단으로 유지합니다.'
 a['answer_contract']['required_terms'] += [['한도'],['생략','제출하지','큐 호출 없이']]
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='virtual-frame-path':
   edit='현재 아홉 노드·모든 간선·조건·인용·한영 의미를 정확히 보존하고 n0 표시만 고칩니다. 이 그림이 페이지의 첫 그림이므로 앞 그림/Prior figure라는 존재하지 않는 참조를 제거합니다. cam이 실제 DMA-BUF 버퍼를 연결한 요청을 PipelineHandler가 준비한다는 관계를 n0 한영 라벨에서 직접 표현합니다. 실제 cam 버퍼 연결과 pipeline 요청 준비 소스를 함께 인용합니다. n0의 실제 PipelineHandler::queueRequest symbol은 유지합니다. 다른 라벨과 동기화·생성·취소·신호 분기는 바꾸지 않습니다. '
  elif v['id']=='submission-gate':
   v['max_label_chars']=72
   edit='현재 단일 스트림·출력 싱크 미요청 범위의11노드, 모든 간선·실제 조건·인용을 보존하고 n4의 한영 표시만 고칩니다. n4는 카메라 큐 호출이라는 주어와 요청 검증을 먼저 명시하고, 검증 실패는 오류 반환이며 통과는 비동기 전달 뒤0반환이라는 두 가능한 호출 결과를 짧게 표현합니다. 영어의 Check fail / Pass처럼 주어와 호출을 생략하지 마세요. Camera queue call 또는 Camera queue를 주어로 쓰고 validates/validation으로 요청 검증임을 드러냅니다. 최대72자이므로 명확한 주어·조건·반환 관계를 생략할 필요가 없습니다. 다른 노드·간선은 기존 간결한 표시를 유지합니다. '
  else:continue
  v['prompt']=edit+'한영 노드72자·간선20자 한도를 지킵니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-startup-topic-v3.py').read_text().replace('startup-topic-v3',tag)
(r/'build/after-virtual-startup-subjects.py').write_text(text,encoding='utf-8')
