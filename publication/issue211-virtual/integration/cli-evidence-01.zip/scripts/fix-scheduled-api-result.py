from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';b=w/'before-scheduled-api-result';b.mkdir()
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 for rel in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
  target=b/root.name/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,target)
 p=root/'config/sections.yaml';data=yaml.safe_load(p.read_bytes());s=next(s for s in data['sections'] if s['id']=='official-cam-validation');t=next(t for t in s['design_topics'] if t['id']=='initial-submission');part=t['parts'][0]
 part['question']+=' 성공이라는 말의 주어는 실제로 수행한 카메라 큐 API 호출로 명시합니다. 한도 때문에 제출을 생략한 도우미도0을 반환하므로 도우미의 성공이나 일반적인 성공을 비동기 제출과 동치로 쓰지 않습니다. 실제 API 호출의 성공은 비동기 호출 예약이며 실제 전달·실행·처리가 완료됐다는 뜻이 아닙니다. 기존 두 문장220자 이내를 지킵니다.'
 part['answer_contract']['reject_patterns'].append({'pattern':'성공은\\s*비동기','message':'Qualify success as the actual camera queue API invocation; the helper can also return zero without submission.'})
 p.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';data=yaml.safe_load(p.read_bytes())
 for v in data['sections']['official-cam-validation']:
  if v['id']!='initial-submission':continue
  v['prompt']='현재 열한 노드·모든 간선·실제 조건·인용·한영 표시를 그대로 보존하고 API 성공 결과 노드의 한영 라벨만 고칩니다. 그 결과는 비동기 호출을 예약한 뒤0을 반환한 것이며 실제 전달·실행·처리가 이미 완료된 것은 아닙니다. 성공 노드에는 예약과0반환이라는 두 짧은 동작만 표시하고 이미 수행/전달 완료/was already performed 같은 표현을 제거합니다. 예약은 실제 API 호출 안에서 반환 전에 이뤄지며 도우미 반환값 검사 뒤에 새로 발생하는 동작으로 옮기지 않습니다. 다른 노드·간선·짧은 라벨과 한도는 그대로 둡니다. 다음은 native 편집 대상 초안입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
  v['answer_contract_en'].setdefault('reject_patterns',[]).append({'pattern':'already performed|delivery.{0,15}completed','message':'A queued invocation is scheduled before return, not completed delivery or execution.'})
 p.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
