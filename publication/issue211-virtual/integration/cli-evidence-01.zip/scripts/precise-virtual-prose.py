from pathlib import Path
import yaml,shutil
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-main-integration'
b=w/'before-precise-flow';b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml']:
 dest=b/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,dest)
def revise(t):
 if t['id']=='flow':
  for p in t['parts']:
   if p['id']=='frame-work':
    p['question']='이미 앞 항목의 진입 검사를 통과한 지점부터 설명하세요. 프레임 정보를 출력하고 captureCount_를 늘린 뒤, 한도가 설정되어 있고 증가한 처리 수가 도달하면 captureDone을 내고 processRequest에서 반환한다고 두 짧은 문장 이내로 쓰세요. 앞 항목의 진입 검사 자체를 반복하지 마세요.'
    p.setdefault('answer_contract',{'basis':'implementation'}).setdefault('reject_patterns',[]).append({'pattern':'진입|먼저.*확인','message':'Start after the entry gate; it is already explained in the previous item.'})
   if p['id']=='reuse-request':
    p['question']='처리를 계속할 요청은 Request::ReuseBuffers로 버퍼를 유지해 재사용한 뒤 CameraSession::queueRequest 도우미를 호출한다고 한 문장으로만 쓰세요. 도우미 호출을 큐에 넣음·실제 제출·재제출 성공으로 단정하지 마세요. 도우미 내부 제출 한도는 다음 항목에서 설명합니다.'
    p.setdefault('answer_contract',{'basis':'implementation'}).setdefault('reject_patterns',[]).append({'pattern':'큐에|다시 제출|재제출|requeue|성공','message':'The helper is called; actual submission is conditional and belongs to the next item.'})
   if p['id']=='invocation-scope':
    p['question']='세 실제 실행 명령은 화면·파일 출력 옵션을 요청하지 않았다는 사실과, 다른 출력 옵션의 비동기 보유 경로는 이번 실행 검증 범위가 아니라는 경계를 두 짧은 문장으로만 설명하세요. 옵션별 내부 구현은 접힌 소스 근거에 남깁니다.'
    p['answer_contract']['reject_patterns']=[{'pattern':'SDL|sink_|CameraSession::start','message':'Keep this invocation boundary short; optional implementation details remain in source evidence.'}]
 if t['id']=='virtual-principle':
  p=next(x for x in t['parts'] if x['id']=='buffer')
  p['question']='가상 영상도 실제 버퍼가 필요하며, virtual 파이프라인이 DMA-BUF를 할당하고 cam이 Request에 붙인다고 설명하세요. 선택한 NV12 경로는 쓰기 방향 DmaSyncer 범위에서 버퍼를 매핑하고 CPU가 패턴을 NV12로 변환해 매핑된 버퍼에 쓰기를 시도한다고 설명하세요. 변환·쓰기 성공을 무조건 보장하지 마세요. 두세 짧은 문장만 쓰고 모든 호출 계층이나 다른 항목의 경고는 반복하지 마세요.'
  p.setdefault('answer_contract',{'basis':'implementation'}).setdefault('required_terms',[]).append(['시도'])
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(t for t in x['sections'] if t['id']=='official-cam-validation')
 for t in s['design_topics']:revise(t)
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
p=g/'examples/libcamera/validation/issue211-reader/section.yaml';x=yaml.safe_load(p.read_bytes())
for t in x['design_topics']:revise(t)
p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
p=g/'examples/libcamera/validation/issue211-virtual/topic.yaml';x=yaml.safe_load(p.read_bytes());revise(x);p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
s=(r/'build/after-virtual-final-rendered.py').read_text().replace("generate-final-scope","generate-precise-flow").replace('final-rendered','precise-flow');(r/'build/after-virtual-precise-flow.py').write_text(s)
