from pathlib import Path
import yaml,shutil
r=Path(__file__).resolve().parent.parent;g=r/'build/generator-main-integration';w=r/'build/issue211-virtual';d=w/'current-main-integration'
b=w/'before-final-clarity';b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','run/facts/facts.json','config/sections.yaml','config/visuals.yaml']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
p=g/'examples/libcamera/validation/issue211-reader/section.yaml';section=yaml.safe_load(p.read_bytes());flow=next(t for t in section['design_topics'] if t['id']=='flow')
for part in flow['parts']:
 part['prompt']=part.get('prompt','')+' 이 항목의 질문에만 한두 짧은 문장으로 답하세요. 출력 싱크 미요청 전제는 invocation-scope에서 한 번만 설명하므로 다른 항목에는 반복하지 마세요. 앞 항목의 조건을 다시 설명하지 마세요.'
 if part['id']=='frame-work':part['question']='진입 검사를 통과하면 프레임 정보를 출력하고 captureCount_를 늘립니다. 증가 후 설정 한도에 도달하면 captureDone을 내고 processRequest를 반환한다는 처리만 간결하게 설명하세요.'
 if part['id']=='reuse-request':part['question']='처리를 계속할 요청은 Request::ReuseBuffers로 버퍼를 유지해 재사용하고 CameraSession::queueRequest 도우미를 호출한다는 동작만 한 문장으로 설명하세요.'
 if part['id']=='submission-limit':part['question']='queueCount_는 카메라 제출을 시도하기 전에 증가하는 별도 카운터이며 성공한 접수 개수가 아님을 설명하세요. 한도가 설정되고 이 카운터가 이미 도달하면 CameraSession::queueRequest가 실제 제출 없이 반환하고, 그 밖에는 카운터를 늘린 뒤 제출을 시도한다는 관계를 두 짧은 문장으로 쓰세요.'
p.write_text(yaml.safe_dump(section,allow_unicode=True,sort_keys=False),encoding='utf-8')
p=g/'examples/libcamera/validation/issue211-virtual/visual.yaml';v=yaml.safe_load(p.read_bytes());v['prompt']+=' 마지막 보완: 준비부터 CPU 변환까지의 노드 중 하나에 Virtual2의 lines 패턴 설정이 입력이며 CPU가 이 패턴을 NV12로 변환한다는 관계를 반드시 명시하세요. n8 requestCompleted의 화면 라벨에 requestCompleted 신호와 cam 통지를 표시하세요. 긴 식별자를 보존하기 위해 이 노드는 72자 이내를 허용합니다. n0은 기존 cam·virtual 할당 주체를 유지하고 n4 변환 노드에 lines 패턴 입력을 넣을 수 있습니다. 기존 분기와 노드 수를 유지합니다.'
for key in ['answer_contract','answer_contract_en']:v[key]['required_terms'] += [['lines'],['requestCompleted']]
p.write_text(yaml.safe_dump(v,allow_unicode=True,sort_keys=False),encoding='utf-8')
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(t for t in x['sections'] if t['id']=='official-cam-validation');s['design_topics']=[flow if t['id']=='flow' else t for t in s['design_topics']];p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());x['sections']['official-cam-validation']=[v if z['id']==v['id'] else z for z in x['sections']['official-cam-validation']];p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
s=(r/'build/after-virtual-edge-clarity-v3.py').read_text().replace('edge-clarity-v3','final-clarity');(r/'build/after-virtual-final-clarity.py').write_text(s)
