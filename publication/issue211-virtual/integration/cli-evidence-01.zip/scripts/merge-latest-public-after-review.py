from pathlib import Path
import json,sys,subprocess,shutil
from sdd.runtime_evidence import run_recorded,require_success,sha256
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';repo=r/'build/libcamera-sdd-issue211';d=w/'current-main-integration';tag=sys.argv[1]
review=json.loads((w/'reviews'/tag/'review.json').read_bytes())['review'];assert review['verdict']=='pass' and not review['findings']
inv=json.loads((w/'windows'/tag/'inventory.json').read_bytes())
for lang,path in [('ko','official-cam-validation.html'),('en','en/official-cam-validation.html')]:assert sha256(repo/'docs'/path)==inv[lang]['html_sha256']
expected=(repo/'docs/site-manifest.json').read_bytes();before=w/'before-final-public-merge';before.mkdir(exist_ok=False);(before/'site-manifest.json').write_bytes(expected);shutil.copyfile(repo/'README.md',before/'README.md')
base=subprocess.check_output(['git','rev-parse','origin/main'],cwd=repo,text=True).strip();assert base=='7d824a9753721edd86a4b509a979230033532f9c'
def run(name,args,success=True):
 out=w/'executions'/name;rec=run_recorded(out,args,timeout=600,cwd=repo)
 if success:require_success(out)
 return rec
merge_head=subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=repo,text=True).strip()
assert merge_head in ['14ee8354c5b185d90c935de22f556930bc2412b2',base]
assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=repo)
if merge_head!=base:
 run('public-main-checkpoint-stage',['git','add','docs'])
 run('public-main-checkpoint-commit',['git','-c','user.name=TTolsun','-c','user.email=112919054+TTolsun@users.noreply.github.com','commit','-m','Integrate the published SDD base before final evidence packaging'])
 merge=run('public-latest-main-merge',['git','-c','user.name=TTolsun','-c','user.email=112919054+TTolsun@users.noreply.github.com','merge','--no-commit','origin/main'],success=False);assert merge['exit_code'] in [0,1]
 run('public-latest-docs-base',['git','restore','--source=origin/main','--staged','--worktree','--','docs','README.md','.gitattributes'])
 run('public-latest-root-records',['git','restore','--source=HEAD','--staged','--worktree','--','run.json','generation-receipts.json'])
else:
 assert (repo/'README.md').read_bytes()==subprocess.check_output(['git','show','origin/main:README.md'],cwd=repo)
p=repo/'.gitattributes';text=p.read_text(encoding='utf-8');rule='publication/issue211-virtual/** -text -whitespace'
if rule not in text:p.write_text(text.rstrip()+'\n'+rule+'\n',encoding='utf-8')
assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=repo)
out=w/'executions/final-public-integrated-export';run_recorded(out,[sys.executable,'-X','utf8','-m','sdd.cli','--config',str(d/'publication.yaml'),'export-site','--out',str(repo/'docs')],timeout=1800,cwd=r);require_success(out)
assert (repo/'docs/site-manifest.json').read_bytes()==expected,'Repeated normal export changed reviewed manifest'
for path,digest in json.loads(expected)['outputs'].items():assert sha256(repo/'docs'/path)==digest,path
(w/'repeated-final-export.json').write_text(json.dumps(dict(schema=1,accepted_review=tag,public_base=base,manifest_sha256=sha256(repo/'docs/site-manifest.json'),outputs=len(json.loads(expected)['outputs']),identical_normal_exports=True,latest_root_readme_preserved=True,human_review='pending'),indent=2)+'\n',encoding='utf-8')
print('Latest public main merged locally; identical reviewed site rebuilt normally')
