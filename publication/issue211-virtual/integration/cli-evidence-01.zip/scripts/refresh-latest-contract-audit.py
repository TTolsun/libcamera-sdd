"""Execute canonical contract-review units, then assemble with the normal audit CLI."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,sys,shutil
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.llm import Agent
from sdd.consistency import groups,request,batches,review_store,validate
from sdd.cli_checkpoint import Capture
from sdd.runtime_evidence import run_recorded,require_success,sha256
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration'
cfg=load(d/'independent-review.yaml');model=KnowledgeModel.load(cfg.facts_path)
assert (cfg.agent.kind,cfg.agent.runner,cfg.agent.model,cfg.agent.args)==('cli','codex','gpt-6.1-terra',['-c','model_reasoning_effort="high"'])
backup=w/'before-latest-contract-audit';backup.mkdir(exist_ok=True)
if not (backup/'consistency-review.json').exists():shutil.copyfile(d/'build/consistency-review.json',backup/'consistency-review.json')
prepared=[]
for group in groups(cfg):
    payload=request(cfg,model,group)
    for index,batch in enumerate(batches(payload,max_input_chars=cfg.agent.max_input_chars)):
        prepared.append((group['id'],index,batch))
print('Canonical contract-review batches:',len(prepared),flush=True)
def worker(item):
    group,index,batch=item;store,data=review_store(cfg,batch);cached=store.read()
    if cached is not None:
        saved,_=cached;assert validate(batch,saved['raw'])==saved['statements'];return {'group':group,'index':index,'new_native_call':False,'receipts':[str(store.calls/p) for p in saved['receipts']]}
    capture=Capture(Agent(cfg.agent,d/'build/prompts'))
    raw=capture.chat(data['system'],data['user'],tag=f'consistency_{group}_{index}',response_schema=data['response_schema'])
    checked=validate(batch,raw);store.write(raw,checked,capture);assert capture.receipts
    print(group,index,'native completed',flush=True)
    return {'group':group,'index':index,'new_native_call':True,'receipts':[str(p) for p in capture.receipts]}
with ThreadPoolExecutor(max_workers=3) as pool:records=list(pool.map(worker,prepared))
(w/'latest-contract-native-units.json').write_text(json.dumps({'schema':1,'batches':records,'scope':'Canonical real native CLI calls completed in parallel; normal audit-consistency independently validates and assembles these exact checkpoints. No unavailable/failed model is replaced by saved responses.','human_review':'pending'},indent=2)+'\n',encoding='utf-8')
suffix=sys.argv[1] if len(sys.argv)>1 else ''
out=w/'executions'/('latest-contract-audit-assemble'+suffix)
run_recorded(out,[sys.executable,'-X','utf8','-m','sdd.cli','--config',str(d/'independent-review.yaml'),'audit-consistency'],timeout=1800,cwd=r)
require_success(out)
report=json.loads((d/'build/consistency-review.json').read_bytes());assert report['status']=='passed' and report['human_review']=='pending'
# Bind the freshly assembled automated report in the existing publication gate.
import yaml
for name in ['publication.yaml','generation.yaml','independent-review.yaml']:
    path=d/name;shutil.copyfile(path,backup/name);config=yaml.safe_load(path.read_bytes())
    for row in config.get('publication',{}).get('reports',[]):
        if Path(row['path']).resolve()==(d/'build/consistency-review.json').resolve():row['sha256']=sha256(d/'build/consistency-review.json')
    path.write_text(yaml.safe_dump(config,allow_unicode=True,sort_keys=False),encoding='utf-8')
(w/'latest-contract-audit.json').write_text(json.dumps({'schema':1,'report_sha256':sha256(d/'build/consistency-review.json'),'status':report['status'],'unresolved':len(report['unresolved']),'contracts':len(report['contracts']),'batches':len(prepared),'human_review':'pending'},indent=2)+'\n',encoding='utf-8')
print('Current cross-document contract gate passed',flush=True)
