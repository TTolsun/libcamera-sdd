from pathlib import Path
import yaml,copy,shutil
r=Path(__file__).resolve().parent.parent;g=r/'build/generator-main-integration';w=r/'build/issue211-virtual';d=w/'current-main-integration'
p=g/'examples/libcamera/validation/issue211-reader/section.yaml';c=yaml.safe_load(p.read_bytes());rep=next(t for t in c['design_topics'] if t['id']=='reproduce');base=next(x for x in rep['parts'] if x['id']=='execution')
def action(ident,question,forbidden,required=None):
 item=copy.deepcopy(base);item['id']=ident;item.pop('subquestions',None);item['question']=question;item['prompt']='이 번호가 맡은 독자 과업만 짧은 평서문으로 쓰세요. 다른 번호의 준비·검사를 반복하지 마세요. 과거 실행의 결과를 새 실행의 증거로 사용하지 마세요. 명령·버전·파일 경로는 질문이 필수로 요구한 경우에만 쓰세요.'
 item['answer_contract']={'basis':'measurement','reject_patterns':[{'pattern':forbidden,'message':'이 단계가 아닌 준비·검사나 과거 결과를 반복하지 말고 현재 과업만 설명하세요.'}]}
 if required:item['answer_contract']['required_terms']=required
 return item
boot=action('kernel-boot',"statement.text를 '5. '로 시작하세요. 승인된 계획에 따라 시험 커널을 설치하고 부팅하는 준비 과업만 짧게 설명하세요. 커널 버전 대조와 장치 접근은 6번의 별도 사전 검사입니다. 이미 부팅되었다는 실행 결과를 보고하지 마세요.",r'실행\s*뒤|적용\s*결과|6\.18|linux-msft|접근|권한|Virtual2')
pre=action('preflight',"statement.text를 '6. '로 시작하세요. 실행 중 커널 버전을 기록된 6.18.33.2-microsoft-standard-WSL2-issue211과 대조하고, root 자식 컨텍스트가 /dev/udmabuf을 실제로 열 수 있는 접근 권한을 검사하며, 설정 파일·실행 입력이 Virtual2 400x300 NV12를 요청하는지 확인하는 사전 검사 과업으로 묶으세요. 하나라도 다르면 실행하지 않습니다. 권한이라는 단어를 쓰되 과거 모드 복제 의무를 만들지 마세요. 실제 적용 결과 검증은 8번에 맡기세요.",r'실행\s*후|실행\s*뒤|새\s*증거|과거.*모드', [['권한'],['Virtual2'],['NV12']])
execute=action('execution',"statement.text를 '7. '로 시작하세요. 사전 검사를 통과한 뒤 연결된 안내에 따라 관찰 도구의 제어 아래에서 수정하지 않은 공식 cam 디버그 빌드를 실행하는 과업만 한 문장으로 쓰세요. 관찰 도구가 cam을 관찰하며 cam이 관찰 도구가 아닙니다. 경로 준비·버전·권한·증거 위치는 다른 단계에서 설명합니다.",r'관찰 도구로|root|커널|SHA|디렉터리|경로|프로브|추출|권한|\d번\s*단계')
results=action('results',"statement.text를 '8. '로 시작하세요. 이번 새 실행이 생성한 증거 디렉터리의 결과로 카메라 선택 Virtual2, 실제 적용 스트림 400x300 NV12, 각 독립 실행의 정상 3프레임과 종료 코드 0을 확인하는 검증 과업만 짧게 쓰세요. 과거 링크는 형식과 절차의 참고이며 새 성공의 증거가 아닙니다. 사전 입력 검사나 커널·장치 접근을 반복하지 마세요.",r'root|커널|권한|장치|실행\s*전|사전|연결된\s*판정\s*기록|기록된\s*결과', [['새'],['증거'],['NV12']])
index=rep['parts'].index(base);rep['parts'][index:index+1]=[boot,pre,execute,results];p.write_text(yaml.safe_dump(c,allow_unicode=True,sort_keys=False),encoding='utf-8')
b=w/'before-final-actions';b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','run/facts/facts.json','config/sections.yaml']:
 target=b/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,target)
for root in [w,d]:
 p=root/'config/sections.yaml';full=yaml.safe_load(p.read_bytes());sec=next(s for s in full['sections'] if s['id']=='official-cam-validation');sec['design_topics']=[rep if t['id']=='reproduce' else t for t in sec['design_topics']];p.write_text(yaml.safe_dump(full,allow_unicode=True,sort_keys=False),encoding='utf-8')
s=(r/'build/after-virtual-concise-v2.py').read_text().replace('generate-concise-source-v2','generate-final-actions').replace("tag='concise-source-v2'","tag='final-actions'").replace('concise-source-v2-translation-prompts','final-actions-translation-prompts').replace('english-before-concise-source-v2.json','english-before-final-actions.json').replace("('concise-source-v2-'+stage)","('final-actions-'+stage)");(r/'build/after-virtual-final-actions.py').write_text(s)
