from pathlib import Path
import yaml,copy,shutil
r=Path(__file__).resolve().parent.parent;g=r/'build/generator-main-integration';w=r/'build/issue211-virtual';d=w/'current-main-integration'
p=g/'examples/libcamera/validation/issue211-reader/section.yaml';c=yaml.safe_load(p.read_bytes());flow=next(t for t in c['design_topics'] if t['id']=='flow')
next(x for x in flow['parts'] if x['id']=='dispatch')['question']+=' 첫 등장에는 CameraSession::processRequest로 소유 클래스를 명시해 VirtualCameraData::processRequest와 구분하세요.'
old=yaml.safe_load((w/'before-sink-context/config/sections.yaml').read_bytes());oldrep=next(t for t in next(s for s in old['sections'] if s['id']=='official-cam-validation')['design_topics'] if t['id']=='reproduce')
rep=next(t for t in c['design_topics'] if t['id']=='reproduce');rep['parts']=copy.deepcopy(oldrep['parts'])
ap=next(x for x in rep['parts'] if x['id']=='approval');ap['question']="statement.text를 '4. '로 시작하세요. 공유 호스트 변경 계획에는 대상 부팅 커널·이미지 SHA-256·영향·백업·부팅·복구 절차가 포함되며, 변경 실행 직전에 그 계획에 별도 승인을 받는다고 설명하세요. PR·Pages 승인이 이를 대신하지 않고 Docker는 승인 계획이 요구할 때만 중지한다는 조건을 한 번만 간결히 남기세요. 이 문단은 계획·승인 과업 하나입니다. 설치나 장치 검사를 반복하지 말고 실제 해시 값이나 안내의 단계 번호를 쓰지 마세요."
ex=next(x for x in rep['parts'] if x['id']=='execution');ex['question']='5~8번을 승인된 커널 전환, 실행 전 입력·접근 확인, 공식 cam 실행, 실제 적용·완료 결과 검증으로 묶어 설명하세요.'
ex['subquestions']=[
"statement.text를 '5. '로 시작하세요. 앞에서 승인받은 계획에 따라 시험 커널을 설치하고 그 커널로 부팅하는 과업만 짧게 쓰세요. 안내 안의 준비 번호나 별도 계획을 인용하지 말고 2단계 계획 또는 두 단계 계획이라는 표현을 쓰지 마세요. 승인 설명과 세 가지 사전 검사를 반복하지 마세요.",
"statement.text를 '6. '로 시작하세요. 실행 커널 버전을 기록된 6.18.33.2-microsoft-standard-WSL2-issue211과 대조하고, root 자식 컨텍스트가 /dev/udmabuf을 실제로 열 수 있는 접근 권한인지 검사하며, 사용하려는 설정 파일·실행 입력이 Virtual2 400x300 NV12를 요청하는지 확인하는 사전 과업으로 묶으세요. 권한이라는 단어를 반드시 쓰세요. 과거 권한 모드를 복제해야 한다고 단정하지 마세요. 하나라도 다르면 실행하지 않으며 실제 적용 설정은 실행 후 검증합니다. 이미 촬영한 결과를 사전에 확인하는 것처럼 쓰지 마세요.",
"statement.text를 '7. '로 시작하세요. 사전 조건이 모두 맞으면 연결된 안내에 따라 관찰 도구로 수정하지 않은 공식 cam 디버그 빌드를 실행하는 과업만 쓰세요. 명령 파일명·인자·SHA·커널·승인 설명을 반복하지 마세요.",
"statement.text를 '8. '로 시작하세요. 실행 뒤 연결된 판정 기록에서 실제 적용 스트림 설정이 요청한 Virtual2 400x300 NV12와 맞고 정상 3프레임과 정상 종료가 확인되는지 검증하는 과업만 짧게 쓰세요. 실행 입력 확인과 실제 적용 결과 확인을 구분하세요. 세부 필드·PID·JSON·원시 도구명은 쓰지 마세요."
]
ex['prompt']+=' 각 번호는 독자 과업 하나입니다. 앞 단계에서 끝낸 승인·조건은 반복하지 말고, 실행 전 입력과 실행 뒤 적용 결과를 구분하세요. 일반 권한 변경 지침이나 과거 모드 복제 의무를 만들지 마세요.'
rep.setdefault('answer_contract',{}).setdefault('reject_patterns',[]).append(dict(pattern=r'2단계\s*계획|두\s*단계\s*계획',message='준비 2번에서 작성하는 계획은 두 단계로 된 계획이 아닙니다.'))
p.write_text(yaml.safe_dump(c,allow_unicode=True,sort_keys=False),encoding='utf-8')
p=g/'examples/libcamera/validation/issue211-virtual/retained-visual-overrides.yaml';vs=yaml.safe_load(p.read_bytes());v=vs[0]
v['prompt']+=' 최신 대조 지적: n4 첫 등장에는 CameraSession::processRequest를 표시합니다. n9 질문과 참 간선은 한도 설정 AND 제출 개수 도달을 모두 포함하며 거짓은 한도 미설정 OR 미도달입니다. n10 라벨은 sinkRelease의 버퍼 유지 재사용과 queueRequest 도우미 호출만 나타내고 실제 제출이나 resubmit이라고 쓰지 않습니다. n8 보유 간선은 현재 함수 반환 뒤 이미 진행 중일 수 있는 싱크 처리가 완료되어 requestProcessed가 발생한 시점을 표시합니다. 나중에 처리를 시작한다고 쓰지 마세요. authored 간선 라벨에 true/false를 직접 쓰지 마세요. 시스템이 조건 표시를 붙입니다. 간선은 핵심 조건만, 노드는 핵심 행동만 짧게 쓰며 같은 설명을 양쪽에서 반복하지 마세요.'
v.setdefault('answer_contract',{'basis':'implementation'}).setdefault('reject_patterns',[]).append(dict(pattern=r'나중에\s*처리',message='이후의 싱크 처리 완료 신호를 표시하세요.'))
v['answer_contract_en']['reject_patterns'] += [dict(pattern=r'sinkRelease[^\n]*\bresubmit\b',message='sinkRelease describes reuse and helper call, not actual submission.'),dict(pattern=r'sink processes it later',message='Show processing completion, not delayed processing start.'),dict(pattern=r'\btrue\b[^\n]*\btrue\b|\bfalse\b[^\n]*\bfalse\b',message='Do not repeat the automatic branch marker.')]
p.write_text(yaml.safe_dump(vs,allow_unicode=True,sort_keys=False),encoding='utf-8')
p=g/'examples/libcamera/validation/issue211-virtual/visual.yaml';virt=yaml.safe_load(p.read_bytes());virt['prompt']+=' 한영 authored 간선 라벨에는 true/false를 직접 쓰지 말고 변환 성공·변환 오류·모든 버퍼 완료·미완료 버퍼 남음처럼 핵심 조건·결과만 짧게 쓰세요. 시스템이 조건 참/거짓 표시를 붙입니다. 간선에 노드의 전체 행동을 반복하지 마세요.'
virt.setdefault('answer_contract_en',{'basis':'implementation'}).setdefault('reject_patterns',[]).append(dict(pattern=r'\btrue\b[^\n]*\btrue\b|\bfalse\b[^\n]*\bfalse\b',message='Do not repeat the automatic branch marker.'));p.write_text(yaml.safe_dump(virt,allow_unicode=True,sort_keys=False),encoding='utf-8')
b=w/'before-concise-source-v2';b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','run/facts/facts.json','config/sections.yaml','config/visuals.yaml']:
 target=b/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,target)
for root in [w,d]:
 p=root/'config/sections.yaml';full=yaml.safe_load(p.read_bytes());sec=next(s for s in full['sections'] if s['id']=='official-cam-validation');sec['design_topics']=[flow if x['id']=='flow' else rep if x['id']=='reproduce' else x for x in sec['design_topics']];p.write_text(yaml.safe_dump(full,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';full=yaml.safe_load(p.read_bytes());full['sections']['official-cam-validation']=[v if x['id']=='completion-flow' else virt if x['id']=='virtual-frame-path' else x for x in full['sections']['official-cam-validation']];p.write_text(yaml.safe_dump(full,allow_unicode=True,sort_keys=False),encoding='utf-8')
s=(r/'build/after-virtual-sink-path.py').read_text().replace('generate-sink-diagram-terms','generate-concise-source-v2').replace("tag='sink-path-final'","tag='concise-source-v2'").replace('sink-path-translation-prompts','concise-source-v2-translation-prompts').replace('english-before-sink-path.json','english-before-concise-source-v2.json').replace("('sink-path-'+stage)","('concise-source-v2-'+stage)");(r/'build/after-virtual-concise-v2.py').write_text(s)
