from pathlib import Path
import sys,time
from sdd.runtime_evidence import run_recorded,require_success
r=Path(__file__).resolve().parent.parent;w=r/"build/issue211-virtual";rec=w/"executions/generate-scheduled-api-result-v2/record.json"
deadline=time.monotonic()+1800
while not rec.exists():
 if time.monotonic()>deadline:raise TimeoutError("Native generation incomplete")
 time.sleep(3)
require_success(rec.parent)
for stage,argv in [("update-current-page-translation-v7",[str(r/"build/update-reviewed-page-translation.py"),"v7","generate-scheduled-api-result-v2"]),("finalize-native-page-v7",[str(r/"build/finalize-native-page.py"),"latest-main-final-v7","update-current-page-translation-v7"])]:
 target=w/"executions"/stage;run_recorded(target,[sys.executable,"-X","utf8"]+argv,timeout=1800,cwd=r);require_success(target)
 print(stage,"passed",flush=True)
