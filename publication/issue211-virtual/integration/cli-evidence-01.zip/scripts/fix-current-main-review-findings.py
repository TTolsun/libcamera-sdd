from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';b=w/'before-current-main-review-fixes';b.mkdir()
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
    for name in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
        dst=b/root.name/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,dst)
    path=root/'config/sections.yaml';data=yaml.safe_load(path.read_bytes());section=next(s for s in data['sections'] if s['id']=='official-cam-validation')
    for topic in section['design_topics']:
        for part in topic['parts']:
            if topic['id']=='flow' and part['id']=='reuse-request':
                part['question']='기록된 출력 싱크 미요청 경로라는 짧은 첫 구절 뒤에, 처리 한도가 설정되지 않았거나 처리 수가 한도에 도달하지 않았으면 버퍼를 유지해 요청을 재사용하고 제출 도우미를 호출한다는 한 문장만 씁니다. 도우미의 제출 생략 조건은 바로 뒤 항목이 이미 설명하므로 이 항목에서는 반복하지 않습니다. 반환값·카운터 증가·큐에 실제 제출된다는 주장도 쓰지 않습니다.'
            if topic['id']=='reproduce' and part['id'] in ['environment','approval']:
                part['question']+=' 굵은 단계 묶음 제목은 구분 표시일 뿐 문장의 주어가 아닙니다. 제목 뒤에 조사(은/는/이/가)를 붙이지 말고 독자가 수행할 직접 행동을 씁니다. 준비가 조사하거나 호스트 변경이 계획을 소유하는 식으로 표현하지 않습니다.'
                part['answer_contract'].setdefault('reject_patterns',[]).append({'pattern':r'\*\*[^\n]+?\*\*[은는이가]','message':'The bold phase label is a heading, not the actor. Keep the actual reproduction action directly after the label.'})
    path.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
    path=root/'config/visuals.yaml';data=yaml.safe_load(path.read_bytes())
    for visual in data['sections']['official-cam-validation']:
        if visual['id']=='initial-submission':
            visual['prompt']='아홉 노드·모든 간선·실제 조건·인용은 그대로 보존하고 camera_queue의 영문 라벨만 고칩니다. 한국어에 있는 카메라 실행 상태 검사와 요청 유효성 검사 두 가지를 영어에도 모두 명시합니다. 실패의 음수 오류 반환, 성공의 비동기 전달 뒤0 반환도 같은 노드에 보존하며 72자 이내로 줄입니다. 나머지 노드와 간선의 한영 표시는 그대로 둡니다. 다음은 native 편집 대상 초안입니다: '+json.dumps(meta['generated_visuals']['records'][visual['id']]['draft'],ensure_ascii=False,separators=(',',':'))
            visual['answer_contract_en'].setdefault('required_terms',[]).append(['running','Running'])
        elif visual['id']=='submission-gate':
            visual['prompt']='일곱 노드·모든 간선·실제 조건·인용·기존 노드의 한영 표시는 그대로 보존하고 attach_buf에서 store_req로 가는 성공 간선의 한영 표시만 고칩니다. 이 그림은 단일 스트림 범위이므로 그 스트림 연결이 끝나 현재 요청 보관으로 진행하는 뜻이어야 합니다. 다음 스트림으로 가는 분기나 보이지 않는 복수 스트림 루프를 암시하지 않습니다. 간선은20자 이내이며 나머지 표시는 보존합니다. 다음은 native 편집 대상 초안입니다: '+json.dumps(meta['generated_visuals']['records'][visual['id']]['draft'],ensure_ascii=False,separators=(',',':'))
        else:continue
    path.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
print('Four current bilingual review findings mapped to native writer constraints')
