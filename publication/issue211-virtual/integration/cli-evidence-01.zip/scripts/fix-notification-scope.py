from pathlib import Path
import yaml,json,shutil
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-main-integration'
b=w/'before-notification-scope';b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 dest=b/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,dest)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'));reference=m['generated_visuals']['records']['virtual-frame-path']['draft']
question='記録'.replace('記録','기록된 명령의 화면·파일 출력 옵션 미선택 조건을 적용한 소스 분석임을 먼저 밝히세요. 그 조건에서 처리를 계속할 요청은 Request::ReuseBuffers로 버퍼를 유지해 재사용하고 CameraSession::queueRequest 도우미를 호출하며, 실제 제출 여부는 별도 한도 검사에 따른다는 관계만 두 짧은 문장 이내로 씁니다. 해당 내부 호출을 새 실행에서 직접 관측했다고 표현하지 마세요. 출력 싱크가 요청을 보유하지 않는다는 뜻이 아니라 출력 옵션 자체를 요청하지 않은 조건입니다.')
def revise(t):
 if t['id']=='flow':next(p for p in t['parts'] if p['id']=='reuse-request')['question']=question
p=g/'examples/libcamera/validation/issue211-reader/section.yaml';x=yaml.safe_load(p.read_bytes())
for t in x['design_topics']:revise(t)
p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
p=g/'examples/libcamera/validation/issue211-virtual/visual.yaml';base=yaml.safe_load(p.read_bytes());base['prompt']=base['prompt'].replace('이번 호출의 cam 통지 없이 마침','이 경로에서 추가 cam 통지 없이 마침').replace('이번 호출의 통지가 없다는 공통 결과만 설명합니다','이 경로가 추가 통지를 중단한다는 공통 결과만 설명하며, 같은 호출에서 앞의 완료 요청들을 이미 통지했을 가능성은 부정하지 않습니다');base['prompt']+=' Pending을 만나 보류하는 요청은 그 Pending 요청과 뒤 요청들입니다. 그 앞의 완료 요청들은 같은 completeRequest 호출에서 이미 통지했을 수 있습니다. Pending 분기나 공통 종료 노드가 이번 호출 전체의 통지 건수를 0으로 단정하지 않게 하세요.'
p.write_text(yaml.safe_dump(base,allow_unicode=True,sort_keys=False),encoding='utf-8')
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(t for t in x['sections'] if t['id']=='official-cam-validation')
 for t in s['design_topics']:revise(t)
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());v=next(t for t in x['sections']['official-cam-validation'] if t['id']=='virtual-frame-path')
 v['prompt']=v['prompt'].split(' 최종 라벨 가독성 보완:')[0]
 v['prompt']+=' 現在'.replace('現在','현재 초안은 나머지 의미와 가독성 검토를 통과했습니다. 아래 12개 노드의 ID·shape·quote_ids, 모든 간선의 from·to·condition_ref·quote_ids 및 n10을 제외한 기존 한영 노드 라벨을 그대로 보존하세요. 이번 새 native 응답에서는 n10 라벨과 n11→n10 간선 라벨만 의미를 바로잡습니다. n11이 Pending을 만나면 그 요청과 뒤 요청의 통지를 보류하지만, 그 앞의 완료 요청들은 같은 호출에서 이미 통지했을 수 있습니다. n10은 이 경로에서 추가 통지 없이 마친다는 의미로 쓰고, 이번 호출 전체의 cam 통지가 0이라는 주장은 제거합니다. n7→n10도 같은 공통 종료를 쓰므로 추가 통지 중단이라는 넓은 의미를 유지합니다. 그 밖에 이미 올바른 생성 오류·버퍼 완료·요청 완료·큐 선두와 현재 요청 관계·순서·매핑 주체·CPU 쓰기 시도는 바꾸지 않습니다. 기존 짧은 n1→n2 가상 경로 라벨과 n5 변환 오류·FrameError/FrameSuccess 분기도 보존하세요. 참고 초안은 편집 입력이며 저장 응답의 재생이 아닙니다. 실제 새 응답은 모든 검사를 다시 통과해야 합니다. 참고 초안: ')+json.dumps(reference,ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
s=(r/'build/after-virtual-final-readable.py').read_text().replace('final-readable','notification-scope');(r/'build/after-virtual-notification-scope.py').write_text(s)
