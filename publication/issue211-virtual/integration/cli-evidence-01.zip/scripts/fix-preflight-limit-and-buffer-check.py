from pathlib import Path
import json,yaml,shutil,sys
from sdd.document_metadata import split_frontmatter
from sdd.runtime_evidence import run_recorded,require_success
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-reader-release';out=w/'before-preflight-limit-buffer-check';out.mkdir()
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'));findings=json.loads((w/'reviews/latest-main-final-v18/review.json').read_bytes())['review']['findings']
for root in [w,d]:
 backup=out/root.name;backup.mkdir()
 for rel in ['config/sections.yaml','config/visuals.yaml']:shutil.copy2(root/rel,backup/Path(rel).name)
 p=root/'config/sections.yaml';data=yaml.safe_load(p.read_bytes());s=next(s for s in data['sections'] if s['id']=='official-cam-validation')
 part=next(p for t in s['design_topics'] if t['id']=='reproduce' for p in t['parts'] if p['id']=='capture-limit-check')
 part['question']='statement.text를 11. 로 시작하고, 실행할 공식 cam 명령이 `--capture=3`으로 3프레임을 요청하도록 지정되었는지 확인하라는 직접 지시 한 문장만 씁니다. 실행 전에는 계획한 명령 인자를 확인하는 단계입니다. 실제 설정 적용이나 프레임 완료는 실행 후 13번과 연결된 실행 절차의 새 증거로 검증하므로 11번에서 이미 실제로 적용되었다고 말하거나 실행 전에 적용 여부를 확인하라고 하지 않습니다. 도우미 내부 전달·기록 필드·확인 방법은 연결된 실행 절차가 설명합니다.'
 part['answer_contract'].setdefault('reject_patterns',[]).append({'pattern':'실제 캡처 한도.{0,12}적용|적용되는지|적용되었는지','message':'Step 11 is a planned-argument inspection; actual application and completed frames are verified after execution.'})
 p.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';data=yaml.safe_load(p.read_bytes());v=next(v for v in data['sections']['official-cam-validation'] if v['id']=='request-completion-order')
 v['prompt']='현재 아홉 노드·간선·심볼·조건 양쪽·인용·나머지 한영 라벨을 모두 보존하고, n2(나머지 요청 버퍼를 기다리는 결과 노드)의 한영 라벨만 수정합니다. 앞 결정은 FrameBuffer 자체의 판정이 아니라 completeBuffer의 반환값입니다. 반환 false는 아직 모든 요청 버퍼가 완료되지 않았으므로 completeRequest를 호출하지 않고 나머지 버퍼를 기다린다는 뜻입니다. FrameBuffer 판정, FrameBuffer check라고 쓰지 않습니다. 내부 symbol FrameBuffer와 소스 인용은 그대로 보존하되 화면 라벨은 실제 판정과 결과를 짧게 나타냅니다. 실제 검토 지적: '+json.dumps(findings,ensure_ascii=False)+' 다음은 native 편집 대상 초안입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 for key in ['answer_contract','answer_contract_en']:
  v[key].setdefault('reject_patterns',[]).append({'pattern':'FrameBuffer 판정|FrameBuffer check','message':'The decision checks completeBuffer return, not the FrameBuffer type itself; false waits for remaining request buffers.'})
 p.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
record=w/'executions/generate-preflight-limit-buffer-check';run_recorded(record,[sys.executable,'-X','utf8','-m','sdd.cli','--config',str(w/'generation.yaml'),'generate','--sections','official-cam-validation'],timeout=1800,cwd=g);require_success(record)
print('Native planned-limit instruction and buffer-check label generated')
