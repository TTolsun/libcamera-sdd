from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='allocation-gate'
b=w/('before-'+tag);b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());part=next(p for s in x['sections'] if s['id']=='official-cam-validation' for t in s['design_topics'] if t['id']=='virtual-principle' for p in t['parts'] if p['id']=='purpose')
 part['question']='고정 libcamera 소스에서 분석한 virtual 파이프라인의 개요를 세 짧은 문장으로 설명합니다. 첫 문장은 고정 소스 분석이라는 범위와, 실제 센서 대신 Virtual2 400x300 lines 패턴을 공급하는 virtual 기능입니다. 둘째 문장은 할당이 성공한 뒤 cam이 실제 DMA-BUF 버퍼를 붙인 요청의 전달을 준비하는 관계입니다. 셋째 문장은 CPU가 NV12 변환과 매핑된 버퍼 쓰기를 모두 시도한다는 뜻입니다. 변환 성공을 단정한 뒤 쓰기만 시도한다고 나누지 않습니다. 완료 조건은 뒤 항목이 맡으므로 반복하지 않습니다. 구현 클래스·함수·enum 이름은 근거에 남기고 이 개요에서는 쓰지 않습니다.'
 part['prompt']='직접적인 주어와 짧은 동사로 설명하세요. CPU의 변환과 쓰기는 함께 시도되는 경로입니다. 구체적 구현 식별자와 다른 항목의 동작을 반복하지 마세요.'
 part['answer_contract']['required_terms'].extend([['CPU'],['NV12'],['매핑'],['시도'],['Virtual2']])
 part['answer_contract'].setdefault('reject_patterns',[]).append(dict(pattern='::|CameraSession|TestPatternGenerator|변환하고|변환하여|변환한',message='Use plain overview prose. Both NV12 conversion and the mapped-buffer write are attempts; do not assert conversion success before an attempted write.'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='virtual-frame-path':
   v['max_nodes']=8;v['required_symbols'].append('startCapture')
   edit='최종 검토에 따라 기존 7개 버퍼 경로를 8개 노드로 보완합니다. n0의 symbol은 exportFrameBuffers 그대로이며 cam의 DMA-BUF 할당 시도가 실패했는지를 판단하는 decision으로 표시합니다. n0의 실제 분기 조건은 CameraSession::startCapture에서 allocator_->allocate 뒤 ret < 0 검사입니다. 이 실패 조건의 true는 새 n7(startCapture symbol)로 이어져 startCapture가 오류를 반환하고 요청 제출을 시작하지 않습니다. false만 기존 n1 요청 준비·비동기 전달로 이어집니다. n0→n1 기존 always 간선을 이 실제 실패 조건의 false로 바꾸고 n0→n7 true 간선을 추가합니다. 양 끝 symbol과 실제 할당 ret 검사를 포함하도록 cam-request-buffers, allocator-to-camera, virtual-buffer-allocation 등 제공된 인용을 보강합니다. 다른 ret 검사로 실패 원인을 바꾸지 않습니다. n2의 예약 대상은 VirtualCameraData::processRequest임을 두 언어에서 명시합니다. n3 매핑 시도, n4 NV12 변환·매핑 버퍼 쓰기 시도, n5 생성 오류, n6 상태와 무관한 버퍼 완료 신호 및 나머지 올바른 인용·분기는 보존합니다. n0는 시도의 결과에 관한 질문으로 씁니다. 실제 새 할당기 실행 성공을 주장하지 않습니다. '
   v['answer_contract']['required_terms'].append(['VirtualCameraData::processRequest']);v['answer_contract_en']['required_terms'].append(['VirtualCameraData::processRequest'])
  elif v['id']=='request-completion-order':
   edit='n3의 한영 라벨만 수정합니다. n3는 현재 요청을 완료로 표시하는 동작 하나입니다. cam 통지는 이후 제출 큐 검사와 맨 앞 Pending 검사를 통과한 n6에서만 수행합니다. n3에서 카메라에 알려야 한다는 의무나 즉시 알림을 쓰지 않습니다. 다른 올바른 라벨, 모든 노드·분기·큐 반복과 실제 소스 조건·인용은 그대로 유지합니다. '
   for key in ['answer_contract','answer_contract_en']:v[key]['reject_patterns'].append(dict(pattern='must notify|알려야|통지해야',message='n3 only marks the request complete; notifications occur later at the ordered queue-head notification node, not as an obligation or immediate action at n3.'))
  else:continue
  v['prompt']=edit+'간선 authored 라벨은 한영 20자 이내로 짧게 씁니다. 아래 초안은 실제 새 CLI 응답의 편집 입력이며 저장 응답 재생이 아닙니다. 참고 초안: '+json.dumps(m['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
(r/'build/after-virtual-allocation-gate.py').write_text((r/'build/after-virtual-bound-preflight.py').read_text().replace('bound-preflight',tag),encoding='utf-8')
