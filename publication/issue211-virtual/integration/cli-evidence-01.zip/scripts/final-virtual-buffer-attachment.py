from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='buffer-attachment'
b=w/('before-'+tag);b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());part=next(p for s in x['sections'] if s['id']=='official-cam-validation' for t in s['design_topics'] if t['id']=='flow' for p in t['parts'] if p['id']=='processing')
 part['question']='processRequest에 들어올 때 처리 한도가 설정되어 있고 처리 수가 이미 그 한도에 도달했다면, 완료 신호를 다시 내지 않고 즉시 반환하여 후속 프레임 처리를 건너뛴다는 한 가지 조건·동작만 짧은 평서문 하나로 씁니다. 요청마다 다시 호출된다는 일반화, 남은 요청 모두에 대한 설명, 이유·효과·뒷 단계 해설을 덧붙이지 않습니다. 취소 분기는 앞 콜백 설명이 맡습니다.'
 part['answer_contract']['required_terms'].append(['건너'])
 part['answer_contract']['reject_patterns'].append(dict(pattern='남아|남은|요청마다|호출되므로|따라서|때문|그 후속|이 분기가',message='State only the entry-limit conditional and immediate return that skips frame processing. Do not generalize calls to all remaining requests or append rationale.'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());v=next(v for v in x['sections']['official-cam-validation'] if v['id']=='virtual-frame-path');v['max_nodes']=9;v['required_symbols'].append('addBuffer')
 v['prompt']='마지막 두 항목 중 그림 수정을 수행합니다. 기존 8개 노드에 n8(addBuffer symbol)을 추가하여 9개 노드로 만듭니다. n8은 cam이 새 요청에 할당된 실제 DMA-BUF 버퍼를 붙이는 시도이며 주체와 동작을 한영 모두 짧게 표시합니다. n0 할당 실패 판정의 false→n1 간선을 false→n8로 바꾸고, cam-request-buffers에 있는 요청 생성 성공 경로임을 짧게 표시합니다. n8→n1은 나머지 요청 준비·카메라 시작이 성공한 경우의 주요 경로를 요약하는 always 간선으로 추가합니다. n1은 Camera가 버퍼를 검증하고 유효한 준비 요청의 비동기 전달을 시도하는 단계이며, 어색한 영어 buffer-less; valid 같은 주어 없는 문구 대신 Camera라는 주체와 checks/tries 같은 분명한 동사를 씁니다. 기존 n1→n2의 검증·준비·큐 전달 성공 조건을 보존합니다. n0 실패 true→n7 반환, n2 VirtualCameraData::processRequest, n3 매핑 시도, n4 CPU NV12 변환 결과의 mapped buffer 쓰기 시도, n5 변환 오류 두 결과, n6 상태와 무관한 버퍼 완료와 다음 그림 연결은 그대로 유지합니다. 새 간선 인용에는 양 끝 symbol과 해당 조건을 포함하도록 cam-request-buffers·allocator-to-camera·camera-queue 등의 실제 발췌를 사용합니다. 다른 올바른 라벨·구조·인용·실제 조건은 보존합니다. 한영 노드 64자, authored 간선 20자 이내의 짧은 동작구를 사용합니다. 아래 초안은 새 native CLI 편집 입력이며 저장 응답 재생이 아닙니다. 참고 초안: '+json.dumps(m['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
(r/'build/after-virtual-buffer-attachment.py').write_text((r/'build/after-virtual-bound-preflight.py').read_text().replace('bound-preflight',tag),encoding='utf-8')
