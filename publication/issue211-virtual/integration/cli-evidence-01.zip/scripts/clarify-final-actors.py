from pathlib import Path
import copy,json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';b=w/'before-final-actors-compact';b.mkdir()
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
catalog=json.loads((d/'run/english.json').read_bytes());review=json.loads((w/'reviews/latest-main-final-v8/review.json').read_bytes())
keys=[k for k,v in catalog['strings'].items() if v=='Prepares multiple initial requests to match a single stream.'];assert len(keys)==1
(w/'heading-subject-native-findings.json').write_text(json.dumps({keys[0]:review['review']['findings'][2]},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for root in [w,d]:
 for rel in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
  target=b/root.name/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,target)
 p=root/'config/sections.yaml';data=yaml.safe_load(p.read_bytes());s=next(s for s in data['sections'] if s['id']=='official-cam-validation')
 for topic in s['design_topics']:
  if topic['id']=='initial-preparation':
   part=copy.deepcopy(topic['parts'][0]);part.pop('role',None);part['max_statements']=1
   part['sources']=list(dict.fromkeys(x for p in topic['parts'] for x in p['sources']))
   part['question']='기록된 단일 스트림·출력 옵션 미요청 범위를 이 준비·제출 두 항목의 공통 조건으로 한 번만 밝히고 cam이 버퍼를 할당해 초기 요청마다 연결한다는 준비의 핵심을 첫 문장으로 씁니다. 모든 준비가 끝나야 카메라 시작으로 넘어가며 할당·요청 생성·버퍼 연결 중 오류가 나면 시작 전에 반환한다는 조건을 둘째 문장에 짧게 묶습니다. 그림의 반복 순회·중간 변수·각 코드 분기를 문장별로 따라 쓰지 않습니다. 두 문장220자 이내이고 cam 외 코드 식별자는 근거에 둡니다.'
   part['answer_contract']['required_terms']=[['단일'],['출력'],['할당'],['요청'],['연결'],['오류'],['시작']]
   topic['parts']=[part]
  elif topic['id']=='initial-submission':
   part=topic['parts'][0]
   part['question']='앞 준비 항목에서 정한 단일 스트림·출력 조건을 그대로 이어받으며 그 조건을 다시 나열하지 않습니다. cam은 요청 준비와 카메라 시작 뒤 한도 안에서만 제출하고 한도 도달 시 생략한다는 핵심을 첫 문장으로 씁니다. 실제 카메라 큐 API가 상태와 요청을 검사해 오류를 반환할 수 있고 성공 시에는 비동기 호출을 예약하며 초기 제출 실패 때 이미 시작한 카메라를 중지한다는 조건을 둘째 문장에 짧게 묶습니다. 실제 API 성공과 제출 생략 도우미의0반환을 구분하고 예약을 처리 완료로 쓰지 않습니다. 두 문장220자 이내이며 cam과 일반 기술 용어 API 외 코드 식별자는 근거에 둡니다.'
   part['answer_contract']['required_terms'] += [['상태'],['오류']]
 p.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';data=yaml.safe_load(p.read_bytes())
 for v in data['sections']['official-cam-validation']:
  if v['id']!='virtual-frame-path':continue
  v['prompt']='현재 아홉 노드·모든 간선·실제 조건·인용·짧은 한영 표시를 그대로 보존하고 요청 처리를 예약하는 노드의 한영 주체만 명확히 합니다. 요청과 목표 타임스탬프를 넘겨 요청 처리를 예약하는 호출 주체는 가상 파이프라인 핸들러이며 가상 장치 객체 자체라고 쓰지 않습니다. 양 언어에 파이프라인 핸들러를 명시하고 대상은 요청 처리이며 요청과 목표 시각을 전달한다는 관계를 보존합니다. 다른 동작·라벨·한도는 바꾸지 않습니다. 다음은 native 편집 대상 초안입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
  for field,pattern in [('answer_contract','가상 장치가.{0,35}예약'),('answer_contract_en','(?i)virtual device.{0,35}schedul')]:v[field].setdefault('reject_patterns',[]).append({'pattern':pattern,'message':'The virtual pipeline handler schedules request processing on the virtual camera data object; identify the actual caller.'})
 p.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
