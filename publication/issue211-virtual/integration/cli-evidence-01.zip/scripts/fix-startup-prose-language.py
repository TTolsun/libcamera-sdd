from pathlib import Path
import shutil,yaml
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='startup-korean'
b=w/('before-'+tag);b.mkdir()
for root in [w,d]:
 p=root/'config/sections.yaml';shutil.copyfile(p,b/(root.name+'-sections.yaml'));x=yaml.safe_load(p.read_bytes());s=next(s for s in x['sections'] if s['id']=='official-cam-validation')
 for t in s['design_topics']:
  if t['id'] not in ['initial-preparation','initial-submission']:continue
  for a in t['parts']:
   a['question']+=' 이 본문 항목은 cam 외의 영문 코드 식별자를 쓰지 않는 한국어 평서문으로만 씁니다. 함수의 역할은 한국어 명사로 표현하고, 괄호 속 코드명 보충도 완전히 제거합니다. camera_->start, CameraSession::startCapture, startCapture, Camera::queueRequest 같은 실제 코드명은 인용 근거에만 남깁니다.'
   a['answer_contract']['reject_patterns'].append({'pattern':r'(?i)\b(?!cam\b)[A-Za-z_][A-Za-z0-9_:]*','message':'본문에 cam 외 영문 코드 식별자가 남았습니다. 괄호 안의 camera_, CameraSession::, startCapture 등도 전부 제거하고 함수 역할을 한국어 명사로만 설명하세요. 코드 인용 근거는 그대로 유지합니다.'})
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
(r/'build/after-virtual-startup-korean.py').write_text((r/'build/after-virtual-startup-scope.py').read_text().replace('startup-scope',tag),encoding='utf-8')
