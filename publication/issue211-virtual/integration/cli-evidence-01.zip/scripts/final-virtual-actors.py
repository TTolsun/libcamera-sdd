from pathlib import Path
import yaml,shutil
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-main-integration'
b=w/'before-final-actors';b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 dest=b/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,dest)
def topic(t):
 if t['id']!='virtual-principle':return
 for part in t['parts']:
  if part['id'] in ['buffer','completion']:
   part['prompt']=part.get('prompt','')+' 이 항목에는 물리 센서·ISP·하드웨어 DMA·성능의 범위 경고를 덧붙이지 마세요. 페이지 끝의 검증 범위가 이미 설명합니다. 질문에 명시된 버퍼·변환·완료 조건만 유지하세요.'
   part.setdefault('answer_contract',{'basis':'implementation'}).setdefault('reject_patterns',[]).append({'pattern':'물리|하드웨어|ISP|성능|검증 범위','message':'Keep the execution limits at the end of the page, without repeating them in this implementation explanation.'})
prompt='''고정된 11개 symbol 바인딩의 핵심 가상 NV12 경로를 한영으로 설명하세요. 노드마다 인용과 고정 symbol을 유지합니다. n0은 cam이 virtual 파이프라인을 통해 실제 DMA-BUF 버퍼를 확보하는 준비 단계입니다. n1은 Camera가 버퍼가 붙은 요청을 확인하고 파이프라인에 제출하는 단계입니다. n2는 virtual 파이프라인의 비동기 전달이며, n3은 쓰기 방향 CPU 동기화 범위 안에서 쓰기 매핑하는 단계입니다. n4는 CPU가 Virtual2의 lines 패턴을 NV12로 변환하고 매핑 버퍼에 쓰기를 시도하는 단계입니다. 변환과 쓰기를 무조건 성공으로 표시하지 않습니다. n5는 generateFrame의 선택된 NV12 변환 반환값이 0이 아닌가를 판정합니다. 참이면 버퍼 메타데이터 FrameError, 거짓이면 FrameSuccess를 유지하며 모두 n6 버퍼 완료 신호로 이어집니다. 일반 CPU 쓰기의 모든 오류를 검사한다는 뜻은 아닙니다. n7은 연결된 핸들러가 요청의 모든 버퍼 완료를 검사하며, 참이면 n8, 거짓이면 n10 이번 핸들러 호출 종료(요청 완료 표시 없음)로 갑니다. n8은 PipelineHandler가 현재 요청을 완료로 표시하는 단계이며 이 함수가 그 동작만 한다는 only는 쓰지 않습니다. n9는 requestCompleted 신호로 cam 콜백에 제출 순서대로 통지하는 단계입니다. n8→n9에는 앞선 요청이 미완료이면 통지가 보류된다는 실제 조건을 유지하세요. n10은 말단입니다.
n1에는 Camera, n8에는 PipelineHandler를 한영 화면 라벨에 명시해 책임을 구분하세요. n4에는 Virtual2, lines, CPU, NV12와 쓰기 시도를, n9에는 requestCompleted와 제출 순서를 유지하세요. 노드 라벨은 72자 이내, authored 간선은 40자 이내입니다. 간선은 다음 동작의 반복 대신 짧은 조건·결과만 씁니다. n0→n1→n2→n3→n4→n5는 condition_ref always인 핵심 경로 요약이며 별도 준비/assert 분기를 추가하지 않습니다. 두 결정의 참/거짓을 실제 source-bound condition_ref로 지정하고 모든 노드를 연결합니다. 모든 인용은 양 끝 symbol을 포함하며 필요하면 선언 구절을 추가합니다. 동기화는 매핑과 CPU 접근을 감싸는 범위이므로 '동기화 후' 또는 'sync, then'은 쓰지 않습니다. 완료 순서는 submission/queue order이며 completion order라고 쓰지 않습니다. authored 간선에 true/false를 반복하거나 노드 행동 전체를 문장으로 옮기지 않습니다. 내부 후속 큐 순회, 일반 호출자 취소와 반환 0의 상세는 근거로 남깁니다.'''
p=g/'examples/libcamera/validation/issue211-virtual/visual.yaml';v=yaml.safe_load(p.read_bytes());v['prompt']=' '.join(prompt.splitlines())
for key in ['answer_contract','answer_contract_en']:
 v[key]['required_terms'] += [['Camera'],['PipelineHandler']]
p.write_text(yaml.safe_dump(v,allow_unicode=True,sort_keys=False),encoding='utf-8')
p=g/'examples/libcamera/validation/issue211-virtual/topic.yaml';x=yaml.safe_load(p.read_bytes());topic(x);p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(t for t in x['sections'] if t['id']=='official-cam-validation')
 for t in s['design_topics']:topic(t)
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());x['sections']['official-cam-validation']=[v if t['id']==v['id'] else t for t in x['sections']['official-cam-validation']];p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
s=(r/'build/after-virtual-precise-flow.py').read_text().replace('precise-flow','final-actors');(r/'build/after-virtual-final-actors.py').write_text(s)
