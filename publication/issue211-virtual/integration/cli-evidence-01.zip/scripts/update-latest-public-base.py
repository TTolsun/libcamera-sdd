from pathlib import Path
import json,sys,shutil,subprocess
from sdd.runtime_evidence import run_recorded,require_success
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';repo=r/'build/libcamera-sdd-issue211';d=w/'current-main-integration'
backup=w/'before-latest-public-base';backup.mkdir()
shutil.copytree(repo/'docs',backup/'docs')
for name in ['README.md','run.json','generation-receipts.json','.gitattributes']:shutil.copyfile(repo/name,backup/name)
base=subprocess.check_output(['git','rev-parse','origin/main'],cwd=repo,text=True).strip();assert base=='7d824a9753721edd86a4b509a979230033532f9c'
assert subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=repo,text=True).strip()=='14ee8354c5b185d90c935de22f556930bc2412b2'
(backup/'git-status.txt').write_bytes(subprocess.check_output(['git','status','--porcelain=v1'],cwd=repo))
assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=repo)
def run(name,args,allow_conflicts=False):
 out=w/'executions'/('latest-base-'+name);z=run_recorded(out,args,timeout=900,cwd=repo,environment={'PYTHONPATH':str(r/'build/generator-reader-release/src'),'PYTHONIOENCODING':'utf-8'})
 if allow_conflicts:assert z['exit_code'] in [0,1]
 else:require_success(out)
run('checkpoint-stage',['git','add','docs'])
run('checkpoint-commit',['git','-c','user.name=TTolsun','-c','user.email=112919054+TTolsun@users.noreply.github.com','commit','-m','Preserve reader draft before updating the public base'])
checkpoint=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
run('merge',['git','merge','--no-commit','origin/main'],True)
run('canonical-base',['git','restore','--source=origin/main','--staged','--worktree','--','docs','README.md','.gitattributes'])
run('owned-root-records',['git','restore','--source=HEAD','--staged','--worktree','--','run.json','generation-receipts.json'])
p=repo/'.gitattributes';s=p.read_text(encoding='utf-8');rule='publication/issue211-virtual/** -text -whitespace'
if rule not in s:p.write_text(s.rstrip()+'\n'+rule+'\n',encoding='utf-8')
assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=repo)
run('candidate-export',[sys.executable,'-X','utf8','-m','sdd.cli','--config',str(d/'publication.yaml'),'export-site','--out',str(repo/'docs')])
record=dict(schema=1,public_base=base,checkpoint=checkpoint,merge_head=subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=repo,text=True).strip(),review_status='Candidate only; independent current-input acceptance remains required',backup='before-latest-public-base',latest_root_readme_preserved=True)
(w/'latest-public-base.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(record)
