from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='last-findings'
b=w/('before-'+tag);b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(s for s in x['sections'] if s['id']=='official-cam-validation')
 part=next(p for t in s['design_topics'] if t['id']=='virtual-principle' for p in t['parts'] if p['id']=='buffer')
 part['question']='패턴 생성기가 쓰기 방향 동기화 범위 안에서 버퍼를 쓰기용으로 매핑한다는 조건 한 가지만 한 짧은 문장으로 설명하세요. CPU의 NV12 변환·매핑 버퍼 쓰기 시도는 개요가 이미 설명했으므로 이 단위에서는 반복하지 않습니다.'
 part['prompt']='패턴 생성기를 주어로 쓰기 동기화 범위와 쓰기용 매핑 조건만 한 문장으로 설명합니다.'
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='virtual-frame-path':
   v['max_label_chars']=72
   edit='가상 프레임 그림의 n1,n3,n4 라벨만 마지막 검토에 맞춰 고치세요. n1은 Camera가 버퍼 없는 요청을 거부하고 유효한 요청의 파이프라인 전달을 비동기로 예약한다는 뜻입니다. 실제 디바이스 제출 성공을 보장하지 않습니다. n3은 패턴 생성기가 쓰기 동기화 범위 안에서 버퍼를 쓰기용으로 매핑하는 동작입니다. n4는 CPU가 Virtual2 lines 패턴을 NV12로 변환하여 매핑된 버퍼에 쓰기를 시도하는 동작입니다. 영어는 각각 책임 주체와 완전한 동사를 넣은 자연스러운 짧은 문장으로 쓰며 필요하면 72자까지 허용합니다. 특히 CPU tries 뒤에는 writing/converting 등 실제 동작 동사가 필요합니다. 나머지 올바른 라벨과 모든 노드·간선·분기 구조·source 인용은 그대로 유지합니다. 비동기 전달에 필요한 인용은 n1과 관련 간선에서 제공된 camera-queue 소스의 적절한 발췌로 보강할 수 있습니다. '
  elif v['id']=='reproduction-flow':
   edit='실행 노드와 관련된 증거 위치 표현만 마지막 검토에 맞춰 고칩니다. 연결된 재현 안내는 한 번의 새 증거 위치를 만들고 그 안에 세 독립 cam 실행의 기록을 분리합니다. 실행마다 별도 최상위 증거 위치를 요구하지 않습니다. run_cam 노드는 공식 cam 3회 독립 실행과 한 새 증거 위치 안의 실행별 기록 분리를 짧게 표시하세요. 나머지 올바른 라벨, YAML·lines·cam 인자 구분, 승인·부팅·불일치 분기, 노드·간선·인용 구조는 그대로 유지합니다. '
  else:continue
  v['prompt']=edit+'간선은 기존 20자 이하 라벨을 유지합니다. 아래 초안은 실제 새 CLI 응답의 편집 입력이며 저장 응답 재생이 아닙니다. 참고 초안: '+json.dumps(m['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
(r/'build/after-virtual-last-findings.py').write_text((r/'build/after-virtual-bound-preflight.py').read_text().replace('bound-preflight',tag),encoding='utf-8')
