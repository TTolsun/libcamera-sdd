from pathlib import Path
import json,shutil,yaml,re
from sdd.config import load
from sdd.llm import Agent
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='initial-reproduction'
b=w/('before-'+tag);b.mkdir()
for name in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
agent=Agent(load(w/'generation.yaml').agent,w/'build/initial-reproduction-caption-prompts')
schema={'type':'object','additionalProperties':False,'required':['title','title_en'],'properties':{k:{'type':'string','maxLength':60} for k in ['title','title_en']}}
raw=agent.chat('Write a short Korean caption and matching English caption. Return JSON only. Scope the diagram explicitly to initial capture startup, not later request reuse. Use plain words, no function identifiers.','Initial DMA-BUF request preparation and submission: allocation, request creation, buffer attachment, helper submission-limit gate, actual Camera queue call and startup failure return.',tag='initial-submission-caption',response_schema=schema)
caption=json.loads(re.sub(r'^```(?:json)?\s*|\s*```$','',raw.strip()));(w/'build/initial-reproduction-caption-prompts/caption.json').write_text(json.dumps(caption,ensure_ascii=False,indent=2),encoding='utf-8')
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
questions={
 'approval':"statement.text를 '4. '로 시작하세요. 변경안·커널 이미지 해시·영향·백업·복구 절차가 포함된 호스트 변경 계획에 대해 실행 직전에 별도 승인을 받는 한 가지 행동만 짧게 씁니다. 계획을 작성하는 행동과 Docker 조건을 이 항목에서 다시 나열하지 마세요. Docker 조건은 그림과 연결 안내에서 확인합니다.",
 'yaml-check':"statement.text를 '8. '로 시작하세요. 사용할 Virtual2 YAML의 크기 400x300과 패턴 값 lines를 하나의 구성 조합으로 대조하는 한 가지 행동만 한 짧은 문장으로 씁니다. 필드의 중첩 경로를 만들어 내지 않습니다.",
 'stream-request':"statement.text를 '10. '로 시작하세요. 사용할 cam 스트림 인자가 400x300 NV12를 요청하는지 확인하는 행동만 한 짧은 문장으로 씁니다. 캡처 시작 조건이나 다른 사전 검사를 반복하지 마세요.",
 'capture-limit-check':"statement.text를 '11. '로 시작하세요. 새 cam에 전달되는 실제 인자가 --capture=3으로 설정되어야 함을 실행 전에 확인하는 한 가지 행동을 씁니다. 재현 도우미를 쓰면 이 인자가 cam에 실제 전달되는 경로까지 같은 입력 확인에 포함합니다. whether만 확인하는 것이 아니라 값 3의 적용을 요구합니다. 그 뒤 앞선 모든 실행 전 확인 조건을 충족해야 캡처를 시작한다는 짧은 조건 문장 하나를 씁니다. 이 항목 밖에서는 시작 조건을 반복하지 않습니다.",
 'execution':"statement.text를 '12. '로 시작하세요. 연결 안내에 따라 하나의 새 증거 위치에 실행별 기록을 분리하며 수정하지 않은 공식 cam을 디버거 관찰 아래 세 독립 프로세스로 실행하는 한 가지 행동만 짧게 씁니다. 사전 조건, 과거 실행, 아직 미검증이라는 경고는 다른 항목에 있으므로 반복하지 않습니다.",
 'results':"statement.text를 '13. '로 시작하세요. 새 실행 결과를 (카메라 Virtual2, 실제 적용 스트림 400x300 NV12, 각 독립 실행의 정상 3프레임, 종료 코드 0)이라는 하나의 기대 결과 조합과 대조하는 한 가지 검증 행동만 한 문장으로 씁니다. 새 결과를 확인하라는 지시이며 이미 완료됐다는 주장이 아닙니다. 과거 기록·아직 미검증이라는 설명을 다시 덧붙이지 않습니다."
}
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());section=next(s for s in x['sections'] if s['id']=='official-cam-validation')
 for t in section['design_topics']:
  if t['id']=='reproduce':
   for part in t['parts']:
    if part['id'] in questions:
     part['question']=questions[part['id']];part['prompt']+=' 과거 결과나 아직 미검증이라는 상태 문장을 지시문에 덧붙이지 않습니다.'
  if t['id']=='flow':
   part=next(p for p in t['parts'] if p['id']=='reuse-request');part['question']+=' 마지막에 재제출 경로의 후속 처리 함수는 제출 도우미의 반환값을 사용하지 않는다는 짧은 문장 하나를 씁니다. 초기 startCapture의 오류 반환과 혼동하지 않습니다.'
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='submission-gate':
   v['title']=caption['title'];v['question']='초기 캡처를 시작할 때 버퍼·요청 준비와 실제 큐 제출을 거치는 조건은 무엇입니까?'
   v['prompt']='현재 유효한 아홉 노드·각 guard의 두 결과·간선·인용은 보존하고 초기 startCapture 경로로 범위를 명확히 합니다. n3 라벨의 재제출에도 동일 적용이라는 부연을 한영 모두 제거합니다. n5는 초기 시작 실패 반환만 짧게 씁니다. 재제출 오류까지 startCapture로 반환한다고 그리지 마세요. 후속 cam 처리의 재제출은 반환값을 무시한다는 차이는 후속 처리 본문이 설명합니다. 다른 기존 라벨의 불필요한 괄호 경고는 줄이고 핵심 행동만 남깁니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
  if v['id']=='virtual-frame-path':
   v['answer_contract_en']['required_terms'].append(['convert','converting','conversion'])
   v['answer_contract']['reject_patterns'].append(dict(pattern='변환하고|변환한 뒤',message='Both conversion and mapped-buffer writing are attempted; do not assert prior conversion success.'))
   v['prompt']='현재 유효한 9개 노드·간선·소스 guard·양쪽 결과·인용은 그대로 보존합니다. n6의 한국어는 CPU가 Virtual2 lines 패턴의 NV12 변환과 매핑 버퍼 쓰기를 함께 시도함을 명시하며 변환하고 쓰기를 시도처럼 앞 동작 성공을 단정하지 않습니다. 영어에는 conversion 또는 converting과 writing to the mapped buffer가 모두 시도 대상임을 명확히 표현합니다. n2 취소 완료 통지는 앞선 Pending 요청이면 보류된다는 조건을 짧게 남기고 즉시 보장 없음이라는 반복 경고는 생략합니다. 함수명이 있는 n4는 VirtualCameraData::processRequest 식별자를 보존합니다. 그 밖의 올바른 의미는 바꾸지 않습니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
  if v['id']=='reproduction-flow':
   v['max_label_chars']=140
   v['prompt']='현재 유효한 10개 노드와 모든 연결·기존 한영 조건을 보존하고 device_verify 실행 전 판정에 cam --capture=3과 재현 도우미 사용 시 이 인자가 실제 전달된다는 확인을 추가합니다. 기존 커널·root 접근·YAML 크기/패턴·카메라·스트림 조건도 모두 보존합니다. 모든 조건이 일치할 때만 실행한다는 간선은 이 조건 전체를 가리킵니다. product-invocation-options 실제 원본 인자 근거와 재현 절차 근거를 새 판정의 인용에 함께 넣습니다. 노드 140자, authored 간선 20자 이내입니다. 나머지 준비·승인·결과와 예외 연결은 바꾸지 않습니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-actual-queue.py').read_text().replace('actual-queue',tag)
text=text.replace("catalog=json.loads(p.read_bytes());print", "catalog=json.loads(p.read_bytes());caption=json.loads((w/'build/initial-reproduction-caption-prompts/caption.json').read_bytes());assert caption['title'] in catalog['strings'];catalog['strings'][caption['title']]=caption['title_en'];print")
text=text.replace("prefix=[sys.executable,'-X','utf8']", "exec((r/'build/translate-final-procedure.py').read_text(encoding='utf-8'))\nprefix=[sys.executable,'-X','utf8']")
(r/'build/after-virtual-initial-reproduction.py').write_text(text,encoding='utf-8')
