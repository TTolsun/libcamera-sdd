from pathlib import Path
import copy,json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';b=w/'before-split-api-outcomes';b.mkdir()
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 for rel in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
  target=b/root.name/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,target)
 path=root/'config/sections.yaml';data=yaml.safe_load(path.read_bytes());s=next(s for s in data['sections'] if s['id']=='official-cam-validation');t=next(t for t in s['design_topics'] if t['id']=='initial-submission')
 part=copy.deepcopy(t['parts'][0]);part['sources']=list(dict.fromkeys(k for p in t['parts'] for k in p['sources']))
 part['question']='기록된 단일 스트림·출력 옵션 미요청 범위에서 cam은 준비된 요청을 카메라 시작 뒤 한도 안에서만 제출하며 한도 도달 시 제출을 생략한다는 핵심을 첫 문장으로 씁니다. 큐 검사는 실패할 수 있고, 성공은 비동기 전달이며, 초기 제출이 실패하면 이미 시작한 카메라를 중지한다는 조건을 둘째 문장에 짧게 묶습니다. 그림의 개별 카운터·수치 반환값·각 함수별 중간 결과를 문장마다 따라 설명하지 않습니다. 전체 두 문장220자 이내이며 실제 조건 네 가지는 보존합니다. 시작 자체의 실패에서 카메라를 중지한다고 쓰지 않습니다. cam 외 영어 코드 식별자는 근거에 둡니다.'
 part['answer_contract']['required_terms']=[['한도'],['생략'],['검사','검증'],['비동기'],['중지']];t['parts']=[part]
 path.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
 path=root/'config/visuals.yaml';data=yaml.safe_load(path.read_bytes())
 for v in data['sections']['official-cam-validation']:
  if v['id']!='initial-submission':continue
  v['max_nodes']=11
  v['prompt']='기존 아홉 노드와 실제 cam 조건 양쪽·인용·의미를 보존하면서 카메라 API 호출 노드에 섞여 있던 두 반환 결과를 별도 짧은 결과 노드 두 개로 분리하여 총 열한 노드로 만듭니다. 카메라 API 호출 노드는 실행 상태·요청 유효성 검사만 짧게 표시합니다. 음수 오류 반환 결과와 비동기 전달 뒤0 반환 결과를 별도 노드에 두고, 각 결과는 기존 도우미 반환값 판정으로 이어집니다. API 호출에서 결과 노드로의 간선은 호출 결과의 소스상 대안을 설명하는 always 간선이며 존재하지 않는 합성 if 조건을 만들지 않습니다. 기존 도우미 음수 판정의 실제 true/false 분기는 그대로 보존합니다. 성공 결과 노드는 이미 수행된 비동기 전달 및 API 반환 결과이며 도우미 검사 뒤에 새로 전달하는 순서로 그리지 않습니다. 기존 카메라 시작 실패는 중지 없이 오류 반환하고, 초기 제출 실패 때만 이미 시작한 카메라를 중지합니다. 다른 역할·순서·간선·라벨은 그대로 두며 노드 최대72자·간선20자를 유지합니다. 전역 노드 한도는 올리지 않습니다. 다음은 native 편집 대상 초안입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 path.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
