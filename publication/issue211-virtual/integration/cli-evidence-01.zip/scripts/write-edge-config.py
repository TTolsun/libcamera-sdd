from pathlib import Path
import json
from sdd.config import load
from sdd.llm import Agent
from sdd.runtime_evidence import sha256
r=Path(__file__).resolve().parent.parent;g=r/'build/generator-main-integration';w=r/'build/issue211-virtual';out=w/'config-edge-documentation';out.mkdir(exist_ok=False);source=g/'src/sdd/generated_visuals.py';code=source.read_text(encoding='utf-8')
writer=Agent(load(w/'generation.yaml').agent,out/'writer/prompts')
schema={'type':'object','additionalProperties':False,'required':['markdown'],'properties':{'markdown':{'type':'string','maxLength':1600}}}
draft=json.loads(writer.chat('Write a concise Korean configuration reference grounded only in supplied implementation. No tools. JSON only.','Add a short standalone fragment for optional max_edge_label_chars on an LLM visual plan, with a minimal YAML example showing its placement. Explain default absent, strict integer 8..240, additional edge-only limit in both languages, combined minimum with the existing all-label max_label_chars, authored labels checked before source guards are appended, no truncation, retry then failure and prior valid output preservation. Nodes keep their existing all-label bound. Do not claim a final rendered-width guarantee. This scalar flag and example need no extra diagram.\nCODE\n'+code,tag='edge-label-config',response_schema=schema))
(out/'config-reference.md').write_text(draft['markdown'],encoding='utf-8')
reviewer=Agent(load(w/'new-document-review.yaml').agent,w/'reviews/config-edge/prompts')
rs={'type':'object','additionalProperties':False,'required':['verdict','findings','scope'],'properties':{'verdict':{'enum':['pass','needs-revision']},'findings':{'type':'array','items':{'type':'string'}},'scope':{'type':'string'}}}
retained='\n'.join((w/name).read_text(encoding='utf-8') for name in ['config-while-documentation-v7/config-reference.md','config-connected-documentation-v2/config-reference.md'])
result=json.loads(reviewer.chat('Independent automatic code grounding, never human approval. No tools. JSON only.','Review the new edge-limit fragment and retained while/connected fragments against current code. Check precise defaults/types, cap interaction, authored versus appended text, retry/failure scope and placement. A short flag with YAML example may omit a diagram.\nNEW\n'+draft['markdown']+'\nRETAINED\n'+retained+'\nCODE\n'+code,tag='edge-config-grounding',response_schema=rs))
record={'review':result,'document_sha256':sha256(out/'config-reference.md'),'source_sha256':sha256(source),'receipt':str(reviewer.last_receipt)};(w/'reviews/config-edge/review.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
assert result['verdict']=='pass' and not result['findings'],result
with (g/'docs/reference/config.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\n'+draft['markdown']+'\n')
print('Configuration native writing and grounding passed')
