from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='actual-queue'
b=w/('before-'+tag);b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/visuals.yaml']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());v=next(v for v in x['sections']['official-cam-validation'] if v['id']=='virtual-frame-path')
 v['prompt']='가상 프레임 그림의 남은 두 표현만 수정합니다. n1(Camera::queueRequest)에서 실패 아님 결과로 n10에 가는 간선은 실제 Camera 호출로 큐에 등록된 요청에만 해당합니다. CameraSession::queueRequest 도우미가 제출 한도에서 호출 없이 0을 반환한 경우는 별도 제출 한도 그림의 경로이며 이 간선으로 진행하지 않습니다. n1 false→n10의 한영 라벨에 실제 큐 등록 요청에만 진행한다는 조건을 짧게 명시하고 helper 반환 0만으로 제출을 단정하지 마세요. n4 영어는 NV12 conversion/converting과 write/writing into mapped buffer 두 동작 모두를 시도함을 명확히 합니다. n4의 반복 Virtual2 이름은 줄일 수 있도록 n0의 한영 할당 질문에 이번 대상 Virtual2를 짧게 명시하고 필요하면 virtual2-config 근거를 추가합니다. 다른 모든 올바른 라벨·12개 노드·실제 guard의 양쪽 결과·인용·연결은 그대로 유지합니다. 한영 노드 60자, authored 간선 20자 이내입니다. 아래 현재 초안은 새 native CLI 편집 입력이며 저장 응답 재생이 아닙니다. 초안: '+json.dumps(m['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-strict-branches-v2.py').read_text().replace('strict-branches-v2',tag);(r/'build/after-virtual-actual-queue.py').write_text(text,encoding='utf-8')
