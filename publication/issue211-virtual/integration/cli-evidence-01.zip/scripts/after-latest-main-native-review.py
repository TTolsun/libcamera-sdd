from pathlib import Path
import sys,json,time,shutil
from sdd.runtime_evidence import run_recorded,require_success,sha256
from sdd.config import load
from sdd.translation_provenance import verified_catalog_units
from sdd.translation import fixed_translation
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-reader-release';site=r/'build/libcamera-sdd-issue211/docs';tag='latest-main-final-v1'
deadline=time.monotonic()+2400
while not (w/'latest-catalog-repair-v1.json').exists():
    if time.monotonic()>deadline:raise TimeoutError('Native catalog repair/review has not completed')
    time.sleep(3)
def run(name,argv):
    out=w/'executions'/('latest-main-final-v1-'+name)
    if out.exists():
        require_success(out);print('Retaining successful execution:',name,flush=True);return
    run_recorded(out,[sys.executable,'-X','utf8']+argv,timeout=1800,cwd=r,environment={'PYTHONPATH':str(g/'src'),'PYTHONIOENCODING':'utf-8'});require_success(out)
# Original stdout/stderr files are siblings of calls/, not inside its UUIDs.
for part in (w/'latest-catalog-translation-v3').glob('part-*'):
    for source in (part/'prompts/cli').iterdir():
        if not source.is_file():raise ValueError('Unexpected CLI archive layout')
        target=d/'build/translation-prompts/cli'/source.name;target.parent.mkdir(exist_ok=True,parents=True)
        if target.exists():assert sha256(target)==sha256(source)
        else:shutil.copyfile(source,target)
run('catalog-acceptance',[str(r/'build/verify-latest-catalog-acceptance.py')])
catalog=json.loads((d/'run/english.json').read_bytes());agent=load(w/'latest-translation-writer.yaml').agent
originals=verified_catalog_units(agent,catalog,[d/'build/translation-prompts/calls'])
repair=json.loads((w/'latest-catalog-repair-v1.json').read_bytes())
fresh=set();repaired=set()
for part in (w/'latest-catalog-translation-v3').glob('part-*'):fresh.update(json.loads((part/'sources.json').read_bytes()))
for part in (w/'latest-catalog-repair-v1').glob('part-*'):
    for origin in json.loads((part/'acceptance.json').read_bytes())['native_origins']:repaired.update(origin['sources'])
fixed={key for key in fresh if fixed_translation(key)==catalog['strings'][key]}
assert len(fresh)==1668 and fresh-set(originals)-fixed<=repaired
(w/'latest-catalog-authentication.json').write_text(json.dumps({'catalog_sha256':sha256(d/'run/english.json'),'standard_native_units':len(originals),'native_repaired_units':len(repaired),'deterministic_location_labels':len(fixed),'repaired_units_also_matching_original_native_values':len(repaired&set(originals)),'all_fresh_units_independently_reviewed':1668,'human_review':'pending'},indent=2)+'\n',encoding='utf-8')
run('export',['-m','sdd.cli','--config',str(d/'publication.yaml'),'export-site','--out',str(site)])
windows=w/'windows'/tag
run('render',[str(g/'examples/libcamera/validation/issue211-reader/render_window.py'),'--work',str(d),'--out',str(windows),'--site',str(site)])
run('review',[str(g/'examples/libcamera/validation/issue211-reader/review.py'),'--work',str(d),'--review-config',str(w/'new-document-review.yaml'),'--out',str(w/'reviews'/tag),'--english',str(windows/'en.txt'),'--korean',str(windows/'ko.txt'),'--inventory',str(windows/'inventory.json'),'--notes',str(w/'notes-final-review/README.md')])
review=json.loads((w/'reviews'/tag/'review.json').read_bytes())['review'];assert review['verdict']=='pass' and not review['findings'],review
print('Final current-main bilingual source grounding PASS',flush=True)
