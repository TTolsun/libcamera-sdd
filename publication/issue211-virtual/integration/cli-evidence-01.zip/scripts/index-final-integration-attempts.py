from pathlib import Path
import json,sys
from sdd.runtime_evidence import sha256
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';tag=sys.argv[1]
accepted=w/'reviews'/tag/'review.json';review=json.loads(accepted.read_bytes())['review'];assert review['verdict']=='pass' and not review['findings']
failed=[];rejected=[]
for p in sorted((w/'executions').rglob('record.json')):
 x=json.loads(p.read_bytes())
 if x.get('exit_code')!=0 or x.get('timed_out'):failed.append({'path':p.relative_to(w).as_posix(),'sha256':sha256(p),'exit_code':x.get('exit_code'),'timed_out':x.get('timed_out'),'cleanup':x.get('cleanup')})
for p in sorted((w/'reviews').rglob('review.json')):
 x=json.loads(p.read_bytes());v=x.get('review',x)
 if v.get('verdict')=='needs-revision':rejected.append({'path':p.relative_to(w).as_posix(),'sha256':sha256(p),'findings':v.get('findings',[])})
(w/'integration-attempts.json').write_text(json.dumps({'schema':1,'accepted_page_review':{'path':accepted.relative_to(w).as_posix(),'sha256':sha256(accepted)},'failed_execution_records':failed,'rejected_review_records':rejected,'scope':'Failures and rejected reviews remain historical and are not accepted as successful runs. The final accepted page and separate upstream-note reviews bind exact output bytes.','human_review':'pending'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Indexed',len(failed),'failed executions and',len(rejected),'rejected reviews')
