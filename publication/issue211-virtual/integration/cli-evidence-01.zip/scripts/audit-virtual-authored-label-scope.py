from pathlib import Path
import json,copy
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.generated_visuals import plans,materialize
from sdd.runtime_evidence import sha256
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual'
cfg=load(w/'generation.yaml');model=KnowledgeModel.load(cfg.facts_path);section=next(s for s in cfg.sections() if s['id']=='official-cam-validation');plan=next(p for p in plans(cfg,section) if p['id']=='request-completion-order')
p=w/'before-authored-label-scope/request-completion-native-probe.json';draft=json.loads(p.read_bytes())
graph=materialize(cfg,model,section,plan,draft,cfg.agent.label)
assert any('queuedRequests_' in e['label'] for e in graph['edges'])
checks=[]
for key in ['label','label_en']:
 bad=copy.deepcopy(draft);bad['nodes']['n4'][key]='queuedRequests_'
 try:materialize(cfg,model,section,plan,bad,cfg.agent.label)
 except ValueError as error:
  assert 'Only authored visible labels' in str(error);checks.append(dict(field=key,rejected=True))
 else:raise AssertionError('Visible implementation identifier was accepted')
print(json.dumps(dict(scope='Configuration probe only, not new model output or runtime success',source_commit=model.meta['source_commit'],probe_native_draft_sha256=sha256(p),good_visible_labels_pass=True,actual_source_guards_retained=True,bad_visible_labels=checks),indent=2))
