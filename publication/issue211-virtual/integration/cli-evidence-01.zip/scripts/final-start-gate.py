from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='start-gate'
b=w/('before-'+tag);b.mkdir()
for name in ['config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='submission-gate':
   v['max_nodes']=10;v['required_symbols'].append('Camera::start')
   v['prompt']=v['prompt'].split('아래 초안')[0]+' 기존 아홉 노드·올바른 한영 라벨·guard·인용은 보존하고 Camera::start를 n9 decision으로 추가합니다. 버퍼 연결 검사 n2의 false 간선을 n3 대신 n9로 보내고 n9는 cam의 camera_->start() 반환이 실패인지 실제 ret<0 조건으로 판정합니다. true는 기존 n5 시작 실패 반환, false는 n3 제출 한도 검사로 갑니다. Camera::start 심볼은 camera-queue 창 끝의 함수 선언과 cam-request-buffers의 실제 camera_->start() 호출·결과 검사 구절을 함께 인용합니다. sink_->start()와 혼동하지 않습니다. 새 간선마다 두 끝점 심볼 및 실제 guard 인용을 포함하고 두 결과를 모두 보존합니다. 한영 노드 라벨은 카메라 세션 시작 실패 여부만 짧게 묻고 코드식은 근거에 둡니다. 나머지 실제 큐 호출 내부의 비동기 전달·제출 생략 조건은 변경하지 않습니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
  if v['id']=='virtual-frame-path':
   v['prompt']='현재 유효한 아홉 노드·모든 실제 조건·양쪽 결과·인용·간선을 정확히 보존하고 세 노드의 한영 라벨만 짧게 줄입니다. n0는 앞 준비 그림에서 오는 버퍼 연결 요청을 PipelineHandler가 준비한다는 뜻을 짧게 표시합니다. n5는 CPU 쓰기 동기화 안에서 쓰기용 DMA-BUF 매핑을 시도한다는 뜻을 짧게 표시하여 DMA-BUF 용어를 이 노드에 둡니다. n8는 버퍼 완료 뒤 다음 그림에서 cam 통지 조건을 확인한다는 연결만 짧게 표시합니다. 한 노드 안에서 프레임 상태 경고와 그림 간 안내를 길게 되풀이하지 않습니다. n0/n5/n8 각각 한 행동과 필요한 연결만 남기고 나머지 노드·인용·간선을 재작성하지 않습니다. n2 취소 완료와 앞선 미완료 요청 통지 보류, n6→n7 성공/오류 결과 반환은 이미 올바르므로 그대로 둡니다. PipelineHandler와 VirtualCameraData::processRequest 식별자는 보존합니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-connected-scope.py').read_text().replace('connected-scope',tag)
text=text.replace("exec((r/'build/translate-connected-module-step.py').read_text(encoding='utf-8'))\n",'')
(r/'build/after-virtual-start-gate.py').write_text(text,encoding='utf-8')
