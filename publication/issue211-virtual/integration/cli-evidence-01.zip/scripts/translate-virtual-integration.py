from pathlib import Path
import json,sys
from sdd.config import load
from sdd.llm import Agent
from sdd.translation import translate_missing
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration'
cfg=load(w/'generation.yaml');assert (cfg.agent.runner,cfg.agent.model,cfg.agent.args)==('claude','claude-haiku-5-5',['--effort','high','--setting-sources','project,local'])
p=d/'run/english.json';catalog=json.loads(p.read_bytes());before=p.read_bytes();(d/'english-before-ui-translation.json').write_bytes(before)
agent=Agent(cfg.agent,w/'build'/('current-main-translation-prompts' if len(sys.argv)==1 else sys.argv[1]));result=translate_missing(cfg,catalog,agent)
assert not [k for k,v in result['strings'].items() if not v]
p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Missing translations: 0')
