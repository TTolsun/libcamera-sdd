from pathlib import Path
import yaml,json,shutil
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-main-integration'
b=w/'before-concise-callback';b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 dest=b/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,dest)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'));reference=m['generated_visuals']['records']['completion-flow']['draft']
def revise(t):
 if t['id']!='flow':return
 questions={
 'dispatch':'CameraSession::requestComplete는 취소 상태 RequestCancelled면 반환하고 그 밖에는 callLater로 CameraSession::processRequest를 이벤트 루프에 미룬다고 먼저 설명하세요. 카메라 매니저 스레드를 막지 않으려는 소스의 이유를 이어서 두 짧은 문장으로 씁니다. 다른 처리 한도·범위 설명은 이 항목에 반복하지 않습니다.',
 'invocation-scope':'세 실제 실행 명령은 화면·파일 출력 옵션을 요청하지 않았다는 사실을 한 문장으로 쓰세요. 다른 출력 옵션을 선택한 동작은 이번 실행으로 검증하지 않았다고 한 문장만 덧붙이세요. 모든 출력 옵션이 요청을 비동기로 보유한다고 주장하거나 비동기 보유 경로를 일반화하지 마세요.',
 'processing':'processRequest 진입 시 captureLimit_가 설정되어 있고 captureCount_가 이미 도달하면 captureDone을 다시 내지 않고 반환한다는 조건과 동작만 한 짧은 문장으로 쓰세요. 첫 등장은 CameraSession::processRequest로 쓰고 다음 항목의 증가 동작은 반복하지 마세요.',
 'frame-work':'프레임 정보를 출력하고 captureCount_를 늘린 뒤, 설정된 한도에 도달하면 captureDone을 내고 processRequest를 반환한다는 동작만 한두 짧은 문장으로 쓰세요. 진입 검사는 반복하지 마세요.',
 'reuse-request':'기록된 출력 싱크 미요청 경로에서 처리를 계속할 요청은 Request::ReuseBuffers로 버퍼를 유지해 재사용한 뒤 CameraSession::queueRequest 도우미를 호출한다는 한 문장만 쓰세요. 제출의 결과·보장·성공이나 다른 옵션 설명은 다음 항목으로 남기고 현재 문장에 붙이지 마세요.',
 'submission-limit':'CameraSession::queueRequest의 queueCount_는 카메라 제출 시도 직전에 늘리는 카운터라고 한 짧은 문장으로 설명하세요. 설정 한도에 이미 도달하면 제출 없이 반환하고 그 밖에는 카운터를 늘려 제출을 시도한다는 분기만 다음 짧은 문장으로 쓰세요. 성공적으로 접수된 개수라는 뜻으로 쓰지 말고 캡처 처리 한도·재사용·다른 옵션은 반복하지 않습니다.'}
 for p in t['parts']:
  if p['id'] in questions:p['question']=questions[p['id']]
p=g/'examples/libcamera/validation/issue211-reader/section.yaml';x=yaml.safe_load(p.read_bytes())
for t in x['design_topics']:revise(t)
p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
p=g/'examples/libcamera/validation/issue211-virtual/retained-visual-overrides.yaml';vs=yaml.safe_load(p.read_bytes());main=next(v for v in vs if v['id']=='completion-flow')
main['prompt']='기록된 출력 싱크 미요청 경로의 고정 10개 노드를 유지하세요. 기존 취소·진입 한도·증가 후 한도 분기와 출처를 보존하며 한영 라벨만 줄입니다. n0 CameraSession::requestComplete 진입, n1 RequestCancelled인가, n2 requestComplete 반환, n3 callLater로 이벤트 루프에 위임, n4 processRequest 진입에서 한도 설정 AND 처리 수 도달인가, n5 processRequest 반환(captureDone 재발행 없음), n6 프레임 정보 출력과 처리 수 증가, n7 증가 후 한도 설정 AND 도달인가, n8 captureDone 후 processRequest 반환, n9 버퍼 유지 재사용 후 제출 도우미 호출입니다. n0→n1, 취소면 n2, 아니면 n3→n4, 진입 한도면 n5, 그 밖에는 n6→n7, 증가 후 한도면 n8, 그 밖에는 n9입니다. 반환 주체는 각각 명시하고 서로 합치지 않습니다. 두 캡처 한도 검사와 신호의 차이는 유지하되 긴 함수 호출식·같은 스레드 이유·출력 범위·제출 도우미 내부를 각 노드에 반복하지 마세요. 제출 도우미는 다음 별도 그림이 설명합니다. 간선에는 짧은 조건만, 노드에는 짧은 행동만 씁니다. 한도 거짓은 미설정 OR 미도달입니다. source condition_ref와 모든 양 끝 symbol 인용을 보존합니다. authored true/false는 시스템 표시와 중복하지 않습니다. 노드·화살표에 같은 동작 전체를 반복하지 않습니다. 취소는 소스 분기이며 이번 실행에서 동적 시험한 것은 아닙니다.'
helper=next(v for v in vs if v['id']=='submission-gate');helper.update(title='제출 도우미는 별도 카운터로 제출을 제한합니다',max_nodes=3,required_symbols=['queueCount_','return','camera_'],sources=['submission-limit'],question='제출 도우미의 별도 카운터 한도에 따라 제출하지 않거나 제출을 시도하는 조건은 무엇입니까?',prompt='앞 그림이 이미 재사용과 도우미 호출을 설명하므로 이 그림은 도우미 내부의 세 노드만 사용합니다. n0은 한도가 설정되고 제출 카운터 queueCount_가 이미 도달했는가라는 결정입니다. 참이면 n1 제출 없이 도우미에서 반환, 거짓(한도 미설정 OR 미도달)이면 n2 카운터 증가 후 카메라 제출 시도입니다. 세 노드와 두 조건 간선만 연결합니다. 실제 조건의 두 branch를 source condition_ref로 인용하고 화살표는 설정·도달 또는 미설정·미도달만 짧게 표시합니다. 카운터는 실제 제출 시도 전에 증가하며 성공 접수를 세는 것이 아닙니다. n2는 시도이며 제출 성공 보장이 아닙니다. 재사용 노드·도우미 호출 노드를 반복하지 마세요. true/false는 시스템 표시와 중복하지 않고 한영 동작·조건을 간결하게 씁니다. source guard와 양 끝 symbol 인용을 보존합니다.')
p.write_text(yaml.safe_dump(vs,allow_unicode=True,sort_keys=False),encoding='utf-8')
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(t for t in x['sections'] if t['id']=='official-cam-validation')
 for t in s['design_topics']:revise(t)
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());out=[]
 for v in x['sections']['official-cam-validation']:
  if v['id']=='completion-flow':v=dict(main);v['prompt']+=' 현재 초안을 편집 입력으로 제공하므로 10개 노드 ID·shape·quote_ids와 간선 from·to·condition_ref·quote_ids는 그대로 보존하고 짧은 한영 라벨만 새 native 응답으로 편집하세요. 참고 초안: '+json.dumps(reference,ensure_ascii=False,separators=(',',':'))
  if v['id']=='submission-gate':v=helper
  out.append(v)
 x['sections']['official-cam-validation']=out;p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
s=(r/'build/after-virtual-queue-prefix.py').read_text().replace('queue-prefix','concise-callback');(r/'build/after-virtual-concise-callback.py').write_text(s)
