from pathlib import Path
import sys
from sdd.runtime_evidence import run_recorded,require_success
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual'
require_success(w/'executions/generate-capture-status-figures')
def run(name,args):
 out=w/'executions'/name;run_recorded(out,[sys.executable,'-X','utf8']+args,timeout=1800,cwd=r);require_success(out);print(name,'PASS',flush=True)
run('update-current-page-translation-v17',[str(r/'build/update-reviewed-page-translation.py'),'v17','generate-capture-status-figures'])
run('latest-contract-native-refresh-capture-status',[str(r/'build/refresh-latest-contract-audit.py'),'-capture-status'])
run('finalize-capture-status-v17',[str(r/'build/finalize-native-page.py'),'latest-main-final-v17','update-current-page-translation-v17','latest-main-final-v16'])
