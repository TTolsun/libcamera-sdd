from pathlib import Path
import yaml,json,shutil
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration'
b=w/'before-final-readable';b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 dest=b/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,dest)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'));reference=m['generated_visuals']['records']['virtual-frame-path']['draft']
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(t for t in x['sections'] if t['id']=='official-cam-validation');t=next(t for t in s['design_topics'] if t['id']=='flow');part=next(p for p in t['parts'] if p['id']=='reuse-request')
 part['question']='화면·파일 출력 옵션을 요청하지 않은 이 기록의 실행에서, 처리를 계속할 요청은 Request::ReuseBuffers로 버퍼를 유지해 재사용한 뒤 CameraSession::queueRequest 도우미를 호출한다고 한 문장으로 설명하세요. 출력 싱크가 존재하지만 요청을 보유하지 않는다는 뜻이 아니라, 세 명령이 출력 옵션 자체를 요청하지 않았다는 조건입니다. 이 조건은 영어 번역에도 그대로 보존되어야 합니다. 제출 결과나 다른 옵션의 동작은 이 항목에 덧붙이지 않습니다.'
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());v=next(t for t in x['sections']['official-cam-validation'] if t['id']=='virtual-frame-path')
 v['prompt']=v['prompt'].split(' 현재 원고를 편집 입력으로 제공합니다.')[0]
 v['prompt']+=' 최종 라벨 가독성 보완: 아래 현재 초안의 노드 ID·shape·quote_ids 및 모든 간선 from·to·condition_ref·quote_ids를 바꾸지 말고 라벨만 새 native 응답으로 편집하세요. n1→n2 간선에는 가상 파이프라인의 처리 경로라는 의미를 명시하고 물리 장치로 보내는 듯한 device 단독 표현은 쓰지 않습니다. n2 화면 라벨에는 queueRequestDevice라는 긴 식별자를 제거하고 VirtualCameraData::processRequest의 queued 호출 예약만 표시합니다. n5는 NV12 변환 오류 여부라는 짧은 판정이며 generateFrame 이름과 반환값 설명은 근거로 내립니다. n5의 두 간선은 FrameError 또는 FrameSuccess라는 결과만 짧게 표시하고 판정 전체를 반복하지 마세요. n6는 버퍼 완료 알림이라는 짧은 동작이면 됩니다. n9와 연결선은 requestCompleted 이름을 한 번만 쓰고, 연속으로 완료된 큐 선두만 순서대로 cam에 통지한다는 관계를 간결하게 유지합니다. 이미 맞는 CPU 쓰기 시도·매핑 대상, 모든 버퍼 완료 여부, 현재 요청 완료 표시, 큐 선두 Pending 보류 조건은 바꾸지 마세요. n0,n1,n3,n4,n7,n8,n10,n11의 올바른 의미·인용은 보존하며 군더더기 함수명 주석이나 동작 반복을 덧붙이지 않습니다. 참고 초안은 편집 입력이며 새 실행·재생 응답이 아닙니다. 실제 새 CLI 응답이 모든 검사를 다시 통과해야 합니다. 참고 초안: '+json.dumps(reference,ensure_ascii=False,separators=(',',':'))
 v['answer_contract_en'].setdefault('reject_patterns',[]).append({'pattern':'queueRequestDevice|(?m:^Is generateFrame)|(?m:^Prepared request passed to device$)','message':'Keep the queued call explicit and labels concise; identify the virtual path rather than a physical device.'})
 v['answer_contract'].setdefault('reject_patterns',[]).append({'pattern':'queueRequestDevice|(?m:^generateFrame의)|(?m:^준비된 요청을 장치로 전달$)','message':'Keep long function identifiers in evidence and identify virtual delivery.'})
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
s=(r/'build/after-virtual-concise-callback.py').read_text().replace('concise-callback','final-readable');(r/'build/after-virtual-final-readable.py').write_text(s)
