from pathlib import Path
import yaml,shutil
r=Path(__file__).resolve().parent.parent;g=r/'build/generator-main-integration';w=r/'build/issue211-virtual';d=w/'current-main-integration'
p=g/'examples/libcamera/validation/issue211-reader/section.yaml';c=yaml.safe_load(p.read_bytes());flow=next(t for t in c['design_topics'] if t['id']=='flow');part=next(x for x in flow['parts'] if x['id']=='submission-limit');part['sources']=['callback-and-processing','submission-limit'];part['question']+=' 두 제공 소스에서 버퍼 유지·요청 재사용·처리 종료 조건을 확인할 수 있습니다. 미확인이라고 부정하지 말고 처리 한도 미도달 시 재사용·도우미 호출, 별도 제출 한도에 따른 실제 제출 시도를 구분하세요.';part['answer_contract']['reject_patterns'].append(dict(pattern=r'확인되지\s*않|미확인|확인할\s*수\s*없',message='선택한 두 소스가 재사용과 한도 조건을 직접 보여 줍니다.'))
p.write_text(yaml.safe_dump(c,allow_unicode=True,sort_keys=False),encoding='utf-8')
p=g/'examples/libcamera/validation/issue211-virtual/retained-visual-overrides.yaml';vs=yaml.safe_load(p.read_bytes())
for v in vs:v['max_edge_label_chars']=40;v['prompt']+=' 화살표는 짧은 조건·이벤트만 씁니다. 노드에 있는 동작을 문장으로 반복하지 말고 무조건 간선은 두세 단어의 짧은 연결어만 씁니다. 상세 조건은 본문과 근거에서 확인합니다.'
helper=next(x for x in vs if x['id']=='submission-gate');helper['prompt']+=' 그림의 시작점은 앞선 소스 경로에서 이미 버퍼를 유지해 재사용한 상태입니다. n0→n1과 n1→n2는 condition_ref always이며 requeue를 새로 판정하는 간선을 넣지 마세요. requeue 판정은 재사용 전의 본래 소스 위치에 있으며 출력 싱크 미요청이라는 전제에서 이미 통과한 조건입니다. 노드나 간선 라벨과 condition_ref에 requeue를 넣지 마세요.'
for lang in ['answer_contract','answer_contract_en']:
 helper.setdefault(lang,{'basis':'implementation'}).setdefault('reject_patterns',[]).append(dict(pattern='requeue',message='This figure starts after reuse; do not move its earlier requeue guard after reuse.'))
repro=next(x for x in vs if x['id']=='reproduction-flow')
for lang in ['answer_contract','answer_contract_en']:
 repro.setdefault(lang,{'basis':'measurement'}).setdefault('reject_patterns',[]).append(dict(pattern='completed_frames',message='Keep evidence field names in evidence; show normal frames to the reader.'))
p.write_text(yaml.safe_dump(vs,allow_unicode=True,sort_keys=False),encoding='utf-8')
p=g/'examples/libcamera/validation/issue211-virtual/visual.yaml';virt=yaml.safe_load(p.read_bytes());virt['max_edge_label_chars']=40;virt['prompt']+=' 무조건 연결 간선은 두세 단어의 짧은 연결어만 씁니다. 분기 간선은 짧은 조건·결과만 쓰고 노드의 행동 전체를 반복하지 마세요.';p.write_text(yaml.safe_dump(virt,allow_unicode=True,sort_keys=False),encoding='utf-8')
b=w/'before-edge-clarity';b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','run/facts/facts.json','config/sections.yaml','config/visuals.yaml']:
 q=b/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,q)
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(t for t in x['sections'] if t['id']=='official-cam-validation');s['design_topics']=[flow if t['id']=='flow' else t for t in s['design_topics']];p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());x['sections']['official-cam-validation']=[virt]+vs;p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
s=(r/'build/after-virtual-recorded-scope-v2.py').read_text().replace('generate-recorded-scope-v2','generate-edge-clarity').replace("tag='recorded-scope-v2'","tag='edge-clarity'").replace('recorded-scope-v2-translation-prompts','edge-clarity-translation-prompts').replace('english-before-recorded-scope-v2.json','english-before-edge-clarity.json').replace("('recorded-scope-v2-'+stage)","('edge-clarity-'+stage)");(r/'build/after-virtual-edge-clarity.py').write_text(s)
