from pathlib import Path
import json,sys,shutil
from sdd.runtime_evidence import run_recorded,require_success
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';tag=sys.argv[1];review=json.loads((w/'reviews'/tag/'review.json').read_bytes())['review'];assert review['verdict']=='pass' and not review['findings']
b=w/'before-accepted-final-proof';b.mkdir()
for name in ['latest-public-base.json','latest-format-base-review.json','current-main-preservation.json','topic-visual-review.json','ui-verification-integrated.json','native-call-verification-integrated.json']:
 p=w/name
 if p.exists():shutil.copyfile(p,b/name)
for name,script,args in [('accepted-format-base','record-format-base.py',[]),('accepted-topic-audit','make-virtual-topic-audit.py',[tag]),('accepted-static-ui-scope','record-final-ui-scope.py',[tag]),('accepted-native-provenance','verify-virtual-integrated-calls.py',[]),('accepted-history-index','index-final-integration-attempts.py',[tag]),('accepted-main-preservation','audit-current-main-preservation.py',[]),('accepted-repeat-export','merge-latest-public-after-review.py',[tag])]:
 out=w/'executions'/name;run_recorded(out,[sys.executable,'-X','utf8',str(r/'build'/script)]+args,timeout=1800,cwd=r);require_success(out);print(name,'PASS',flush=True)
