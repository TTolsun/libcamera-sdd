from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';b=w/'before-finish-reader-labels';b.mkdir()
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 for rel in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
  target=b/root.name/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,target)
 p=root/'config/sections.yaml';data=yaml.safe_load(p.read_bytes());s=next(s for s in data['sections'] if s['id']=='official-cam-validation')
 part=next(p for t in s['design_topics'] if t['id']=='flow' for p in t['parts'] if p['id']=='submission-limit')
 part['question']='처리 수와 제출 시도 수는 같은 캡처 한도 값과 비교되지만, 처리 수 검사는 처리 함수에서, 제출 시도 수 검사는 제출 도우미에서 이뤄져 시점이 다르다는 사실만 짧은 한 문장으로 설명합니다. 그림·항목의 위치 안내, 편집 안내, 내부 필드 이름, 이미 설명한 제출 생략 조건은 쓰지 않습니다. 한도 값 자체가 둘이라고 쓰지 않습니다.'
 part['answer_contract']['reject_patterns'].append({'pattern':'그림|앞 항목|현재 항목','message':'Explain actual counter-check timing; omit editorial figure or item location directions.'})
 p.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';data=yaml.safe_load(p.read_bytes())
 for v in data['sections']['official-cam-validation']:
  if v['id']=='virtual-frame-path':
   v['prompt']='현재 아홉 노드·모든 간선·실제 조건·인용·모든 한국어 라벨·다른 영어 라벨을 그대로 보존하고 요청 처리를 예약하는 노드의 영어 라벨만 수정합니다. 가상 파이프라인 핸들러는 요청과 목표 시각을 처리 함수에 인수로 넘기며 queued 호출을 예약합니다. 목표 시각은 예약 동작의 실행 시점이 아닙니다. 영어에서 with 또는 passing으로 인수 관계를 명확히 하고 schedules at target time처럼 쓰지 않습니다. 별도 대기 노드의 목표 시각까지 기다리는 동작은 유지합니다. 최대72자를 유지합니다. 다음은 native 편집 대상 초안입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
   v['answer_contract_en'].setdefault('reject_patterns',[]).append({'pattern':'(?i)schedul.{0,45}at (?:the )?target','message':'Target time is an argument to the queued processing call; waiting happens in the receiver, not at scheduling time.'})
  elif v['id']=='initial-submission':
   v['max_label_chars']=48
   v['prompt']='현재 열한 노드·모든 간선·실제 조건 양쪽·인용·순서를 정확히 보존하고 한영 라벨만 짧은 행동구·판정 질문으로 줄입니다. 노드 라벨은 합니다/판정합니다 같은 완전한 문장 대신 핵심 동작을 나타내며 양 언어 최대48자입니다. 시작 오류 반환은 카메라 중지를 뜻하지 않으며, 초기 제출 오류 경로만 이미 시작한 카메라를 중지합니다. 상태·요청 검사, API 음수 결과, 비동기 호출 예약 뒤0반환, 도우미 음수 판정, 한도에 따른 제출 생략과 반복을 모두 보존합니다. 예약은 처리 완료가 아니며 코드 식별자와 내부 수치 필드는 근거에 둡니다. guard 간선은 조건 질문을 반복하거나 true/false를 직접 넣지 말고 분기 뒤 행동·결과를 간결하게 표시합니다. 자동 분기 표시는 유지됩니다. 다음은 native 편집 대상 초안입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
  else:continue
 p.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
