from pathlib import Path
import json,shutil,yaml,copy
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='startup-topic'
b=w/('before-'+tag);b.mkdir()
for name in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(s for s in x['sections'] if s['id']=='official-cam-validation');vtopic=next(t for t in s['design_topics'] if t['id']=='virtual-principle')
 question='기록된 단일 스트림·출력 싱크 미요청 구성에서 카메라 시작 전 모든 초기 요청 준비, 제출 한도와 큐 호출 오류 처리는 어떤 순서입니까?'
 topic={'id':'initial-requests','title':'기록된 단일 스트림에서 초기 요청을 준비하고 제출합니다','question':question,'covers':['initial-requests'],'product':{'id':'libcamera-official-cam-trial','feature':'recorded-no-output-sink'},'design_prompt':'focused','sources':[copy.deepcopy(a) for a in vtopic['sources'] if a['id'] in ['cam-request-buffers','camera-queue','pipeline-dispatch']],'prompt':'이 항목은 실제 기록된 한 개 스트림과 출력 싱크 미요청 구성을 대상으로 초기 준비와 제출을 설명합니다. 앞 항목은 virtual의 프레임 생성과 완료 통지를 설명하므로 반복하지 않습니다. 내부 변수·코드 식별자는 근거 영역에 둡니다.','parts':[{'id':'overview','role':'summary','question':'기록된 단일 스트림·출력 싱크 미요청 구성의 초기 캡처 준비·제출이라는 범위를 먼저 명시하고, cam이 모든 초기 요청과 버퍼를 먼저 준비한 뒤 카메라를 시작하고 요청별 제출 한도를 검사한다는 순서를 짧게 설명합니다. 큐 호출은 검증 실패시 오류를 반환하고, 통과하면 요청을 비동기로 전달한 뒤0을 반환하며, 초기 제출 도우미가 음수 오류를 반환하면 카메라를 중지하고 오류를 반환한다는 관계를 덧붙입니다. 짧은 한 문단3–4문장으로 쓰고 콜백·재현 설명이나 내부 식별자를 반복하지 않습니다. 일반 다중 스트림 전체 흐름이라고 확대하지 마세요.','sources':['cam-request-buffers','camera-queue','pipeline-dispatch','product-invocation-options'],'max_statements':1,'answer_contract':{'basis':'implementation','required_terms':[['단일 스트림'],['요청'],['버퍼'],['카메라']]}}]}
 s['design_topics'].insert(s['design_topics'].index(vtopic)+1,topic);s['design_requirements'].insert(2,{'id':'initial-requests','question':question})
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());v=next(v for v in x['sections']['official-cam-validation'] if v['id']=='submission-gate');v['topic']='initial-requests';v['title']='단일 스트림의 초기 준비·제출과 실패 처리';v['question']=question;v['max_nodes']=11;v['max_label_chars']=56
 v['required_symbols']=[s for s in v['required_symbols'] if s!='queueCount_']
 v['prompt']='실제 기록된 단일 스트림·출력 싱크 미요청 구성으로 범위를 한정한 초기 요청 준비와 제출 그림입니다. 일반 다중 스트림 반복을 묘사하지 않습니다. 기존 초안의 n8 제출 시도수 증가 노드를 없애고 n3 한도 false에서 n4 카메라 큐 호출로 가는 간선에 시도수 증가 뒤 호출임을 짧게 표시합니다. 실제 카운터 증가 근거는 유지합니다. 나머지11노드의 모든 준비·시작·한도·오류 조건과 요청 준비 반복, 초기 제출 순회, 소스 인용을 보존합니다. n0false 라벨은 단일 스트림 할당 성공 뒤 요청 준비, n2false는 버퍼 연결 성공 뒤 현재 요청 보관입니다. n7은 현재 요청 보관이라는 짧은 동작구이며 requests_ 같은 내부 이름을 표시하지 않습니다. n7에서 남은 요청이 있으면 n1로 반복하고 모든 초기 요청·버퍼 준비 뒤에만 n9 카메라 시작으로 갑니다. n4 라벨은 카메라 큐 호출의 검증 실패시 오류 반환, 통과시 비동기 전달 후0반환을 짧게 표현하며 n10으로만 이어져 도우미 반환값을 검사합니다. n11은 이 출력 싱크 미요청 범위의 큐 오류시 카메라 중지 후 오류 반환입니다. n6은 남은 초기 요청 순회와 모두 끝나면 초기 제출 종료를 간결하게 표시합니다. 노드·간선의 모든 표시에서 내부 requests_, captureLimit_, queueCount_, sink_ 등을 빼고 실제 symbol·조건·인용은 그대로 근거로 남깁니다. 노드56자·간선20자 한영 한도를 지키고 실제 조건의 양쪽 결과를 모두 보존합니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-preparation-order-v2.py').read_text().replace('preparation-order-v2',tag)
(r/'build/after-virtual-startup-topic.py').write_text(text,encoding='utf-8')
