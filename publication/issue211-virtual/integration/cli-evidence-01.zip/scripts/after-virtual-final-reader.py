from pathlib import Path
import sys,json,shutil
from sdd.runtime_evidence import run_recorded,require_success
from sdd.config import load
from sdd.localization_cli import prepare_catalog
from sdd.translation import translate_missing
from sdd.llm import Agent
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-main-integration';site=r/'build/libcamera-sdd-issue211/docs';tag='final-reader'
require_success(w/'executions/generate-final-scope')
shutil.copyfile(w/'run/manuscripts/official-cam-validation.md',d/'run/manuscripts/official-cam-validation.md')
facts=json.loads((d/'run/facts/facts.json').read_bytes());new=json.loads((w/'run/facts/facts.json').read_bytes());assert facts['meta']['source_commit']==new['meta']['source_commit']
facts['evidence']={k:v for k,v in facts['evidence'].items() if not k.startswith('official-cam-validation/')}|{k:v for k,v in new['evidence'].items() if k.startswith('official-cam-validation/')}
(d/'run/facts/facts.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cfg=load(w/'generation.yaml');render=load(d/'publication.yaml');p=d/'run/english.json';shutil.copyfile(p,d/'english-before-final-reader.json');prepare_catalog(render,p,translate=False)
catalog=json.loads(p.read_bytes());print('Missing before fresh Claude translation',sum(not v for v in catalog['strings'].values()),flush=True)
agent=Agent(cfg.agent,w/'build/final-reader-translation-prompts');translated=translate_missing(cfg,catalog,agent);assert all(translated['strings'].values());p.write_text(json.dumps(translated,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
prefix=[sys.executable,'-X','utf8']
def run(stage,argv):
 out=w/'executions'/('final-reader-'+stage);run_recorded(out,prefix+argv,timeout=1800,cwd=r);require_success(out)
run('export',['-m','sdd.cli','--config',str(d/'publication.yaml'),'export-site','--out',str(site)])
windows=w/'windows'/tag
run('render',[str(g/'examples/libcamera/validation/issue211-reader/render_window.py'),'--work',str(d),'--out',str(windows),'--site',str(site)])
run('review',[str(g/'examples/libcamera/validation/issue211-reader/review.py'),'--work',str(d),'--review-config',str(w/'new-document-review.yaml'),'--out',str(w/'reviews'/tag),'--english',str(windows/'en.txt'),'--korean',str(windows/'ko.txt'),'--inventory',str(windows/'inventory.json'),'--notes',str(w/'notes-resume-upstream/README.md')])
review=json.loads((w/'reviews'/tag/'review.json').read_bytes())['review'];assert review['verdict']=='pass' and not review['findings'],review
print('Sink-context final bilingual review passed')
