from pathlib import Path
import copy,json,re,shutil,yaml,sys
from sdd.config import load
from sdd.llm import Agent
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='separate-preparation'
b=w/('before-'+tag)
if '--resume' in sys.argv:
 for name in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:assert (b/name).read_bytes()==(w/name).read_bytes()
else:
 b.mkdir()
 for name in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
  p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
a=Agent(load(w/'generation.yaml').agent,w/'build/separate-preparation-caption-retry-prompts')
schema={'type':'object','additionalProperties':False,'required':['title','title_en'],'properties':{k:{'type':'string','maxLength':70} for k in ['title','title_en']}}
raw=a.chat('Write a concise Korean diagram caption and matching English caption. Return JSON only. Explain request preparation and the distinction between a submission helper returning success without submission at its limit versus an actual Camera queue call. Keep it short; this is source analysis, not newly observed execution.','The diagram shows DMA-BUF allocation, request creation and buffer attachment error gates, then a submission-limit gate, an increment of submission attempts, actual Camera queue validation, and queued delivery to the pipeline.',tag='preparation-caption',response_schema=schema)
caption=json.loads(re.sub(r'^```(?:json)?\s*|\s*```$','',raw.strip()));(w/'build/separate-preparation-caption-retry-prompts/caption.json').write_text(json.dumps(caption,ensure_ascii=False,indent=2),encoding='utf-8')
for root in [w,d]:
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());vs=x['sections']['official-cam-validation'];A=next(v for v in vs if v['id']=='virtual-frame-path');D=next(v for v in vs if v['id']=='submission-gate')
 D.update(topic='virtual-principle',title=caption['title'],kind='decision',max_nodes=9,max_label_chars=70,require_guard_branches=True,while_conditions=True,required_symbols=['exportFrameBuffers','createRequest','addBuffer','CameraSession::queueRequest','Camera::queueRequest','startCapture','captureLimit_','PipelineHandler::queueRequest','queueCount_'],sources=['virtual-buffer-allocation','cam-request-buffers','allocator-to-camera','camera-export','camera-queue','pipeline-dispatch','virtual2-config'])
 D['answer_contract']={'basis':'implementation'};D['answer_contract_en']={'basis':'implementation'}
 D['question']='버퍼·요청 준비와 제출 도우미의 한도 검사를 거쳐 실제 카메라 큐 호출로 진행하는 조건은 무엇입니까?'
 D['prompt']='정확히 9개 노드 n0..n8로 별도 준비 그림을 새로 작성하세요. n0 exportFrameBuffers 실제 할당 실패 guard true→n5 시작 실패 반환, false→n1 요청 생성 실패 여부(!request) true→n5,false→n2 addBuffer 실패 guard true→n5,false→n3입니다. 세 검사 모두 cam startCapture 실제 guard 근거를 갖춥니다. 다른 시작 조건이 충족된 주요 경로의 요약이며 n5는 앞선 요청이 전혀 제출되지 않았다고 단정하지 않습니다. n3 CameraSession::queueRequest는 한도가 설정되고 제출 시도 수가 이미 한도 이상인지 결정합니다. 실제 helper guard true→n6 captureLimit_는 이 요청을 제출하지 않고 0 반환, false→n8 queueCount_ 제출 시도 수 증가→n4 Camera::queueRequest 실제 API 호출 실패 판정입니다. n4의 guard는 호출자 startCapture의 실제 helper ret<0를 인용하되 도우미 한도 분기를 이미 통과한 Camera 호출 결과임을 밝힙니다. true→n5,false→n7 PipelineHandler::queueRequest 비동기 전달이며 다음 패턴 그림으로 이어집니다. helper가 0 반환했다고 언제나 제출한 것으로 그리지 마세요. 짧은 한영 행동·질문 라벨, 한 노드 한 행동, 간선 20자 이내입니다. 모든 실제 guard의 양쪽 결과는 같은 decision에서 출발하며 source guard를 보존합니다. 제출 한도는 재사용 후 재제출에도 같은 도우미로 적용됩니다. 이 그림에 변환/완료 동작을 추가하지 마세요.'
 A.update(max_nodes=9,required_symbols=['PipelineHandler::queueRequest','PipelineHandler::doQueueRequest','completeRequest','queueRequestDevice','VirtualCameraData::processRequest','MappedFrameBuffer','ARGBToNV12','generateFrame','bufferCompleted'],sources=['pipeline-dispatch','pipeline-register','pipeline-completion','request-status-completion','virtual-queue','virtual-frame','pattern-frame','virtual-start','virtual-completion','virtual2-config'])
 # Remove obsolete allocation-only label rules while retaining the strict source and readability contracts.
 for key in ['answer_contract','answer_contract_en']:
  A[key]['reject_patterns']=[q for q in A[key]['reject_patterns'] if 'cancelRequest' not in q['pattern']]
 A['prompt']='앞 준비 그림에서 실제 Camera 큐 호출을 통과한 요청부터 정확히 9개 노드 n0..n8로 새로 작성합니다. n0 PipelineHandler::queueRequest는 실제 큐 전달 수신과 prepare 준비 시작, n1 PipelineHandler::doQueueRequest는 준비 완료·큐 차례 후 cancelled_ 판정입니다. n0→n1는 준비 완료 신호와 대기 큐 차례 조건을 짧게 명시한 주요 경로 요약 always입니다. 실제 cancelled_ guard true→n2 completeRequest는 취소 상태 완료를 표시하고 순서 통지 경로로 보냅니다. n2 라벨은 앞선 Pending 요청이 있으면 취소 통지도 보류됨을 한영 모두 명시하며 즉시 통지를 보장하지 않습니다. false→n3 queueRequestDevice는 queued 예약→n4 VirtualCameraData::processRequest 실행과 목표 시각 대기→n5 MappedFrameBuffer 쓰기 동기화 범위 안 쓰기용 매핑 시도→n6 ARGBToNV12 CPU의 Virtual2 lines 패턴 NV12 변환 및 매핑 버퍼 쓰기 두 동작 시도→n7 generateFrame 변환 오류 판정→n8 bufferCompleted입니다. n7 실제 ret<0 true/false 두 결과 모두 n8로 가며 true는 FrameError, false는 FrameSuccess입니다. n8는 상태와 무관한 버퍼 완료 신호이며 다음 완료·순서 그림으로 이어집니다. n0/n1 source pipeline-register와 pipeline-dispatch, n2 request-status-completion 및 pipeline-completion 근거를 함께 확인합니다. 준비 도우미/할당/Camera API/제출 카운터를 이 그림에 다시 넣지 않습니다. 노드 60자, authored 간선 20자, 한국어·영어 모두 짧은 행동·질문으로 씁니다. 쓰기 방향 동기화는 매핑/변환/쓰기를 둘러싸는 범위이며 그 뒤 따로 시작한다고 쓰지 마세요. 취소 분기 true/false와 변환 오류 true/false는 실제 guard를 보존합니다.'
 x['sections']['official-cam-validation']=[D,A]+[v for v in vs if v['id'] not in [D['id'],A['id']]]
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/sections.yaml';s=yaml.safe_load(p.read_bytes());topic=next(t for z in s['sections'] if z['id']=='official-cam-validation' for t in z['design_topics'] if t['id']=='reproduce');parts=topic['parts']
 step=copy.deepcopy(next(t for t in parts if t['id']=='camera-selection'));step.update(id='capture-limit-check',question="statement.text를 '11. '로 시작하세요. 실제 실행할 cam 명령의 캡처 한도가 --capture=3인지 실행 전에 확인하는 짧은 명령형 문장 하나를 쓰세요. 재현 도우미를 사용하면 그 도우미가 실제 cam에 이 인자를 전달하는지도 확인합니다. 이전 기록이 아닌 새 실행 명령의 입력 확인입니다.")
 step['answer_contract']={'basis':'measurement','required_terms':[['--capture=3']]};parts.insert(next(i for i,t in enumerate(parts) if t['id']=='execution'),step)
 for part in parts:
  if part['id']=='stream-request':part['question']=part['question'].split('두 번째 짧은 문장은')[0]
  if part['id']=='execution':part['question']=part['question'].replace("'11. '","'12. '")+' 앞선 모든 실행 전 조건이 충족된 뒤 실행하는 행동입니다.'
  if part['id']=='results':part['question']=part['question'].replace("'12. '","'13. '")
 p.write_text(yaml.safe_dump(s,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-actual-queue.py').read_text().replace('actual-queue',tag)
text=text.replace("catalog=json.loads(p.read_bytes());print", "catalog=json.loads(p.read_bytes());caption=json.loads((w/'build/separate-preparation-caption-retry-prompts/caption.json').read_bytes());assert caption['title'] in catalog['strings'];catalog['strings'][caption['title']]=caption['title_en'];print")
(r/'build/after-virtual-separate-preparation.py').write_text(text,encoding='utf-8')
