from pathlib import Path
import json,shutil,yaml,subprocess,hashlib,collections
from sdd.site_localization import display_strings
r=Path(__file__).resolve().parent.parent; w=r/'build/issue211-virtual'; public=r/'build/libcamera-sdd-issue211'
old=Path('C:/Users/baboe/.codex/worktrees/b199/camera-hal-sdd-generator/build/issue214/draft-v1')
dest=w/'current-main-integration'
if dest.exists():raise ValueError('Preserve prior integration')
shutil.copytree(old,dest)
def read(p):return json.loads(p.read_bytes())
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for p in dest.glob('*.yaml'):
 text=p.read_text(encoding='utf-8').replace(str(old),str(dest)).replace(old.as_posix(),dest.as_posix())
 p.write_text(text,encoding='utf-8')
for name in ['sections','visuals']:
 p=dest/'config'/(name+'.yaml'); d=yaml.safe_load(p.read_bytes()); ours=yaml.safe_load((w/'config'/(name+'.yaml')).read_bytes())
 if name=='sections':d['sections']=[next(s for s in ours['sections'] if s['id']=='official-cam-validation') if s['id']=='official-cam-validation' else s for s in d['sections']]
 else:d['sections']['official-cam-validation']=ours['sections']['official-cam-validation']
 p.write_text(yaml.safe_dump(d,allow_unicode=True,sort_keys=False),encoding='utf-8')
shutil.copyfile(w/'run/manuscripts/official-cam-validation.md',dest/'run/manuscripts/official-cam-validation.md')
facts=read(dest/'run/facts/facts.json');ours=read(w/'run/facts/facts.json')
assert facts['meta']['source_commit']==ours['meta']['source_commit']=='293d751a814e0d4c34e85ad457ccd9d5eefd1a61'
facts['evidence']={k:v for k,v in facts['evidence'].items() if not k.startswith('official-cam-validation/')}|{k:v for k,v in ours['evidence'].items() if k.startswith('official-cam-validation/')}
write(dest/'run/facts/facts.json',facts)
catalog=read(dest/'run/english.json');new=read(w/'run/english.json')
page=(public/'docs/official-cam-validation.html').read_text(encoding='utf-8')
units=set(display_strings(page)); shared=set()
for p in (public/'docs').glob('*.html'):
 if p.name!='official-cam-validation.html':shared.update(display_strings(p.read_text(encoding='utf-8')))
selected={key for key in units if key not in shared}|{key for key in new['strings'] if key not in catalog['strings']}
for key in selected:
 if key in new['strings']:
  catalog['strings'][key]=new['strings'][key]
  catalog['translation_contexts'][key]=new['translation_contexts'].get(key,[])
catalog['source_contexts'].update(new['source_contexts']);write(dest/'run/english.json',catalog)
cfg=yaml.safe_load((dest/'publication.yaml').read_bytes())
cfg['source']['root']=str(r/'build/libcamera-source-issue211')
cfg['site']['manuscript_profiles']['official-cam-validation.md']=str(w/'generation.yaml')
cfg['site']['mermaid_dir']=str(public/'docs/assets/mermaid')
cfg['documentation']['pages']['official-cam-validation.md']={}
cfg['publication']['operation_id']='issue211-virtual-current-main-integration'
# Existing baseline contracts for the three issue214 pages remain intact.
# The changed official-cam contract is the independently reviewed source-backed expansion.
from sdd.config import load
from sdd.publication_plan import _requirements
before=load(Path(cfg['publication']['baseline_config']))
expected=_requirements(before.sections()); actual=_requirements(yaml.safe_load((dest/'config/sections.yaml').read_bytes())['sections'])
for key,value in expected.items():
 if actual.get(key)!=value and key.startswith('official-cam-validation/'):
  cfg['publication']['allowed_contract_changes'][key]='Preserve the reviewed virtual-principle and counter/signal clarification from generator PR222; final native bilingual review counter-signal-final passed.'
(dest/'publication.yaml').write_text(yaml.safe_dump(cfg,allow_unicode=True,sort_keys=False),encoding='utf-8')
write(dest/'integration-inputs.json',dict(schema=1,public_base='14ee8354c5b185d90c935de22f556930bc2412b2',generator_commit='658f013075528d91d545eb5b795da13b5887edd2',baseline=facts['meta']['source_commit'],changed_manuscript='official-cam-validation.md',other_manuscripts='Copied exactly from issue214 final workspace',translation_overlay_keys=len(selected),historical_checks='Original issue214 reports retained with their original code/input bindings; not new performance measurements',human_review='pending'))
print(dest)
