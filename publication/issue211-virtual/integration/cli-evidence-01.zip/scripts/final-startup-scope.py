from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='startup-scope'
b=w/('before-'+tag);b.mkdir()
for name in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(s for s in x['sections'] if s['id']=='official-cam-validation')
 for t in s['design_topics']:
  if t['id'] not in ['initial-preparation','initial-submission']:continue
  if t['id']=='initial-preparation':t['title']='여러 초기 요청을 단일 스트림에 맞춰 준비합니다'
  for a in t['parts']:
   a['question']+=' 표시 본문에는 내부 변수·긴 함수명·오류 출력 문자열·뒤 항목 안내·관측되지 않은 내부 값 설명을 넣지 않습니다. 인용은 근거에서 제공하므로 쉬운 주어·동작·조건만 짧게 설명합니다.'
   a['answer_contract'].setdefault('reject_patterns',[]).append({'pattern':r'::|requests_|camera_|sink_|ConnectionType|Failed to|Can.t create|뒤 항목|관측되지|관찰되지','message':'Keep implementation identifiers, console strings, unobserved internal state and editorial navigation in evidence; retain only the requested concise behavior and consequential conditions.'})
   if t['id']=='initial-submission' and a['id']=='start':a['question']='기록된 단일 스트림·출력 옵션 미요청 범위를 먼저 밝히고, cam이 모든 초기 요청 준비를 마친 뒤 카메라 시작 함수를 호출한다는 첫 짧은 문장을 씁니다. 시작 함수가 오류를 반환하면 초기 캡처 함수도 그 오류를 반환한다는 두 번째 짧은 문장으로 마칩니다. 이 분기에서 카메라를 중지한다고 쓰지 않습니다. 이후 한도 검사·큐 호출·내부 변수·미관측 경고·다음 항목 안내·오류 메시지 문자열을 쓰지 않습니다.'
   if t['id']=='initial-submission' and a['id']=='queue-result':
    a['question']='카메라 큐 호출은 카메라가 실행 중인지와 요청 유효성을 검사하며 실패하면 오류를 반환하고, 선행 검사를 모두 통과하면 요청을 비동기로 전달한 뒤0을 반환한다는 관계를 짧은 문장으로 설명합니다. 카메라 실행 상태 검사를 빠뜨린 채 요청의 일부 속성만 열거하고 그것이 모든 성공 조건이라고 쓰지 마세요. 초기 제출 도우미가 음수 오류를 반환하면 cam이 이미 시작한 카메라를 중지하고 오류를 반환한다는 두 번째 짧은 문장으로 마칩니다. 클래스·변수·enum·세부 검증 목록·콘솔 출력 문자열은 근거에 남깁니다.'
    a['answer_contract']['required_terms']=[['실행 상태','실행 중','실행중'],['검사','검증']]
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='submission-gate':
   v['title']='초기 요청들의 준비 반복과 준비 완료'
   v['prompt']='현재 검증된 일곱 노드·모든 간선·실제 조건·인용·표시를 정확히 보존합니다. 제목은 복수의 초기 요청들을 준비하고 준비 단계가 완료되는 뜻이며 요청 하나의 종료를 뜻하지 않습니다. 그래프 내부의 동작이나 분기를 바꾸지 않습니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
  elif v['id']=='initial-submission':
   v['prompt']='현재 검증된 아홉 노드·모든 간선·실제 조건·인용을 정확히 보존하고 start_fail과 camera_queue의 한영 라벨만 고칩니다. start_fail은 startCapture 함수가 카메라 시작 오류를 반환하는 동작입니다. 카메라 stop을 호출하지 않으므로 return and stop/반환하고 종료 같은 종료 주체가 모호한 표현 대신 startCapture를 주어로 오류 반환을 명시하세요. camera_queue는 카메라 큐 호출이 카메라 실행 상태 및 요청을 검증하고 실패하면 오류를 반환하며, 통과하면 비동기 전달 후0을 반환한다는 두 결과를 명확한 주어로 짧게 씁니다. 요청 검사 일부만으로 무조건 성공한다고 쓰지 않습니다. stop_err의 실제 큐 오류시 카메라 중지와 오류 반환은 그대로 보존합니다. 다른 표시·분기·정상 종료는 바꾸지 않습니다. 한영 노드72자·간선20자 이내입니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
  else:continue
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
(r/'build/after-virtual-startup-scope.py').write_text((r/'build/after-virtual-split-startup.py').read_text().replace('split-startup',tag),encoding='utf-8')
