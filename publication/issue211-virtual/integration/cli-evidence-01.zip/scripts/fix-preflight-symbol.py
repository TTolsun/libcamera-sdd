from pathlib import Path
import shutil,yaml
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.generated_visuals import plans,inputs
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration'
b=w/'before-preflight-groups-v2/config';b.mkdir(parents=True);shutil.copyfile(w/'config/visuals.yaml',b/'visuals.yaml')
for root in [w,d]:
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());v=next(v for v in x['sections']['official-cam-validation'] if v['id']=='reproduction-flow')
 v['required_symbols']=[s if s!='YAML' else 'Virtual2' for s in v['required_symbols']]
 v['prompt']=v['prompt'].replace('yaml_check(YAML)','yaml_check(Virtual2)').replace('아래 초안은','host_approval 노드에는 호스트 변경 실행 직전이라는 한국어와 immediately before host change라는 영어 시점을 명확히 유지하며 immediately를 다른 검사 노드에 붙이지 않습니다. 아래 초안은')
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
cfg=load(w/'generation.yaml');m=KnowledgeModel.load(cfg.facts_path);s=next(s for s in cfg.sections() if s['id']=='official-cam-validation')
for plan in plans(cfg,s):inputs(cfg,m,s,plan)
print('All five current visual plans passed actual source-symbol/input preflight')
p=r/'build/after-virtual-preflight-groups.py';p.with_name('after-virtual-preflight-groups-v2.py').write_text(p.read_text().replace('preflight-groups','preflight-groups-v2').replace('translate-preflight-choice-steps.py','translate-preflight-choice-steps.py'),encoding='utf-8')
