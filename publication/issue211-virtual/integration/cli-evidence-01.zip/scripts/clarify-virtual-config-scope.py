from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='configuration-scope'
b=w/('before-'+tag);b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());part=next(p for s in x['sections'] if s['id']=='official-cam-validation' for t in s['design_topics'] if t['id']=='virtual-principle' for p in t['parts'] if p['id']=='purpose')
 part['question']='고정 libcamera 소스에서 분석한 virtual 파이프라인의 개요를 네 짧은 문장으로 설명합니다. 첫 문장은 고정 소스 분석이라는 범위와, 실제 센서 대신 소프트웨어 테스트 패턴이나 이미지 입력을 지원하는 virtual 기능의 일반 설명입니다. 둘째 문장은 이번에 선택한 Virtual2 구성이 400x300 lines 패턴을 공급한다는 구체 사례입니다. 기능 전체가 이 설정 하나로 고정됐다고 정의하지 마세요. 셋째 문장은 할당이 성공한 뒤 cam이 실제 DMA-BUF 버퍼를 붙인 요청의 전달을 준비하는 관계입니다. 넷째 문장은 CPU가 NV12 변환과 매핑된 버퍼 쓰기를 모두 시도한다는 뜻입니다. 완료 조건과 구현 식별자는 뒤 항목·근거가 맡으므로 반복하지 않습니다.'
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='virtual-frame-path':
   edit='n0 할당 실패 판정의 false→n1 간선과 n1 라벨만 수정합니다. 할당 성공 뒤 요청 생성·버퍼 추가·카메라 시작·제출도 실패할 수 있습니다. 이 그림이 그 나머지 준비·시작의 성공 경로를 요약한다는 조건을 간선에 짧게 표시하고, 제출 성공을 보장하는 표현을 피하세요. 간선 라벨에 submit/요청 제출이라는 확정 동작을 쓰지 말고 후속 준비 성공 경로라는 뜻을 씁니다. n1은 Camera의 버퍼 없는 요청 거부를 유지하면서, 나머지 cam 준비·시작이 성공한 경로에서 비동기 전달을 시도함을 한영 모두 표시합니다. 실제 디바이스 제출 성공 보장이 아닙니다. n0의 실패 true→n7과 실제 할당 조건, n2의 VirtualCameraData::processRequest, 매핑·변환 시도, 완료 신호와 다음 그림 연결 등 다른 올바른 구조·라벨·인용은 그대로 보존합니다. '
  elif v['id']=='reproduction-flow':
   v['max_label_chars']=96
   edit='device_verify 조건 노드의 한영 라벨만 수정합니다. 기록된 커널과 root의 /dev/udmabuf 접근, YAML의 크기 400x300 및 패턴 값 lines, 새 cam 명령의 카메라 Virtual2 및 스트림 400x300 NV12를 짧게 구분합니다. YAML: 크기/패턴과 cam: 카메라/스트림이라는 두 확인 대상을 명시하여 서로 혼동되지 않게 하세요. 이 조건 노드의 여러 필수 입력을 정확히 보이기 위해 한영 96자까지 허용하되 짧은 구절로 씁니다. 다른 모든 올바른 노드와 간선, 실행 직전 별도 승인, 조건 불일치 중단과 한 새 증거 위치 안 세 실행 분리는 그대로 보존합니다. '
  else:continue
  v['prompt']=edit+'간선 authored 라벨은 한영 20자 이내이며 실제 분기 조건·인용은 보존합니다. 아래 초안은 실제 새 native CLI 편집 입력이며 저장 응답 재생이 아닙니다. 참고 초안: '+json.dumps(m['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
(r/'build/after-virtual-configuration-scope.py').write_text((r/'build/after-virtual-bound-preflight.py').read_text().replace('bound-preflight',tag),encoding='utf-8')
