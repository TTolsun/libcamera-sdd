from pathlib import Path
import json,shutil,yaml,sys
from sdd.document_metadata import split_frontmatter
from sdd.runtime_evidence import run_recorded,require_success
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-reader-release';out=w/'before-capture-status-figures';out.mkdir()
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
findings=json.loads((w/'reviews/latest-main-final-v16/review.json').read_bytes())['review']['findings']
for root in [w,d]:
 p=root/'config/visuals.yaml';backup=out/root.name;backup.mkdir();shutil.copy2(p,backup/'visuals.yaml');data=yaml.safe_load(p.read_bytes())
 for v in data['sections']['official-cam-validation']:
  if v['id'] not in ['virtual-frame-path','request-completion-order','submission-gate']:continue
  instructions='현재 노드 수·간선·실제 guard 양쪽·인용·현재 올바른 한영 의미를 보존하고 아래 독립 Terra 지적을 해당 그림에 적용합니다. 소스가 권위이며 검토는 수정 방향입니다. 판정은 결정 노드에서, 결과 동작은 도착 노드에서 한 번만 설명하며 간선은 짧은 분기 결과로 제한합니다. 식별자는 다른 식별자에 화살표로 붙이지 말고 공백으로 구분하여 단어 중간 줄바꿈을 피합니다. '
  if v['id']=='virtual-frame-path':
   instructions+='오류 guard의 true 간선에는 FrameError 설정, false 간선에는 FrameSuccess 설정을 명시하고 두 간선은 공통 버퍼 완료 노드로 합칩니다. 공통 노드는 버퍼 완료와 별도 요청 완료의 차이를 유지하되 상태 설정을 반복하지 않습니다. 취소 노드는 해당 요청의 취소 완료 처리 후 큐 앞에서부터 통지하며, 통지 대상 전체가 취소 요청이라는 뜻이 아니어야 합니다. 앞 RequestPending에서 뒤 요청은 보류하고 검사는 중단합니다. 목표 시각은 queued 호출 인수이며 대기는 수신 측에서 한다는 뜻, CPU 쓰기 동기화·매핑·NV12 lines 패턴 변환과 쓰기 시도를 보존합니다. '
  elif v['id']=='request-completion-order':
   if 'request-status-completion' not in v['sources']:v['sources'].append('request-status-completion')
   instructions+='요청 상태 표시 노드는 정상 RequestComplete와 취소 RequestCancelled 유지의 구분을 실제 Request::Private::complete 소스로 설명합니다. 상태 표시는 통지와 구분됩니다. 큐 비어 있지 않음, 맨 앞 Pending이면 뒤 통지 보류·반복 중단, 아니면 맨 앞 하나 꺼내 통지 후 반복을 유지합니다. Pending 조건은 결정 노드, 뒤 통지 보류·중단은 그 결과 노드에 각각 한 번씩 둡니다. requestComplete와 requestCompleted 식별자는 각각 공백으로 분리된 단어로 사용하며 화살표나 중간 줄바꿈으로 합치지 않습니다. '
  else:instructions+='초기 버퍼 연결 실패 판정 뒤 간선은 오류라는 짧은 결과만 나타내며 버퍼 연결 실패 시 반환처럼 판정과 반환 동작을 반복하지 않습니다. 공통 오류 반환 노드가 반환을 담당합니다. 할당·요청 생성·버퍼 연결의 실패와 성공 양쪽, 남은 초기 요청 반복, 카메라 시작 전 준비 완료 범위를 유지합니다. '
  v['prompt']=instructions+'실제 검토 지적: '+json.dumps(findings,ensure_ascii=False)+' 다음은 native 편집 대상 초안입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
record=w/'executions/generate-capture-status-figures';run_recorded(record,[sys.executable,'-X','utf8','-m','sdd.cli','--config',str(w/'generation.yaml'),'generate','--sections','official-cam-validation'],timeout=1800,cwd=g);require_success(record)
print('Native capture-state figures generated')
