from pathlib import Path
import json,sys
from sdd.runtime_evidence import run_recorded,require_success
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration'
require_success(w/'executions/generate-current-base-bb03350')
finding=json.loads((w/'reviews/latest-main-final-v13/review.json').read_bytes())['review']['findings'][1]
catalog=json.loads((d/'run/english.json').read_bytes())
selected={key:finding+(' Preserve the source-leading {{0}} phase heading exactly at the beginning followed by a space, outside the following instruction. It is a standalone phase heading, not the linked procedure object.' if key.startswith('{{0}}') else '') for key in catalog['strings'] if '실제 캡처 한도로 적용' in key or '연결된 실행 절차를 따라 소스를 수정하지 않은 공식' in key}
assert len(selected)==2
path=w/'reproduction-imperative-native-findings-v15.json';path.write_text(json.dumps(selected,ensure_ascii=False,indent=2),encoding='utf-8')
def run(name,args):
 out=w/'executions'/name;run_recorded(out,[sys.executable,'-X','utf8']+args,timeout=1800,cwd=r);require_success(out);print(name,'PASS',flush=True)
run('update-current-page-translation-v15',[str(r/'build/update-reviewed-page-translation.py'),'v15','generate-current-base-bb03350',str(path)])
run('finalize-current-base-v15',[str(r/'build/finalize-native-page.py'),'latest-main-final-v15','update-current-page-translation-v15','latest-main-final-v13'])
