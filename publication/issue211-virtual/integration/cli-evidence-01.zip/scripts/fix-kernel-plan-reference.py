from pathlib import Path
import shutil,yaml
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';b=w/'before-kernel-plan-reference';b.mkdir()
for root in [w,d]:
 p=root/'config/sections.yaml';shutil.copyfile(p,b/(root.name+'-sections.yaml'));data=yaml.safe_load(p.read_bytes());section=next(s for s in data['sections'] if s['id']=='official-cam-validation')
 part=next(p for t in section['design_topics'] if t['id']=='reproduce' for p in t['parts'] if p['id']=='kernel-boot')
 part['question']+=' 과거 근거의 2단계 계획이라는 문구는 옮기지 않습니다. 그것은 과거 절차의 계획 작성 항목 번호이며 계획 자체의 단계 수가 아닙니다. 이 문장에는 단계 번호·단계 수·이미지 해시·백업 위치 등 앞 항목의 계획 내용을 다시 열거하지 말고 승인된 계획에 따른 시험 커널 설치와 부팅만 직접 지시하세요.'
 p.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
