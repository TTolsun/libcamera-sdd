from sdd.translation import _validate_text
from sdd.runtime_evidence import sha256
import re
p=d/'run/english.json';catalog=json.loads(p.read_bytes());before=p.read_bytes()
selectors=['호스트 상태를 바꾸지 않고 사용할 커널','사용할 커널이 지원하는 모듈','1단계에서 조사한 커널 결과','부팅할 커널 이미지와','호스트 승인 뒤 승인된 계획','실행 중인 커널 버전이 기록된','root 자식 컨텍스트에서','사용할 Virtual2 YAML에서','새로 사용할 cam 명령의','사용할 cam 인자의','사전 조건을 통과하면 연결된','새 실행이 생성한 증거 디렉터리에서']
sources=[]
for start in selectors:
 keys=[key for key in catalog['strings'] if key.startswith(start)];assert len(keys)==1,(start,keys);sources.append(keys[0])
system='Translate these twelve Korean technical reproduction steps into concise English instructions in imperative mood. Start each action with a verb and address the reader implicitly. Preserve every source condition, subject, uncertainty, scope and opaque {{number}} token with exact counts. All preceding checks means all earlier preflight checks, not the immediately preceding step. lines is the Virtual2 YAML test-pattern value, distinct from the supported size. Use read_only_context only to resolve token meaning and technical relationships. Return JSON with translations, an array of twelve translated strings in source order. Do not add numbers, warnings or facts absent from each source.'
schema={'type':'object','properties':{'translations':{'type':'array','items':{'type':'string'},'minItems':12,'maxItems':12}},'required':['translations'],'additionalProperties':False}
payload=dict(sources=sources,read_only_context={k:catalog['translation_contexts'].get(k,[]) for k in sources})
native=Agent(cfg.agent,w/'build/short-labels-procedure-translation-prompts')
raw=native.chat(system,json.dumps(payload,ensure_ascii=False),tag='procedure-imperative-translation',response_schema=schema)
values=json.loads(re.sub(r'^```(?:json)?\s*|\s*```$','',raw.strip()))['translations'];assert len(values)==12
for source,value in zip(sources,values):catalog['strings'][source]=_validate_text(source,value)
(d/'english-before-procedure-native-translation.json').write_bytes(before)
p.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(w/'build/short-labels-procedure-translation-prompts/selection.json').write_text(json.dumps(dict(sources=sources,catalog_sha256=sha256(p),scope='Fresh native Claude CLI translation of the twelve reproduction instructions; all other catalogue values preserved'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
