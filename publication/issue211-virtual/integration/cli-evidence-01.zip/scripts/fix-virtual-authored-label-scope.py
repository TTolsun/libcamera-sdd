from pathlib import Path
import yaml,shutil
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration'
b=w/'before-authored-label-scope';b.mkdir(exist_ok=False)
shutil.copyfile(w/'build/prompts/002_visual_official-cam-validation_request-completion-order_0.response.md',b/'request-completion-native-probe.json')
for root in [w,d]:
 p=root/'config/visuals.yaml'
 if root==w:shutil.copyfile(p,b/'visuals.yaml')
 x=yaml.safe_load(p.read_bytes());v=next(v for v in x['sections']['official-cam-validation'] if v['id']=='request-completion-order')
 for key in ['answer_contract','answer_contract_en']:
  for rule in v[key]['reject_patterns']:
   if rule['pattern'].startswith('::|queuedRequests_'):
    rule['pattern']='(?m)^[^·\\n]*(?:'+rule['pattern']+')'
    rule['message']='Only authored visible labels must omit qualified functions, queuedRequests_, doQueueRequests, complete() and internal call-order detail. Preserve the source guards in evidence; their automatic suffix is intentionally excluded from this readability rule.'
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
(r/'build/after-virtual-scope-labels-v2.py').write_text((r/'build/after-virtual-scope-labels.py').read_text().replace('scope-labels','scope-labels-v2'),encoding='utf-8')
