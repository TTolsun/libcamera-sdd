from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='reader-actors'
b=w/('before-'+tag);b.mkdir()
for name in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());part=next(p for s in x['sections'] if s['id']=='official-cam-validation' for t in s['design_topics'] if t['id']=='flow' for p in t['parts'] if p['id']=='processing')
 part['question']+=' 여기서 다시 내지 않는 신호는 captureDone이므로 일반적인 완료 신호라고 쓰지 말고 `captureDone`을 명시하세요.'
 part['answer_contract'].setdefault('required_terms',[]).append(['captureDone'])
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='submission-gate':
   v['prompt']='초기 요청 준비 그림을 아홉 노드로 작성합니다. n0 exportFrameBuffers: DMA-BUF 할당 실패? true→n5 초기 시작 실패 반환,false→n1 createRequest: 요청 생성 실패? true→n5,false→n2 addBuffer: 버퍼 연결 실패? true→n5,false→n3 CameraSession::queueRequest: 설정된 제출 한도가 이미 찼는가? true→n6 captureLimit_: 제출 없이 도우미 반환,false→n8 queueCount_: 제출 시도 수 증가→n4 Camera::queueRequest: 실제 카메라 큐 호출 action box→n7 PipelineHandler::queueRequest: 검증 통과 시 Camera 호출 내부에서 queued 비동기 호출을 예약합니다. n4는 호출 결과를 검사하는 decision이 아닙니다. n4→n7 always 간선은 호출 내부의 검증 통과 경로만 요약하며 호출 반환 후 예약한다고 그리지 않습니다. Camera API 내부 검증 실패의 여러 반환 분기는 이 그림의 정상 내부 예약 요약 밖이며 전체 Camera API 제어 흐름 그림으로 주장하지 않습니다. n5 오류 반환은 n0/n1/n2의 시작 준비 실패를 받습니다. 도우미 한도 true/false 및 세 준비 실패 guard는 실제 소스 조건의 두 결과를 보존합니다. n0/n1/n2/n3는 decision입니다. 한영 라벨에서는 함수·내부 카운터 이름·반환 숫자·긴 괄호 경고를 모두 근거에 두고, 위에 설명한 짧은 행동·질문만 사용합니다. n7의 짧은 라벨에는 호출 내부 예약이며 검증 통과 경로임을 명시합니다. 노드의 symbol과 quote_ids로 정확한 소스 이름을 보존합니다. 한영 authored 간선은 20자 이내입니다. 아래 초안은 실제 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
   for key in ['answer_contract','answer_contract_en']:
    v[key].setdefault('reject_patterns',[]).append(dict(pattern=r'(?m)^[^·\n]*(?:exportFrameBuffers|createRequest|addBuffer|startCapture|captureLimit_|queueCount_|::|ConnectionTypeQueued)',message='Use concise preparation actions and decisions in authored labels. Keep function/counter identifiers in symbol bindings and evidence.'))
  if v['id']=='virtual-frame-path':
   v['prompt']='현재 유효한 아홉 노드·모든 인용·간선·실제 guard의 두 결과를 보존하고 한영 표면 라벨만 짧게 정리합니다. n0는 PipelineHandler가 요청을 받아 준비를 시작한다고 주체를 명시합니다. Camera API 호출을 직접 받는다는 표현은 쓰지 않습니다. n1은 준비·차례 뒤 취소 여부, n2는 취소 상태 완료와 앞선 미완료 요청이 있으면 통지 보류라는 핵심 조건만 남깁니다. n3는 가상 파이프라인의 프레임 처리 예약, n4는 VirtualCameraData::processRequest의 목표 시각 대기, n5는 쓰기 동기화 범위 안에서 쓰기용 버퍼 매핑 시도, n6는 CPU의 Virtual2 lines NV12 변환과 매핑 버퍼 쓰기 두 동작의 시도, n7은 생성 오류 여부, n8은 버퍼 완료 신호입니다. n0 PipelineHandler와 n4 VirtualCameraData::processRequest라는 동작 주체만 필요한 식별자로 남기고 cancelled_, MappedFrameBuffer, bufferCompleted 같은 내부 식별자는 화면 라벨에서 빼며 symbol·소스 인용은 보존합니다. n6 영어 conversion과 mapped buffer write는 모두 시도이며 60자 이내에 넣고 다른 올바른 동작을 바꾸지 않습니다. 간선은 동작이나 조건을 두 번 풀어 쓰지 말고 짧게 씁니다. 아래 초안은 실제 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
   v['answer_contract']['required_terms'].append(['PipelineHandler']);v['answer_contract_en']['required_terms'].append(['PipelineHandler'])
  if v['id']=='reproduction-flow':
   v['max_label_chars']=160
   v['answer_contract'].setdefault('required_terms',[]).append(['cam 캡처 한도 3'])
   v['answer_contract_en'].setdefault('required_terms',[]).append(['cam capture limit 3'])
   v['prompt']='현재 10개 노드·인용·모든 연결·기존 조건은 그대로 보존하고 device_verify 한영 라벨을 고칩니다. 모든 실행에서 cam에 전달되는 캡처 한도 3을 확인해야 하며, 그와 별도로 재현 도우미를 쓰면 인자 전달 경로도 확인해야 합니다. 한도 3을 도우미를 쓰는 경우에만 적용하는 조건으로 묶지 않습니다. 이 판정 노드에 한국어 cam 캡처 한도 3, 영어 cam capture limit 3이라는 독립된 조건을 먼저 쓰고, 세미콜론 뒤에 도우미 사용 시 인자 전달 확인이라는 별도 조건을 붙입니다. 기존 커널, root 장치 접근, YAML 400x300 및 lines, cam Virtual2와 400x300 NV12 조건도 보존합니다. 원시 명령 문자열이나 대입 연산자는 화면 라벨에 쓰지 않습니다. 노드 160자·간선 20자 이내입니다. 아래 초안은 실제 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-initial-reproduction-v3.py').read_text().replace('initial-reproduction-v3',tag)
# Existing procedure translations are unchanged. Rewriting them is unnecessary.
text=text.replace("exec((r/'build/translate-final-procedure.py').read_text(encoding='utf-8'))\n",'')
(r/'build/after-virtual-reader-actors.py').write_text(text,encoding='utf-8')
