from pathlib import Path
import json,yaml,shutil
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';b=w/'before-final-request-action';b.mkdir()
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 for rel in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
  target=b/root.name/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,target)
 path=root/'config/sections.yaml';data=yaml.safe_load(path.read_bytes());s=next(s for s in data['sections'] if s['id']=='official-cam-validation')
 for t in s['design_topics']:
  for p in t['parts']:
   if t['id']=='flow' and p['id']=='reuse-request':
    p['question']+=' 첫 구절에서 기록된 실행 명령이 출력 싱크를 요청하지 않았다는 주어·목적어·행동을 명시합니다. 출력 싱크가 요청을 하지 않는다는 뜻으로 읽힐 수 있는 생략형 표현은 쓰지 않습니다.'
 path.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
 path=root/'config/visuals.yaml';data=yaml.safe_load(path.read_bytes())
 for v in data['sections']['official-cam-validation']:
  if v['id']!='virtual-frame-path':continue
  v['prompt']='현재 아홉 노드·모든 간선·실제 조건·소스 인용·다른 표시를 정확히 보존하고 queued 처리를 예약하는 노드의 한영 라벨만 고칩니다. 가상 파이프라인이 예약하는 대상은 요청 처리이며, 요청과 목표 타임스탬프를 전달한다는 관계를 양쪽 언어에서 명확히 표시합니다. 단순히 프레임을 예약한다거나 가상 장치가 알아서 프레임을 만드는 것처럼 쓰지 않습니다. 긴 함수명·내부 필드 이름은 근거로 두고 72자 이내 동작문으로 나타냅니다. 다음은 native 편집 대상 초안입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
  v['answer_contract'].setdefault('reject_patterns',[]).append({'pattern':'프레임 처리를 예약','message':'The queued action processes a request with its target timestamp; make the actual request-processing action explicit.'})
  v['answer_contract_en'].setdefault('reject_patterns',[]).append({'pattern':'[Ss]chedules? frames','message':'The queued action is request processing, not an unspecified frame scheduling action.'})
 path.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
