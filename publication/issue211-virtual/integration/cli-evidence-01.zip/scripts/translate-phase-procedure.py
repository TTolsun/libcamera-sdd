from sdd.translation import _validate_text
from sdd.document_metadata import split_frontmatter
from sdd.runtime_evidence import sha256
import html,re
p=d/'run/english.json';catalog=json.loads(p.read_bytes());before=p.read_bytes()
meta,_=split_frontmatter((d/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
def normalized(value):
 value=re.sub(r'\*\*([^*]+)\*\*',r'\1',value)
 value=re.sub(r'`([^`]+)`',r'\1',value)
 return re.sub(r'\s+',' ',html.unescape(value)).strip()
numbered=[]
for row in meta['generated_design']['answers']['reproduce']:
 if match:=re.match(r'^(\d+)\.\s+(.+)',row['text'],re.S):numbered.append((int(match[1]),match[2]))
assert [n for n,_ in numbered]==list(range(1,14))
sources=[]
for n,text in numbered:
 keys=[key for key in catalog['strings'] if any(normalized(ctx['resolved_source'])==normalized(text) for ctx in catalog['translation_contexts'].get(key,[]))]
 assert len(keys)==1,(n,text,keys)
 sources.append(keys[0])
system='Translate these thirteen Korean reproduction instructions into concise imperative English. For a step with a phase-heading placeholder, keep that placeholder first and write the imperative action after it. Begin other actions with a verb. Preserve all source conditions, subjects, uncertainty, scope and opaque {{number}} tokens with exact counts. These instruct a future fresh execution, not completed facts. Do not add only or other restrictions absent from the Korean source. Preserve allocator choice before required-module checks, actual cam capture limit 3 and helper pass-through when used, and all checks before execution. Return JSON translations with thirteen strings in source order, no step numbers or new facts.'
schema={'type':'object','additionalProperties':False,'required':['translations'],'properties':{'translations':{'type':'array','items':{'type':'string'},'minItems':13,'maxItems':13}}}
payload=dict(sources=sources,read_only_context={k:catalog['translation_contexts'].get(k,[]) for k in sources})
native=Agent(cfg.agent,w/'build/phase-blocks-procedure-translation-prompts')
raw=native.chat(system,json.dumps(payload,ensure_ascii=False),tag='imperative-procedure',response_schema=schema)
values=json.loads(re.sub(r'^```(?:json)?\s*|\s*```$','',raw.strip()))['translations'];assert len(values)==13
for source,value in zip(sources,values):catalog['strings'][source]=_validate_text(source,value)
(d/'english-before-phase-blocks-imperative.json').write_bytes(before)
p.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(w/'build/phase-blocks-procedure-translation-prompts/selection.json').write_text(json.dumps(dict(sources=sources,catalog_sha256=sha256(p),scope='Fresh native Claude CLI translation of all thirteen reproduction instructions; other catalogue values preserved'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
