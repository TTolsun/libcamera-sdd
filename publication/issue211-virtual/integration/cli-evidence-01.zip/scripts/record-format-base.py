from pathlib import Path
import subprocess,json,hashlib
from sdd.runtime_evidence import require_success,sha256
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';g=r/'build/generator-reader-release';repo=r/'build/libcamera-sdd-issue211'
base=subprocess.check_output(['git','rev-parse','origin/main'],cwd=repo,text=True).strip()
assert subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=repo,text=True).strip()==base=='7d824a9753721edd86a4b509a979230033532f9c'
assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=repo)
require_success(w/'executions/connected-scope-export')
record=dict(schema=1,public_base=base,checkpoint=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),merge_head=base,review_status='Base integrated; final independent acceptance is recorded separately',backup='before-latest-public-base',normal_candidate_export='executions/connected-scope-export/record.json',latest_root_readme_preserved=(repo/'README.md').read_bytes()==subprocess.check_output(['git','show','origin/main:README.md'],cwd=repo))
assert record['latest_root_readme_preserved'];(w/'latest-public-base.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
prs=[(225,'a570acc188e32fcd8bc1b786d5c13cd1b653ff0b','Reader routes and compact sidebar'),(226,'8d7a27c4cfaf4954f2aca3868bd3c47bf7b706ee','Class relationships before source evidence'),(227,'2e1892a3b67a390bc6935917c8589994c192b4c4','Unified generation/review information; preserve historical and human-review state'),(218,'be57d9783433f31840291eb8a85b45d1aeeb54b1','Stage input/checkpoint reuse optimization'),(232,'81bbede4aec948a3751550674b29c19927e453d7','Portable CLI selection; retain approved in-house choices')]
prs += [(233,'172dd9a1d3834cda398d6798df113e28a94a2676','Per-item visual audit and section evidence placement'),
        (234,'c99849fb62f0ea3ae5895f1ef0a604cc6416269a','Literal Mermaid labels and mobile close controls'),
        (235,'d771418576d49a899f1036d131488d7de1bc7639','Authenticated translation migration and source-bound guide diagrams'),
        (236,'47d97132f79d848c20a3de20c2ca4a99930da8ea','Preserve reader questions and bind readable source windows'),
        (237,'ff9161a0e057b9524c099fd3e1e4da9247a3c2aa','Atomic configured source windows'),
        (238,'e104b6ec6369ee485a33ce8a7c199a545b73b141','Source-backed connector vocabulary and recorded citation revalidation'),
        (239,'bb033505cd28f616db32072833f0e793a4af2d35','Actionable missing citation symbol diagnostics')]
for n,commit,title in prs:subprocess.run(['git','merge-base','--is-ancestor',commit,'HEAD'],cwd=g,check=True)
files={}
for rel in ['src/sdd/export_site.py','src/sdd/reading_cleanup.py','src/sdd/site_assets/reading.css']:
 current=(g/rel).read_bytes();canonical=subprocess.check_output(['git','show','origin/main:'+rel],cwd=g)
 assert current.replace(b'\r\n',b'\n')==canonical.replace(b'\r\n',b'\n'),rel
 files[rel]=dict(working_sha256=sha256(g/rel),main_blob_sha256=hashlib.sha256(canonical).hexdigest(),equal_after_newline_normalization=True)
result=dict(schema=1,generator_main=subprocess.check_output(['git','rev-parse','origin/main'],cwd=g,text=True).strip(),actual_working_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=g,text=True).strip(),public_main=base,reviewed_prs=[dict(number=n,merge_sha=commit,title=title,url='https://github.com/TTolsun/camera-hal-sdd-generator/pull/'+str(n),included_in_working_head=True) for n,commit,title in prs],active_format_files=files,source_review='Sol inspected the merged changes; final rendered UI and publication hashes are recorded separately',human_review='pending')
(w/'latest-format-base-review.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print('Latest bases and merged format/optimization PRs verified')
