from pathlib import Path
import yaml,json,shutil
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-main-integration'
b=w/'before-queue-prefix';b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 dest=b/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,dest)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'));reference=m['generated_visuals']['records']['virtual-frame-path']['draft']
def revise_flow(t):
 if t['id']!='flow':return
 p=next(x for x in t['parts'] if x['id']=='reuse-request')
 p['question']='이 항목은 기록된 출력 싱크 미요청 경로에만 해당함을 문장 앞에서 명시하세요. 그 경로에서 처리를 계속할 요청은 Request::ReuseBuffers로 버퍼를 유지해 재사용한 뒤 CameraSession::queueRequest 도우미를 호출한다는 한 문장만 쓰세요. 도우미 호출을 실제 제출 성공으로 단정하지 마세요. 출력 옵션이 다른 일반 경로에는 이 단정을 적용하지 않습니다.'
 p['prompt']=p.get('prompt','')+' 재사용 항목은 오해 방지를 위해 기록된 출력 싱크 미요청 경로라는 한정을 한 번 명시하는 예외입니다. 다른 옵션의 내부 동작이나 범위 경고 목록은 덧붙이지 않습니다.'
p=g/'examples/libcamera/validation/issue211-reader/section.yaml';x=yaml.safe_load(p.read_bytes())
for t in x['design_topics']:revise_flow(t)
p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
p=g/'examples/libcamera/validation/issue211-virtual/visual.yaml';v=yaml.safe_load(p.read_bytes())
v['prompt']=' '.join('''고정된 12개 symbol 바인딩을 유지하고 핵심 가상 NV12 경로를 짧은 한영 라벨로 설명하세요. n0은 cam이 virtual 파이프라인을 통해 DMA-BUF를 확보합니다. n1은 Camera가 버퍼가 붙은 요청을 확인하고 파이프라인에 제출합니다. n2는 VirtualCameraData::processRequest의 queued 호출을 예약합니다. queueRequestDevice 자체의 호출이 비동기라는 뜻이 아닙니다. 영어는 schedules 또는 queues라는 동사로 call 예약을 분명히 하고 reserves라는 모호한 동사는 쓰지 마세요. n3은 패턴 생성기가 CPU 쓰기 동기화 범위 안에서 버퍼를 쓰기용으로 매핑합니다. n2→n3은 패턴 생성기 호출 관계이며 processRequest 자체가 매핑한다고 쓰지 않습니다. n4는 CPU가 Virtual2 lines 패턴을 NV12로 변환해 매핑된 버퍼에 쓰기를 시도합니다. 영어에도 tries/attempts와 mapped buffer라는 쓰기 대상을 명시합니다. 성공 보장 경고를 반복하지 말고 시도 동사에 의미를 담습니다. n5는 NV12 변환 반환값이 0이 아닌가라는 판정입니다. CPU 오류 일반 주석은 필요 없습니다. 참이면 버퍼 프레임 메타데이터 FrameError, 거짓이면 FrameSuccess를 유지하며 모두 n6 버퍼 완료 신호로 이어집니다. n7은 연결된 핸들러가 모든 요청 버퍼 완료를 검사합니다. 참이면 n8 PipelineHandler가 현재 요청을 완료로 표시하고, 거짓이면 n10 이번 호출의 cam 통지 없이 마침으로 갑니다.
n8 다음 n11은 제출 큐 맨 앞 요청이 아직 Pending인가를 판단합니다. 큐 맨 앞 요청은 현재 완료 처리 중인 요청과 같을 수도 다를 수도 있습니다. 다르다고 단정하는 괄호나 설명을 넣지 마세요. n11 참이면 n10으로 통지를 보류합니다. 거짓이면 n9에서 큐 앞부터 연속으로 완료된 요청들만 제출 순서대로 requestCompleted 신호를 통해 cam에 통지합니다. n9는 현재 요청이 반드시 이 호출에서 통지된다는 보장이 아닙니다. 앞의 완료 요청들을 통지하다가 현재 요청 앞의 Pending에서 멈출 수도 있으므로 ready/completed queue prefix만 처리한다는 의미를 유지합니다. 전체 반복을 별도 노드로 늘리지 않고 이 핵심 조건을 요약합니다. n10은 두 종료 경로가 공유하므로 요청 완료 표시가 없다고 단정하지 않고 이번 호출의 통지가 없다는 공통 결과만 설명합니다.
모든 노드와 간선을 연결하고 세 결정의 두 결과를 실제 source-bound condition_ref로 표시합니다. n0→n1→n2→n3→n4→n5와 n8→n11의 연결은 always인 핵심 경로 요약입니다. n8→n9 직접 간선은 없습니다. 노드는 짧은 행동·판정, 간선은 짧은 관계·결과만 쓰고 행동 전체를 반복하지 않습니다. n1의 Camera, n8의 PipelineHandler, n2의 VirtualCameraData::processRequest, n9의 requestCompleted와 n4의 CPU·Virtual2·lines·NV12는 필요합니다. 그 밖의 함수명 괄호 주석이나 긴 코드 식별자 목록은 근거로 남깁니다. 특히 n5의 generateFrame, n6의 bufferCompleted, n11의 RequestPending enum은 화면에서 쉬운 동작·상태로 설명하고 내부 symbol은 그대로 보존합니다. 인용은 양 끝 symbol과 실제 guard를 포함해야 합니다. n11→n10에는 Pending guard와 PipelineHandlerVirtual::bufferCompleted 선언 구절이 모두 필요합니다. 노드 72자, authored 간선 40자 한도 안에서 영어 25~55자의 자연스러운 표현을 우선합니다. authored true/false는 시스템 표시와 중복하지 않습니다. 쓰기 동기화는 매핑·CPU 접근을 감싸며, 완료 통지는 submission/queue order입니다. 물리 장치·성능 경고, 일반 취소와 반환값의 상세는 이 그림에 넣지 않습니다.'''.splitlines())
p.write_text(yaml.safe_dump(v,allow_unicode=True,sort_keys=False),encoding='utf-8')
v['prompt']+=' 현재 원고를 편집 입력으로 제공합니다. 12개 노드 ID·shape·quote_ids 및 모든 간선의 from·to·condition_ref·quote_ids를 그대로 보존하고 한영 라벨만 위 지적대로 수정하세요. 이 입력은 저장 응답의 재생이나 새 실행 증거가 아니며 실제 새 native CLI 응답이 모든 검사를 다시 통과해야 합니다. 참고 초안: '+json.dumps(reference,ensure_ascii=False,separators=(',',':'))
v['answer_contract_en']['required_terms'] += [['tries','attempts'],['mapped']]
v['answer_contract_en'].setdefault('reject_patterns',[]).append({'pattern':'not current request|\\breserves\\b','message':'The queue head may be the current request; use a clear scheduling verb for queued invocation.'})
v['answer_contract'].setdefault('reject_patterns',[]).append({'pattern':'현재 요청 아님|현재 요청이 아님','message':'The queue head may be the current completed request.'})
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(t for t in x['sections'] if t['id']=='official-cam-validation')
 for t in s['design_topics']:revise_flow(t)
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());x['sections']['official-cam-validation']=[v if t['id']==v['id'] else t for t in x['sections']['official-cam-validation']];p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
s=(r/'build/after-virtual-reader-labels.py').read_text().replace('reader-labels','queue-prefix');(r/'build/after-virtual-queue-prefix.py').write_text(s)
