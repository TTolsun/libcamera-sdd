from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='queued-execution'
b=w/('before-'+tag);b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='virtual-frame-path':
   v['max_nodes']=10;v['required_symbols'].append('VirtualCameraData::processRequest')
   edit='새 검토에서 남은 가상 경로 지적만 보완합니다. 9개 기존 노드에 n9(VirtualCameraData::processRequest symbol)를 추가해 10개 노드로 만듭니다. n2는 queueRequestDevice가 VirtualCameraData::processRequest를 queued 예약하는 단계 그대로입니다. n2→n3 간선을 n2→n9→n3로 바꿉니다. n9는 예약된 VirtualCameraData::processRequest가 실제 실행되어 목표 시각을 기다리는 단계이고, 그 뒤 n9→n3에서 패턴 생성기를 호출합니다. 이 두 간선은 always인 실제 호출 관계 요약이며 스케줄러가 직접 생성기를 부른다고 쓰지 않습니다. n8은 cam의 요청 버퍼 추가 실패 여부를 묻는 decision으로 바꿉니다. 실제 조건은 startCapture에서 request->addBuffer 다음 ret < 0입니다. 실패 true→n7 오류 반환, 실패 아님 false→n1은 나머지 준비·시작 성공 경로로 이어집니다. n7은 할당 또는 버퍼 추가 실패로 startCapture가 오류를 반환하고 요청 제출을 중단하는 공통 결과입니다. n1 한영 라벨은 Camera가 버퍼 유무와 활성 스트림에 속한 버퍼인지 검증하고 비동기 전달을 시도한다는 뜻을 짧게 명시합니다. 준비·검증·전달 성공 경로라는 기존 다음 단계 조건은 유지합니다. n0 할당 실패 두 결과, n3 매핑 시도, n4 CPU NV12 변환 결과의 매핑 버퍼 쓰기 시도, n5 변환 오류 두 결과, n6 상태와 무관한 버퍼 완료 및 다음 그림 연결은 그대로 유지합니다. 신규 인용은 두 endpoint symbol과 실제 guard를 모두 포함하도록 제공된 virtual-queue·virtual-frame·pattern-frame·cam-request-buffers 등의 발췌를 선택합니다. '
  elif v['id']=='completion-flow':
   edit='n6의 한영 라벨만 보완합니다. 한도가 미설정 또는 미도달인 경로에서 프레임 정보를 출력한 뒤 처리 카운터를 하나 증가시킨다는 실제 순서를 둘 다 표시합니다. 카운터 증가만 쓰고 프레임 정보 출력을 빠뜨리지 않습니다. 다른 모든 올바른 라벨·노드·간선·취소/진입 한도/증가 뒤 한도 조건과 인용은 그대로 보존합니다. '
  else:continue
  v['prompt']=edit+'한영 노드 64자, authored 간선 20자 이내의 짧고 분명한 동작구를 씁니다. 실제 조건과 현재 올바른 라벨은 보존합니다. 아래 초안은 새 native CLI 편집 입력이며 저장 응답 재생이 아닙니다. 참고 초안: '+json.dumps(m['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
(r/'build/after-virtual-queued-execution.py').write_text((r/'build/after-virtual-bound-preflight.py').read_text().replace('bound-preflight',tag),encoding='utf-8')
