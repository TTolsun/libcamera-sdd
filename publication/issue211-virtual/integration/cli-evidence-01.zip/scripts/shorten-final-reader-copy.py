from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';b=w/'before-final-reader-copy';b.mkdir()
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 for rel in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
  target=b/root.name/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,target)
 path=root/'config/sections.yaml';data=yaml.safe_load(path.read_bytes());s=next(s for s in data['sections'] if s['id']=='official-cam-validation')
 for t in s['design_topics']:
  for p in t['parts']:
   if t['id']=='flow' and p['id']=='submission-limit':
    p['question']='처리 수와 제출 시도 수는 같은 캡처 한도 값과 서로 다른 위치·시점에서 비교된다는 관계만 한 짧은 문장으로 설명합니다. 처리 수의 검사 위치는 현재 그림에, 제출 시도 수의 검사 위치는 앞 초기 제출 그림에 있으므로 조건·분기·도우미의 제출 생략을 다시 설명하지 않습니다. 한도 값이 두 개라고 쓰지 않습니다.'
   if t['id']=='reproduce' and p['id']!='scope':
    p['prompt']=p.get('prompt','').replace('짧은 평서문','짧은 지시문').replace('평서문','지시문')
    p['question']+=' 이 단계는 독자에게 직접 수행을 요청하는 -하세요 형태의 지시문으로 씁니다. 기존 번호·굵은 단계 묶음·모든 조건은 보존하고, 조사가 이루어집니다 같은 수동 보고문으로 쓰지 않습니다.'
 path.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
 path=root/'config/visuals.yaml';data=yaml.safe_load(path.read_bytes())
 for v in data['sections']['official-cam-validation']:
  if v['id'] not in ['virtual-frame-path','request-completion-order']:continue
  v['prompt']='현재 아홉 노드·모든 간선·실제 조건 양쪽·인용·의미를 정확히 보존하고 한영 표시만 간결한 동작구·판정 질문으로 줄입니다. 노드는 합니다/습니다로 끝나는 긴 문장 대신 핵심 행동을 나타내며 가능한 한40자 안팎으로 씁니다. 한영 최대72자는 유지합니다. guard 간선에는 판정 질문을 반복하거나 예/아니오/true/false를 직접 넣지 말고 분기 뒤 행동·결과를 짧게 표시합니다. 자동 true/false 표시는 렌더러가 유지하고 전체 조건은 근거에 남습니다. 오류·취소·요청 통지의 의미를 잃지 않습니다. 가상 경로는 write 방향 동기화 시도와 쓰기 매핑 시도, CPU lines 패턴의 NV12 변환·쓰기 시도, 가상 파이프라인이 요청과 목표 시각을 전달하며 요청 처리를 예약하는 관계, 성공·오류 모두의 버퍼 완료 신호를 보존합니다. 완료 순서 그림은 모든 버퍼 완료, 큐 존재, 맨 앞 Pending 대기, 한 요청 꺼내 통지하고 반복하는 관계를 보존합니다. 다음은 native 편집 대상 초안입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 path.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
