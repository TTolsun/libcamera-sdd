from pathlib import Path
import json,sys,subprocess
from sdd.runtime_evidence import run_recorded,require_success
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';repo=r/'build/libcamera-sdd-issue211';d=w/'current-main-integration'
assert (w/'before-latest-public-base/docs/site-manifest.json').is_file()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='d25a28b0a5a2aee527b189e8c92e46643a8cb482'
base=subprocess.check_output(['git','rev-parse','origin/main'],cwd=repo,text=True).strip();assert base=='7d824a9753721edd86a4b509a979230033532f9c'
identity=['git','-c','user.name=TTolsun','-c','user.email=112919054+TTolsun@users.noreply.github.com']
def run(name,args,allow_conflicts=False):
 out=w/'executions'/('latest-base-v2-'+name);z=run_recorded(out,args,timeout=900,cwd=repo,environment={'PYTHONPATH':str(r/'build/generator-reader-release/src'),'PYTHONIOENCODING':'utf-8'})
 if allow_conflicts:assert z['exit_code'] in [0,1]
 else:require_success(out)
run('attributes-stage',['git','add','.gitattributes'])
run('attributes-checkpoint',identity+['commit','-m','Preserve evidence byte rules before the public base merge'])
checkpoint=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
run('merge',identity+['merge','--no-commit','origin/main'],True)
run('canonical-base',['git','restore','--source=origin/main','--staged','--worktree','--','docs','README.md','.gitattributes'])
run('owned-root-records',['git','restore','--source=HEAD','--staged','--worktree','--','run.json','generation-receipts.json'])
p=repo/'.gitattributes';s=p.read_text(encoding='utf-8');rule='publication/issue211-virtual/** -text -whitespace'
if rule not in s:p.write_text(s.rstrip()+'\n'+rule+'\n',encoding='utf-8')
assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=repo)
run('candidate-export',[sys.executable,'-X','utf8','-m','sdd.cli','--config',str(d/'publication.yaml'),'export-site','--out',str(repo/'docs')])
record=dict(schema=1,public_base=base,checkpoint=checkpoint,merge_head=subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=repo,text=True).strip(),review_status='Candidate only; current-input independent acceptance remains required',backup='before-latest-public-base',latest_root_readme_preserved=True,generator_base='9ecfa182edf162872db128a7270d70af75403059',format_prs=[225,226,227])
(w/'latest-public-base.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(record)
