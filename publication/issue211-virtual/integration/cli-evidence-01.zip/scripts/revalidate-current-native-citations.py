"""Record current source-binding checks through the real generator path."""
from pathlib import Path
import json,re,shutil
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.document_metadata import split_frontmatter
from sdd.render_profiles import for_page
from sdd import generated_visuals
from sdd.runtime_evidence import sha256
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';cfg=load(d/'publication.yaml');model=KnowledgeModel.load(cfg.facts_path)
out=w/'citation-binding-revalidation-bb03350';out.mkdir()
class NoInference:
 def chat(self,*args,**kwargs):raise ValueError('Fresh native inference is required; no machine-only migration is permitted for this record')
records=[]
for section in cfg.sections():
 rel=section.get('output',section['id']+'.md');p=cfg.sdd_dir/rel
 if rel=='official-cam-validation.md' or not p.exists():continue
 old=p.read_text(encoding='utf-8');meta,body=split_frontmatter(old)
 if not meta.get('generated_visuals'):continue
 pagecfg=for_page(cfg,rel)
 artifact=generated_visuals.generate(pagecfg,model,section,NoInference(),old)
 assert artifact and all(v['reused'] for v in artifact['records'].values())
 artifact['body_sha256']=meta['generated_visuals']['body_sha256']
 new=re.sub(r'^generated_visuals:.*$',lambda _: 'generated_visuals: '+json.dumps(artifact,ensure_ascii=False),old,count=1,flags=re.M)
 assert split_frontmatter(new)[1]==body
 generated_visuals.from_manuscript(pagecfg,model,section,new)
 backup=out/rel;backup.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,backup)
 p.write_text(new,encoding='utf-8')
 records.append({'path':rel,'before_sha256':sha256(backup),'after_sha256':sha256(p),'body_unchanged':True,'new_inference':False,'records':artifact['records']})
(out/'report.json').write_text(json.dumps({'schema':1,'records':records,'policy':generated_visuals.CITATION_BINDING_POLICY,'human_review':'pending'},ensure_ascii=False,indent=2),encoding='utf-8')
print('Recorded citation revalidation without prose changes:',len(records))
