from pathlib import Path
import json
from sdd.call_records import load_record
from sdd.cli_provenance import verify_cli_receipt
from sdd.config import load
from sdd.runtime_evidence import sha256
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';base=Path('C:/Users/baboe/.codex/worktrees/b199/camera-hal-sdd-generator/build/issue214/draft-v1')
inherited=set(json.loads((w/'retained-receipts.json').read_bytes()))
external={sha256(p) for p in base.rglob('*.receipt.json') if not any(x.startswith('call-') for x in p.parts[:-1])}
latest=Path('C:/Users/baboe/.codex/worktrees/7b3d/camera-hal-sdd-generator/build/libcamera-content/draft/build')
latest_receipts={sha256(p) for p in latest.rglob('*.receipt.json') if not any(x.startswith('call-') for x in p.parts[:-1])}
profiles={'claude':load(w/'generation.yaml').agent,'codex':load(w/'new-document-review.yaml').agent}
fresh=[];old=[];other=[];retained_latest=[];fixtures=[];fixture_roots={}
for record in (w/'executions').glob('*/record.json'):
 data=json.loads(record.read_bytes());argv=data.get('argv',[])
 if 'pytest' in argv and '--basetemp' in argv:
  path=Path(argv[argv.index('--basetemp')+1]).resolve()
  if path.is_relative_to(w.resolve()):fixture_roots[path]=record.relative_to(w).as_posix()
for p in sorted(w.rglob('*.receipt.json')):
 if any(x.startswith('call-') for x in p.parts[:-1]):continue
 row=dict(path=p.relative_to(w).as_posix(),sha256=sha256(p))
 fixture=next((record for path,record in fixture_roots.items() if p.resolve().is_relative_to(path)),None)
 if fixture:
  fixtures.append(dict(**row,test_execution=fixture,scope='Synthetic regression fixture; never counted as a native model call or capture proof'));continue
 if row['sha256'] in inherited:old.append(row);continue
 if row['sha256'] in external:other.append(row);continue
 if row['sha256'] in latest_receipts:retained_latest.append(row);continue
 rec=load_record(p);assert rec.receipt['transport']=='cli';runner=rec.receipt['provider']['runner'];cfg=profiles[runner]
 assert (cfg.model,cfg.args)==({'claude':('claude-haiku-5-5',['--effort','high','--setting-sources','project,local']),'codex':('gpt-6.1-terra',['-c','model_reasoning_effort="high"'])}[runner])
 checked=verify_cli_receipt(rec.request,rec.raw,rec.receipt,p.parent.parent,cfg)
 fresh.append(dict(**row,runner=runner,model=rec.receipt['model'],verified=checked))
assert {x['runner'] for x in fresh}=={'claude','codex'}
result=dict(schema=1,new_completed_call_records=fresh,retained_issue211_reader_records=old,retained_issue214_records=other,retained_submission_diagnosis_records=retained_latest,historical_sources=['publication/issue211-reader','publication/issue214','publication/submission-diagnosis'],scope='Native CLI receipt integrity; copied records retain provenance and are not new calls. Semantic acceptance is separate. Failed raw executions remain failures.',human_review='pending')
result['distinct_new_native_receipt_hashes']={runner:len({row['sha256'] for row in fresh if row['runner']==runner}) for runner in profiles}
result['regression_fixture_receipts']=fixtures
(w/'native-call-verification-integrated.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(dict(new_records=len(fresh),reader_records=len(old),issue214_records=len(other),submission_diagnosis_records=len(retained_latest)))
