from pathlib import Path
import yaml,json,shutil
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-main-integration'
b=w/'before-notification-boundary';b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 dest=b/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,dest)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'));reference=m['generated_visuals']['records']['virtual-frame-path']['draft']
def topic(t):
 if t['id']!='virtual-principle':return
 for p in t['parts']:
  if p['id']=='buffer':p['question']+=' CPU 소유의 libyuv라는 표현 대신 CPU에서 libyuv::ARGBToNV12 함수를 호출하여 변환과 쓰기를 시도하는 주체·함수 관계를 명확히 하세요.'
  if p['id']=='completion':p['question']+=' 버퍼 완료 신호 자체를 성공을 가정하거나 판단하는 주어로 삼지 마세요. 신호를 받았다는 사실만으로 프레임 생성이 성공했다고 판단할 수 없다는 관계를 명확히 하세요. 이 관계는 영어 번역에서도 보존되어야 합니다.'
p=g/'examples/libcamera/validation/issue211-virtual/visual.yaml';v=yaml.safe_load(p.read_bytes());v['max_nodes']=12;v['required_symbols'].append('RequestPending')
v['prompt']+=' 최종 경계 수정: 고정된 기존 11개 바인딩은 유지하고 n11 RequestPending 결정 하나를 추가하여 전체 12개 노드를 사용합니다. n2는 queueRequestDevice 자체가 비동기 호출된다는 뜻이 아니라 그 함수가 VirtualCameraData::processRequest의 queued 비동기 호출을 예약하는 단계입니다. 화면 라벨에 VirtualCameraData::processRequest와 예약/queued invocation 관계를 명시하세요. n8은 현재 요청 완료 표시입니다. 그 다음 n11은 제출 큐 맨 앞 요청의 상태가 RequestPending인가를 판단합니다. n8→n9 직접 연결을 제거하고 n8→n11, n11 거짓(큐 맨 앞이 완료 상태)이면 n9 requestCompleted 통지, n11 참(큐 맨 앞이 아직 Pending)이면 n10 이번 호출의 cam 통지 없이 마침으로 연결하세요. n10은 n7의 미완료 버퍼 분기와 공유하므로 요청 완료 표시가 항상 없다는 문구를 제거하고 이번 호출의 cam 통지가 없다는 공통 결과만 씁니다. n7→n10에서는 n8 완료 표시를 지나지 않고 n11→n10에서는 완료 표시를 지난다는 두 경로 차이를 유지하세요. 실제 source condition_ref의 RequestPending guard를 인용하고 true/false는 시스템 표시이므로 라벨에서 반복하지 않습니다. n11은 현재 완료 처리한 요청이 아니라 제출 큐 맨 앞 요청을 검사합니다. 이 그림은 제출 순서 통지 조건의 첫 검사 요약이며 전체 큐 반복을 그리지는 않습니다. 기존 올바른 n0,n1,n3,n4,n5,n6,n7,n8,n9 라벨·인용과 앞의 간선은 되도록 유지하고 새로운 일반 오류·보장·반환값·함수 목록을 덧붙이지 마세요.'
p.write_text(yaml.safe_dump(v,allow_unicode=True,sort_keys=False),encoding='utf-8')
p=g/'examples/libcamera/validation/issue211-virtual/topic.yaml';x=yaml.safe_load(p.read_bytes());topic(x);p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
v['prompt']+=' 아래 JSON은 현재 원고의 수정 대상 초안이며 소스 근거나 새 실행 결과가 아닙니다. 새 native CLI 응답으로 앞서 지정한 경계와 n2,n10,n11만 수정하고 나머지 올바른 의미와 연결을 보존하세요. 모든 새 응답은 기존 구절·조건·연결 검사를 다시 통과해야 합니다. 참고 초안: '+json.dumps(reference,ensure_ascii=False,separators=(',',':'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(t for t in x['sections'] if t['id']=='official-cam-validation')
 for t in s['design_topics']:topic(t)
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());x['sections']['official-cam-validation']=[v if t['id']==v['id'] else t for t in x['sections']['official-cam-validation']];p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
s=(r/'build/after-virtual-final-actors-v2.py').read_text().replace('final-actors-v2','notification-boundary');(r/'build/after-virtual-notification-boundary.py').write_text(s)
