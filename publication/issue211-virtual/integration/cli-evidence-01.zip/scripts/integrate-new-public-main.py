from pathlib import Path
import json,yaml,shutil,gzip,sys
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';p=r/'build/latest-public-inputs/publication/submission-diagnosis'
b=w/'before-public-main-7d824';b.mkdir(exist_ok=False)
for name in ['config','run/manuscripts'] :shutil.copytree(d/name,b/name)
for name in ['run/facts/facts.json','run/english.json','publication.yaml','integration-inputs.json']:
 dest=b/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(d/name,dest)
own=yaml.safe_load((d/'config/sections.yaml').read_bytes());ownsection=next(x for x in own['sections'] if x['id']=='official-cam-validation')
ownvis=yaml.safe_load((d/'config/visuals.yaml').read_bytes())['sections']['official-cam-validation']
ownfacts=json.loads((d/'run/facts/facts.json').read_bytes());owncatalog=json.loads((d/'run/english.json').read_bytes())
owncfg=yaml.safe_load((d/'publication.yaml').read_bytes())
shutil.copytree(p/'config',d/'config',dirs_exist_ok=True)
sys.path.insert(0,str(r/'build/generator-main-integration/examples/libcamera/validation/issue211-virtual'))
from invocation_scope import attach
attach(d,r/'build/generator-main-integration/examples/libcamera/validation/issue211-virtual/invocation-options.json')
shutil.copytree(p/'manuscripts',d/'run/manuscripts',dirs_exist_ok=True)
for name in ['site-intro.md']:shutil.copyfile(p/name,d/name)
for q in (p/'profiles').glob('*.yaml'):
 text=q.read_text(encoding='utf-8').replace('C:\\Users\\baboe\\.codex\\worktrees\\7b3d\\camera-hal-sdd-generator\\build\\libcamera-content\\draft',str(d))
 (d/q.name).write_text(text,encoding='utf-8')
cfg=yaml.safe_load((d/'publication.yaml').read_bytes());cfg['source']=owncfg['source'];cfg['site']['mermaid_dir']=owncfg['site']['mermaid_dir'];cfg['site']['manuscript_profiles']['official-cam-validation.md']=str(w/'reader-verification.yaml');cfg['site']['english_catalog']=str(d/'run/english.json');cfg['site']['intro']=str(d/'site-intro.md');cfg['paths']['prompts']=owncfg['paths']['prompts'];cfg['paths']['templates']=owncfg['paths']['templates'];cfg['paths']['style']=owncfg['paths']['style'];cfg['documentation']['pages']['official-cam-validation.md']={}
cfg['publication']['operation_id']='issue211-virtual-current-main-7d824-integration'
cfg['publication']['allowed_contract_changes'].update({k:v for k,v in owncfg['publication']['allowed_contract_changes'].items() if k.startswith('official-cam-validation/')})
for rec in cfg['publication']['reports']:
 dest=Path(rec['path']);name=dest.name;src=p/name
 if not src.exists():raise ValueError(str(src))
 dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
(d/'publication.yaml').write_text(yaml.safe_dump(cfg,allow_unicode=True,sort_keys=False),encoding='utf-8')
q=d/'config/sections.yaml';x=yaml.safe_load(q.read_bytes());x['sections']=[ownsection if t['id']=='official-cam-validation' else t for t in x['sections']];q.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
q=d/'config/visuals.yaml';x=yaml.safe_load(q.read_bytes());x['sections']['official-cam-validation']=ownvis;q.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
facts=json.loads(gzip.decompress((p/'facts293.json.gz').read_bytes()));assert facts['meta']['source_commit']==ownfacts['meta']['source_commit'];facts['evidence']={k:v for k,v in facts['evidence'].items() if not k.startswith('official-cam-validation/')}|{k:v for k,v in ownfacts['evidence'].items() if k.startswith('official-cam-validation/')}
(d/'run/facts/facts.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
catalog=json.loads((p/'english.json').read_bytes())
for key in ['strings','translation_contexts','source_contexts']:
 for k,v in owncatalog[key].items():catalog[key].setdefault(k,v)
(d/'run/english.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
x=json.loads((d/'integration-inputs.json').read_bytes());x.update(public_base='7d824a9753721edd86a4b509a979230033532f9c',other_manuscripts='Exact public submission-diagnosis package bytes, including unresolved issue214 fixes; own official-cam manuscript overlaid only by native generation',historical_checks='Latest public reports retain original bindings; no new performance or runtime measurement')
(d/'integration-inputs.json').write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
print('Latest public inputs integrated')
