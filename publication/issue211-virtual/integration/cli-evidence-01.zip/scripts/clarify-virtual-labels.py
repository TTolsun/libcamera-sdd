from pathlib import Path
import yaml,json,shutil
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-main-integration'
b=w/'before-reader-labels';b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 dest=b/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,dest)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'));reference=m['generated_visuals']['records']['virtual-frame-path']['draft']
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(t for t in x['sections'] if t['id']=='official-cam-validation');t=next(t for t in s['design_topics'] if t['id']=='virtual-principle');part=next(p for p in t['parts'] if p['id']=='buffer')
 part['question']='긴 코드 이름을 나열하지 말고, 먼저 버퍼 확보 → 요청 제출 → CPU 패턴 쓰기 → 완료 알림이라는 큰 흐름을 쉬운 한국어로 설명하세요. 이 항목은 가상 파이프라인이 실제 DMA-BUF 버퍼를 확보하면 cam이 Request에 붙여 제출한다는 관계와, CPU가 쓰기 방향 동기화 범위에서 매핑된 버퍼에 패턴을 NV12로 변환해 쓰기를 시도한다는 관계만 세 짧은 문장 이내로 씁니다. 완료 통지와 실패 조건은 다음 항목이 설명합니다. 함수·클래스 이름은 본문에 더 나열하지 말고 연결된 소스 근거에 남깁니다.'
 part['answer_contract'].setdefault('reject_patterns',[]).append({'pattern':'::|exportFrameBuffers|startCapture|addBuffer|ARGBToNV12|MappedFrameBuffer|DmaSyncer|generateFrame','message':'Explain the core behavior first; detailed identifiers remain in the source evidence.'})
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());v=next(t for t in x['sections']['official-cam-validation'] if t['id']=='virtual-frame-path')
 base=yaml.safe_load((g/'examples/libcamera/validation/issue211-virtual/visual.yaml').read_bytes())['prompt']
 v['prompt']=base+' 마지막 독자 검토에 따른 라벨 편집입니다. 아래 현재 초안의 12개 노드 ID·shape·quote_ids, 모든 간선의 from·to·condition_ref·quote_ids를 그대로 보존하세요. 이 의미·인용·분기 구조는 바꾸지 않고 한영 라벨만 간결하게 편집합니다. 함수명 괄호 주석과 구현 세부사항은 근거로 내리고, 짧은 동작·판정 및 필요한 책임 주체만 남깁니다. n0은 cam과 virtual 버퍼 확보, n1은 Camera의 요청 제출, n2는 VirtualCameraData::processRequest queued 호출 예약, n3은 패턴 생성기의 쓰기 동기화 범위 안 버퍼 쓰기 매핑, n4는 CPU가 Virtual2 lines 패턴을 NV12로 변환하여 매핑된 버퍼에 쓰기를 시도함을 한영 모두 명시합니다. n3의 주체는 패턴 생성기이며 processRequest 자체가 매핑한다고 쓰지 마세요. n2→n3 간선은 패턴 생성기 호출이라는 짧은 관계만 씁니다. n4 영어에는 tries 또는 attempts와 mapped buffer라는 쓰기 대상을 반드시 표시하세요. n5는 NV12 변환 반환값이 0이 아닌가라는 판정만 남기고 CPU 오류 검사의 일반 주석은 제거하세요. n6 버퍼 완료 신호와 n7 모든 버퍼 완료 판정, n8 PipelineHandler의 요청 완료 표시, n9 requestCompleted 제출 순서 통지, n10 이번 호출의 cam 통지 없음, n11 제출 큐 맨 앞 요청의 미완료 판정을 유지합니다. n6→n7은 핸들러 전달이라는 관계만 짧게 씁니다. FrameError/FrameSuccess 분기와 버퍼 완료·요청 완료 차이, 제출 큐 맨 앞 미완료에 따른 보류는 유지합니다. 노드의 코드 함수명 괄호 주석·긴 호출 목록을 제거하고 같은 동작을 화살표에서 반복하지 마세요. 나머지 바르게 설명된 노드와 간선의 의미를 바꾸지 마세요. 참고 초안은 편집 입력이며 새 실행 증거나 저장 응답의 재생이 아닙니다. 실제 새 native CLI 응답이 모든 자동 검사와 독립 검토를 통과해야 합니다. 참고 초안: '+json.dumps(reference,ensure_ascii=False,separators=(',',':'))
 v['answer_contract_en']['required_terms'] += [['tries','attempts'],['mapped']]
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
s=(r/'build/after-virtual-notification-boundary.py').read_text().replace('notification-boundary','reader-labels');(r/'build/after-virtual-reader-labels.py').write_text(s)
