from pathlib import Path
from html.parser import HTMLParser
import json,sys
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.runtime_evidence import sha256
from sdd.generated_visuals import plans,materialize
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';site=r/'build/libcamera-sdd-issue211/docs';tag=sys.argv[1]
review=json.loads((w/'reviews'/tag/'review.json').read_text())['review']
if review['verdict']!='pass' or review['findings']:raise ValueError('Unresolved final review')
cfg=load(w/'generation.yaml');model=KnowledgeModel.load(cfg.facts_path);section=next(s for s in cfg.sections() if s['id']=='official-cam-validation');topics=section['design_topics']
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
diagram_checks=[]
for plan in plans(cfg,section):
 rec=meta['generated_visuals']['records'][plan['id']]
 graph=materialize(cfg,model,section,dict(plan,require_connected=True),rec['draft'],rec['producer'])
 if graph!=rec['graph']:raise ValueError('Audited graph differs from published graph')
 diagram_checks.append(dict(id=plan['id'],nodes=len(graph['nodes']),edges=len(graph['edges']),connected=True))
class Parts(HTMLParser):
 def __init__(self):super().__init__();self.article=False;self.fold=0;self.pre=False;self.rows=[];self.current=None;self.h=None
 def handle_starttag(self,t,attrs):
  a=dict(attrs)
  if t=='article':self.article=True
  if not self.article:return
  if t=='details':self.fold+=1
  if t=='pre':self.pre=True
  if self.fold or self.pre:return
  if t=='h2':
   self.current=dict(anchor=a.get('id'),text='',paragraphs=0,subheadings=[]) if len(self.rows)<len(topics) else None
   if self.current is not None:self.rows.append(self.current)
  if self.current is not None:
   if t=='p':self.current['paragraphs']+=1
   if t=='h3':self.current['subheadings'].append(a.get('id'))
 def handle_endtag(self,t):
  if t=='details' and self.article:self.fold-=1
  if t=='pre':self.pre=False
  if t=='article':self.article=False
 def handle_data(self,data):
  if self.article and not self.fold and not self.pre and self.current is not None:self.current['text']+=data
pages={}
for lang,rel in [('ko','official-cam-validation.html'),('en','en/official-cam-validation.html')]:
 p=Parts();p.feed((site/rel).read_text(encoding='utf-8'))
 if len(p.rows)!=len(topics):raise ValueError('Topic anchor inventory differs')
 pages[lang]=dict(path=rel,html_sha256=sha256(site/rel),topics=[dict(anchor=x['anchor'],visible_characters=len(x['text'].strip()),paragraphs=x['paragraphs'],figure_caption_anchors=x['subheadings']) for x in p.rows])
visuals=dict(conclusion=[],**{'virtual-principle':['virtual-frame-path','request-completion-order'],'initial-preparation':['submission-gate'],'initial-submission':['initial-submission'],'flow':['completion-flow'],'reproduce':['reproduction-flow']})
items=[]
for i,t in enumerate(topics):
 windows=[]
 for s in t.get('sources',[]):
  key=section['id']+'/'+t['id']+'/'+s['id'];rec=model.evidence[key]
  if rec['status']!='available' or rec['commit']!=model.meta['source_commit']:raise ValueError('Unbound source window')
  windows.append(dict(id=key,file=rec['file'],line=rec['line'],sha256=rec['sha256'],selector=rec['selector']))
 items.append(dict(id=t['id'],question=t['question'],visual=visuals[t['id']],omission_reason='Short allocator obstacle/result/restored-state distinction; independently accepted by final Terra review' if t['id']=='conclusion' else None,pages={l:pages[l]['topics'][i] for l in pages},source_windows=windows,measurement_evidence='publication/issue211 and linked pinned reproduction guide; no new runtime'))
 part_audit=[]
 for part in t.get('parts',[]):
  figures=visuals[t['id']]
  if t['id']=='virtual-principle':figures=['request-completion-order'] if part['id']=='completion' else ['virtual-frame-path'] if part['id']=='buffer' else visuals[t['id']]
  if t['id']=='flow':figures=['initial-submission'] if part['id']=='submission-limit' else ['completion-flow'] if part['id'] in ['dispatch','processing','frame-work','reuse-request'] else []
  if t['id']=='reproduce':figures=['reproduction-flow']
  part_audit.append(dict(id=part['id'],question=part['question'],figures=figures,omission_reason=None if figures else 'Short outcome, invocation boundary or measured observation; text identifies a single condition/result without additional branching.'))
 items[-1]['independent_parts']=part_audit
configuration_items=[dict(file='docs/reference/config.md',option=option,fragment_sha256=sha256(w/fragment),diagram='omitted',reason='A boolean flag with a YAML usage example; no additional figure needed for this scalar configuration contract',grounding='reviews/config-connected-v2/review.json') for option,fragment in [('while_conditions','config-while-documentation-v7/config-reference.md'),('require_connected','config-connected-documentation-v2/config-reference.md')]]
record=dict(schema=1,pages=pages,items=items,configuration_items=configuration_items,diagram_checks=diagram_checks,accepted_review='reviews/'+tag+'/review.json',source_commit=model.meta['source_commit'],scope='Changed official-cam page and each independent explanatory topic only; source appendix excluded; no whole-site issue215 completion',human_review='pending',unreviewed=['Physical hardware, callback-return/performance and internal HAL; latest-SHA execution'])
configuration_items.append(dict(file='docs/reference/config.md',option='max_edge_label_chars',fragment_sha256=sha256(w/'config-edge-documentation-v3/config-reference.md'),diagram='omitted',reason='Scalar label-length contract is expressed directly by a YAML example.',grounding='integration/configuration-review/review.json'))
configuration_items.append(dict(file='docs/reference/config.md',option='require_guard_branches',fragment_sha256=sha256(w/'config-guard-branch-documentation-v2/config-reference.md'),diagram='omitted',reason='An optional boolean with a direct configuration example; validates the structure of cited branches, not semantic completeness.',grounding='integration/configuration-guard-branch-review/review.json'))
for item in configuration_items:
 if item['option'] in ['max_edge_label_chars','require_guard_branches']:
  item['historical_grounding']=item['grounding'];item['grounding']='integration/current-configuration-grounding/review.json'
(w/'topic-visual-review.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Topic audit:',len(items))
