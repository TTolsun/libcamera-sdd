from pathlib import Path
import sys,json
from sdd.config import load
from sdd.export_site import _render_site
from sdd.runtime_evidence import run_recorded,require_success,sha256
from sdd.validation_stage import staged
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-reader-release';tag=sys.argv[1] if len(sys.argv)>1 else 'latest-main-preview-v1';preview=w/('private-current-page-'+tag)
assert not preview.exists()
@staged
def render_preview(cfg):return _render_site(cfg,preview,check_consistency=False)
render_preview(load(d/'publication.yaml'))
(w/('private-current-page-'+tag+'.json')).write_text(json.dumps({'schema':1,'path':str(preview),'scope':'Private normal-renderer preview only, same supported path used by catalog discovery. Existing stale contract/publication gates are not waived. Publication must later pass normal export and match these reviewed page hashes.','html_sha256':{lang:sha256(preview/rel) for lang,rel in [('ko','official-cam-validation.html'),('en','en/official-cam-validation.html')]},'human_review':'pending'},indent=2)+'\n',encoding='utf-8')
def run(name,args):
    out=w/'executions'/(tag+'-'+name);run_recorded(out,[sys.executable,'-X','utf8']+args,timeout=1800,cwd=r);require_success(out)
windows=w/'windows'/tag
run('window',[str(g/'examples/libcamera/validation/issue211-reader/render_window.py'),'--work',str(d),'--out',str(windows),'--site',str(preview)])
run('review',[str(g/'examples/libcamera/validation/issue211-reader/review.py'),'--work',str(d),'--review-config',str(w/'new-document-review.yaml'),'--out',str(w/'reviews'/tag),'--english',str(windows/'en.txt'),'--korean',str(windows/'ko.txt'),'--inventory',str(windows/'inventory.json'),'--notes',str(w/'notes-final-review/README.md')])
review=json.loads((w/'reviews'/tag/'review.json').read_bytes())['review'];assert review['verdict']=='pass' and not review['findings'],review
print('Private bilingual preview grounding passed; normal publication gate remains required',flush=True)
