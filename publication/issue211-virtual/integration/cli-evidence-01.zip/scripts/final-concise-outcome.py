from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='concise-outcome'
b=w/('before-'+tag);b.mkdir()
for name in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());t=next(t for s in x['sections'] if s['id']=='official-cam-validation' for t in s['design_topics'] if t['id']=='flow')
 for part in t['parts']:
  if part['id']=='reuse-request':part['question']='처리 한도가 설정되지 않았거나 처리 수가 아직 한도에 도달하지 않았으면 버퍼를 유지해 요청을 재사용하고 제출 도우미를 호출한다는 한 문장을 씁니다. 실제 제출은 도우미의 별도 한도 검사에 따라 생략될 수 있다는 짧은 두 번째 문장으로 마칩니다. 기록 명령의 출력 옵션 범위는 앞 항목이 이미 설명했으므로 반복하지 않습니다. 도우미 반환값이나 내부 카운터 설명을 넣지 않습니다.'
  if part['id']=='submission-limit':part['question']='제출 한도가 설정되어 있고 제출 시도 수가 이미 그 한도에 도달했다면 제출 도우미가 이번 제출을 생략한다는 한 가지 조건을 한 짧은 문장으로 씁니다. 처리 한도와 별개인 제출 한도라는 구분은 유지합니다. 카운터 증가·반환값·내부 함수 식별자는 그림과 근거에 남기며 본문에서 다시 설명하지 않습니다.'
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());v=next(v for v in x['sections']['official-cam-validation'] if v['id']=='virtual-frame-path')
 v['prompt']='이것은 전체 그림을 새로 해석하는 작업이 아니라 유효한 native 초안의 두 표시 항목을 수정하는 작업입니다. 아래 초안의 나머지 모든 노드·간선·label·label_en·quote_ids·condition_ref·shape를 정확히 보존합니다. (1) n2의 label_en에 취소 요청 완료라는 대상·상태를 명시하고, 제출 순서 통지와 앞선 미완료 요청이면 통지가 보류된다는 조건을 60자 이내에 함께 보존합니다. Cancelled completion 또는 Complete cancelled 표현이 필요합니다. n2 한국어는 이미 이 의미를 갖추었으므로 그대로 둡니다. (2) n6에서 n7로 가는 always 간선은 성공과 오류 모두의 생성 결과 반환을 뜻하므로 한영 라벨을 결과 반환이라는 짧은 행동으로 고칩니다. 오류 로그·오류 시라는 제한은 그 간선에 넣지 않습니다. 이 간선의 기존 양 끝점 인용을 보존하고 성공 경로 return 0; 및 오류 반환을 함께 뒷받침하는 source 인용도 포함합니다. 다른 모든 표시와 인용을 재작성하지 않습니다. 아래 초안은 새 native CLI 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 v['answer_contract_en']['required_terms'].append(['Cancelled completion','Complete cancelled'])
 for key in ['answer_contract','answer_contract_en']:v[key]['reject_patterns'].append(dict(pattern=r'(?m)^[^·\n]*(?:\blog\b|로그)',message='Keep logging details in evidence; the sole conversion-to-result edge returns either success or error, not only an error.'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-allocation-outcome.py').read_text().replace('allocation-outcome',tag)
(r/'build/after-virtual-concise-outcome.py').write_text(text,encoding='utf-8')
