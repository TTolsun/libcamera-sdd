from pathlib import Path
import yaml,shutil
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration'
b=w/'before-execution-directory-contract';b.mkdir()
for root in [w,d]:
 p=root/'config/sections.yaml';shutil.copyfile(p,b/(root.name+'-sections.yaml'));x=yaml.safe_load(p.read_bytes());t=next(t for s in x['sections'] if s['id']=='official-cam-validation' for t in s['design_topics'] if t['id']=='reproduce');a=next(a for a in t['parts'] if a['id']=='execution')
 rules=a['answer_contract']['reject_patterns'];assert any('|디렉터리|' in item['pattern'] for item in rules)
 for item in rules:item['pattern']=item['pattern'].replace('|디렉터리|','|')
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
