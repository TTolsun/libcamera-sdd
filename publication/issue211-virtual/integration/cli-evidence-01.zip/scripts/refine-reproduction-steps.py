from pathlib import Path
import yaml,json,shutil,copy,subprocess
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-main-integration';base=g/'examples/libcamera/validation/issue211-virtual'
b=w/'before-distinct-preflight';b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 dest=b/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,dest)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'));ref=m['generated_visuals']['records']['request-completion-order']['draft']
def revise(section):
 t=next(t for t in section['design_topics'] if t['id']=='reproduce');t['product']['feature']='recorded-no-output-sink'
 items=t['parts'];old=next(p for p in items if p['id']=='request-check');where=items.index(old)
 q=copy.deepcopy(old);q.update(id='yaml-check',question="statement.text를 '8. '로 시작하세요. 사용할 Virtual2 YAML에서 지원 크기 400x300과 별도의 줄무늬 패턴 lines를 확인하는 행동만 한 짧은 문장으로 쓰세요.")
 camera=copy.deepcopy(old);camera.update(id='camera-selection',sources=[],question="statement.text를 '9. '로 시작하세요. 사용할 cam 명령의 카메라 선택 인자가 Virtual2인지 확인하는 행동만 한 짧은 문장으로 쓰세요. 제공된 과거 세 명령의 옵션 기록에 이 인자가 있으며, 여기서는 새로 사용할 명령을 확인하는 절차를 씁니다.");camera['answer_contract']['required_terms']=[['Virtual2']]
 stream=copy.deepcopy(old);stream.update(id='stream-request',sources=[],question="statement.text를 '10. '로 시작하세요. 사용할 cam 명령의 스트림 인자가 400x300 NV12를 요청하는지 확인하는 행동만 쓰세요. 앞 단계까지 확인한 조건이 하나라도 다르면 캡처를 시작하지 않는 조건을 여기서 한 번만 남깁니다. 과거 인자 기록은 기대 조건의 근거이며 새 실행의 성공 증거가 아닙니다.");stream['answer_contract']['required_terms']=[['NV12']]
 items[where:where+1]=[q,camera,stream]
 for p in items:
  if p['id']=='yaml-check':p['answer_contract']['required_terms']=[['Virtual2'],['lines']]
  if p['id']=='kernel-check':p['question']="statement.text를 '6. '로 시작하세요. 실행 중인 커널 버전을 기록된 6.18.33.2-microsoft-standard-WSL2-issue211과 대조하는 행동만 한 문장으로 씁니다. 다른 단계의 장치·입력·새 증거 설명은 반복하지 않습니다."
  if p['id']=='access-check':p['question']="statement.text를 '7. '로 시작하세요. root 자식 컨텍스트가 /dev/udmabuf을 열 수 있는 접근 권한을 확인하는 행동만 한 문장으로 씁니다. 커널이나 설정·명령 검사는 반복하지 않습니다."
  if p['id']=='execution':p['question']="statement.text를 '11. '로 시작하세요. 사전 조건을 통과하면 연결된 안내에 따라 디버거 관찰 아래 수정하지 않은 공식 cam을 세 번 독립 실행하고, 각 실행의 새 증거를 남기는 행동만 씁니다."
  if p['id']=='results':p['question']=p['question'].replace("'10. '","'12. '")
  if p['id'] in ['yaml-check','camera-selection','stream-request','kernel-check','access-check']:
   p['prompt']='지정한 단계의 직접 확인 행동만 짧게 쓰고 다른 단계·과거 기록의 부족·실행 뒤 결과를 덧붙이지 않습니다.'
   p['answer_contract'].setdefault('reject_patterns',[]).append({'pattern':'미확인|확인되지|포함되어 있지|자료가 없','message':'Expected inputs are evidenced by the provided source and historical command projection; describe the new preflight action directly.'})
section=yaml.safe_load((g/'examples/libcamera/validation/issue211-reader/section.yaml').read_bytes());revise(section)
# Keep the historical reader's standalone preparation compatible; the new
# invocation-scoped recipe owns its separate section configuration.
new=base/'section.yaml';assert not new.exists();new.write_text(yaml.safe_dump(section,allow_unicode=True,sort_keys=False),encoding='utf-8')
original=subprocess.check_output(['git','show','origin/main:examples/libcamera/validation/issue211-reader/section.yaml'],cwd=g);(g/'examples/libcamera/validation/issue211-reader/section.yaml').write_bytes(original)
p=base/'prepare.py';text=p.read_text(encoding='utf-8');text=text.replace("(root/'examples/libcamera/validation/issue211-reader/section.yaml')","(base/'section.yaml')");p.write_text(text,encoding='utf-8')
p=base/'retained-visual-overrides.yaml';vs=yaml.safe_load(p.read_bytes());comp=next(v for v in vs if v['id']=='request-completion-order');comp['prompt']+=' 최종 가독성 보완: 실제 큐 반복·세 결정·서로 다른 두 결과와 source 인용은 보존하고 n4의 queuedRequests_, n7의 doQueueRequests, 함수 종료 아님 같은 내부 이름·부정 주석은 한영 화면 라벨에서 빼세요. n4는 제출 큐에 요청이 남았는지, n5는 맨 앞 요청이 아직 미완료인지, n6는 완료된 맨 앞을 꺼내 cam에 순서대로 알림, n7은 다음 대기 요청 처리라는 짧은 동작이면 됩니다. 근거의 함수·변수 식별자와 고정 symbol은 그대로 보존합니다. n2 남은 버퍼 대기와 n7 후속 요청 처리는 별도 노드로 유지합니다. 종료·반환을 새로 주장하지 마세요.';p.write_text(yaml.safe_dump(vs,allow_unicode=True,sort_keys=False),encoding='utf-8')
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(t for t in x['sections'] if t['id']=='official-cam-validation');revise(s);p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());v=next(t for t in x['sections']['official-cam-validation'] if t['id']==comp['id']);v['prompt']=comp['prompt']+' 現在'.replace('現在','현재 검증된 초안의 노드 ID·shape·quote_ids, 모든 간선 from·to·condition_ref·quote_ids 및 다른 올바른 라벨은 보존하고 앞서 지적한 내부 이름과 부정 주석만 새 native 응답에서 짧은 동작으로 편집하세요. 참고 초안은 편집 입력이며 저장 응답의 재생이 아닙니다. 참고 초안: ')+json.dumps(ref,ensure_ascii=False,separators=(',',':'));p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
s=(r/'build/after-virtual-split-completion.py').read_text().replace('split-completion','distinct-preflight');(r/'build/after-virtual-distinct-preflight.py').write_text(s)
