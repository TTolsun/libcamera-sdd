from pathlib import Path
from html.parser import HTMLParser
import json,sys
from sdd.runtime_evidence import sha256
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';site=r/'build/libcamera-sdd-issue211/docs';tag=sys.argv[1]
review=json.loads((w/'reviews'/tag/'review.json').read_bytes())['review'];assert review['verdict']=='pass' and not review['findings']
inventory=json.loads((w/'windows'/tag/'inventory.json').read_bytes())
class Page(HTMLParser):
 def __init__(self):super().__init__();self.article=False;self.fold=0;self.pre=0;self.h2=False;self.headings=[];self.figure_links=[];self.evidence=0;self.open_details=0;self.visible=[]
 def handle_starttag(self,t,attrs):
  a=dict(attrs)
  if a.get('id')=='page-evidence':self.evidence+=1
  if t=='article':self.article=True
  if not self.article:return
  if t=='details':self.fold+=1;self.open_details+=int('open' in a)
  if t=='pre':self.pre+=1
  if self.fold or self.pre:return
  if t=='h2':self.h2=True;self.headings.append('')
  if t=='a' and a.get('href','').endswith('.mmd'):self.figure_links.append(a['href'])
 def handle_endtag(self,t):
  if t=='article':self.article=False
  if not self.article:return
  if t=='details':self.fold-=1
  if t=='pre':self.pre-=1
  if t=='h2':self.h2=False
 def handle_data(self,text):
  if self.article and not self.fold and not self.pre:
   self.visible.append(text)
   if self.h2:self.headings[-1]+=text
pages={}
for lang,rel in [('ko','official-cam-validation.html'),('en','en/official-cam-validation.html')]:
 p=Page();p.feed((site/rel).read_text(encoding='utf-8'));assert sha256(site/rel)==inventory[lang]['html_sha256'];assert p.evidence==1 and p.open_details==0;assert len(p.headings)==7 and len(p.figure_links)==6
 assert all(link.endswith(ident+'.mmd') for link,ident in zip(p.figure_links,['virtual-frame-path','request-completion-order','submission-gate','initial-submission','completion-flow','reproduction-flow']))
 text=''.join(p.visible);assert all(token not in text for token in ['PID 434','TID 437','PID 449','PID 464'])
 pages[lang]={'path':rel,'html_sha256':sha256(site/rel),'topic_and_source_headings':p.headings,'figure_order':p.figure_links,'unified_evidence_sections':p.evidence,'initially_open_details':p.open_details}
historical={}
for name,counts in [('phase-blocks',[10,9,7,10,12]),('signal-wording',[10,9,9,10,12])]:
 p=w/'windows'/name/'inventory.json'
 if p.exists():historical[name]={'korean_html_sha256':json.loads(p.read_bytes())['ko']['html_sha256'],'observed_svg_node_counts':counts,'scope':'Earlier actual in-app browser observation only; not the final outputs.'}
result={'schema':1,'current_static_checks':pages,'final_interactive_observation':'not performed','reason':'Computer Use stopped because it could not determine the current browser URL on Windows confidently enough to enforce policy. No further UI input or alternative UI automation was attempted.','earlier_interactive_observations':historical,'earlier_zoom_and_search':'Phase-blocks Korean pattern diagram: actual 100% view, NV12 match count 1, Escape closed dialog; this is not a fresh final-page observation.','human_review':'pending'}
(w/'ui-verification-integrated.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Current bilingual static structure verified; final interactive limitation recorded')
