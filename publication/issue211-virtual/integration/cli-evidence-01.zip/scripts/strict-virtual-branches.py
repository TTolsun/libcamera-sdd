from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='strict-branches'
b=w/('before-'+tag);b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());t=next(t for s in x['sections'] if s['id']=='official-cam-validation' for t in s['design_topics'] if t['id']=='virtual-principle')
 t['sources'].append(dict(id='request-status-completion',file='src/libcamera/request.cpp',start='void Request::Private::complete()',end='void Request::Private::doCancelRequest()'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='virtual-frame-path':
   v['max_nodes']=12;v['required_symbols'][1]='Camera::queueRequest';v['required_symbols'].extend(['PipelineHandler::doQueueRequest','completeRequest']);v['sources'].append('request-status-completion');v['require_guard_branches']=True
   edit='12개 고정 symbol 노드로 요청 검증과 나중 준비를 분리합니다. n0는 할당 실패 판정, n8은 버퍼 추가 실패 판정이고 각 실패는 n7 startCapture 오류 반환입니다. n1(Camera::queueRequest)은 버퍼 유무·활성 스트림 검증 및 큐 등록의 실패 여부 판정입니다. 반환을 확인하는 실제 cam startCapture의 queueRequest 호출 뒤 ret < 0 조건과 Camera 구현을 함께 인용합니다. 실패면 n7의 시작 중단·오류 반환, 성공이면 나중 파이프라인 준비와 큐 차례를 기다리는 경로의 n10으로 갑니다. n7은 이전 요청이 이미 제출됐을 수 있으므로 모든 요청이 전혀 제출되지 않았다고 단정하지 않고 시작 중단과 오류 반환만 표시합니다. n10(PipelineHandler::doQueueRequest)은 요청 준비·차례가 된 후 cancelled_ 여부를 판정합니다. 실제 source guard cancelled_ true는 n11(completeRequest)의 취소 요청 완료·순서 통지 경로로 이어집니다. 취소 완료 역시 요청 순서 통지를 거치므로 즉시 cam 통지 보장이라고 쓰지 않습니다. 취소 상태는 request-status-completion의 상태 처리로 근거를 보완합니다. cancelled_ false만 n2 virtual queueRequestDevice로 갑니다. n2 queued 예약→n9 VirtualCameraData::processRequest 실행·목표 시각 대기→n3 쓰기 동기화 범위의 매핑 시도→n4 CPU NV12 변환·매핑 버퍼 쓰기 시도→n5 생성 오류 판정→n6 상태와 무관한 버퍼 완료를 유지합니다. n0,n8,n1,n10,n5는 실제 source guard의 두 결과를 갖춘 decision입니다. 다른 노드에 true/false 조건을 붙이지 않습니다. 실패하지 않은 주요 준비 경로의 다른 연결은 관계 요약이며 출처를 인용합니다. 긴 구현 설명 대신 짧은 동작·질문 라벨로 씁니다. '
   ref=json.dumps(m['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
  elif v['id']=='request-completion-order':
   v['max_nodes']=7;v['required_symbols']=['PipelineHandlerVirtual::bufferCompleted','completeBuffer','FrameBuffer','completeRequest','RequestPending','requestCompleted','queuedRequests_'];v['require_guard_branches']=True
   v['question']='버퍼 완료 뒤 모든 버퍼 완료 조건, 앞선 Pending 요청에 의한 통지 대기, 가능한 완료 요청들의 순서 통지는 어떻게 cam 콜백으로 이어집니까?'
   edit='일곱 노드로 버퍼 완료와 통지 순서만 명시합니다. n0는 앞 그림의 버퍼 완료 수신, n1은 해당 요청의 모든 버퍼 완료 판정입니다. 미완료 결과는 n2 나머지 버퍼 완료 대기, 완료 결과는 n3 이미 큐에 들어간 해당 요청의 완료 상태 표시입니다. n3→n4는 큐 맨 앞 상태 확인 관계입니다. n4(RequestPending)는 큐 맨 앞 요청의 실제 Pending guard를 판정합니다. Pending true는 n6(queuedRequests_)의 뒤 요청 통지 보류, false는 n5(requestCompleted)의 통지 가능한 완료 큐 앞부분을 제출 순서대로 cam requestComplete에 알리는 요약입니다. n5는 방금 완료 표시한 요청만 즉시 통지한다고 단정하지 않으며, 첫 Pending 전까지의 가능한 완료 요청들만 처리하는 집합 동작입니다. 내부 큐 스캔 반복과 후속 새 요청 제출은 이 독자 그림의 범위가 아니며 소스 근거에 남깁니다. n1과 n4는 각 실제 guard의 두 결과를 갖춘 decision이고 다른 노드의 간선에 true/false를 붙이지 않습니다. n5 한영 라벨에는 requestCompleted와 cam requestComplete 연결을 명시합니다. 구현 변수명은 근거에 두고 짧은 라벨로 설명합니다. '
   ref='새 범위의 일곱 노드는 제공된 소스에서 새 native CLI 응답으로 구성합니다.'
  else:continue
  v['prompt']=edit+'한영 노드 최대 '+str(v['max_label_chars'])+'자, authored 간선 20자입니다. 조건·인용은 현재 소스에서 실제로 확인합니다. 이전 초안은 편집 입력이며 실행 증거나 응답 재생이 아닙니다. 이전 초안: '+ref
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-bound-preflight.py').read_text().replace('bound-preflight',tag).replace('build/generator-main-integration','build/generator-reader-release')
(r/'build/after-virtual-strict-branches.py').write_text(text,encoding='utf-8')
