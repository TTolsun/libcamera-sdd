from pathlib import Path
import copy,yaml
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';g=r/'build/generator-reader-release';dest=g/'examples/libcamera/validation/issue211-virtual'
section=next(s for s in yaml.safe_load((w/'config/sections.yaml').read_bytes())['sections'] if s['id']=='official-cam-validation')
topic=next(t for t in section['design_topics'] if t['id']=='virtual-principle')
base=copy.deepcopy(section);base['design_topics']=[t for t in base['design_topics'] if t['id']!='virtual-principle'];base['design_requirements']=[t for t in base['design_requirements'] if t['id']!='virtual-principle']
visuals=yaml.safe_load((w/'config/visuals.yaml').read_bytes())['sections']['official-cam-validation']
for v in visuals:
 for marker in ['아래 초안','참고 초안:','구조:','다음은 native 편집 대상 초안','아래 기존 상세 초안','실제 검토 지적:']:
  if marker in v['prompt']:v['prompt']=v['prompt'].split(marker,1)[0].strip()
 if v['id']=='virtual-frame-path':
  original=yaml.safe_load((w/'before-initial-reproduction/config/visuals.yaml').read_bytes())
  instructions=next(x['prompt'] for x in original['sections']['official-cam-validation'] if x['id']==v['id'])
  instructions=instructions.replace('제출 한도는 재사용 후 재제출에도 같은 도우미로 적용됩니다.','')
  v['prompt']=instructions+' '+v['prompt']
 if v['id']=='request-completion-order':
  v['prompt']+=' 처음 생성할 때 아홉 노드는 가상 버퍼 완료 수신, 모든 요청 버퍼 완료 판정, 나머지 버퍼 대기, 해당 요청 완료 표시, 큐 맨 앞 Pending 판정, 맨 앞 요청 하나의 순서 통지, Pending 앞에서 뒤 요청 통지 보류, 통지할 큐 요청 존재 판정, 이번 통지 검사 종료입니다. 큐 존재 판정의 true는 Pending 판정으로, false는 이번 검사 종료로 갑니다. Pending이면 보류하고, 아니면 맨 앞 요청을 꺼내 requestCompleted로 cam requestComplete에 통지한 뒤 큐 존재 판정으로 되돌아갑니다. 모든 실제 guard의 true/false 양쪽을 유지하고 빈 큐 또는 Pending에서 반복을 멈춥니다. 이후 doQueueRequests는 이 통지 검사 범위 밖이며 표시에는 내부 큐 변수명을 쓰지 않습니다.'
 if v['id']=='submission-gate':
  v['prompt']+=' 처음 생성할 때는 할당 실패 판정, 공통 오류 반환, 남은 초기 요청 판정, 요청 생성 실패 판정, 버퍼 연결 실패 판정, 현재 요청 보관, 모든 초기 요청 준비 완료라는 일곱 역할로 소스의 준비 반복을 설명합니다. 할당·생성·연결의 오류는 반환으로, 성공한 단일 스트림 연결은 현재 요청 보관과 남은 요청 재확인으로 이어집니다. 카메라 시작은 다음 그림의 범위입니다. 모든 실제 조건 양쪽과 소스 인용을 유지합니다.'
 if v['id']=='initial-submission':
  v['prompt']+=' 처음 생성할 때 아홉 역할은 카메라 시작 실패 판정, 시작 오류 반환, 남은 초기 요청 판정, 제출 한도 판정, 실제 카메라 큐 호출 시도, 호출 결과의 음수 오류 판정, 이미 시작한 카메라 중지 후 제출 오류 반환, 성공한 실제 호출의 예약됨·0반환 결과, 초기 제출 순회 완료입니다. 한도 도달은 호출 없이0을 반환하고 남은 요청을 확인합니다. 한도 미설정·미달이면 실제 호출을 하고, 음수이면 중지·오류 반환하며 아니면 성공한 호출 결과를 확인하고 반복합니다. 성공 결과 상자는 결과 상태를 설명하며 그 위치에서 새 예약이나 실행을 수행한다는 뜻이 아닙니다. 모든 실제 조건의 양쪽·인용·시작 실패와 제출 실패의 차이를 보존합니다.'
for name,data in [('topic.yaml',topic),('section.yaml',base),('visual.yaml',next(v for v in visuals if v['id']=='virtual-frame-path')),('retained-visual-overrides.yaml',[v for v in visuals if v['id']!='virtual-frame-path'])]:
 (dest/name).write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False,width=100),encoding='utf-8')
print('Prepared source-only reusable recipe; no authored graph, manuscript, model response or historical run changed')
