from pathlib import Path
import json,sys
from sdd.runtime_evidence import run_recorded,require_success
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration'
review=json.loads((w/'reviews/latest-main-final-v19/review.json').read_bytes())['review'];assert len(review['findings'])==1
catalog=json.loads((d/'run/english.json').read_bytes());selected={k:review['findings'][0] for k in catalog['strings'] if '실행할 공식 cam 명령의 인자' in k};assert len(selected)==1
p=w/'final-english-instruction-native-findings.json';p.write_text(json.dumps(selected,ensure_ascii=False,indent=2),encoding='utf-8')
def run(name,args):
 out=w/'executions'/name;run_recorded(out,[sys.executable,'-X','utf8']+args,timeout=1800,cwd=r);require_success(out);print(name,'PASS',flush=True)
run('update-current-page-translation-v20',[str(r/'build/update-reviewed-page-translation.py'),'v20','generate-preflight-limit-buffer-check',str(p)])
run('finalize-final-english-v20',[str(r/'build/finalize-native-page.py'),'latest-main-final-v20','update-current-page-translation-v20','latest-main-final-v19'])
