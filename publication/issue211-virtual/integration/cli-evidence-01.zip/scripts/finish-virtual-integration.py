from pathlib import Path
import sys,json
from sdd.runtime_evidence import run_recorded,require_success
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-main-integration';site=r/'build/libcamera-sdd-issue211/docs'
require_success(w/'executions/translate-current-main-ui-network')
prefix=[sys.executable,'-X','utf8']
def run(stage,argv):
 out=w/'executions'/('current-main-'+stage);run_recorded(out,prefix+argv,timeout=1800,cwd=r);require_success(out)
run('export',['-m','sdd.cli','--config',str(d/'publication.yaml'),'export-site','--out',str(site)])
windows=w/'windows/current-main-final'
run('render',[str(g/'examples/libcamera/validation/issue211-reader/render_window.py'),'--work',str(d),'--out',str(windows),'--site',str(site)])
notes=w/'notes-resume-upstream/README.md'
run('review',[str(g/'examples/libcamera/validation/issue211-reader/review.py'),'--work',str(d),'--review-config',str(w/'new-document-review.yaml'),'--out',str(w/'reviews/current-main-final'),'--english',str(windows/'en.txt'),'--korean',str(windows/'ko.txt'),'--inventory',str(windows/'inventory.json'),'--notes',str(notes)])
review=json.loads((w/'reviews/current-main-final/review.json').read_bytes())['review']
assert review['verdict']=='pass' and not review['findings'],review
print('Current-main final review passed')
