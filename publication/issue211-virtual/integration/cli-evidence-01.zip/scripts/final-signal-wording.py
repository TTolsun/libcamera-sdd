from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='signal-wording'
b=w/('before-'+tag);b.mkdir()
for name in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());t=next(t for s in x['sections'] if s['id']=='official-cam-validation' for t in s['design_topics'] if t['id']=='virtual-principle')
 part=next(a for a in t['parts'] if a['id']=='buffer')
 part['question']+=' 쓰기 방향 동기화와 쓰기용 매핑은 모두 시도로 표현합니다. 동기화가 성공적으로 열렸거나 범위를 확보했다고 단정하지 말고, 패턴 생성기가 쓰기 방향 동기화를 시도한 뒤 버퍼의 쓰기용 매핑을 시도하는 순서만 한 짧은 문장으로 설명합니다. 이 조건은 영어 번역에서도 보존합니다.'
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='virtual-frame-path':
   edit='현재 아홉 노드와 모든 간선·조건·소스 인용을 정확히 유지하고 n5와 n8의 한영 표시만 고칩니다. n5는 CPU 쓰기 방향 동기화와 쓰기용 DMA-BUF 매핑을 모두 시도한다는 동작구로 쓰고 동기화 성공을 전제하지 않습니다. n8은 프레임 생성 결과가 성공이든 오류든 버퍼 완료 신호를 발생시킨다는 동작구입니다. 버퍼 완료가 성공했다고 단정하지 말고 신호 발생임을 반드시 명시합니다. 다음 그림이 요청 통지 조건을 다룬다는 연결은 짧게 유지해도 됩니다. 나머지 라벨·바인딩·분기는 변경하지 않습니다. 한영 노드72자·간선20자 한도를 지킵니다. '
  elif v['id']=='request-completion-order':
   edit='현재 아홉 노드와 모든 간선·실제 조건·인용·반복을 정확히 보존하며 n6,n7,n8의 한영 표시만 짧게 정리합니다. n6은 앞선 미완료 요청 때문에 뒤 요청 통지 보류, n7은 통지할 요청이 남았는가라는 짧은 질문, n8은 이번 통지 검사 종료입니다. 표시 라벨에는 while, queuedRequests_, 코드 접미사, 구현 변수명을 쓰지 않습니다. 실제 노드 symbol과 quote_ids 및 조건 바인딩은 그대로 유지하므로 근거는 잃지 않습니다. n7 true/false와 n4 true/false, n5에서 n7로 돌아가는 반복을 모두 보존합니다. 한영 노드56자·간선20자 한도를 지킵니다. '
  else:continue
  v['prompt']=edit+'아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
(r/'build/after-virtual-signal-wording.py').write_text((r/'build/after-virtual-ordered-prefix.py').read_text().replace('ordered-prefix',tag),encoding='utf-8')
