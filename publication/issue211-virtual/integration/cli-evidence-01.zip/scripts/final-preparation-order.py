from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='preparation-order'
b=w/('before-'+tag);b.mkdir()
for name in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(s for s in x['sections'] if s['id']=='official-cam-validation')
 t=next(t for t in s['design_topics'] if t['id']=='reproduce');part=next(a for a in t['parts'] if a['id']=='execution');part['question']+=' 아직 존재하지 않는 새 증거 디렉터리 하나를 사용하고 그 디렉터리 안에서 실행별 기록을 구분한다는 관계를 명확히 쓰세요. 한 위치에 분리한다는 모호한 표현을 쓰지 않습니다. 단계 묶음 제목은 유지합니다.'
 t=next(t for t in s['design_topics'] if t['id']=='flow');part=next(a for a in t['parts'] if a['id']=='processing');part['question']+=' 함수를 도착하는 주어로 쓰지 말고 processRequest가 호출될 때의 조건으로 표현합니다. 영어에도 When processRequest is called/invoked처럼 호출 관계가 명확해야 합니다.'
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());v=next(v for v in x['sections']['official-cam-validation'] if v['id']=='submission-gate')
 v['required_symbols']=[s for s in v['required_symbols'] if s!='PipelineHandler::queueRequest']
 v['prompt']='현재 열두 노드의 실제 오류·한도·카메라 시작 조건을 보존하면서 준비 반복과 큐 호출 반환 관계를 정확히 고칩니다. 최대12노드입니다. n0는 스트림별 버퍼 할당 실패 검사이며 모든 스트림 할당 뒤 n1의 초기 요청별 생성으로 갑니다. n2는 현재 요청의 각 스트림에 대한 버퍼 연결 실패 검사입니다. 기존 n7의 별도 비동기 전달 노드는 없애고 이 ID를 현재 요청을 저장하고 다음 초기 요청의 준비를 반복하는 단계로 재사용합니다. n7 symbol은 requests_ 또는 실제 해당 보관 코드 식별자와 인용으로 바꿉니다. n2 false→n7, n7에서 남은 요청이 있으면 n1로 돌아가고 모든 요청의 모든 스트림 버퍼가 준비된 뒤에만 n9 카메라 시작으로 갑니다. n7의 for 반복 관계는 실제 요청 준비 for와 requests_.push_back 코드에 인용하고, if용 조건 ID를 억지로 붙이지 않습니다. 카메라 시작을 버퍼 하나 연결 직후 수행하는 것으로 그리지 않습니다. n4 카메라 큐 호출 노드 자체의 한영 짧은 라벨에서 검증 실패는 오류 반환, 성공은 PipelineHandler에 비동기 전달 뒤0반환이라는 두 가능한 호출 결과를 표현합니다. n4의 출력은 n10 반환값 검사 하나로만 이어집니다. 비동기 전달을 반환값 검사 뒤의 사건으로 그리거나 독립 두 분기로 그리지 않습니다. n10 음수 true→n11 카메라 중지, 싱크 있으면 중지, 오류 반환이고 false→n6 다음 초기 요청 순회입니다. n6에서 남은 초기 요청에 대해 n3 제출 한도 검사로 반복한다는 관계를 명시하고 모두 끝나면 초기 제출 종료임을 표시합니다. 내부 sink_ 식별자와 군더더기 긴 문장을 표시에서 빼세요. 준비 중 오류와 카메라 시작·제출 한도·증가·큐 반환 오류의 실제 기존 분기 및 근거를 보존합니다. 각 노드72자/간선20자 한영 동작구로 간결하게 쓰고 반복은 실제 for 구절에 연결합니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
(r/'build/after-virtual-preparation-order.py').write_text((r/'build/after-virtual-queue-error.py').read_text().replace('queue-error',tag),encoding='utf-8')
