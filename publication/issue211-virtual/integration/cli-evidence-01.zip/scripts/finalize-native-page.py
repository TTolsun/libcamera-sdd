from pathlib import Path
import sys,json,time,difflib
from sdd.runtime_evidence import run_recorded,require_success,sha256
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-reader-release';site=r/'build/libcamera-sdd-issue211/docs';tag=sys.argv[1] if len(sys.argv)>1 else 'latest-main-final-v2';translation=sys.argv[2] if len(sys.argv)>2 else 'update-current-page-translation-v2'
deadline=time.monotonic()+1800
while not (w/'latest-contract-audit.json').exists() or not (w/'executions'/translation/'record.json').exists():
    if time.monotonic()>deadline:raise TimeoutError('Mandatory native review gates are not complete')
    time.sleep(3)
require_success(w/'executions'/translation)
assert json.loads((w/'latest-contract-audit.json').read_bytes())['status']=='passed'
assert json.loads((w/'current-page-translation-acceptance.json').read_bytes())['catalog_sha256']==sha256(d/'run/english.json')
def run(name,args):
    out=w/'executions'/(tag+'-'+name);run_recorded(out,[sys.executable,'-X','utf8']+args,timeout=1800,cwd=r);require_success(out)
run('export',['-m','sdd.cli','--config',str(d/'publication.yaml'),'export-site','--out',str(site)])
windows=w/'windows'/tag
run('window',[str(g/'examples/libcamera/validation/issue211-reader/render_window.py'),'--work',str(d),'--out',str(windows),'--site',str(site)])
notes=w/'notes-final-review/README.md'
previous=sys.argv[3] if len(sys.argv)>3 else ('latest-main-final-v12' if tag=='latest-main-final-v13' else None)
if previous:
 from sdd.call_records import load_record
 from sdd.cli_provenance import verify_cli_receipt
 from sdd.config import load
 prior_path=w/'reviews'/previous/'review.json';prior=json.loads(prior_path.read_bytes());receipt=Path(prior['receipt']);native=load_record(receipt)
 verify_cli_receipt(native.request,native.raw,native.receipt,receipt.parent.parent,load(w/'new-document-review.yaml').agent)
 assert json.loads(native.raw)==prior['review']
 old=w/'windows'/previous;assert prior['inventory_sha256']==sha256(old/'inventory.json')
 changes={lang:'\n'.join(difflib.unified_diff((old/(lang+'.txt')).read_text(encoding='utf-8').splitlines(),(windows/(lang+'.txt')).read_text(encoding='utf-8').splitlines(),fromfile=previous,tofile=tag)) for lang in ['ko','en']}
 continuity={'review_mode':'Full current document, with authenticated previous findings and exact visible-text changes as additional context','prior_is_approval':False,'new_independent_native_review_required':True,'prior_review_sha256':sha256(prior_path),'previous_review':prior['review'],'current_inventory_sha256':sha256(windows/'inventory.json'),'visible_text_changes':changes,'current_diagram_sources':'Supplied in the current inventory; previous findings are not substituted for current source review.'}
 target=w/('notes-continuity-'+tag);target.mkdir(exist_ok=False);notes=target/'README.md'
 notes.write_text((w/'notes-final-review/README.md').read_text(encoding='utf-8')+'\n\n'+json.dumps(continuity,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
run('review',[str(g/'examples/libcamera/validation/issue211-reader/review.py'),'--work',str(d),'--review-config',str(w/'new-document-review.yaml'),'--out',str(w/'reviews'/tag),'--english',str(windows/'en.txt'),'--korean',str(windows/'ko.txt'),'--inventory',str(windows/'inventory.json'),'--notes',str(notes)])
review=json.loads((w/'reviews'/tag/'review.json').read_bytes())['review'];assert review['verdict']=='pass' and not review['findings'],review
print('Normal gated export and final bilingual source grounding passed',flush=True)
