from pathlib import Path
import sys,time
from sdd.runtime_evidence import run_recorded,require_success
r=Path(__file__).resolve().parent.parent;w=r/"build/issue211-virtual";record=w/"executions/generate-finish-reader-labels/record.json";deadline=time.monotonic()+1800
while not record.exists():
 if time.monotonic()>deadline:raise TimeoutError("Native generation incomplete")
 time.sleep(3)
require_success(record.parent)
for stage,args in [("update-current-page-translation-v10",[str(r/"build/update-reviewed-page-translation.py"),"v10","generate-finish-reader-labels"]),("finalize-native-page-v10",[str(r/"build/finalize-native-page.py"),"latest-main-final-v10","update-current-page-translation-v10"])]:
 target=w/"executions"/stage;run_recorded(target,[sys.executable,"-X","utf8"]+args,timeout=1800,cwd=r);require_success(target);print(stage,"passed",flush=True)
