from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='connected-reader'
b=w/('before-'+tag);b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='virtual-frame-path':
   edit='마지막 그림 검토의 세부 수정입니다. n1→n2, n2→n3, n3→n4, n4→n5는 선택된 가상 경로의 주요 호출 관계를 요약하는 always 간선입니다. 네 간선의 condition_ref를 always로 설정하고 prepared request 전달·패턴 생성 호출·쓰기 동기화 범위·변환 결과 확인 같은 짧은 관계만 표시하세요. 불리언 true/false나 특정 stream 일치 분기를 이 process 노드들에 붙이지 않습니다. 판정 노드는 n0 할당 실패 여부와 n5 변환 오류 여부이며, 각각의 두 결과와 정확한 실제 소스 조건을 그대로 보존합니다. n6는 프레임 상태와 무관한 버퍼 완료 신호이며 다음 요청 완료 그림의 핸들러로 이어짐을 한영 라벨에 짧게 표시합니다. n0→n7 실패 반환과 n0→n1 성공 경로, n2 VirtualCameraData::processRequest, 나머지 올바른 라벨·인용·구조는 유지합니다. '
  elif v['id']=='request-completion-order':
   v['max_label_chars']=72
   edit='n0,n3,n6의 한영 라벨만 바꿉니다. n0는 앞 가상 프레임 그림에서 나온 버퍼 완료 신호를 핸들러가 받는다는 연결입니다. n3는 현재 요청의 상태를 완료로 변경하는 한 단계입니다. 이는 함수 전체 동작이 이 단계뿐이라는 뜻이 아니므로 only/만이라는 제한이나 호출 순서 제약 설명을 쓰지 않습니다. n3 뒤의 큐 검사·앞 Pending 검사·통지·대기 요청 처리는 기존 개별 노드가 나타냅니다. n6는 큐 맨 앞 요청을 제출 순서대로 꺼내 requestCompleted 신호로 cam의 requestComplete 콜백에 통지한다는 동작이며 다음 콜백 그림으로 연결됨을 짧게 표시합니다. critical requestCompleted와 requestComplete 이름은 보존하여 cam의 실제 콜백 연결을 명확히 합니다. 다른 모든 올바른 라벨·인용·노드·실제 조건·큐 반복은 유지합니다. '
   for key in ['answer_contract','answer_contract_en']:v[key]['reject_patterns'].append(dict(pattern=r'(?i)\bonly\b|표시만|표시만\s*함|순서 제약|call order',message='A node describes a completion-marking step, not the entirety of completeRequest. Do not claim only/sole behavior or add an internal call-order aside; later nodes show ordered notification and waiting work.'))
  else:continue
  v['prompt']=edit+'간선 authored 라벨은 한영 20자 이내로 짧게 쓰고 필수 실제 source guards는 보존합니다. 아래 초안은 새 native CLI 편집 입력이며 저장 응답 재생이 아닙니다. 참고 초안: '+json.dumps(m['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
(r/'build/after-virtual-connected-reader.py').write_text((r/'build/after-virtual-bound-preflight.py').read_text().replace('bound-preflight',tag),encoding='utf-8')
