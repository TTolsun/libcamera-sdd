from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='connected-scope'
b=w/('before-'+tag);b.mkdir()
for name in ['config/sections.yaml','config/visuals.yaml','run/manuscripts/official-cam-validation.md']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());section=next(s for s in x['sections'] if s['id']=='official-cam-validation')
 for t in section['design_topics']:
  for part in t['parts']:
   if t['id']=='flow' and part['id']=='reuse-request':
    part['question']='문장 맨 앞의 짧은 구절로 기록된 출력 싱크 미요청 경로임을 명시하세요. 이 경로에서 처리 한도가 설정되지 않았거나 처리 수가 아직 한도에 도달하지 않았으면 버퍼를 유지해 요청을 재사용하고 제출 도우미를 호출한다는 한 문장을 씁니다. 실제 제출은 도우미의 한도 검사에 따라 생략될 수 있다는 둘째 짧은 문장으로 마칩니다. 출력 싱크가 요청을 보유하는 일반 경로까지 무조건 재사용한다고 쓰지 않습니다. 반환값과 카운터 증가 설명은 넣지 않습니다.'
   if t['id']=='reproduce' and part['id']=='modules':
    part['question']="statement.text를 '2. '로 시작하세요. 선택한 커널과 할당기에 필요한 모듈만 설치 여부와 커널 버전 일치를 조사한다는 한 가지 행동을 짧게 씁니다. 기록된 udmabuf 시험은 내장 드라이버였으며 별도 모듈을 설치하지 않았다는 둘째 짧은 문장으로 한정합니다. 모든 지원 모듈의 사용을 요구하거나 지금 모듈을 로드한다고 쓰지 마세요. WSL 공유 커널 조건은 그림과 연결 안내에 이미 있으므로 반복하지 않습니다. 설정 심볼·의존 목록·후보 조사는 다른 항목에 남깁니다."
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='virtual-frame-path':
   v['max_label_chars']=72
   if 'cam-request-buffers' not in v['sources']:v['sources'].append('cam-request-buffers')
   v['prompt']='현재 유효한 아홉 노드와 모든 guard·양쪽 결과·인용·간선을 그대로 보존하고 첫 노드와 마지막 노드 표시만 고칩니다. n0는 앞의 초기 준비 그림에서 DMA-BUF 버퍼가 연결된 요청을 PipelineHandler가 받아 준비한다는 출발점을 짧게 표시합니다. 요청에 버퍼를 붙이는 cam-request-buffers와 요청을 받는 pipeline-dispatch의 인용을 함께 사용하세요. n8은 버퍼 완료 신호가 다음 완료·통지 순서 그림으로 이어지며 그 그림에서 cam 콜백 통지 조건을 확인한다는 끝점을 짧게 표시합니다. 버퍼 완료만으로 cam 콜백이 즉시 또는 무조건 발생한다고 쓰지 않습니다. 두 언어에 같은 이전/다음 그림 연결을 넣습니다. n2의 취소 완료·앞선 미완료 요청 통지 보류와 n6→n7의 성공/오류 결과 반환은 이미 올바르므로 정확히 보존하고 다른 모든 표시는 바꾸지 않습니다. 노드 72자·간선 20자 이내입니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
   for key in ['answer_contract','answer_contract_en']:v[key]['required_terms'].append(['DMA-BUF'])
  if v['id']=='submission-gate':
   v['prompt']=v['prompt'].split('아래 초안')[0]+' 현재 유효한 모든 노드·인용·guard·간선을 보존하고 n2에서 n3로 가는 false 간선의 한영 라벨만 고칩니다. 이 간선은 버퍼 연결 후 제출 한도 검사로 진행한다는 의미입니다. 이 지점에서 이미 제출했다고 쓰지 않습니다. n3의 한도 검사 결과에 따라 제출 없이 반환할 수 있습니다. 다른 모든 표시를 정확히 보존합니다. 아래 초안은 새 native 편집 입력입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-shared-limit-v2.py').read_text().replace('shared-limit-v2',tag)
text=text.replace("prefix=[sys.executable,'-X','utf8']", "exec((r/'build/translate-connected-module-step.py').read_text(encoding='utf-8'))\nprefix=[sys.executable,'-X','utf8']")
(r/'build/after-virtual-connected-scope.py').write_text(text,encoding='utf-8')
helper=(r/'build/translate-final-procedure.py').read_text().replace('initial-reproduction','connected-scope')
helper=helper.replace("assert [n for n,_ in numbered]==list(range(1,14))", "assert [n for n,_ in numbered]==list(range(1,14))\nnumbered=[row for row in numbered if row[0]==2]")
helper=helper.replace("'minItems':13,'maxItems':13", "'minItems':1,'maxItems':1").replace('assert len(values)==13','assert len(values)==1')
helper=helper.replace('Translate these thirteen Korean reproduction instructions','Translate this single Korean module-preparation instruction').replace('thirteen strings in source order','one string in source order').replace('all thirteen reproduction instructions','the changed module-preparation instruction')
(r/'build/translate-connected-module-step.py').write_text(helper,encoding='utf-8')
