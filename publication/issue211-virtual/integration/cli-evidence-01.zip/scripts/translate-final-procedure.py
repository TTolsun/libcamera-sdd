from sdd.translation import _validate_text
from sdd.document_metadata import split_frontmatter
from sdd.runtime_evidence import sha256
import html,re
p=d/'run/english.json';catalog=json.loads(p.read_bytes());before=p.read_bytes()
meta,_=split_frontmatter((d/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
def normalized(value):
 value=re.sub(r'`([^`]+)`',r'\1',value)
 return re.sub(r'\s+',' ',html.unescape(value)).strip()
numbered=[]
for row in meta['generated_design']['answers']['reproduce']:
 if match:=re.match(r'^(\d+)\.\s+(.+)',row['text'],re.S):numbered.append((int(match[1]),match[2]))
assert [n for n,_ in numbered]==list(range(1,14))
sources=[]
for n,text in numbered:
 keys=[key for key in catalog['strings'] if any(normalized(ctx['resolved_source'])==normalized(text) for ctx in catalog['translation_contexts'].get(key,[]))]
 assert len(keys)==1,(n,text,keys)
 sources.append(keys[0])
system='Translate these thirteen Korean reproduction instructions into concise imperative English. Begin each action with a verb. Preserve every prerequisite, condition, source scope and opaque {{number}} token with exact counts. These are instructions for a future fresh execution, never claims it already happened. The --capture=3 check requires this actual value and, when using the helper, actual pass-through to cam; asking whether without requiring the value is insufficient. Preserve all preceding preflight checks as the start condition. Preserve distinct YAML size and pattern values. Return only JSON translations: thirteen strings in source order, without step numbers, new facts or repeated warnings.'
schema={'type':'object','additionalProperties':False,'required':['translations'],'properties':{'translations':{'type':'array','items':{'type':'string'},'minItems':13,'maxItems':13}}}
payload=dict(sources=sources,read_only_context={k:catalog['translation_contexts'].get(k,[]) for k in sources})
native=Agent(cfg.agent,w/'build/initial-reproduction-procedure-translation-prompts')
raw=native.chat(system,json.dumps(payload,ensure_ascii=False),tag='imperative-procedure',response_schema=schema)
values=json.loads(re.sub(r'^```(?:json)?\s*|\s*```$','',raw.strip()))['translations'];assert len(values)==13
for source,value in zip(sources,values):catalog['strings'][source]=_validate_text(source,value)
(d/'english-before-initial-reproduction-imperative.json').write_bytes(before)
p.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(w/'build/initial-reproduction-procedure-translation-prompts/selection.json').write_text(json.dumps(dict(sources=sources,catalog_sha256=sha256(p),scope='Fresh native Claude CLI translation of all thirteen reproduction instructions; other catalogue values preserved'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
