from pathlib import Path
import shutil,yaml
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration'
b=w/'before-shared-limit-v2/config';b.mkdir(parents=True);shutil.copyfile(w/'config/sections.yaml',b/'sections.yaml')
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());part=next(p for s in x['sections'] if s['id']=='official-cam-validation' for t in s['design_topics'] if t['id']=='flow' for p in t['parts'] if p['id']=='submission-limit')
 assert part['sources']==['submission-limit'];part['sources'].append('callback-and-processing')
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
p=r/'build/after-virtual-shared-limit.py';p.with_name('after-virtual-shared-limit-v2.py').write_text(p.read_text().replace('shared-limit','shared-limit-v2'),encoding='utf-8')
