from pathlib import Path
import yaml,shutil
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-main-integration'
b=w/'before-reader-order';b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml']:
 dest=b/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,dest)
def revise(t):
 if t['id']=='virtual-principle':
  p=next(p for p in t['parts'] if p['id']=='purpose');p['sources']=[s['id'] for s in t['sources']]
  p['question']='그림 바로 앞에 놓이는 이 첫 문단에서, 고정한 libcamera 소스를 분석해 설명하는 구현 흐름임을 분명히 하세요. 선택된 Virtual2가 센서 대신 400x300 lines 줄무늬 패턴을 공급한다는 개요와, cam의 실제 DMA-BUF 확보·버퍼가 붙은 요청 제출 → CPU의 NV12 패턴 쓰기 시도 → 버퍼·요청 완료 조건을 거친 cam 통지라는 핵심 흐름을 쉬운 말로 세 짧은 문장 이내로 설명하세요. 상세 분기와 예외는 그림 뒤 항목이 설명하므로 이 문단에는 함수·클래스 이름, 관측한 내부 실행이라는 단정, 다른 영상 입력 옵션이나 경고 목록을 추가하지 않습니다.'
  p['prompt']='질문에 필요한 핵심 소스 흐름을 먼저 짧게 설명하세요. 해시·PID·TID·JSON 키와 긴 코드 식별자는 근거에 둡니다. 소스의 처리 조건을 성공 보장으로 바꾸지 않습니다.'
  p=next(p for p in t['parts'] if p['id']=='buffer');p['question']='그림 뒤의 이 항목은 CPU 접근 조건만 설명하세요. 소스의 패턴 생성기는 쓰기 방향 동기화 범위 안에서 버퍼를 쓰기용으로 매핑하고, CPU가 패턴을 NV12로 변환하여 매핑된 버퍼에 쓰기를 시도한다는 두 동작을 두 짧은 문장 이내로 씁니다. 앞 요약의 전체 흐름을 반복하거나 함수·클래스 이름과 범위 경고를 나열하지 않습니다.'
 if t['id']=='flow':
  p=next(p for p in t['parts'] if p['id']=='reuse-request');p['question']='기록된 명령에서 화면·파일 출력 옵션을 요청하지 않은 조건을 적용한 소스 분석임을 문장 앞에서 밝히세요. 그 조건에서는 처리를 계속할 요청의 버퍼를 Request::ReuseBuffers로 유지해 재사용하고 CameraSession::queueRequest 도우미를 호출하며, 실제 제출은 별도 한도 검사에 따른다는 관계만 두 짧은 문장 이내로 설명합니다. 조건을 한 번만 쓰고 바로 동작을 설명하세요.'
  p['prompt']='소스 분석이라는 주체와 출력 옵션 조건을 한 번 밝힌 뒤 재사용·도우미 호출·실제 제출의 조건을 간결하게 설명하세요. 기록된 실행에서 이 내부 호출을 직접 관측했다고 쓰지 않습니다. 이전 오역이나 다른 해석을 부정하는 대비 문장은 작성하지 않습니다.'
  p['answer_contract'].setdefault('reject_patterns',[]).append({'pattern':'아니라|뜻이 아니|의미가 아니','message':'State the actual source condition directly instead of repeating a contrast with an earlier mistranslation.'})
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(t for t in x['sections'] if t['id']=='official-cam-validation')
 for t in s['design_topics']:revise(t)
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
for name in ['examples/libcamera/validation/issue211-reader/section.yaml','examples/libcamera/validation/issue211-virtual/topic.yaml']:
 p=g/name;x=yaml.safe_load(p.read_bytes())
 if 'design_topics' in x:
  for t in x['design_topics']:revise(t)
 else:revise(x)
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
s=(r/'build/after-virtual-notification-scope.py').read_text().replace('notification-scope','reader-order');(r/'build/after-virtual-reader-order.py').write_text(s)
