from pathlib import Path
import sys
from sdd.runtime_evidence import run_recorded,require_success
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual'
require_success(w/'executions/generate-preflight-limit-buffer-check')
def run(name,args):
 out=w/'executions'/name;run_recorded(out,[sys.executable,'-X','utf8']+args,timeout=1800,cwd=r);require_success(out);print(name,'PASS',flush=True)
run('update-current-page-translation-v19',[str(r/'build/update-reviewed-page-translation.py'),'v19','generate-preflight-limit-buffer-check'])
run('latest-contract-native-refresh-preflight-buffer',[str(r/'build/refresh-latest-contract-audit.py'),'-preflight-buffer'])
run('finalize-preflight-buffer-v19',[str(r/'build/finalize-native-page.py'),'latest-main-final-v19','update-current-page-translation-v19','latest-main-final-v18'])
