from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='scope-labels'
b=w/('before-'+tag);b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='virtual-frame-path':
   edit='n0와 n3의 한영 라벨만 수정합니다. n0는 실제 DMA-BUF 확보를 시도하는 소스 경로입니다. n3는 패턴 생성기가 CPU 쓰기 동기화 범위 안에서 버퍼의 쓰기용 매핑을 시도합니다. 두 시도 모두 실패할 수 있으므로 시도 동사를 넣습니다. 관측된 할당 성공은 앞의 실행 결과이고 이 그림은 구현 분석입니다. 나머지 올바른 라벨과 모든 분기·인용·구조는 그대로 보존합니다. '
   v['answer_contract'].setdefault('reject_patterns',[]).append(dict(pattern=r'버퍼를\s*확보합니다|매핑합니다',message='Allocation and mapping labels describe attempts, not guaranteed success. Use Korean attempt verbs for n0/n3.'))
   v['answer_contract_en'].setdefault('reject_patterns',[]).append(dict(pattern=r'\bobtains\b|\bmaps\b',message='Describe n0 allocation and n3 mapping as attempts: attempts to allocate/map, not unconditional obtains/maps.'))
  elif v['id']=='request-completion-order':
   edit='한영 화면 라벨에서 구현 변수와 내부 호출 이름을 제거하고 쉬운 동작만 짧게 씁니다. source symbol·quote_ids와 실제 분기·반복 구조는 그대로 보존합니다. n0 버퍼 완료 수신, n1 해당 요청의 모든 버퍼 완료 여부, n2 그 요청의 남은 FrameBuffer 완료 대기, n3 해당 요청 완료 표시, n4 제출 큐에 요청이 남았는지, n5 맨 앞 요청이 아직 Pending인지, n6 완료된 맨 앞 요청을 cam에 제출 순서대로 통지, n7 이어 대기 요청 처리라는 의미입니다. 화면에 queuedRequests_, doQueueRequests, complete(), 호출 순서 제약 없음 같은 내부 세부를 쓰지 마세요. 큐 반복 화살표와 모든 조건은 유지하며, 라벨에서만 구현 세부를 줄입니다. '
   for key in ['answer_contract','answer_contract_en']:v[key].setdefault('reject_patterns',[]).append(dict(pattern=r'::|queuedRequests_|doQueueRequests|complete\(\)|call order|호출 순서',message='Keep implementation variable, qualified function and internal call-order detail in evidence. Use short actions/questions in labels; preserve all symbols, guards and graph structure.'))
  elif v['id']=='reproduction-flow':
   edit='host_approval 노드의 한영 라벨만 수정합니다. 승인 시점이 호스트 변경 실행 직전임을 한영 모두 명시합니다. 영어에는 immediately before라는 시점이 필요합니다. 별도 호스트 승인이라는 범위와 실행 직전이라는 시점만 짧게 쓰고 PR·Docker 경고를 이 노드에서 반복하지 않습니다. 다른 모든 노드와 간선, 필요한 승인·Docker·부팅·불일치·새 증거 조건을 그대로 보존합니다. '
   v['answer_contract_en']['required_terms'].append(['immediately'])
  else:continue
  v['prompt']=edit+'간선 한영 20자 한도와 연결된 실제 분기를 유지합니다. 아래 초안은 실제 새 CLI 응답의 편집 입력이며 저장 응답 재생이 아닙니다. 참고 초안: '+json.dumps(m['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
(r/'build/after-virtual-scope-labels.py').write_text((r/'build/after-virtual-bound-preflight.py').read_text().replace('bound-preflight',tag),encoding='utf-8')
