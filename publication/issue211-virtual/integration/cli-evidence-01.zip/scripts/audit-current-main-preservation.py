from pathlib import Path
import subprocess,json,re
from sdd.runtime_evidence import sha256
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.render_profiles import for_page
from sdd.scenario_sections import refresh_encoded_appendix,_same_encoded_overview
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';repo=r/'build/libcamera-sdd-issue211';site=repo/'docs'
base=subprocess.check_output(['git','rev-parse','origin/main'],cwd=repo,text=True).strip();assert base=='7d824a9753721edd86a4b509a979230033532f9c'
cfg=load(d/'publication.yaml');model=KnowledgeModel.load(cfg.facts_path);sections={s.get('output',s['id']+'.md'):s for s in cfg.sections()};snapshots=json.loads((w/'previous-scenario-appendices.json').read_bytes())
identical=[];refreshed=[];revalidated=[]
revalidation=json.loads((w/'citation-binding-revalidation-bb03350/report.json').read_bytes())
for p in sorted((d/'run/manuscripts').rglob('*.md')):
 rel=p.relative_to(d/'run/manuscripts').as_posix()
 if rel=='official-cam-validation.md':continue
 old=subprocess.check_output(['git','show',base+':publication/submission-diagnosis/manuscripts/'+rel],cwd=repo)
 current=p.read_bytes()
 validation=next((x for x in revalidation['records'] if x['path']==rel),None)
 if validation:
  assert validation['after_sha256']==sha256(p) and validation['body_unchanged'] and not validation['new_inference']
  prior=w/'citation-binding-revalidation-bb03350'/rel
  assert validation['before_sha256']==sha256(prior)
  current=prior.read_bytes();revalidated.append({'path':rel,'report':'citation-binding-revalidation-bb03350/report.json','new_inference':False,'body_unchanged':True})
 if current==old:identical.append(rel);continue
 section=sections[rel];assert section.get('scenario'),rel
 expected=refresh_encoded_appendix(for_page(cfg,rel),model,section,old.decode('utf-8'),snapshots[section['id']])
 assert current.decode('utf-8')==expected,rel
 refreshed.append({'path':rel,'sha256':sha256(p),'change':'Proven generator-owned Mermaid encoding refresh; original native prose and review state retained'})
manifest=json.loads((site/'site-manifest.json').read_bytes());diagrams=[]
for rel in manifest['outputs']:
 if not rel.endswith('.mmd') or 'official-cam-validation' in rel:continue
 old=subprocess.check_output(['git','show',base+':docs/'+rel],cwd=repo).decode('utf-8');new=(site/rel).read_text(encoding='utf-8')
 norm=lambda text:re.sub(r'<br/>|\s+','',text)
 encoded=_same_encoded_overview('```mermaid\n'+norm(old)+'\n```','```mermaid\n'+norm(new)+'\n```')
 diagrams.append({'path':rel,'sha256':sha256(site/rel),'byte_identical':old.encode()==(site/rel).read_bytes(),'literal_encoding_and_reflow_only':encoded})
record={'schema':2,'public_base':base,'unchanged_manuscripts':identical,'verified_encoding_refreshes':refreshed,'diagrams':diagrams,'current_generator_main':subprocess.check_output(['git','rev-parse','origin/main'],cwd=r/'build/generator-reader-release',text=True).strip(),'presentation':'Current main layout and literal-label fixes intentionally apply; unchanged HTML bytes are not claimed.','english':'Legacy unproven translations are retranslated with native Claude and independently grounded; see separate records.','scope':'Original native Korean manuscripts retained, apart from proven encoding-only managed appendices. No whole-site issue215 semantic acceptance or human approval is claimed.','human_review':'pending'}
assert len(identical)+len(refreshed)==28
record['recorded_citation_revalidations']=revalidated
(w/'current-main-preservation.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print('Preserved native manuscript bodies',len(identical),'encoding-only',len(refreshed),'citation revalidation',len(revalidated),'diagram records',len(diagrams))
