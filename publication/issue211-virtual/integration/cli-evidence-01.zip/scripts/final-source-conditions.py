from pathlib import Path
import yaml,json,shutil
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-main-integration'
yaml_record=next(s for s in yaml.safe_load((g/'examples/libcamera/validation/issue211-virtual/topic.yaml').read_bytes())['sources'] if s['id']=='virtual2-config')
b=w/'before-source-conditions';b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 dest=b/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,dest)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'));ref=m['generated_visuals']['records']['virtual-frame-path']['draft']
def revise(t):
 if t['id']=='flow':
  p=next(p for p in t['parts'] if p['id']=='reuse-request');p['question']='記録'.replace('記録','기록된 명령의 출력 옵션 미선택 조건을 적용한 소스 분석이라고 먼저 밝히세요. 이 조건에서 캡처 한도가 미설정이거나 처리 수가 한도에 미도달하면 Request::ReuseBuffers로 버퍼를 유지해 재사용하고 CameraSession::queueRequest 도우미를 호출하며, 실제 제출은 도우미의 별도 한도 검사에 따른다는 관계를 두 짧은 문장으로 쓰세요. 미설정 OR 미도달을 둘 다 명시하고 한도가 설정된 경우만으로 축소하지 않습니다. 직접 관측했다고 주장하거나 이전 오역을 부정하는 대비 문장은 추가하지 않습니다.')
  p['answer_contract'].setdefault('required_terms',[]).extend([['미설정','설정되지'],['미도달','도달하지','아래','적으면']])
 if t['id']=='reproduce':
  if not any(s['id']=='virtual2-config' for s in t['sources']):t['sources'].append(dict(yaml_record))
  p=next(p for p in t['parts'] if p['id']=='request-check');p['sources']=['virtual2-config'];p['question']="statement.text를 '8. '로 시작하세요. Virtual2 YAML은 400x300 해상도와 lines 줄무늬 패턴을 정하고, cam 명령은 Virtual2를 선택하며 스트림 인자로 400x300 NV12를 요청한다는 두 입력의 서로 다른 역할을 확인하는 행동을 설명하세요. YAML 자체가 NV12를 요청한다고 쓰지 마세요. 앞의 커널·접근·입력 조건 중 하나라도 다르면 실행을 중단하는 조건은 한 번만 남깁니다. 실제 적용 설정과 완료 결과는 실행 뒤 단계에서 확인합니다."
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(t for t in x['sections'] if t['id']=='official-cam-validation')
 for t in s['design_topics']:revise(t)
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes());v=next(t for t in x['sections']['official-cam-validation'] if t['id']=='virtual-frame-path')
 v['prompt']=v['prompt'].split(' 現在')[0].split(' 현재 초안은 나머지 의미와 가독성 검토를 통과했습니다.')[0]
 v['prompt']+=' 최종 통지 분기 의미 수정: 아래 12개 노드의 ID·shape와 n10 외 노드 라벨·인용, 모든 간선의 from·to·condition_ref·quote_ids를 보존합니다. n10은 함수·핸들러 종료를 뜻하지 않는 통지 경계 상태로 바꿉니다. n7→n10은 버퍼가 아직 미완료여서 이 경로가 즉시 cam 통지로 가지 않는 상태이고, n11→n10은 큐 선두 Pending과 그 뒤 요청들의 통지가 보류된 상태입니다. 같은 completeRequest 호출에서 앞의 완료 요청을 이미 통지했을 수 있고, Pending에서 통지 반복을 멈춘 뒤에도 doQueueRequests 같은 남은 작업은 계속됩니다. 따라서 n10에 ends, returns, finishes, call ends, 호출 마침, 반환, 핸들러 종료라는 표현을 쓰지 말고 이 분기에서 직접 cam 통지로 진행하지 않는다는 공통 상태만 짧게 표시하세요. n10은 현재 통지 판정의 경계이지 전체 함수의 제어 흐름 종료가 아닙니다. 필요하면 n10 인용에 pipeline-completion의 Pending break 구절과 virtual-completion 선언·검사 구절을 함께 추가하여 두 경로를 뒷받침합니다. n11→n10 라벨은 Pending 요청과 그 뒤 요청의 통지 보류라는 의미로 유지합니다. 기존의 다른 올바른 라벨·분기·가독성은 바꾸지 마세요. 참고 초안은 편집 입력이며 실제 새 native 응답이 검사를 통과해야 합니다. 참고 초안: '+json.dumps(ref,ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
p=g/'examples/libcamera/validation/issue211-reader/section.yaml';x=yaml.safe_load(p.read_bytes())
for t in x['design_topics']:revise(t)
p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
p=g/'examples/libcamera/validation/issue211-virtual/visual.yaml';x=yaml.safe_load(p.read_bytes());x['prompt']+=' 통지 보류는 함수 종료가 아닙니다. n10은 두 분기에서 직접 cam 통지로 진행하지 않는다는 통지 경계 상태로 표시하고 함수·핸들러의 ends/returns/finishes/종료/반환으로 쓰지 않습니다. Pending을 만나 통지 반복이 멈춰도 completeRequest의 doQueueRequests 같은 남은 작업은 계속되며, 같은 호출에서 앞의 완료 요청을 이미 통지했을 수 있습니다. 필요하면 n10 인용에 virtual-completion 선언·검사와 pipeline-completion의 Pending break를 함께 포함합니다.';p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
s=(r/'build/after-virtual-reader-order-v2.py').read_text().replace('reader-order-v2','source-conditions-v2');(r/'build/after-virtual-source-conditions-v2.py').write_text(s)
