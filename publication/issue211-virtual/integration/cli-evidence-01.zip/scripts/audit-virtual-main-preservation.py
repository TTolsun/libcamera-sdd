from pathlib import Path
from html.parser import HTMLParser
import subprocess,json,re,html as html_module
from sdd.runtime_evidence import sha256
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';repo=r/'build/libcamera-sdd-issue211';site=repo/'docs'
tree=subprocess.check_output(['git','ls-tree','-r','origin/main','--','docs','publication/submission-diagnosis/manuscripts'],cwd=repo,text=True)
objects=[line.split('\t',1) for line in tree.splitlines()]
raw=subprocess.check_output(['git','cat-file','--batch'],input=('\n'.join(row[0].split()[2] for row in objects)+'\n').encode(),cwd=repo)
cache={};offset=0
for header,path in objects:
 end=raw.index(b'\n',offset);size=int(raw[offset:end].split()[-1]);cache[path]=raw[end+1:end+1+size];offset=end+size+2
def prior(path):return cache[path]
base=subprocess.check_output(['git','rev-parse','origin/main'],cwd=repo,text=True).strip();assert base=='7d824a9753721edd86a4b509a979230033532f9c',base
class Visible(HTMLParser):
 def __init__(self):super().__init__();self.article=False;self.fold=0;self.pre=False;self.text=[]
 def handle_starttag(self,t,a):
  if t=='article':self.article=True
  if self.article and t=='details':self.fold+=1
  if self.article and t=='pre':self.pre=True
 def handle_endtag(self,t):
  if self.article and t=='details':self.fold-=1
  if t=='pre':self.pre=False
  if t=='article':self.article=False
 def handle_data(self,s):
  if self.article and not self.fold and not self.pre:self.text.append(s)
def visible(data):
 p=Visible();p.feed(data.decode('utf-8'));return re.sub(r'\s+',' ',''.join(p.text)).strip()
manuscripts=[]
for p in sorted((d/'run/manuscripts').rglob('*.md')):
 rel=p.relative_to(d/'run/manuscripts').as_posix()
 if rel=='official-cam-validation.md':continue
 assert p.read_bytes()==prior('publication/submission-diagnosis/manuscripts/'+rel),rel
 manuscripts.append(rel)
manifest=json.loads((site/'site-manifest.json').read_bytes());html=[];diagrams=[];reflowed=[]
for rel in manifest['outputs']:
 if 'official-cam-validation' in rel:continue
 if rel.endswith('.mmd'):
  before=prior('docs/'+rel);after=(site/rel).read_bytes()
  if after!=before:
   normalize=lambda value:re.sub(r'<br/>|\s+','',html_module.unescape(value.decode('utf-8')))
   assert normalize(before)==normalize(after),rel
   reflowed.append(dict(path=rel,new_sha256=sha256(site/rel),reason='Qualified code identifiers remain intact; all non-whitespace diagram characters are identical'))
  else:diagrams.append(rel)
 if rel.endswith('.html'):
  assert visible((site/rel).read_bytes())==visible(prior('docs/'+rel)),rel;html.append(rel)
for rel in ['assets/reading.css','assets/site.js','assets/reader-tools.js']:
 assert (site/rel).read_bytes()==prior('docs/'+rel),rel
result=dict(schema=1,public_base=base,unchanged_other_manuscripts=manuscripts,unchanged_other_visible_article_text=html,unchanged_other_mermaid_files=diagrams,reflowed_other_mermaid_files=reflowed,latest_presentation_assets_preserved=True,scope='Exact prior manuscript bytes; visible article text excludes folded evidence and raw Mermaid. Other diagrams are byte-identical or differ only by whitespace and line breaks with qualified identifiers preserved. No whole-site new LLM approval.',human_review='pending')
(w/'current-main-preservation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(dict(manuscripts=len(manuscripts),html=len(html),diagrams=len(diagrams),reflowed=len(reflowed)))
