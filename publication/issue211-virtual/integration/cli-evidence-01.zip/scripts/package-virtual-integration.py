from pathlib import Path
import json,shutil,gzip,zipfile,subprocess,sys
from sdd.runtime_evidence import sha256
from sdd.site_build import verify_site
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';repo=r/'build/libcamera-sdd-issue211';site=repo/'docs';p=repo/'publication/issue211-virtual';tag=sys.argv[1]
review=json.loads((w/'reviews'/tag/'review.json').read_bytes());assert review['review']['verdict']=='pass' and not review['review']['findings']
assert review['document_sha256']==sha256(d/'run/manuscripts/official-cam-validation.md')
assert review['inventory_sha256']==sha256(w/'windows'/tag/'inventory.json')
inv=json.loads((w/'windows'/tag/'inventory.json').read_bytes());manifest=json.loads((site/'site-manifest.json').read_bytes());valid=verify_site(site)
for lang,rel in [('ko','official-cam-validation.html'),('en','en/official-cam-validation.html')]:assert inv[lang]['html_sha256']==sha256(site/rel)
merge=json.loads((w/'generator-sink-merge.json').read_bytes());assert merge['merged']
recipe_merge=json.loads((w/'reader-recipe-merge.json').read_bytes());assert recipe_merge['merged']
assert json.loads((w/'native-call-verification-integrated.json').read_bytes())['new_completed_call_records']
config_review=json.loads((w/'reviews/config-edge-v3/review.json').read_bytes())
assert config_review['review']['verdict']=='pass' and not config_review['review']['findings']
assert sha256(r/'build/generator-main-integration/src/sdd/generated_visuals.py')=='b7ce0a54551f35d6c950d1be0b8726356e9a82d32723b98f91515645368a1969'
guard_review=json.loads((w/'reviews/config-guard-branches-v2/review.json').read_bytes())
assert guard_review['review']['verdict']=='pass' and not guard_review['review']['findings']
current_config=json.loads((w/'reviews/current-config-fragments-bb03350/review.json').read_bytes())
assert current_config['review']['verdict']=='pass' and not current_config['review']['findings']
for rel,digest in current_config['implementation'].items():assert sha256(r/'build/generator-reader-release'/rel)==digest
assert json.loads((w/'current-page-translation-acceptance.json').read_bytes())['catalog_sha256']==sha256(d/'run/english.json')
extra=p/'integration';extra.mkdir(exist_ok=False)
shutil.copytree(w/'citation-binding-revalidation-bb03350',extra/'citation-binding-revalidation')
for name in ['latest-catalog-repair-v1.json','latest-catalog-unit-acceptance.json','latest-catalog-authentication.json','current-page-translation-acceptance.json','latest-contract-audit.json','latest-contract-native-units.json','dependent-stage-cancellation.json','phase-heading-native-findings.json','single-stream-native-findings.json','heading-subject-native-findings.json']:
 shutil.copyfile(w/name,extra/name)
for name in ['run.json','generation-receipts.json','english.json','facts293.json.gz','evidence-index.json']:
 shutil.copyfile(p/name,extra/('prior-'+name))
shutil.copyfile(p/'README.md',extra/'prior-README.md')
upstream_review=json.loads((w/'reviews/final-upstream-notes-v3/review.json').read_bytes())
assert upstream_review['review']['verdict']=='pass' and not upstream_review['review']['findings']
assert upstream_review['bindings']['notes_sha256']==sha256(w/'notes-final-upstream-v3/README.md')
assert upstream_review['bindings']['upstream_record_sha256']==sha256(w/'upstream-final-sync.json')
shutil.copytree(w/'notes-final-upstream-v3',extra/'upstream-notes')
shutil.copytree(w/'reviews/final-upstream-notes-v3',extra/'upstream-notes-review')
shutil.copyfile(w/'upstream-final-sync.json',extra/'upstream-final-sync.json')
shutil.copyfile(w/'notes-final-upstream-v3/README.md',p/'README.md')
(extra/'parent-root').mkdir()
for name in ['README.md','run.json','generation-receipts.json']:(extra/'parent-root'/name).write_bytes(subprocess.check_output(['git','show','origin/main:'+name],cwd=repo))
for src,dst in [('config','config'),('run/manuscripts','manuscripts')]:shutil.copytree(d/src,extra/dst)
for name in ['historical-style','current-style','reader-preserved-style','templates']:shutil.copytree(d/name,extra/name)
report_index=[]
import yaml
for row in yaml.safe_load((d/'publication.yaml').read_bytes())['publication']['reports']:
 source=Path(row['path']);target=extra/'inherited-reports'/source.name;target.parent.mkdir(exist_ok=True)
 assert sha256(source)==row['sha256'];shutil.copyfile(source,target)
 report_index.append(dict(path=target.relative_to(extra).as_posix(),sha256=row['sha256'],original_bindings=row.get('bindings'),scope='Inherited public submission-diagnosis report; not a newly executed check'))
(extra/'inherited-report-index.json').write_text(json.dumps(report_index,indent=2)+'\n',encoding='utf-8')
(extra/'profiles').mkdir()
for item in d.glob('*.yaml'):shutil.copyfile(item,extra/'profiles'/item.name)
for name in ['generation.yaml','new-document-review.yaml','reader-verification.yaml']:shutil.copyfile(w/name,extra/'profiles'/('selected-'+name))
shutil.copyfile(d/'site-intro.md',extra/'site-intro.md');shutil.copyfile(d/'run/english.json',extra/'english.json')
(extra/'facts293.json.gz').write_bytes(gzip.compress((d/'run/facts/facts.json').read_bytes(),mtime=0))
for name in ['integration-inputs.json']:
 shutil.copyfile(d/name,extra/name)
for name in ['native-call-verification-integrated.json','generator-sink-merge.json','reader-recipe-merge.json','reader-recipe-final-ci.json','ui-verification-integrated.json','current-main-preservation.json','topic-visual-review.json','integration-preflight-failures.json','native-fragment-formatting-repair.json','current-scenario-encoding-refresh.json','official-reader-contract-revisions.json','latest-translation-migration-inventory.json','latest-catalog-translation-v3.json','integration-attempts.json','final-recipe-preparation.json','latest-public-base.json','latest-format-base-review.json','superseded-ci-cancellation.json','source230-ci.json','source230-final-ci.json','source230-accepted-ci.json','source230-release-ci.json','source230-merged-ci.json','repeated-final-export.json']:
 shutil.copyfile(w/name,extra/name)
shutil.copytree(w/'reviews'/tag,p/'reviews'/tag);shutil.copytree(w/'windows'/tag,extra/'rendered-review-window')
shutil.copytree(w/'reviews/config-edge-v3',extra/'configuration-review')
shutil.copyfile(w/'config-edge-documentation-v3/config-reference.md',extra/'configuration-fragment.md')
shutil.copytree(w/'reviews/config-guard-branches-v2',extra/'configuration-guard-branch-review')
shutil.copytree(w/'reviews/current-config-fragments-bb03350',extra/'current-configuration-grounding')
shutil.copyfile(w/'config-guard-branch-documentation-v2/config-reference.md',extra/'configuration-guard-branch-fragment.md')
(p/'reviews/acceptance.json').write_text(json.dumps(dict(accepted=tag+'/review.json',supersedes='counter-signal-final/review.json',rule='Only the final integrated bilingual review bound to identical published HTML hashes accepts this deployment; prior drafts/reviews remain historical',human_review='pending'),indent=2)+'\n',encoding='utf-8')
oldindex=json.loads((p/'archive-index.json').read_bytes());entries={};sources=[]
for parent in [d/'build/prompts',d/'build/cli-checkpoints',*w.glob('current-page-translation-v[0-9]*'),*w.glob('current-base-runbook*'),w/'latest-catalog-translation-v3',w/'latest-catalog-repair-v1',w/'build',w/'executions',w/'windows',w/'reviews',*w.glob('before-*'),*w.glob('notes-*'),*w.glob('config-edge-documentation*'),*w.glob('config-guard-branch-documentation*')]:
 for item in parent.rglob('*'):
  if not item.is_file() or any(x.startswith('call-') for x in item.parts[:-1]):continue
  name='workspace/'+item.relative_to(w).as_posix()
  if oldindex.get(name)==sha256(item):continue
  sources.append((item,name))
for name in ['integrate-virtual-current-main.py','translate-virtual-integration.py','finish-virtual-integration.py','verify-virtual-integrated-calls.py','after-virtual-sink.py','package-virtual-integration.py','after-virtual-sink-path.py','audit-virtual-main-preservation.py','revise-concise-virtual.py','after-virtual-concise-v2.py','revise-final-actions.py','after-virtual-final-actions.py','revise-flow-ownership.py','after-virtual-ownership.py','scope-recorded-cam.py','after-virtual-recorded-scope.py','after-virtual-recorded-scope-v2.py','revise-edge-clarity.py','refine-reuse-scope.py','after-virtual-edge-clarity.py','after-virtual-edge-clarity-v2.py','after-virtual-edge-clarity-v3.py','write-edge-config.py','write-edge-config-v2.py','write-edge-config-v3.py','finalize-virtual-clarity.py','after-virtual-final-clarity.py','integrate-new-public-main.py','after-virtual-final-integrated.py','make-virtual-topic-audit.py','verify-package-issue211-virtual.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['after-virtual-final-scope.py','after-virtual-final-reader.py','after-virtual-final-rendered.py','precise-virtual-prose.py','after-virtual-precise-flow.py','final-virtual-actors.py','after-virtual-final-actors.py','after-virtual-final-actors-v2.py','fix-virtual-notification-boundary.py','after-virtual-notification-boundary.py','clarify-virtual-labels.py','after-virtual-reader-labels.py','merge-latest-public-after-review.py','fix-queue-prefix-wording.py','after-virtual-queue-prefix.py','condense-callback-explanation.py','after-virtual-concise-callback.py','final-readable-virtual.py','after-virtual-final-readable.py','fix-notification-scope.py','after-virtual-notification-scope.py','final-reader-order.py','after-virtual-reader-order.py','after-virtual-reader-order-v2.py','final-source-conditions.py','after-virtual-source-conditions-v2.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['after-virtual-positive-preflight.py','split-virtual-completion.py','after-virtual-split-completion.py','refine-reproduction-steps.py','after-virtual-distinct-preflight.py']:
 sources.append((r/'build'/name,'scripts/'+name))
sources.append((r/'build/after-virtual-bound-preflight.py','scripts/after-virtual-bound-preflight.py'))
for name in ['final-virtual-wording.py','after-virtual-final-wording.py','after-virtual-final-wording-v2.py','final-virtual-reader-copy.py','after-virtual-reader-copy.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['tighten-virtual-reader.py','translate-virtual-procedure.py','after-virtual-short-labels.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['refine-virtual-last-findings.py','after-virtual-last-findings.py','after-virtual-last-findings-v2.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-virtual-scope-labels.py','after-virtual-scope-labels.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['fix-virtual-authored-label-scope.py','audit-virtual-authored-label-scope.py','after-virtual-scope-labels-v2.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-virtual-allocation-gate.py','after-virtual-allocation-gate.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['connect-virtual-reader-figures.py','after-virtual-connected-reader.py','prepare-final-reader-recipe.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['clarify-virtual-config-scope.py','after-virtual-configuration-scope.py','after-virtual-configuration-scope-v2.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['readable-virtual-actions.py','after-virtual-readable-actions.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-virtual-buffer-attachment.py','after-virtual-buffer-attachment.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['complete-virtual-observed-path.py','after-virtual-queued-execution.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['condense-virtual-completion.py','after-virtual-completion-overview.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['strict-virtual-branches.py','after-virtual-strict-branches.py','after-virtual-strict-branches-v2.py','write-guard-branch-config.py','write-guard-branch-config-v2.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['qualify-actual-camera-queue.py','after-virtual-actual-queue.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['split-virtual-preparation.py','after-virtual-separate-preparation.py','after-virtual-separate-preparation-v2.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-initial-reproduction.py','after-virtual-initial-reproduction.py','after-virtual-initial-reproduction-v2.py','after-virtual-initial-reproduction-v3.py','translate-final-procedure.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-reader-actors.py','after-virtual-reader-actors.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-allocation-outcome.py','after-virtual-allocation-outcome.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-concise-outcome.py','after-virtual-concise-outcome.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-shared-limit.py','after-virtual-shared-limit.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['fix-shared-limit-evidence.py','after-virtual-shared-limit-v2.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-connected-scope.py','after-virtual-connected-scope.py','translate-connected-module-step.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-start-gate.py','after-virtual-start-gate.py','update-latest-public-base.py','resume-latest-public-base.py','record-format-base.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-camera-start-label.py','after-virtual-camera-start-label.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-preflight-groups.py','after-virtual-preflight-groups.py','translate-preflight-choice-steps.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['fix-preflight-symbol.py','after-virtual-preflight-groups-v2.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-phase-blocks.py','after-virtual-phase-blocks.py','translate-phase-procedure.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-ordered-prefix.py','after-virtual-ordered-prefix.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-signal-wording.py','after-virtual-signal-wording.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-queue-error.py','after-virtual-queue-error.py']:
 sources.append((r/'build'/name,'scripts/'+name))
sources.append((r/'build/finish-accepted-virtual-proof.py','scripts/finish-accepted-virtual-proof.py'))
sources.append((r/'build/record-final-ui-scope.py','scripts/record-final-ui-scope.py'))
sources.append((r/'build/validate-final-libcamera-recipe.py','scripts/validate-final-libcamera-recipe.py'))
sources.append((r/'build/index-final-integration-attempts.py','scripts/index-final-integration-attempts.py'))
sources.append((r/'build/review-final-upstream-notes.py','scripts/review-final-upstream-notes.py'))
for name in ['normalize-upstream-note-lines.py','review-final-upstream-notes-v3.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-preparation-order.py','after-virtual-preparation-order.py','revise-final-upstream-notes.py','review-final-upstream-notes-v2.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['fix-execution-directory-contract.py','after-virtual-preparation-order-v2.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-startup-topic.py','after-virtual-startup-topic.py','after-virtual-startup-topic-v3.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-startup-subjects.py','after-virtual-startup-subjects.py','final-split-startup.py','after-virtual-split-startup.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['final-startup-scope.py','after-virtual-startup-scope.py','fix-startup-prose-language.py','after-virtual-startup-korean.py','after-virtual-startup-korean-v2.py','run-latest-catalog-translation-v3.py','audit-current-main-preservation.py','review-current-config-fragments.py','repair-latest-catalog.py','review-latest-catalog.py','verify-latest-catalog-acceptance.py','after-latest-main-native-review.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['refresh-latest-contract-audit.py','review-private-current-page.py','fix-current-main-review-findings.py','update-reviewed-page-translation.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['finalize-native-page.py','fix-final-request-action.py','shorten-final-reader-copy.py','fix-kernel-plan-reference.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['fix-last-reader-boundaries.py','split-api-outcomes.py','fix-scheduled-api-result.py','complete-scheduled-api-v7.py','clarify-final-actors.py','finish-reader-labels.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['src/sdd/visuals.py','src/sdd/generated_visuals.py','tests/test_generated_visuals.py','tests/test_invocation_scope.py','tests/test_visual_label_identifiers.py','docs/reference/config.md','examples/libcamera/validation/issue211-reader/review.py','examples/libcamera/validation/issue211-reader/prepare.py','examples/libcamera/validation/issue211-virtual/invocation_scope.py','examples/libcamera/validation/issue211-virtual/invocation-options.json','examples/libcamera/validation/issue211-reader/section.yaml','examples/libcamera/validation/issue211-virtual/topic.yaml','examples/libcamera/validation/issue211-virtual/retained-visual-overrides.yaml','examples/libcamera/validation/issue211-virtual/visual.yaml']:
 sources.append((r/'build/generator-main-integration'/name,'generator-core-230/'+name))
for name in ['examples/libcamera/validation/issue211-virtual/section.yaml','examples/libcamera/validation/issue211-virtual/prepare.py']:
 sources.append((r/'build/generator-main-integration'/name,'generator-core-230/'+name))
recipe_root=r/'build/generator-reader-release'
for name in ['finish-reader-current-base.py','finalize-current-base-page.py','revalidate-current-native-citations.py','complete-reader-v10.py','fix-current-capture-status-figures.py','finalize-capture-status-page.py','fix-final-state-timing.py','finalize-state-timing-page.py','fix-preflight-limit-and-buffer-check.py','finalize-preflight-buffer-page.py','fix-final-english-instruction.py']:
 sources.append((r/'build'/name,'scripts/'+name))
for name in ['cam_invocation.py','preview_cam.py','run_cam.py','OFFICIAL_CAM.md']:
 rel='examples/libcamera/runtime/'+name;sources.append((recipe_root/rel,'generator-reader-recipe/'+rel))
for rel in ['tests/test_cam_invocation.py','tests/test_official_cam_evidence.py']:
 sources.append((recipe_root/rel,'generator-reader-recipe/'+rel))
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=recipe_root,text=True).strip()==recipe_merge['head_sha']
for name in ['topic.yaml','section.yaml','visual.yaml','retained-visual-overrides.yaml']:
 rel='examples/libcamera/validation/issue211-virtual/'+name
 sources.append((recipe_root/rel,'generator-reader-recipe/'+rel))
for rel in ['src/sdd/translation_repair.py','tests/test_translation_repair.py','src/sdd/scenario_sections.py','tests/test_scenario_encoding_refresh.py','examples/libcamera/validation/issue211-virtual/refresh_appendices.py','examples/libcamera/validation/issue211-virtual/translate_partition.py','src/sdd/product_context.py','tests/test_product_context.py','src/sdd/generated_visuals.py','src/sdd/visuals.py','tests/test_generated_visuals.py','tests/test_visual_label_identifiers.py','docs/reference/config.md','examples/libcamera/validation/issue211-virtual/prepare.py']:
 sources.append((recipe_root/rel,'generator-reader-recipe/'+rel))
(extra/'generator-snapshots.json').write_text(json.dumps(dict(core=merge,core_archive_prefix='generator-core-230',reader_recipe=recipe_merge,reader_recipe_archive_prefix='generator-reader-recipe',published_configuration='integration/config',scope='The core snapshot and later reusable example recipe have separate Git provenance. The actual published execution configuration and native CLI receipts are retained independently.'),indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(extra/'cli-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for item,name in sorted(sources,key=lambda x:x[1]):
  assert name not in entries;z.write(item,name);entries[name]=sha256(item)
(extra/'archive-index.json').write_text(json.dumps(entries,indent=2)+'\n',encoding='utf-8')
old=json.loads((p/'run.json').read_bytes());run=old|dict(build_id=manifest['build_id'],manifest_sha256=sha256(site/'site-manifest.json'),manifest_outputs=len(manifest['outputs']),reader_page_html_sha256={l:inv[l]['html_sha256'] for l in ['ko','en']},site_verification=valid,review='publication/issue211-virtual/reviews/'+tag+'/review.json',integration=dict(public_base='7d824a9753721edd86a4b509a979230033532f9c',profile='publication/issue211-virtual/integration/profiles/publication.yaml',preservation='publication/issue211-virtual/integration/current-main-preservation.json',followup_generator_merge=merge),deployment='Predeployment snapshot; actual Pages/live proof is in public PR78',human_review='pending')
run['integration']['reader_recipe_merge']=recipe_merge
receipts=json.loads((p/'generation-receipts.json').read_bytes())|dict(integration_index='publication/issue211-virtual/integration/native-call-verification-integrated.json',integration_archive='publication/issue211-virtual/integration/cli-evidence.zip',inherited_issue214='publication/issue214',scope='Fresh native generation/translation/review records are distinguished from copied issue211-reader and issue214 records; no failed run is accepted')
for name,data in [('run.json',run),('generation-receipts.json',receipts)]:
 for target in [repo/name,p/name]:target.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
files={item.relative_to(p).as_posix():sha256(item) for item in sorted(p.rglob('*')) if item.is_file() and item.name!='evidence-index.json'}
# The prior index is evidence too; only the root self-index is excluded.
files={item.relative_to(p).as_posix():sha256(item) for item in sorted(p.rglob('*')) if item.is_file() and item!=p/'evidence-index.json'}
(p/'evidence-index.json').write_text(json.dumps(dict(schema=1,files=files,site_manifest=run['manifest_sha256'],site_outputs=manifest['outputs']),indent=2)+'\n',encoding='utf-8')
print(dict(package_files=len(files),extra_archive_files=len(entries),build_id=manifest['build_id'],outputs=len(manifest['outputs'])))
