"""Bind every accepted English unit to actual independent review and native repairs."""
from pathlib import Path
import json,hashlib
from sdd.config import load
from sdd.call_records import load_record
from sdd.cli_provenance import verify_cli_receipt
from sdd.translation import _validate_text
from sdd.translation_context import for_source
from sdd.runtime_evidence import sha256
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration'
writer=load(w/'latest-translation-writer.yaml').agent;reviewer=load(w/'new-document-review.yaml').agent
catalog=json.loads((d/'run/english.json').read_bytes());units={};digest=lambda s:hashlib.sha256(s.encode()).hexdigest()
def native(path,profile):
    p=Path(path);record=load_record(p);verify_cli_receipt(record.request,record.raw,record.receipt,p.parent.parent,profile)
    return record,json.JSONDecoder().raw_decode(record.request['user'])[0],json.loads(record.raw)
def check_review(record,ids):
    assert set(record['reviewed_ids'])==set(ids) and len(record['reviewed_ids'])==len(ids)
    assert all(f['id'] in ids for f in record['findings'])
    assert record['verdict']==('needs-revision' if record['findings'] else 'pass')
def bindings(source):
    return [{k:v for k,v in c.items() if k!='source_ids'} for c in catalog.get('translation_contexts',{}).get(source,[])]
for part in sorted((w/'latest-catalog-translation-v3').glob('part-*')):
    keys=json.loads((part/'sources.json').read_bytes());original=json.loads((part/'result.json').read_bytes())
    initial=json.loads((w/'reviews/latest-catalog-equivalence-v1'/part.name/'review.json').read_bytes())
    call,payload,response=native(initial['receipt'],reviewer);assert response==initial['review'];check_review(response,payload)
    assert [payload[str(i)]['korean'] for i in range(len(keys))]==keys
    state={k:original['strings'][k] for k in keys};accepted={}
    for row in payload.values():assert row['english']==state[row['korean']] and row['bindings']==bindings(row['korean'])
    remaining={payload[f['id']]['korean']:f['reason'] for f in response['findings']}
    for source in keys:
        if source not in remaining:accepted[source]=(state[source],initial['receipt'])
    target=w/'latest-catalog-repair-v1'/part.name
    for stage in sorted(target.glob('attempt-*'),key=lambda p:int(p.name.split('-')[1])):
        review_file=stage/'review.json'
        if not review_file.exists():continue # Rejected native validation attempts remain failures.
        pending=set(remaining);written=set()
        for folder in sorted(stage.glob('writer-*')):
            calls=sorted(folder.rglob('*.receipt.json'))
            assert calls
            for p in calls:native(p,writer)
            call,rows,answer=native(calls[-1],writer)
            assert set(answer)=={'translations'} and set(answer['translations'])==set(rows)
            for key,row in rows.items():
                source=row['korean'];assert source in pending and source not in written
                assert row['previous_english']==state[source] and row['review_finding']==remaining[source]
                assert row['read_only_context']==for_source(catalog,source)
                state[source]=_validate_text(source,answer['translations'][key]);written.add(source)
        assert written==pending
        review=json.loads(review_file.read_bytes());call,rows,answer=native(review['receipt'],reviewer)
        assert rows==review['units'] and answer==review['review'];check_review(answer,rows)
        assert {row['korean'] for row in rows.values()}==pending
        for row in rows.values():assert row['english']==state[row['korean']] and row['bindings']==bindings(row['korean'])
        remaining={rows[f['id']]['korean']:f['reason'] for f in answer['findings']}
        for source in pending-remaining.keys():accepted[source]=(state[source],review['receipt'])
    assert not remaining and set(accepted)==set(keys)
    final=json.loads((target/'result.json').read_bytes())
    for source,(english,receipt) in accepted.items():
        assert catalog['strings'][source]==final['strings'][source]==state[source]==english
        key=digest(source);assert key not in units
        units[key]={'english_sha256':digest(english),'review_receipt':str(Path(receipt).relative_to(w)),'review_receipt_sha256':sha256(Path(receipt))}
assert len(units)==1668
report={'schema':1,'catalog_sha256':sha256(d/'run/english.json'),'accepted_translation_units':units,'scope':'Translation equivalence to retained Korean and resolved bindings; actual target-page whole-source grounding is separate.','human_review':'pending'}
(w/'latest-catalog-unit-acceptance.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print('Native-bound independently reviewed translation units:',len(units))
