from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration'
b=w/'before-final-wording';b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/sections.yaml';x=yaml.safe_load(p.read_bytes());s=next(s for s in x['sections'] if s['id']=='official-cam-validation');t=next(t for t in s['design_topics'] if t['id']=='reproduce')
 for part in t['parts']:
  if part['id']=='environment':
   part['question']="statement.text를 '1. '로 시작하세요. 개발자가 호스트 상태를 바꾸지 않고 기존 WSL/Docker에 영향 없는 조사부터 진행하여 선택한 커널의 Kconfig와 의존 심볼을 확인한다고 두 짧은 문장으로 직접 서술하세요. 공유 커널·배포판 추가에 관한 설명은 다음 모듈 단위에만 있습니다. 이 단위는 Kconfig와 의존 심볼 조사만 맡습니다."
   part['answer_contract'].setdefault('reject_patterns',[]).append(dict(pattern='배포판|공유.*커널',message='Keep the shared-kernel condition once in the modules part; this part covers Kconfig/dependencies.'))
  if part['id']=='stream-request':
   part['question']="statement.text를 '10. '로 시작하세요. 사용할 cam 스트림 인자가 400x300 NV12를 요청하는지 확인합니다. 지금까지 조사·확인한 커널, 장치 접근, Virtual2 YAML, 카메라 선택, 스트림 요청 중 어느 조건이라도 다르면 캡처를 시작하지 않는다고 두 짧은 문장으로 명시하세요. 과거 명령은 기대 조건의 근거이고 새 실행 성공 증거가 아닙니다."
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id'] not in ['virtual-frame-path','request-completion-order']:continue
  target=('n6의 한영 라벨만 명확하게 편집하세요. 상태와 무관하게 버퍼 완료 신호를 보낸다는 동작을 명시하세요. 프레임 생성 성공 여부는 별도의 프레임 상태로 판단합니다. 버퍼 완료가 실패라는 단정은 하지 않습니다. 짧고 자연스러운 라벨로 씁니다.' if v['id']=='virtual-frame-path' else 'n2의 한영 라벨만 명확하게 편집하세요. 아직 완료되지 않은 버퍼들은 해당 요청에 속합니다. 요청 완료 처리는 그 요청의 나머지 FrameBuffer들이 완료될 때까지 기다린다는 뜻을 짧게 표시하세요.')
  v['prompt']+=' 최종 표현 수정: '+target+' 현재 검증된 초안의 모든 노드 ID·shape·quote_ids와 모든 간선 from·to·condition_ref·quote_ids, 다른 올바른 한영 라벨을 그대로 보존하세요. 아래 초안은 새 CLI 응답의 편집 입력이며 저장 응답 재생이나 새 런타임 증거가 아닙니다. 참고 초안: '+json.dumps(m['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
text=(r/'build/after-virtual-bound-preflight.py').read_text().replace('bound-preflight','final-wording');(r/'build/after-virtual-final-wording.py').write_text(text,encoding='utf-8')
