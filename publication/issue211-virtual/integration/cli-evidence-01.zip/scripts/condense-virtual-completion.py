from pathlib import Path
import json,shutil,yaml
from sdd.document_metadata import split_frontmatter
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';tag='completion-overview'
b=w/('before-'+tag);b.mkdir(exist_ok=False)
for name in ['run/manuscripts/official-cam-validation.md','config/sections.yaml','config/visuals.yaml']:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/name,p)
m,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'))
for root in [w,d]:
 p=root/'config/visuals.yaml';x=yaml.safe_load(p.read_bytes())
 for v in x['sections']['official-cam-validation']:
  if v['id']=='virtual-frame-path':
   v['max_label_chars']=60
   for key in ['answer_contract','answer_contract_en']:v[key]['reject_patterns'].append(dict(pattern=r'(?m)^[^·\n]*(?:exportFrameBuffers|queueRequestDevice|\baddBuffer\b|generateFrame|ret\s*[<>=])',message='Keep implementation function names and literal return-value guards in evidence. Use brief actions/decisions in authored visible labels; preserve actual symbol bindings and conditions. VirtualCameraData::processRequest remains the necessary scheduled target identity.'))
   edit='10개 노드와 모든 간선·실제 분기·인용을 그대로 보존하며 한영 라벨만 간결한 동작구로 줄입니다. n0 할당 실패?, n7 제출 전 오류 반환, n8 요청에 버퍼 연결 실패?, n1 Camera의 버퍼·활성 스트림 검증과 비동기 전달 시도, n2 virtual 처리 queued 예약, n9 VirtualCameraData::processRequest 실행·목표 시각 대기, n3 쓰기 동기화 범위의 쓰기용 매핑 시도, n4 CPU의 Virtual2 lines NV12 변환·매핑 버퍼 쓰기 시도, n5 생성 오류?, n6 상태와 무관한 버퍼 완료·다음 그림 연결입니다. 구현 함수 이름·ret 식을 반복하지 말고 꼭 필요한 VirtualCameraData::processRequest 타깃만 명시합니다. 다른 node symbol·quote_ids 및 조건식은 근거에서 보존합니다. 각 노드는 한 질문이나 동작구이며 한국어의 합니다/습니까 같은 긴 문장과 영어의 The 같은 군더더기를 줄입니다. '
   ref='참고 초안: '+json.dumps(m['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
  elif v['id']=='request-completion-order':
   v['question']='버퍼 완료와 모든 요청 버퍼 완료 조건, 요청 완료 표시, 앞선 요청 뒤의 제출 순서 통지는 어떻게 구분되고 cam 콜백으로 연결됩니까?'
   v['max_nodes']=5;v['max_label_chars']=56;v['required_symbols']=['PipelineHandlerVirtual::bufferCompleted','completeBuffer','FrameBuffer','completeRequest','requestCompleted']
   edit='독자 질문을 내부 큐 구현이 아니라 버퍼 완료와 요청 완료·순서 통지의 관계로 좁혀 다섯 노드로 새로 요약합니다. n0는 앞 가상 그림의 버퍼 완료를 핸들러가 받는 단계입니다. n1은 해당 요청의 모든 버퍼가 완료됐는지를 판정합니다. 미완료 결과는 n2의 그 요청 나머지 버퍼 완료 대기, 완료 결과는 n3의 해당 요청 상태 완료 표시로 이어집니다. n0→n1은 실제 호출 관계, n1의 두 결과는 실제 completeBuffer 조건에 바인딩합니다. n3→n4는 순서가 된 완료 요청들의 통지를 요약하는 관계입니다. 이 간선은 항상 즉시 통지됨을 뜻하지 않으므로 앞선 요청이 완료되어 제출 차례가 된 경우라는 조건을 짧게 명시합니다. n4는 통지 순서가 된 완료 요청들을 requestCompleted로 cam의 requestComplete 콜백에 제출 순서대로 알리는 요약입니다. 이번 호출에서 방금 표시한 요청만 즉시 통지된다고 단정하지 않습니다. n4 한영 라벨에는 실제 signal requestCompleted와 cam callback requestComplete 연결을 명시합니다. 내부 queuedRequests_ 스캔·반복·doQueueRequests 구현은 소스 근거와 기존 상세 설명에 남기며 새 노드로 늘리지 않습니다. 버퍼 대기와 앞선 요청에 따른 통지 지연을 혼동하지 않습니다. sources와 quote_ids는 제공된 실제 함수를 따르고, 순서 조건은 pipeline-completion의 실제 큐 코드와 camera-notification 및 cam-signal-connection으로 근거를 연결합니다. '
   ref='이것은 새 독자 범위의 소스 기반 요약이며 과거 그래프를 새 출력으로 재생하지 않습니다.'
  else:continue
  v['prompt']=edit+'노드는 한영 최대 '+str(v['max_label_chars'])+'자, authored 간선은 20자 이내입니다. 각 라벨은 짧은 질문·동작구로 쓰고 정확한 조건·콜백 연결을 유지합니다. '+ref
 p.write_text(yaml.safe_dump(x,allow_unicode=True,sort_keys=False),encoding='utf-8')
(r/'build/after-virtual-completion-overview.py').write_text((r/'build/after-virtual-bound-preflight.py').read_text().replace('bound-preflight',tag),encoding='utf-8')
