from pathlib import Path
import json,yaml,shutil,sys
from sdd.document_metadata import split_frontmatter
from sdd.runtime_evidence import run_recorded,require_success
r=Path(__file__).resolve().parent.parent;w=r/'build/issue211-virtual';d=w/'current-main-integration';g=r/'build/generator-reader-release';out=w/'before-final-state-timing';out.mkdir()
meta,_=split_frontmatter((w/'run/manuscripts/official-cam-validation.md').read_text(encoding='utf-8'));findings=json.loads((w/'reviews/latest-main-final-v17/review.json').read_bytes())['review']['findings']
for root in [w,d]:
 p=root/'config/visuals.yaml';backup=out/root.name;backup.mkdir();shutil.copy2(p,backup/'visuals.yaml');data=yaml.safe_load(p.read_bytes())
 for v in data['sections']['official-cam-validation']:
  if v['id'] not in ['virtual-frame-path','request-completion-order','submission-gate']:continue
  instructions='현재 그래프 구조·노드 수·간선·심볼·실제 조건 양쪽·인용을 보존하고 지정한 라벨만 수정합니다. 다른 라벨은 유지합니다. '
  if v['id']=='virtual-frame-path':
   instructions+='현재 n5에서 프레임 생성 호출 전 FrameSuccess 초기화가 먼저 있고, 그 뒤 CPU 쓰기 동기화 범위 안에서 쓰기용 DMA-BUF 매핑을 시도함을 한영으로 명시합니다. 초기화는 CPU 동기화 범위보다 먼저이며 매핑·변환은 동기화 범위 안입니다. 필요하면 virtual-frame의 초기화 구절을 n5 quote_ids에 추가합니다. n7 오류 true 간선은 FrameError로 변경, false 간선은 이미 초기화된 FrameSuccess 유지로 표현합니다. 성공 상태를 결과 판정 뒤 새로 설정한다고 쓰지 않습니다. n2 영어에도 RequestCancelled와 큐 앞부터 통지 및 앞 RequestPending에서 중단하는 관계를 최대64자로 명시합니다. 취소 상태가 해당 요청의 상태이고 큐 통지 전체가 취소 요청만을 뜻하지 않게 합니다. '
   terms=v['answer_contract_en']['required_terms'];terms[:]=[['Cancelled completion','Complete cancelled','RequestCancelled'] if x==['Cancelled completion','Complete cancelled'] else x for x in terms]
   for key in ['answer_contract','answer_contract_en']:
    v[key].setdefault('reject_patterns',[]).append({'pattern':'정상: FrameSuccess 설정|Sets FrameSuccess','message':'FrameSuccess is initialized before generation; successful generation preserves it instead of setting it afterward.'})
  elif v['id']=='request-completion-order':
   instructions+='n6 라벨은 뒤 요청 통지 보류와 반복 중단이라는 결과만 적습니다. n6에 RequestPending, Pending, 맨 앞, Front 등 앞 결정 노드의 조건을 반복하지 않습니다. n4→n6 및 n4→n5 간선 라벨에는 보류·통지·hold·notify 동작을 쓰지 않고 상태 분기만 짧게 둡니다. n8은 통지 검사 종료 결과만 표시하고 빈 큐/Pending 조건을 반복하지 않습니다. n3의 정상/취소 상태 구분과 n5의 공백으로 구분한 식별자는 보존합니다. '
   for key in ['answer_contract','answer_contract_en']:
    v[key].setdefault('reject_patterns',[]).append({'pattern':'맨 앞 RequestPending:|Front Pending:|Pending: 보류|Pending: hold|Pending 아님: 통지|Not Pending: notify','message':'Keep the Pending test in the decision, its state on the branch, and hold/notification actions only in their result nodes.'})
  else:
   instructions+='err_return은 오류 값 반환과 카메라 시작 전 종료라는 결과만 명시합니다. err_return의 라벨에 할당·생성·연결 실패 조건을 반복하지 않습니다. 그 조건들은 각각 앞 결정 노드에서 설명합니다. 나머지 노드와 간선은 모두 유지합니다. '
   for key in ['answer_contract','answer_contract_en']:
    v[key].setdefault('reject_patterns',[]).append({'pattern':'할당·생성·연결 실패|Alloc, create or attach fails','message':'The shared error-return node states the result; preceding decisions already identify allocation, creation and attachment failures.'})
  v['prompt']=instructions+'실제 검토 지적: '+json.dumps(findings,ensure_ascii=False)+' 다음은 native 편집 대상 초안입니다: '+json.dumps(meta['generated_visuals']['records'][v['id']]['draft'],ensure_ascii=False,separators=(',',':'))
 p.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
record=w/'executions/generate-final-state-timing';run_recorded(record,[sys.executable,'-X','utf8','-m','sdd.cli','--config',str(w/'generation.yaml'),'generate','--sections','official-cam-validation'],timeout=1800,cwd=g);require_success(record)
print('Native state timing and concise result labels generated')
