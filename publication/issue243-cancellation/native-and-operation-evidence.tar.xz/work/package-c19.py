from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile

from sdd.cli_provenance import verify_cli_receipt
from sdd.config import load
from sdd.publication import copy_site
from sdd.site_build import verify_site

work=Path(__file__).resolve().parent
root=work.parents[1]
release=work/'c19-release'
public=root/'build/issue243/public-sdd'
export_result=work/'c19-export-05/result.json'
site=Path(json.loads(export_result.read_bytes())['site_directory'])
base='0c519bf59f465149f4de85b6716090d2c0694640'
old=public/'publication/issue253-contract-reuse/integrated-c19'
sha=lambda raw:hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git','-C',str(public),*args])


def read(path):
    return json.loads(path.read_bytes())


def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')


audit=read(work/'c19-audit-01/result.json')
final_review=read(work/'native-review-c19-final-01/review.json')
assert audit['status']=='passed' and not audit['unresolved']
assert not final_review['new_findings']
assert all(r['current_status']=='supported' for r in final_review['cases'])
assert all(r['status']=='supported' for r in final_review['checks'])
verification=verify_site(site)
manifest=read(site/'site-manifest.json')
before_manifest=read(public/'docs/site-manifest.json')
assert git('rev-parse','HEAD').decode().strip()==base
assert git('rev-parse','origin/main').decode().strip()==base
assert not git('status','--porcelain')
changed=[n for n,d in manifest['outputs'].items() if before_manifest['outputs'].get(n)!=d]
assert set(manifest['outputs'])==set(before_manifest['outputs'])
assert [n for n in changed if n.endswith('.md')]==['pipeline-requests.md']
plan=read(work/'c19-final-review-plan.json')
for case in plan['cases']:
    for doc in case['current_rendered']:
        reviewed=(work/'c19-private-final'/doc['path']).read_bytes()
        exported=(site/doc['path']).read_bytes()
        assert sha(reviewed)==doc['sha256']
        article=lambda value:re.search(rb'<article\b.*?</article>',value,re.S).group()
        assert article(reviewed)==article(exported),doc['path']
assert all(sha((site/path).read_bytes())==record['sha256'] for path,record in plan['current_diagrams'].items())

index=read(old/'public-release-index.json')
native=[]
for tag, directory, profile in [
    ('working',release/'build/prompts/calls',release/'review.yaml'),
    ('translation',release/'build/translation-prompts/calls',release/'translation.yaml'),
    ('prior-review',work/'native-review-latest-01/prompts/calls',work/'independent-review.yaml'),
    ('final-review',work/'native-review-c19-final-01/prompts/calls',work/'independent-review.yaml'),
    ('retained-figure-draft',work/'figure-scope-01/prompts/calls',work/'independent-review.yaml'),
]:
    agent=load(profile).agent
    for path in sorted(directory.rglob('*.receipt.json')):
        if path.is_relative_to(release):
            key='release/'+path.relative_to(release).as_posix()
            if key in index:
                assert sha(path.read_bytes())==index[key]['sha256']
                continue
        prefix=str(path).removesuffix('.receipt.json')
        request=read(Path(prefix+'.request.json'))
        response=Path(prefix+'.response.txt').read_text(encoding='utf-8')
        receipt=read(path)
        proof=verify_cli_receipt(request,response,receipt,directory,agent)
        native.append(dict(stage=tag,tag=receipt.get('tag'),path=path.relative_to(work).as_posix(),verification=proof))
assert sum(r['stage']=='final-review' for r in native)==1
assert sum(r['stage']=='working' and str(r['tag']).startswith('contract-') for r in native)==audit['fresh_batches']

dest=public/'publication/issue243-cancellation'
dest.mkdir()
save(dest/'resolution.json',dict(status='verified-candidate',source_commit=audit['source_commit'],
    previous_public_commit=base,publication_runtime='02159b94968b29970de7a6f79a6d6e08feb107a9',
    original_findings=4,original_remaining=0,new_status_timing_error_repaired=1,
    independent_final_review=final_review,standard_audit=audit,prior_358_live=read(work/'latest-live-verification.json'),
    outputs=verification,changed_outputs=changed,retained_answers=read(work/'c19-scoped-repair-02/result.json')['retained'],
    concurrent_public_integration=read(work/'public100-integration.json'),
    verified_native_records=native,human_review='pending'))
files={}
for p in release.rglob('*'):
    if not p.is_file() or any(x in p.parts for x in ['execution-locks','__pycache__','publication-operations']):
        continue
    key='release/'+p.relative_to(release).as_posix()
    raw=p.read_bytes()
    if sha(raw)!=index.get(key,{}).get('sha256'):
        files[key]=raw
for dirname in ['native-review-latest-01','native-review-c19-final-01','figure-scope-01','c19-scoped-repair','c19-scoped-repair-02',
                'c19-translate-01','c19-translate-02','c19-translate-03','c19-audit-01']:
    for p in (work/dirname).rglob('*'):
        if p.is_file() and not any(x in p.parts for x in ['execution-locks','__pycache__']):
            files['work/'+p.relative_to(work).as_posix()]=p.read_bytes()
for name in ['latest-public-plan.json','c19-final-review-plan.json','latest-live-verification.json',
             'c19-repair.log','c19-repair02.log','c19-preview01.log','c19-translate01.log','c19-translate02.log',
             'c19-translate03.log','c19-audit01.log','c19-review-final01.log','restore-c19.py','fix-c19.py',
             'c19-stages.py','verify-latest.py','package-c19.py','review.py','independent-review.yaml']:
    files['work/'+name]=(work/name).read_bytes()
files['work/c19-export-result.json']=export_result.read_bytes()
files['work/c19-export-01/failure.json']=(work/'c19-export-01/failure.json').read_bytes()
files['work/c19-export01.log']=(work/'c19-export01.log').read_bytes()
files['work/c19-export-02/failure.json']=(work/'c19-export-02/failure.json').read_bytes()
files['work/c19-export02.log']=(work/'c19-export02.log').read_bytes()
files['work/c19-export-03/failure.json']=(work/'c19-export-03/failure.json').read_bytes()
files['work/c19-export03.log']=(work/'c19-export03.log').read_bytes()
files['work/public100-integration.json']=(work/'public100-integration.json').read_bytes()
files['work/integrate-public100.py']=(work/'integrate-public100.py').read_bytes()
files['work/public100-unbound-catalog.json']=(work/'public100-unbound-catalog.json').read_bytes()
archive=dest/'native-and-operation-evidence.tar.xz'
with tarfile.open(archive,'w:xz') as bundle:
    for name,raw in sorted(files.items()):
        member=tarfile.TarInfo(name)
        member.size=len(raw)
        bundle.addfile(member,io.BytesIO(raw))
save(dest/'archive-index.json',{name:sha(raw) for name,raw in sorted(files.items())})
save(dest/'package.json',dict(schema=1,files=len(files),archive_sha256=sha(archive.read_bytes()),
    index_sha256=sha((dest/'archive-index.json').read_bytes()),
    inherited_archive='../issue253-contract-reuse/integrated-c19/public-release-evidence.tar.gz',
    inherited_archive_sha256=read(old/'public-release.json')['archive_sha256'],
    restoration='Apply release/ overlay to the authenticated c19 baseline. Preserve original attempts and native receipts. Resolve recorded local paths explicitly.',
    human_review='pending'))
(dest/'README.md').write_text('''# 요청 취소의 내부 플래그와 완료 상태

공개 PR #98이 기존 네 미판정을 해결했고 PR #99가 그 수정을 공식 소스 c19d051에 반영했습니다. 이 후속 검토는 최신 공개 원고에서 내부 취소 플래그 설정과 이후 요청 상태 대입을 한 시점처럼 읽히게 한 별도 문제를 확인했습니다.

Codex CLI gpt-6.1-terra high로 취소 답변 하나를 보정했습니다. 내부 취소는 대기 버퍼 알림을 보낸 뒤 `cancelled_`를 설정합니다. 이어 `completeRequest`가 호출하는 `Request::Private::complete()`에서 요청 상태를 `RequestCancelled`로 바꿉니다. 일반 완료 그림은 모든 버퍼 완료와 필요한 후속 작업 조건을 유지하며 적용 범위를 명시합니다. 기존 그림 주소도 보존했습니다.

별도 지정 CLI가 네 원래 지적과 변경된 한영 원고 및 그림을 대조했습니다. 표준 계약 감사, 원래 실패 기록, 검증한 원본 영수증과 실행 범위는 `resolution.json`과 증거 archive에 있습니다. 사람 검토는 대기 상태입니다.

예제 설정의 보정과 CI는 [생성기 PR #291](https://github.com/TTolsun/camera-hal-sdd-generator/pull/291)에 기록했습니다. 공개 사이트 조립은 직전 발행과 동일한 고정 생성기 버전으로 수행했습니다. 이 패키지는 배포 전 후보를 기록합니다.
''',encoding='utf-8',newline='\n')
attrs=public/'.gitattributes'
text=attrs.read_text(encoding='utf-8')
rule='publication/issue243-cancellation/** -text -whitespace'
assert rule not in text
attrs.write_text(text.rstrip()+'\n'+rule+'\n',encoding='utf-8')
copy_site(site,public/'docs',scratch=public/'.git/sdd-cancel-status')
print(json.dumps(dict(changed=changed,files=len(files),archive_bytes=archive.stat().st_size,build_id=manifest['build_id']),ensure_ascii=False),flush=True)
