{
  "cases": [
    {
      "id": "ownership-reuse/catalog/948d857e662479be/en",
      "current_status": "unjudged",
      "action": "needs-evidence",
      "original_gap": "The historical wording presented investigator recording as an observed action.",
      "reason": "Both current versions describe a possible investigation procedure, not an observed implementation action. The configure branch supports the conditional -EINVAL outcome when validation is reached and differs from Valid. However, the supplied configuration-validation-contract window does not contain the Adjusted contract, so the adjacent claims about Adjusted and the caller's duty cannot be assessed from the pinned evidence. Retain the supported procedure and branch clauses; obtain the relevant validation contract before judging the full paragraph.",
      "source_ids": [
        "configuration-validation-contract",
        "configure-validation-branch"
      ],
      "visual": "The supplied submission-checks diagrams concern queueRequest and do not directly cover configuration validation or the proposed investigation."
    },
    {
      "id": "callbacks-synchronization/pipeline-requests.md/completion/6",
      "current_status": "error",
      "action": "revise",
      "original_gap": "The historical normal-completion wording did not distinguish pending-buffer cancellation.",
      "reason": "The current normal-completion and CameraManager-thread clauses are supported, as are cancellation of each pending buffer, emission of bufferCompleted, clearing the pending list, and the subsequent completeRequest call. In both languages, however, the internal-cancellation sentence says the request is marked cancelled at that stage. Internal cancellation sets the cancelled_ flag; completeRequest subsequently calls complete(), which sets the request status to RequestCancelled. Correct only that distinction and retain the supported clauses.",
      "source_ids": [
        "pipeline-completion-and-cancellation",
        "internal-completion-and-cancellation"
      ],
      "visual": "The Korean and English buffer-request-completion diagrams show normal completion, not the cancellation path. Label their scope as normal completion or amend them if they are intended to cover cancellation."
    },
    {
      "id": "callbacks-synchronization/catalog/9d141e4b7ca20344",
      "current_status": "supported",
      "action": "retain",
      "original_gap": "The historical guard descriptions omitted earlier returns.",
      "reason": "The current Korean paragraph conditions the buffer and stream checks on reaching them and identifies the preceding access, camera ownership, status, and controls exits. Its queued invokeMethod and subsequent return-0 wording does not claim that the receiver has completed; request completion is separately signalled. Retain the current clauses.",
      "source_ids": [
        "queue-api-and-guards",
        "queued-invocation"
      ],
      "visual": "The Korean submission-checks diagram directly covers the ordered guards, access outcomes, queued scheduling, and return 0; no amendment is needed for this scope."
    },
    {
      "id": "callbacks-synchronization/catalog/9d141e4b7ca20344/en",
      "current_status": "supported",
      "action": "retain",
      "original_gap": "The historical English guard descriptions omitted earlier returns.",
      "reason": "The current English paragraph matches the Korean conditions and preceding exits. It places return 0 after the queued invokeMethod call without asserting receiver completion, and separately identifies requestCompleted. Retain the current clauses.",
      "source_ids": [
        "queue-api-and-guards",
        "queued-invocation"
      ],
      "visual": "The English submission-checks diagram directly covers the ordered guards, access outcomes, queued scheduling, and return 0; no amendment is needed for this scope."
    }
  ],
  "checks": [
    {
      "id": "early-return-guards",
      "status": "supported",
      "reason": "Both current queueRequest paragraphs account for access, creating-camera, request-status, and controls returns before the empty-buffer guard, and condition stream iteration on passing that guard. The diagrams also distinguish disconnected and non-Running access outcomes.",
      "source_ids": [
        "queue-api-and-guards",
        "access-state",
        "access-overloads"
      ]
    },
    {
      "id": "investigation-plan-versus-observed-behavior",
      "status": "unjudged",
      "reason": "Both languages make recording a possible investigation-plan action, and the conditional configure return is supported. The pinned validation-contract window does not establish the adjacent Adjusted claims, leaving the complete paragraph incompletely evidenced.",
      "source_ids": [
        "configure-validation-branch",
        "configuration-validation-contract"
      ]
    },
    {
      "id": "normal-completion-versus-cancellation",
      "status": "error",
      "reason": "Normal completion is correctly distinguished from cancellation, but both current cancellation descriptions conflate setting the internal cancelled flag with the later request-status update in complete().",
      "source_ids": [
        "pipeline-completion-and-cancellation",
        "internal-completion-and-cancellation"
      ]
    },
    {
      "id": "ko-en-fidelity-and-visual-scope",
      "status": "error",
      "reason": "The paired texts agree on the assessed points, including the shared cancellation-status error. The submission-check diagrams cover their queueing scope; the completion diagrams cover normal completion only and need a scope label or cancellation coverage if presented as covering both paths.",
      "source_ids": [
        "queue-api-and-guards",
        "queued-invocation",
        "pipeline-completion-and-cancellation",
        "internal-completion-and-cancellation",
        "configure-validation-branch"
      ]
    }
  ],
  "new_findings": [
    "The current cancellation paragraph has a request-status timing error in both languages: internal cancellation sets a flag, while the later complete() call updates the request status."
  ],
  "limitations": [
    "The supplied configuration-validation-contract window does not include the Adjusted contract or caller obligation.",
    "Assessment is limited to the supplied rendered excerpts, diagrams, and pinned source windows; full page placement and visual captions are not available."
  ]
}
