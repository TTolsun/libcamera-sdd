from pathlib import Path
import hashlib
import json
import shutil
import tarfile

import yaml

work = Path(__file__).resolve().parent
root = work.parents[1]
public = root/'build/issue243/public-sdd'
package = public/'publication/issue253-contract-reuse/integrated-c19'
sha = lambda b: hashlib.sha256(b).hexdigest()
meta = json.loads((package/'public-release.json').read_bytes())
index_raw = (package/'public-release-index.json').read_bytes()
archive = package/'public-release-evidence.tar.gz'
assert sha(archive.read_bytes()) == meta['archive_sha256']
assert sha(index_raw) == meta['archive_index_sha256']
index = json.loads(index_raw)
original = work/'c19-original'
original.mkdir(exist_ok=True)
seen = set()
with tarfile.open(archive) as tar:
    for member in tar:
        assert member.isfile() and member.name in index and member.name not in seen
        dest = (original/member.name).resolve()
        assert dest.is_relative_to(original.resolve())
        raw = tar.extractfile(member).read()
        assert sha(raw) == index[member.name]['sha256']
        dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists():
            assert dest.read_bytes() == raw
        else:
            dest.write_bytes(raw)
        seen.add(member.name)
assert len(seen) == meta['archive_files'] and seen == set(index)
out = work/'c19-release'
if not out.exists():
    shutil.copytree(original/'release',out)
cfg = yaml.safe_load((original/'release/publication.yaml').read_bytes())
old = str(Path(cfg['output']['facts_dir']).parent).replace('\\','/')
old_source = cfg['source']['root'].replace('\\','/')
old_compile = cfg['source']['compile_commands'].replace('\\','/')
compile = original/'source/clang/compile_commands.json'

def relocate(value):
    if isinstance(value, dict):
        return {k: relocate(v) for k,v in value.items()}
    if isinstance(value,list):
        return [relocate(v) for v in value]
    if isinstance(value,str):
        p=value.replace('\\','/')
        if p == old_source:
            return str(work/'source-c19')
        if p == old_compile and compile.is_file():
            return str(compile)
        if p==old or p.startswith(old+'/'):
            return str(out/p[len(old):].lstrip('/'))
    return value

for name in ('publication.yaml','translation.yaml','baseline98.yaml'):
    p=out/name
    original_cfg=yaml.safe_load((original/'release'/name).read_bytes())
    c=relocate(original_cfg)
    if 'site' in c:
        c['site']['mermaid_dir']=str(public/'docs/assets/mermaid')
    if 'publication' in c:
        c['publication']['operation_id']='issue243-c19-cancel-status'
        for report, old_report in zip(c['publication'].get('reports',[]),
                                      original_cfg['publication'].get('reports',[])):
            # Keep historical prerequisite records at their original bytes even
            # after standard audit replaces the current working report.
            p_report=Path(report['path'])
            if p_report.is_relative_to(out):
                p_report=original/'release'/p_report.relative_to(out)
            if not p_report.is_file():
                p_report=Path(old_report['path'])
            assert sha(p_report.read_bytes())==report['sha256'],p_report
            report['path']=str(p_report)
    p.write_text(yaml.safe_dump(c,allow_unicode=True,sort_keys=False),encoding='utf-8')
current=yaml.safe_load((out/'publication.yaml').read_bytes())
independent=yaml.safe_load((original/'release/review.yaml').read_bytes())
current['agent']=independent['agent']
(out/'review.yaml').write_text(yaml.safe_dump(current,allow_unicode=True,sort_keys=False),encoding='utf-8')
manifest=json.loads((public/'docs/site-manifest.json').read_bytes())
assert sha((out/'facts/facts.json').read_bytes())==manifest['inputs']['facts']
for name,digest in manifest['outputs'].items():
    if name.endswith('.md'):
        raw=(public/'docs'/name).read_bytes()
        assert sha(raw)==digest
        dest=out/'manuscripts'/name
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(raw)
print('Verified and restored',len(seen),'archived files and current public manuscripts',flush=True)
