from pathlib import Path
from contextlib import contextmanager, nullcontext
from unittest.mock import patch
import hashlib
import json
import os
import shutil
import sys
import time

from sdd.config import load
from sdd.consistency import audit
from sdd.export_site import export_site
from sdd.facts.model import KnowledgeModel
from sdd.llm import Agent
from sdd.localization_cli import prepare_catalog
from sdd.site_build import verify_site

work=Path(__file__).resolve().parent
release=work/'c19-release'
stage=sys.argv[1]
attempt=sys.argv[2] if len(sys.argv)>2 else '01'
out=work/f'c19-{stage}-{attempt}'
out.mkdir()
cfg=load(release/('review.yaml' if stage=='audit' else 'publication.yaml'))
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
start=time.monotonic()

@contextmanager
def drain_staging_notifications(cfg):
    """Poll the same Windows input watchers at output write boundaries."""
    from sdd.input_watch import Changes, DirectoryWatch
    from sdd.validation_stage import current
    write_text, write_bytes, copyfile = Path.write_text, Path.write_bytes, shutil.copyfile
    unlink, rmdir, watch_path = os.unlink, os.rmdir, Changes.watch
    watch_poll=DirectoryWatch.poll
    base=cfg.build_dir.resolve()
    def output(path):
        path=Path(path).absolute()
        if path.is_relative_to(base):
            parts=path.relative_to(base).parts
            return bool(parts and parts[0].startswith('.site-'))
        return False
    def drain(path):
        if output(path) and current() is not None:
            current().changes.poll()
    def wrapped_text(path,*a,**kw):
        result=write_text(path,*a,**kw)
        drain(path)
        return result
    def wrapped_bytes(path,*a,**kw):
        result=write_bytes(path,*a,**kw)
        drain(path)
        return result
    def wrapped_copy(src,dst,*a,**kw):
        result=copyfile(src,dst,*a,**kw)
        drain(dst)
        return result
    def wrapped_unlink(path,*a,**kw):
        result=unlink(path,*a,**kw)
        if isinstance(path,(str,os.PathLike)):
            drain(path)
        return result
    def wrapped_rmdir(path,*a,**kw):
        result=rmdir(path,*a,**kw)
        if isinstance(path,(str,os.PathLike)):
            drain(path)
        return result
    def trace_watch(changes,path):
        parent=path.parent
        while not parent.is_dir():
            parent=parent.parent
        if parent==cfg.root and parent!=path.parent:
            print('Recursive source watcher for absent parent:',path,flush=True)
        return watch_path(changes,path)
    def diagnostic(watch):
        try:
            return watch_poll(watch)
        except OSError as exc:
            raise OSError(f'{watch.directory}: {exc}') from exc
    with patch.object(Path,'write_text',wrapped_text), patch.object(Path,'write_bytes',wrapped_bytes), \
            patch.object(shutil,'copyfile',wrapped_copy), patch.object(DirectoryWatch,'poll',diagnostic), \
            patch.object(os,'unlink',wrapped_unlink), patch.object(os,'rmdir',wrapped_rmdir), \
            patch.object(Changes,'watch',trace_watch):
        yield

try:
    if stage=='translate':
        catalog=release/'english.json'
        before=catalog.read_bytes()
        (out/'before.json').write_bytes(before)
        prepare_catalog(cfg,catalog,translate=True)
        a=json.loads(before)['strings']
        b=json.loads(catalog.read_bytes())['strings']
        result=dict(status='translated',changed=[k for k,v in b.items() if a.get(k)!=v],
                    removed=[k for k in a if k not in b],catalog_sha256=sha(catalog))
    elif stage=='audit':
        model=KnowledgeModel.load(cfg.facts_path)
        dump=cfg.build_dir/'prompts'
        agent=Agent(cfg.agent,dump_dir=dump)
        agent._counter=max((int(p.name.split('_',1)[0]) for p in dump.glob('*_*.md') if p.name.split('_',1)[0].isdigit()),default=0)
        report=cfg.build_dir/'consistency-review.json'
        (out/'before.json').write_bytes(report.read_bytes())
        audit_report=audit(cfg,model,agent)
        result={k:audit_report[k] for k in ['status','source_commit','fresh_batches','reused_batches','source_equivalent_batches','human_review','unresolved']}
        result['report_sha256']=sha(report)
    elif stage=='export':
        destination=Path(sys.argv[3]) if len(sys.argv)>3 else out
        with (nullcontext() if attempt=='05' else drain_staging_notifications(cfg)):
            first=export_site(cfg,destination/'first')
            final=export_site(cfg,destination/'final')
        m=first/'site-manifest.json'
        assert m.read_bytes()==(final/'site-manifest.json').read_bytes()
        result=dict(status='verified',site_directory=str(final),manifest_sha256=sha(m),build_id=json.loads(m.read_bytes())['build_id'],
                    outputs=len(json.loads(m.read_bytes())['outputs']),site=verify_site(final))
    else:
        raise ValueError(stage)
    result.update(seconds=time.monotonic()-start,human_review='pending')
    (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False),flush=True)
except BaseException as e:
    (out/'failure.json').write_text(json.dumps(dict(error=str(e),type=type(e).__name__,stage=stage,seconds=time.monotonic()-start),ensure_ascii=False,indent=2),encoding='utf-8')
    raise
