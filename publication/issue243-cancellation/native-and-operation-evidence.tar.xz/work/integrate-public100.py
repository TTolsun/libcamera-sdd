from pathlib import Path
import hashlib
import json
import subprocess
import sys
import yaml

from sdd.config import load
from sdd.localization_cli import prepare_catalog

work=Path(__file__).resolve().parent
release=work/'c19-release'
public=work.parents[1]/'build/issue243/public-sdd'
def manifest(ref):
    raw=subprocess.check_output(['git','show',ref+':docs/site-manifest.json'],cwd=public)
    return json.loads(raw)

old,new=manifest('76a4640'),manifest('origin/main')
assert old['engine']==new['engine']
assert set(old['outputs'])-set(new['outputs'])=={
    'reader-work.html','reader-decision.html','en/reader-work.html','en/reader-decision.html'}
assert {k for k in old['inputs']|new['inputs'] if old['inputs'].get(k)!=new['inputs'].get(k)}=={
    'configuration','english_catalog','reader_paths'}
assert old['inputs']['consistency_review']==new['inputs']['consistency_review']
catalog=release/'english.json'
before_path=work/'before-public100-english.json'
if '--bind-published-context' not in sys.argv:
    for name in ('publication.yaml','review.yaml'):
        p=release/name
        before=p.read_bytes()
        (work/('before-public100-'+name)).write_bytes(before)
        cfg=yaml.safe_load(before)
        assert cfg['site'].pop('reader_paths')
        p.write_text(yaml.safe_dump(cfg,allow_unicode=True,sort_keys=False),encoding='utf-8')
    before_path.write_bytes(catalog.read_bytes())
    prepare_catalog(load(release/'publication.yaml'),catalog,translate=False)
before=before_path.read_bytes()
previous=json.loads(before)['strings']
prepared=json.loads(catalog.read_bytes())
current=prepared['strings']
published=Path('C:/Users/baboe/.codex/worktrees/5dee/camera-hal-sdd-generator/build/reader-retirement/english.json').read_bytes()
published_sha=hashlib.sha256(published).hexdigest()
assert published_sha==new['inputs']['english_catalog']
authoritative=json.loads(published)
assert authoritative['source_commit']==prepared['source_commit']
restored=[]
for key,value in current.items():
    if value.strip():
        continue
    ctx=prepared['translation_contexts'][key]
    assert ctx==authoritative['translation_contexts'][key]
    for row in ctx:
        for sid in row['source_ids']:
            assert prepared['source_contexts'][sid]==authoritative['source_contexts'][sid]
    assert previous[key]==authoritative['strings'][key] and previous[key].strip()
    current[key]=authoritative['strings'][key]
    restored.append(dict(source_sha256=hashlib.sha256(key.encode()).hexdigest(),
                         translation_sha256=hashlib.sha256(current[key].encode()).hexdigest()))
assert all(previous.get(k)==v and v.strip() for k,v in current.items())
(work/'public100-unbound-catalog.json').write_bytes(catalog.read_bytes())
catalog.write_text(json.dumps(prepared,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
# The baseline deliberately probes this absent default config path. Restore the
# empty parent directory to keep the Windows watcher scoped to that directory.
missing=release/'prior98/base/config/sections.yaml'
assert not missing.exists()
missing.parent.mkdir(parents=True,exist_ok=True)
result=dict(source_commit='c19d05128f3ae1f0ebe63acb4deaca9fbb1dde78',
    incorporated_public_commit='0c519bf59f465149f4de85b6716090d2c0694640',
    removed_role_pages=sorted(set(old['outputs'])-set(new['outputs'])),
    retained_translations=len(current),removed_unused_strings=len(previous)-len(current),
    published_catalog_sha256=published_sha,restored_published_contexts=restored,
    new_cli_calls=0,absent_baseline_file_preserved=True,human_review='pending')
(work/'public100-integration.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result),flush=True)
