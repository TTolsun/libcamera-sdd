from pathlib import Path
import hashlib
import json
import subprocess
import time

import html5lib
from sdd.publication import verify_remote
from sdd.site_build import verify_site

work = Path(__file__).resolve().parent
root = work.parents[1]
public = root / 'build/issue243/public-sdd'
source = root / 'build/issue243/libcamera293'
site = public / 'docs'
sha = lambda b: hashlib.sha256(b).hexdigest()


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])


def write(name, payload):
    path = work / name
    with path.open('x', encoding='utf-8', newline='\n') as out:
        json.dump(payload, out, ensure_ascii=False, indent=2)
        out.write('\n')


def rendered(name, predicates):
    raw = (site / name).read_bytes()
    document = html5lib.parse(raw.decode('utf-8'), namespaceHTMLElements=False)
    article = next(document.iter('article'))
    matched = []
    for node in article.iter():
        if node.tag not in {'p', 'li', 'h2', 'h3', 'h4'}:
            continue
        text = ' '.join(''.join(node.itertext()).split())
        if any(all(term in text for term in terms) for terms in predicates):
            matched.append(dict(text=text, id=node.attrib.get('id')))
    assert matched, name
    return dict(path=name, sha256=sha(raw), selected=matched)


def prepare(output='latest-public-plan.json'):
    before = json.loads((work / 'final-plan-04-compact.json').read_bytes())
    public_commit = git(public, 'rev-parse', 'HEAD').decode().strip()
    assert public_commit == git(public, 'rev-parse', 'origin/main').decode().strip()
    raw = (public/'docs/contract-consistency.json').read_bytes()
    report = json.loads(raw)
    revision = report['source_commit']
    assert report['status'] == 'passed' and report['human_review'] == 'pending'
    assert not report['unresolved']
    assert not any(f['status'] == 'contradiction' for g in report['contracts'] for f in g['findings'])
    windows = {}
    for name, spec in {
        'queue-api-and-guards': ('src/libcamera/camera.cpp', 1308, 1384),
        'access-state': ('src/libcamera/camera.cpp', 690, 735),
        'access-overloads': ('include/libcamera/internal/camera.h', 49, 65),
        'configuration-validation-contract': ('src/libcamera/camera.cpp', 322, 347),
        'configure-validation-branch': ('src/libcamera/camera.cpp', 1191, 1239),
        'pipeline-completion-and-cancellation': ('src/libcamera/pipeline_handler.cpp', 545, 620),
        'internal-completion-and-cancellation': ('src/libcamera/request.cpp', 90, 170),
        'queued-invocation': ('src/libcamera/base/bound_method.cpp', 11, 99),
    }.items():
        path, lo, hi = spec
        current = git(source, 'show', revision+':'+path)
        previous = git(source, 'show', before['source_commit']+':'+path)
        lines = current.decode().splitlines(keepends=True)
        text = ''.join(lines[lo-1:hi])
        assert len(lines) >= hi
        windows[name] = dict(file=path, line=lo, end_line=hi, text=text,
                             sha256=sha(text.encode()), same_file_bytes_as_original=current==previous)

    queue = [rendered('camera-requests.html', [('앞선 접근', 'buffers'), ('빈 버퍼 검사', 'activeStreams_'), ('invokeMethod', 'requestCompleted')]),
             rendered('en/camera-requests.html', [('preceding access', 'buffers'), ('stream iteration', 'activeStreams_'), ('invokeMethod', 'requestCompleted')])]
    investigation = [rendered('request-diagnosis.html', [('config->validate()', '-EINVAL'), ('Adjusted', '호출자')]),
                     rendered('en/request-diagnosis.html', [('investigation plan', 'config->validate()', '-EINVAL'), ('Adjusted', 'caller')])]
    completion = [rendered('pipeline-requests.html', [('일반', 'completeBuffer'), ('cancelRequest', 'completeRequest'), ('CameraManager', 'completeRequest'), ('일반적인 버퍼 완료',), ('일반적인 완료 경로',)]),
                  rendered('en/pipeline-requests.html', [('completion', 'completeBuffer'), ('cancelRequest', 'completeRequest'), ('CameraManager', 'completeRequest'), ('typical buffer completion',), ('typical completion path',), ('normal completion path',)])]
    diagrams = {}
    for name in ('pipeline-requests.buffer-request-completion.mmd', 'en/pipeline-requests.buffer-request-completion.mmd',
                 'request-diagnosis.submission-checks.mmd', 'en/request-diagnosis.submission-checks.mmd',
                 'request-diagnosis.configure-failures.mmd', 'en/request-diagnosis.configure-failures.mmd',
                 'request-diagnosis.configuration-implementation-observation.mmd',
                 'en/request-diagnosis.configuration-implementation-observation.mmd'):
        raw = (site / name).read_bytes()
        diagrams[name] = dict(sha256=sha(raw), text=raw.decode())
    contexts = [investigation, completion, queue, queue]
    cases = []
    for prior, current in zip(before['cases'], contexts):
        cases.append(dict(id=prior['id'], historical_finding={k: prior['finding'][k] for k in ['status','reason','claim_quote']}, current_rendered=current))
    plan = dict(schema=1, public_commit=public_commit, source_commit=revision, report_sha256=sha(raw),
                cases=cases, required_checks=before['required_checks'], source_windows=windows,
                current_diagrams=diagrams, human_review='pending',
                review_reason='Judge the actual rendered texts and diagrams against the complete relevant pinned source windows. Previous review exposed a new status-timing error and an omitted Adjusted excerpt. This candidate separates internal cancelled_ from later RequestCancelled, explicitly scopes the ordinary-completion figure, and restores the literal validation contract. Historical verdicts are context, not a success oracle.')
    if output!='latest-public-plan.json':
        plan['candidate_based_on_public_commit']=public_commit
        plan['prior_review_sha256']=sha((work/'native-review-latest-01/review.json').read_bytes())
        plan['candidate_not_yet_deployed']=True
    write(output, plan)
    print('Prepared',len(cases),'findings and',len(windows),'literal source windows',flush=True)


if __name__ == '__main__':
    import sys
    if sys.argv[1:] == ['remote']:
        begin = time.monotonic()
        manifest = (site/'site-manifest.json').read_bytes()
        verification = verify_site(site)
        build = verify_remote(site, 'https://ttolsun.github.io/libcamera-sdd')
        record = dict(status='verified', public_commit=git(public,'rev-parse','HEAD').decode().strip(),
                      build_id=build, manifest_sha256=sha(manifest), outputs=len(json.loads(manifest)['outputs']),
                      local=verification, human_review='pending', seconds=time.monotonic()-begin)
        write('latest-live-verification.json', record)
        print(json.dumps(record, ensure_ascii=False),flush=True)
    elif sys.argv[1:2]==['candidate']:
        from sdd.config import load
        from sdd.export_site import _render_site
        from sdd.validation_stage import staged
        release=work/'c19-release'
        site=work/'c19-private-final'
        if sys.argv[2:]!=['--reuse-render']:
            site=staged(_render_site)(load(release/'publication.yaml'),site,check_consistency=False)
        verify_site(site,manifest=False)
        prepare('c19-final-review-plan.json')
    else:
        prepare()
