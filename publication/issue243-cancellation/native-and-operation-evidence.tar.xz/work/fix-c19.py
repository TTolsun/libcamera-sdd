from copy import deepcopy
from pathlib import Path
import hashlib
import json
import re
import sys
import time

import yaml
from sdd.config import load
from sdd.contract_schema import configuration_errors
from sdd.design_execution import _request_unit
from sdd.design_request import _design_units, prepare_requests
from sdd.document_metadata import split_frontmatter
from sdd.evidence import collect
from sdd.facts.model import KnowledgeModel
from sdd.generate import Generator
from sdd.generated_design import _assemble_generation, verify
from sdd.generation_run import Execution
from sdd.llm import Agent

work=Path(__file__).resolve().parent
root=work.parents[1]
release=work/'c19-release'
cfg=load(release/'publication.yaml')
prepared='--prepared' in sys.argv
out=work/('c19-scoped-repair-02' if prepared else 'c19-scoped-repair')
out.mkdir()
source=dict(id='cancel-status-transition',file='src/libcamera/request.cpp',
            start='void Request::Private::complete()',end='void Request::Private::doCancelRequest()')
selection=dict(sections=[dict(id='pipeline-requests',design_topics=[
    dict(id='completion',question='Request status transition after setting the internal flag.',sources=[source])])])
selection_path=out/'source-selection.yaml'
selection_path.write_text(yaml.safe_dump(selection,sort_keys=False),encoding='utf-8')
question=('cancelRequest에서 대기 버퍼를 취소하고 각각 bufferCompleted를 발생시키는 내부 처리와 '
          '그 뒤 completeRequest를 호출하는 순서를 설명하세요. 내부 취소에서 cancelled_ 플래그를 '
          '설정하고 대기 버퍼 목록을 비우는 시점과, 이후 Request::Private::complete()가 요청 상태에 '
          'RequestCancelled를 대입하는 시점을 구분하세요. 일반 완료의 completeBuffer 호출 의무나 '
          '반환 뒤 접근 및 스레드 계약은 반복하지 마세요.')
for path in (() if prepared else (root/'examples/libcamera/config/sections.yaml',cfg.sections_file)):
    text=path.read_text(encoding='utf-8')
    start=text.index('- id: pipeline-requests\n')
    topic=text.index('  - id: completion\n',start)
    pending=text.index('    - id: ordering-contract\n',topic)
    block='    - id: cancel-status-transition\n      file: src/libcamera/request.cpp\n      start: void Request::Private::complete()\n      end: void Request::Private::doCancelRequest()\n'
    text=text[:pending]+block+text[pending:]
    at=text.index('    - id: cancel\n',topic)
    q=text.index('      question:',at)
    sources=text.index('      sources:',q)
    text=text[:q]+'      question: '+question+'\n'+text[sources:]
    contract=text.index('      answer_contract:',q)
    text=text[:contract]+'      - request-contract\n      - cancel-status-transition\n'+text[contract:]
    terms=text.index('        - - completeRequest\n',contract)+len('        - - completeRequest\n')
    text=text[:terms]+'        - - cancelled_\n        - - RequestCancelled\n'+text[terms:]
    yaml.safe_load(text)
    path.write_text(text,encoding='utf-8')

figure=json.loads((work/'figure-scope-01/draft.json').read_bytes())
for path in (() if prepared else (root/'examples/libcamera/config/visuals.yaml',Path(cfg.raw['visuals']['file']))):
    text=path.read_text(encoding='utf-8')
    start=text.index('  - id: buffer-request-completion\n')
    a=text.index('    title:',start)
    b=text.index('    nodes:',a)
    text=text[:a]+f"    title: {figure['title']} {{#버퍼-완료에서-요청-반환까지}}\n    question: {figure['question']}\n"+text[b:]
    yaml.safe_load(text)
    path.write_text(text,encoding='utf-8')

cfg=load(release/'publication.yaml')
section=next(s for s in cfg.sections() if s['id']=='pipeline-requests')
assert not configuration_errors(section),configuration_errors(section)
model=KnowledgeModel.load(cfg.facts_path)
select_cfg=deepcopy(cfg)
select_cfg.paths['sections_file']=selection_path
select_cfg.raw['documentation']={'enabled':False}
selected=deepcopy(model)
collect(select_cfg,selected)
assert len(selected.evidence)==1
sid,record=next(iter(selected.evidence.items()))
assert sid not in model.evidence and 'request->status_ = cancelled_' in record['text']
model.evidence[sid]=record
model.save(cfg.facts_path)
(out/'source-record.json').write_text(json.dumps({sid:record},ensure_ascii=False,indent=2),encoding='utf-8')

path=cfg.sdd_dir/'pipeline-requests.md'
before=path.read_bytes()
(out/'before.md').write_bytes(before)
old_meta,_=split_frontmatter(before.decode())
old=old_meta['generated_design']
plan=prepare_requests(cfg,model,section,before.decode())
answers=deepcopy(old['answers'])
rows=answers['completion']
ix,= [i for i,x in enumerate(rows) if x.get('part_id')=='cancel']
answers['completion']=rows[:ix]+rows[ix+1:]
dump=cfg.build_dir/'prompts'
agent=Agent(cfg.agent,dump_dir=dump)
agent._counter=max((int(p.name.split('_',1)[0]) for p in dump.glob('*_*.md') if p.name.split('_',1)[0].isdigit()),default=0)
execution=Execution(cfg,agent,model=model)
execution.path=out/'generation-run.json'
unit=next(x for x in _design_units(section,{}) if x['id']=='completion' and x.get('_part_id')=='cancel')
started=time.monotonic()
with execution.track('scoped-cancel-status'):
    statements,native=_request_unit(cfg,model,execution,section,unit,plan.prompts['completion'],plan.policy['design_grounding'],None,answers)
    assert len(statements)==1 and statements[0].get('part_id')=='cancel'
    answers['completion']=rows[:ix]+statements+rows[ix+1:]
    result=_assemble_generation(cfg,model,section,answers,deepcopy(old['topic_inputs']),
        [t for t in answers if t!='completion'],[],deepcopy(old['topic_agents']),plan.policy)
    result.artifact['partial_revision']=dict(topic='completion',parts=['cancel'],
        prior_manuscript_sha256=hashlib.sha256(before).hexdigest(),native_record=native,
        human_review='pending',retained_topic_identities='Historical identities retained.')
    gen=Generator(cfg,model,execution)
    gen.generated_designs['pipeline-requests']=result
    written=gen._prose(section)
    verify(model,section,written.read_text(encoding='utf-8'),cfg=cfg)
new_meta,_=split_frontmatter(written.read_text(encoding='utf-8'))
assert new_meta['semantic_review']==old_meta['semantic_review']
assert new_meta['generated_design']['answers']==answers
assert [(t,i) for t,rr in old['answers'].items() for i,st in enumerate(rr)
        if st!=answers[t][i]]==[('completion',ix)]
record=dict(status='generated',new=statements[0],old=rows[ix],retained=sum(map(len,answers.values()))-1,
            human_review='pending',seconds=time.monotonic()-started)
(out/'result.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(record,ensure_ascii=False),flush=True)
