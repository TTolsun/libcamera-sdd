<!-- system -->
Return exactly OK. No tools.

<!-- user -->
Confirm this selected model and effort can complete this call.
