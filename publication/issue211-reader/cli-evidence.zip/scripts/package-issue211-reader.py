"""Preserve the earlier release and package only this public reader correction."""
from pathlib import Path
import json,gzip,shutil,zipfile,yaml
from sdd.runtime_evidence import sha256
from sdd.site_build import verify_site
root=Path(__file__).resolve().parent.parent;work=root/'build/issue211-reader';repo=root/'build/libcamera-sdd-issue211'
site=repo/'docs';validated=verify_site(site)
manifest=json.loads((site/'site-manifest.json').read_text(encoding='utf-8'))
inventory=json.loads((work/'windows/published-v9/inventory.json').read_text(encoding='utf-8'))
for lang,rel in [('ko','official-cam-validation.html'),('en','en/official-cam-validation.html')]:
    if inventory[lang]['html_sha256']!=sha256(site/rel):raise ValueError('Reviewed page changed: '+lang)
for selected in ['bilingual-navigation','config-reference-current-source']:
    if json.loads((work/f'reviews/{selected}/review.json').read_text())['review']['verdict']!='pass':raise ValueError('Review has unresolved findings: '+selected)
merges=json.loads((work/'generator-merge.json').read_text())
if len(merges['pull_requests'])!=4 or not all(row['merged'] for row in merges['pull_requests']):raise ValueError('All generator PRs must be merged first')
package=repo/'publication/issue211-reader';package.mkdir(exist_ok=False)
(package/'previous-release').mkdir()
for name in ['README.md','run.json','generation-receipts.json']:shutil.copyfile(repo/name,package/'previous-release'/name)
for src,dst in [('config','config'),('run/manuscripts','manuscripts'),('historical-style','historical-style'),('reviews','reviews'),('windows/published-v9','rendered-review-window')]:
    shutil.copytree(work/src,package/dst)
shutil.copytree(root/'style',package/'current-style')
(package/'reviews/acceptance.json').write_text(json.dumps(dict(schema=1,
    accepted=['bilingual-navigation/review.json','config-reference-current-source/review.json'],
    acceptance_rule='Only the final full-site bilingual review, bound to the identical published HTML hashes, is current page acceptance. Earlier draft verdicts do not establish final acceptance.',
    excluded={'final-korean-accepted/review.json':'Fresh render directory creation failed; this invocation received an earlier window. Preserved, never used for acceptance.'},
    human_review='pending'),indent=2)+'\n',encoding='utf-8')
(package/'facts293.json.gz').write_bytes(gzip.compress((work/'run/facts/facts.json').read_bytes(),mtime=0))
for src,dst in [('run/english.json','english.json'),('site-intro.md','site-intro.md'),('native-call-verification.json','native-call-verification.json'),('native-verification-before-bilingual.json','native-verification-before-bilingual.json'),('publication-notes-review-input.json','publication-notes-review-input.json'),('generator-merge.json','generator-merge.json'),('upstream-sync.json','upstream-sync.json'),('build/consistency-review.json','consistency-review.json')]:
    shutil.copyfile(work/src,package/dst)
(package/'profiles').mkdir()
for name in ['generation.yaml','publication.yaml','reader-verification.yaml','historical-contract-review.yaml','new-document-review.yaml']:
    shutil.copyfile(work/name,package/'profiles'/name)
for name in ['generation-profile.yaml','independent-review-profile.yaml']:
    shutil.copyfile(root/'examples/libcamera/validation/issue211'/name,package/'profiles'/name)
roles=dict(schema=1,current_page='Selected native Claude writing/translation/visuals, current style; independent native Terra review',
           unchanged_pages='Exact historical style and original visual identity authentication only; no current-policy whole-site review or issue215 completion',
           historical_contract='Original retained Haiku audit; not a new Terra run',model_calls_during_export=False,global_defaults_changed=False,
           paths='Original execution-specific absolute paths retained as evidence, not a relocatable configuration')
(package/'profiles/roles.json').write_text(json.dumps(roles,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(work/'notes/README.md',package/'README.md');shutil.copyfile(work/'notes/root-README.md',repo/'README.md')
visual_review=dict(schema=1,source_commit='293d751a814e0d4c34e85ad457ccd9d5eefd1a61',topics=[
    dict(topic='conclusion',visual='omitted',reason='One short obstacle/result/restored-state distinction is explained in prose; independently reviewed omission'),
    dict(topic='flow',visual='completion-flow',purpose='Cancellation, event-loop processing, limit/completion and requeue branches'),
    dict(topic='reproduce',visual='reproduction-flow',purpose='Approval, conditional Docker stop, exact prerequisites and no-capture mismatch path')],
    independent_review='reviews/bilingual-navigation/review.json',human_review='pending',unreviewed='Whole-site issue215 migration, hardware and internal HAL')
(package/'topic-visual-review.json').write_text(json.dumps(visual_review,indent=2)+'\n',encoding='utf-8')
index={};sources=[]
for parent in [work/'build/prompts',work/'build/translation-prompts',work/'build/cli-checkpoints',work/'build/generation-runs',work/'notes',work/'executions',*work.glob('before-*'),*work.glob('profile-documentation*'),*work.glob('translation*')]:
    if parent.is_dir():sources.extend((p,'workspace/'+p.relative_to(work).as_posix()) for p in parent.rglob('*') if p.is_file())
for parent in [root/'examples/libcamera/validation/issue211-reader']:
    sources.extend((p,'generator/'+p.relative_to(root).as_posix()) for p in parent.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for name in ['package-issue211-reader.py','verify-reader-native.py','verify-reader-package.py','verify-reader-live.py','review-reader-config.py','write-reader-config.py','write-reader-heading.py','export-issue211-reader.py']:
    sources.append((root/'build'/name,'scripts/'+name))
with zipfile.ZipFile(package/'cli-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p,name in sorted(sources,key=lambda row:row[1]):
        if any(part.startswith('call-') for part in p.parts[:-1]):continue
        if name in index:raise ValueError('Duplicate archive path')
        z.write(p,name);index[name]=sha256(p)
(package/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
merge=json.loads((work/'generator-merge.json').read_text());writer=yaml.safe_load((work/'generation.yaml').read_text())['agent'];reviewer=yaml.safe_load((work/'new-document-review.yaml').read_text())['agent']
run=dict(schema=1,source_repository='https://gitlab.freedesktop.org/camera/libcamera.git',source_commit='293d751a814e0d4c34e85ad457ccd9d5eefd1a61',upstream_changed=False,
         generator_prs=['https://github.com/TTolsun/camera-hal-sdd-generator/pull/217','https://github.com/TTolsun/camera-hal-sdd-generator/pull/219','https://github.com/TTolsun/camera-hal-sdd-generator/pull/220','https://github.com/TTolsun/camera-hal-sdd-generator/pull/221'],generator_merge=merge,
         build_id=manifest['build_id'],manifest_sha256=sha256(site/'site-manifest.json'),manifest_outputs=len(manifest['outputs']),
         validation=validated,reader_page_html_sha256={l:inventory[l]['html_sha256'] for l in ['ko','en']},
         facts_sha256=sha256(work/'run/facts/facts.json'),english_catalog_sha256=sha256(work/'run/english.json'),
         native_writer=writer,native_reviewer=reviewer,new_runtime_execution=False,runtime_records='publication/issue211',human_review='pending',
         deployment='Predeployment record; actual Pages and live output hashes recorded after merge in the publication PR')
receipts=dict(schema=1,scope='New reader correction calls separately verified; copied historical calls retain original identities; semantic rejections and failed attempts preserved',writer=writer,reviewer=reviewer,
              native_call_verification='publication/issue211-reader/native-call-verification.json',archive_index='publication/issue211-reader/archive-index.json',human_review='pending')
for name,data in [('run.json',run),('generation-receipts.json',receipts)]:
    for target in [repo/name,package/name]:target.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
files={p.relative_to(package).as_posix():sha256(p) for p in sorted(package.rglob('*')) if p.is_file()}
(package/'evidence-index.json').write_text(json.dumps(dict(schema=1,files=files,site_manifest=run['manifest_sha256'],site_outputs=manifest['outputs']),indent=2)+'\n',encoding='utf-8')
with (repo/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:f.write('\n# Preserve exact reader-correction native records and original history.\npublication/issue211-reader/** -text -whitespace\n')
print(dict(package_files=len(files),archive_files=len(index),zip_bytes=(package/'cli-evidence.zip').stat().st_size,build_id=manifest['build_id']))
