from pathlib import Path
import json
from sdd.config import load
from sdd.call_records import load_record
from sdd.cli_provenance import verify_cli_receipt
from sdd.runtime_evidence import sha256
root=Path(__file__).resolve().parent.parent
work=root/'build/issue211-reader'
old=root/'build/issue211-publication'
historical={sha256(p) for p in old.rglob('*.receipt.json')}
profiles={runner:load(root/'examples/libcamera/validation/issue211'/file).agent for runner,file in [('claude','generation-profile.yaml'),('codex','independent-review-profile.yaml')]}
rows=[];retained=[]
for path in sorted(work.rglob('*.receipt.json')):
    if any(part.startswith('call-') for part in path.parts[:-1]):continue
    if sha256(path) in historical:
        retained.append(path.relative_to(work).as_posix());continue
    data=json.loads(path.read_text(encoding='utf-8'))
    if data.get('transport')!='cli':continue
    rec=load_record(path)
    runner=data['provider']['runner']
    result=verify_cli_receipt(rec.request,rec.raw,rec.receipt,path.parent.parent,profiles[runner])
    rows.append(dict(receipt=path.relative_to(work).as_posix(),sha256=sha256(path),model=data['model'],runner=runner,tag=data['tag'],completed_at=data['completed_at'],verified=result))
if not rows or not any(r['runner']=='claude' for r in rows) or not any(r['runner']=='codex' for r in rows):raise ValueError('Missing selected native calls')
out=dict(schema=1,new_completed_calls=rows,retained_historical_receipts=retained,
         scope='Integrity and exact selected native CLI arguments only; semantic outcomes live in individual reviews. Rejected drafts and failed attempts are not relabeled accepted.',human_review='pending',http_calls=0)
(work/'native-call-verification.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(dict(new_completed=len(rows),historical_retained=len(retained)))
