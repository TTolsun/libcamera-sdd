from pathlib import Path
import sys,json
from sdd.runtime_evidence import run_recorded,require_success
root=Path(__file__).resolve().parent.parent;work=root/'build/issue211-reader'
out=work/'executions'/(sys.argv[1] if len(sys.argv)>1 else 'public-site-export')
run_recorded(out,[sys.executable,'-X','utf8','-m','sdd.cli','--config',str(work/'publication.yaml'),'export-site','--out',str(root/'build/libcamera-sdd-issue211/docs')],timeout=1800,cwd=root)
require_success(out)
print((out/'stdout').read_text(encoding='utf-8'))
