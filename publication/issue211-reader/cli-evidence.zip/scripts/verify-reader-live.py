from pathlib import Path
import hashlib,json,sys,urllib.request
from sdd.runtime_evidence import run_recorded,require_success,sha256
root=Path(__file__).resolve().parent.parent;work=root/'build/issue211-reader';site=root/'build/libcamera-sdd-issue211/docs'
out=work/'executions/live-publication'
argv=[sys.executable,'-X','utf8','-m','sdd.cli','--config',str(work/'publication.yaml'),'verify-publication','--url','https://ttolsun.github.io/libcamera-sdd/','--site',str(site),'--timeout','900','--interval','10']
run_recorded(out,argv,timeout=950,cwd=root);require_success(out)
manifest=json.loads((site/'site-manifest.json').read_text(encoding='utf-8'))
rows=[]
for rel,name in [('site-manifest.json','manifest.json'),('official-cam-validation.html','ko.html'),('en/official-cam-validation.html','en.html')]:
    url='https://ttolsun.github.io/libcamera-sdd/'+rel
    with urllib.request.urlopen(urllib.request.Request(url,headers={'Cache-Control':'no-cache'}),timeout=45) as response:
        data=response.read();status=response.status;headers=dict(response.headers)
    digest=hashlib.sha256(data).hexdigest();expected=sha256(site/rel)
    if status!=200 or digest!=expected:raise ValueError('Live bytes differ: '+rel)
    (out/name).write_bytes(data)
    rows.append(dict(url=url,status=status,sha256=digest,expected_sha256=expected,headers=headers))
result=dict(schema=1,build_id=manifest['build_id'],all_manifest_outputs_verified=len(manifest['outputs']),manifest_sha256=sha256(site/'site-manifest.json'),selected_live_bytes=rows,verification_record_sha256=sha256(out/'record.json'),stdout_sha256=sha256(out/'stdout'),stderr_sha256=sha256(out/'stderr'))
(out/'live.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
