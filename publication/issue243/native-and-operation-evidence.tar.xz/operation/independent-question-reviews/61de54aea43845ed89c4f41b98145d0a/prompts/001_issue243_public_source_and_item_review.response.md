{
  "verdict": "insufficient-evidence",
  "checks": [
    {
      "id": "invalid-extreme",
      "status": "supported",
      "reason": "Invalid means the configuration is invalid and cannot be adjusted; an empty configuration is an example of an extreme case where it may occur.",
      "source_ids": ["vendor-assurance/constraints/invalid"]
    },
    {
      "id": "adjusted-state",
      "status": "supported",
      "reason": "Adjusted indicates that the configuration was adjusted and is now valid.",
      "source_ids": ["vendor-assurance/constraints/adjusted-state"]
    },
    {
      "id": "adjusted-changes",
      "status": "supported",
      "reason": "The text preserves the possibility of changes to any stream and removal of stream configurations, without asserting that every stream changed.",
      "source_ids": ["vendor-assurance/constraints/adjusted-changes"]
    },
    {
      "id": "adjusted-review",
      "status": "supported",
      "reason": "The caller must check an adjusted configuration carefully.",
      "source_ids": ["vendor-assurance/constraints/adjusted"]
    },
    {
      "id": "valid",
      "status": "supported",
      "reason": "Valid means the configuration was already valid and was not adjusted.",
      "source_ids": ["vendor-assurance/constraints/valid"]
    },
    {
      "id": "roles-valid",
      "status": "supported",
      "reason": "The documented return is a valid configuration when the requested roles can be satisfied.",
      "source_ids": ["vendor-assurance/constraints/generate-contract"]
    },
    {
      "id": "roles-null",
      "status": "supported",
      "reason": "The documented return is a null pointer when the requested roles cannot be satisfied.",
      "source_ids": ["vendor-assurance/constraints/generate-result"]
    },
    {
      "id": "no-success-before-null",
      "status": "supported",
      "reason": "The diagram describes a request to generate a default configuration before branching; it does not claim generation succeeded before the null branch.",
      "source_ids": ["vendor-assurance/constraints/generate-contract"]
    },
    {
      "id": "configure-input",
      "status": "supported",
      "reason": "The interface contract guarantees prior validation and prohibits further validation by the pipeline handler implementation.",
      "source_ids": ["vendor-assurance/constraints/configure-input"]
    },
    {
      "id": "configure-result",
      "status": "supported",
      "reason": "The documented contract returns zero on success and a negative error code otherwise; prior validation is not presented as a guarantee of success.",
      "source_ids": ["vendor-assurance/constraints/configure-result"]
    },
    {
      "id": "measurement-scope",
      "status": "supported",
      "reason": "The stated benchmark measures statistics collection and debayering, excluding frame capture and output.",
      "source_ids": ["vendor-assurance/measurement/benchmark"]
    },
    {
      "id": "measurement-procedure",
      "status": "supported",
      "reason": "The source describes running cam or qcam with a Software ISP pipeline; no measured result is claimed.",
      "source_ids": ["vendor-assurance/measurement/benchmark"]
    },
    {
      "id": "bilingual-diagrams",
      "status": "supported",
      "reason": "The Korean and English labels and branches in both supplied local diagrams preserve the documented status and configuration-generation contracts.",
      "source_ids": ["vendor-assurance/constraints/valid", "vendor-assurance/constraints/generate-contract"]
    },
    {
      "id": "class-relationships",
      "status": "supported",
      "reason": "The displayed inheritance arrows and Camera field references match the supplied declarations; the isolated IPAManager node asserts no relationship.",
      "source_ids": ["structural-declaration:libcamera::Camera", "structural-declaration:libcamera::Object", "structural-declaration:libcamera::Extensible", "structural-declaration:libcamera::IPAManager", "structural-declaration:libcamera::PipelineHandler", "structural-declaration:libcamera::PipelineHandlerIPU3", "structural-declaration:libcamera::PipelineHandlerRkISP1"]
    },
    {
      "id": "english-prose",
      "status": "unjudged",
      "reason": "The supplied English translations faithfully convey their Korean text, and the technical passages match the available sources. The claimed end line of the lsc.cpp excerpt and the review-status record cannot be independently verified from the supplied windows.",
      "source_ids": ["translation-source:bc000ee568d90f13e6946b7574d1a92290270b8594bd9449dd54458ba6ac64e3", "translation-source:5b219c0d287985da85343ebfed58f2c0ab7fc65635129141016b21bd45969a40", "translation-source:c1f4cc7aeedfc57e2bc5ebd6825a77f605173b44f7fde564aebc01bb013119cf", "translation-source:1305054b4a0655a883d0cef7398ff34824da06ecdbac0dfbf1f06de218bb6ebc", "translation-source:2247db4a7b9353362f9df6c84aaa5c2810dec4eaaae4b3b36d19c57e427f5790", "translation-source:907d979f60258b4572a0557b6054ec814990084ca3e69a291317855a3b27084d"]
    }
  ],
  "items": [
    {
      "id": "constraints/invalid",
      "status": "appropriate",
      "reason": "The validation-results figure explains Invalid and its extreme-case limitation.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/invalid"],
      "unreviewed_scope": ["Rendered appearance"]
    },
    {
      "id": "constraints/adjusted",
      "status": "appropriate",
      "reason": "The validation-results figure states that adjustment occurred and the configuration is now valid.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/adjusted-state"],
      "unreviewed_scope": ["Rendered appearance"]
    },
    {
      "id": "constraints/adjusted-changes",
      "status": "appropriate",
      "reason": "The validation-results figure shows the possible parameter changes and removal of stream configurations.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/adjusted-changes"],
      "unreviewed_scope": ["Rendered appearance"]
    },
    {
      "id": "constraints/adjusted-review",
      "status": "appropriate",
      "reason": "The validation-results figure states the caller's duty to check the configuration carefully.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/adjusted"],
      "unreviewed_scope": ["Rendered appearance"]
    },
    {
      "id": "constraints/valid",
      "status": "appropriate",
      "reason": "The validation-results figure states that the configuration was already valid and unchanged.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/valid"],
      "unreviewed_scope": ["Rendered appearance"]
    },
    {
      "id": "constraints/roles",
      "status": "appropriate",
      "reason": "The configuration-contract-validity figure distinguishes the valid and null return branches.",
      "figures": ["configuration-contract-validity"],
      "source_ids": ["vendor-assurance/constraints/generate-contract"],
      "unreviewed_scope": ["Rendered appearance"]
    },
    {
      "id": "constraints/configure-input",
      "status": "omit",
      "reason": "The validated-input premise and prohibition on additional validation are adequately expressed in one short statement; neither local figure addresses this contract.",
      "figures": [],
      "source_ids": ["vendor-assurance/constraints/configure-input"],
      "unreviewed_scope": []
    },
    {
      "id": "constraints/configure",
      "status": "omit",
      "reason": "The success and failure return values are adequately expressed in one short statement; neither local figure addresses configure returns.",
      "figures": [],
      "source_ids": ["vendor-assurance/constraints/configure-result"],
      "unreviewed_scope": []
    },
    {
      "id": "measurement/scope",
      "status": "omit",
      "reason": "The included processing and excluded capture and output stages are clearly stated in two short sentences.",
      "figures": [],
      "source_ids": ["vendor-assurance/measurement/benchmark"],
      "unreviewed_scope": []
    },
    {
      "id": "measurement/procedure",
      "status": "omit",
      "reason": "The pipeline environment and two alternative tools are clearly stated in one short sentence.",
      "figures": [],
      "source_ids": ["vendor-assurance/measurement/benchmark"],
      "unreviewed_scope": []
    },
    {
      "id": "class-relationships",
      "status": "appropriate",
      "reason": "The existing class diagram presents the asserted inheritance and field-reference relationships without implying call order.",
      "figures": ["class-diagram"],
      "source_ids": ["structural-declaration:libcamera::Camera", "structural-declaration:libcamera::Object", "structural-declaration:libcamera::Extensible", "structural-declaration:libcamera::IPAManager", "structural-declaration:libcamera::PipelineHandler", "structural-declaration:libcamera::PipelineHandlerIPU3", "structural-declaration:libcamera::PipelineHandlerRkISP1"],
      "unreviewed_scope": ["Rendered appearance", "Relationships outside the displayed declarations"]
    }
  ],
  "new_findings": [],
  "limitations": [
    "No source window was supplied to verify the lsc.cpp excerpt's stated end line or an independent record of the review-status date.",
    "This review covers the supplied source windows and text only; it does not verify rendered diagrams, browser behavior, runtime behavior, the whole site, or in-house implementations.",
    "The cited contracts are not evidence that every implementation conforms, and this automated review is not human approval."
  ]
}
