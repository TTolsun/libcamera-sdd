{
  "verdict": "changes-required",
  "checks": [
    {
      "id": "invalid-extreme",
      "status": "supported",
      "reason": "본문과 두 언어의 그림은 무효와 조정 불가를 함께 설명하고, 빈 구성은 극단적인 경우의 예로 제시합니다.",
      "source_ids": ["vendor-assurance/constraints/invalid"]
    },
    {
      "id": "adjusted-state",
      "status": "supported",
      "reason": "본문과 그림은 Adjusted가 조정된 후 유효한 구성을 뜻한다고 설명합니다.",
      "source_ids": ["vendor-assurance/constraints/adjusted-state"]
    },
    {
      "id": "adjusted-changes",
      "status": "error",
      "reason": "본문은 각 변경 가능성을 보존하지만, 그림의 한국어 표현은 파라미터 변경과 구성 삭제가 함께 발생했을 가능성으로 읽힐 수 있습니다. 두 가능성을 각각 표현해야 합니다.",
      "source_ids": ["vendor-assurance/constraints/adjusted-changes"]
    },
    {
      "id": "adjusted-review",
      "status": "supported",
      "reason": "본문과 그림은 호출자가 구성을 주의 깊게 확인해야 한다는 의무를 보존합니다.",
      "source_ids": ["vendor-assurance/constraints/adjusted"]
    },
    {
      "id": "valid",
      "status": "supported",
      "reason": "본문과 그림은 구성이 이미 유효했고 조정되지 않았다고 설명합니다.",
      "source_ids": ["vendor-assurance/constraints/valid"]
    },
    {
      "id": "roles-valid",
      "status": "supported",
      "reason": "요청한 역할을 충족할 수 있을 때 유효한 구성을 반환한다는 계약과 일치합니다.",
      "source_ids": ["vendor-assurance/constraints/generate-result", "vendor-assurance/constraints/generate-contract"]
    },
    {
      "id": "roles-null",
      "status": "supported",
      "reason": "요청한 역할을 충족할 수 없을 때 null 포인터를 반환한다는 계약과 일치합니다.",
      "source_ids": ["vendor-assurance/constraints/generate-result"]
    },
    {
      "id": "no-success-before-null",
      "status": "supported",
      "reason": "생성 그림의 공통 노드는 기본 구성 생성 요청을 나타내며, null 분기 전에 생성 성공을 주장하지 않습니다.",
      "source_ids": ["vendor-assurance/constraints/generate-contract"]
    },
    {
      "id": "configure-input",
      "status": "supported",
      "reason": "검증된 입력 전제와 파이프라인 핸들러의 추가 검증 금지 의무를 정확히 설명합니다.",
      "source_ids": ["vendor-assurance/constraints/configure-input"]
    },
    {
      "id": "configure-result",
      "status": "supported",
      "reason": "성공 시 0, 실패 시 음수 오류 코드라는 반환 계약을 설명하며 검증만으로 성공을 보장하지 않습니다.",
      "source_ids": ["vendor-assurance/constraints/configure-result"]
    },
    {
      "id": "measurement-scope",
      "status": "supported",
      "reason": "통계 수집과 디베이어링 처리만 측정하고 프레임 캡처와 출력을 제외한다고 명시합니다.",
      "source_ids": ["vendor-assurance/measurement/benchmark"]
    },
    {
      "id": "measurement-procedure",
      "status": "supported",
      "reason": "Software ISP 파이프라인에서 cam 또는 qcam을 실행하는 방법을 제시하며 측정 결과를 주장하지 않습니다.",
      "source_ids": ["vendor-assurance/measurement/benchmark"]
    },
    {
      "id": "bilingual-diagrams",
      "status": "error",
      "reason": "검증 결과 그림의 공통 시작 노드는 한영 모두 항상 구성을 조정하는 것처럼 표시되어 조정되지 않는 Valid와 조정할 수 없는 Invalid로 이어집니다. 소스의 'possibly adjust'에 맞게 조정 가능성을 표현해야 합니다. 또한 한국어 Adjusted 노드는 두 변경 가능성을 각각 독립적으로 표현해야 합니다. 역할 기반 생성 그림의 한영 분기 조건은 근거와 일치합니다.",
      "source_ids": ["vendor-assurance/constraints/valid", "vendor-assurance/constraints/adjusted-changes", "vendor-assurance/constraints/generate-contract"]
    }
  ],
  "items": [
    {
      "id": "constraints/invalid",
      "status": "appropriate",
      "reason": "검증 결과 그림이 Invalid의 의미와 발생 범위를 직접 설명합니다.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/invalid"],
      "unreviewed_scope": ["실제 렌더링"]
    },
    {
      "id": "constraints/adjusted",
      "status": "appropriate",
      "reason": "검증 결과 그림이 조정 여부와 조정 후 유효성을 직접 설명합니다.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/adjusted-state"],
      "unreviewed_scope": ["실제 렌더링"]
    },
    {
      "id": "constraints/adjusted-changes",
      "status": "appropriate",
      "reason": "검증 결과 그림이 질문과 관련되지만 한국어 노드에서 두 변경 가능성을 각각 표현하도록 수정해야 합니다.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/adjusted-changes"],
      "unreviewed_scope": ["실제 렌더링"]
    },
    {
      "id": "constraints/adjusted-review",
      "status": "appropriate",
      "reason": "검증 결과 그림이 호출자의 확인 의무를 직접 설명합니다.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/adjusted"],
      "unreviewed_scope": ["실제 렌더링"]
    },
    {
      "id": "constraints/valid",
      "status": "appropriate",
      "reason": "검증 결과 그림의 Valid 노드가 원래 유효성과 조정 여부를 설명합니다.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/valid"],
      "unreviewed_scope": ["실제 렌더링"]
    },
    {
      "id": "constraints/roles",
      "status": "appropriate",
      "reason": "역할 기반 구성 생성 그림이 요청과 유효 구성 및 null 반환 분기를 직접 보여 줍니다.",
      "figures": ["configuration-contract-validity"],
      "source_ids": ["vendor-assurance/constraints/generate-contract", "vendor-assurance/constraints/generate-result"],
      "unreviewed_scope": ["실제 렌더링"]
    },
    {
      "id": "constraints/configure-input",
      "status": "omit",
      "reason": "검증된 입력과 추가 검증 금지는 짧은 문장으로 충분하며 두 그림은 이 계약을 직접 다루지 않습니다.",
      "figures": [],
      "source_ids": ["vendor-assurance/constraints/configure-input"],
      "unreviewed_scope": []
    },
    {
      "id": "constraints/configure",
      "status": "omit",
      "reason": "성공과 실패의 반환값은 짧은 문장으로 충분하며 별도 그림이 필요하지 않습니다.",
      "figures": [],
      "source_ids": ["vendor-assurance/constraints/configure-result"],
      "unreviewed_scope": []
    },
    {
      "id": "measurement/scope",
      "status": "omit",
      "reason": "측정 단계와 제외 범위가 두 짧은 문장으로 구분되며 두 그림은 해당 범위를 다루지 않습니다.",
      "figures": [],
      "source_ids": ["vendor-assurance/measurement/benchmark"],
      "unreviewed_scope": []
    },
    {
      "id": "measurement/procedure",
      "status": "omit",
      "reason": "파이프라인 환경과 실행 도구를 한 문장으로 설명할 수 있습니다.",
      "figures": [],
      "source_ids": ["vendor-assurance/measurement/benchmark"],
      "unreviewed_scope": []
    }
  ],
  "new_findings": [
    "validation-results의 시작 노드를 한영 모두 '필요하면 조정하고 검증 상태를 반환한다'는 의미로 바꾸면 조정되지 않는 Valid 및 조정 불가 Invalid 분기와 일치합니다.",
    "validation-results의 한국어 Adjusted 노드에서 파라미터 변경과 스트림 구성 삭제를 각각 '~했을 수 있다'고 표현해야 한쪽만 발생할 가능성도 분명해집니다."
  ],
  "limitations": [
    "제공된 소스 발췌와 선택된 페이지의 문장 및 두 현지 그림의 의미와 관련성만 검토했습니다.",
    "클래스 관계 그림을 검증할 소스 발췌는 제공되지 않아 해당 관계는 판단하지 않았습니다.",
    "실제 SVG 렌더링, 브라우저 UI, 런타임, 전체 사이트 및 사내 검증은 수행하지 않았습니다. 이 자동 검토는 사람의 승인이 아닙니다."
  ]
}
