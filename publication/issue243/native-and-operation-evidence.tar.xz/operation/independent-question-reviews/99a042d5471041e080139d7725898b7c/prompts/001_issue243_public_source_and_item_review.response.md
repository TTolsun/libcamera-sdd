{
  "verdict": "insufficient-evidence",
  "checks": [
    {
      "id": "invalid-extreme",
      "status": "supported",
      "reason": "Invalid means the configuration is invalid and cannot be adjusted; the text preserves that it may occur only in extreme cases, with an empty configuration as an example.",
      "source_ids": ["vendor-assurance/constraints/invalid"]
    },
    {
      "id": "adjusted-state",
      "status": "supported",
      "reason": "Adjusted means the configuration was adjusted and is now valid.",
      "source_ids": ["vendor-assurance/constraints/adjusted-state"]
    },
    {
      "id": "adjusted-changes",
      "status": "supported",
      "reason": "The prose preserves the possibility of changes to parameters of any stream and removal of stream configurations without claiming all streams changed.",
      "source_ids": ["vendor-assurance/constraints/adjusted-changes"]
    },
    {
      "id": "adjusted-review",
      "status": "supported",
      "reason": "The caller must check the adjusted configuration carefully.",
      "source_ids": ["vendor-assurance/constraints/adjusted"]
    },
    {
      "id": "valid",
      "status": "supported",
      "reason": "Valid describes a configuration that was already valid and was not adjusted.",
      "source_ids": ["vendor-assurance/constraints/valid"]
    },
    {
      "id": "roles-valid",
      "status": "supported",
      "reason": "The interface contract specifies a valid CameraConfiguration when the requested roles can be satisfied.",
      "source_ids": ["vendor-assurance/constraints/generate-contract"]
    },
    {
      "id": "roles-null",
      "status": "supported",
      "reason": "The interface contract specifies a null pointer otherwise.",
      "source_ids": ["vendor-assurance/constraints/generate-result"]
    },
    {
      "id": "no-success-before-null",
      "status": "supported",
      "reason": "The diagram describes a request to generate a default configuration before branching; it does not assert successful generation before the null branch.",
      "source_ids": ["vendor-assurance/constraints/generate-contract"]
    },
    {
      "id": "configure-input",
      "status": "supported",
      "reason": "The contract guarantees prior validation and prohibits further validation by the pipeline handler implementation.",
      "source_ids": ["vendor-assurance/constraints/configure-input"]
    },
    {
      "id": "configure-result",
      "status": "supported",
      "reason": "The configure contract specifies zero on success and a negative error code otherwise; prior validation is not presented as a guarantee of success.",
      "source_ids": ["vendor-assurance/constraints/configure-result"]
    },
    {
      "id": "measurement-scope",
      "status": "supported",
      "reason": "The benchmark measures statistics collection and debayering processing time, excluding frame capture and output.",
      "source_ids": ["vendor-assurance/measurement/benchmark"]
    },
    {
      "id": "measurement-procedure",
      "status": "supported",
      "reason": "The source describes running cam or qcam with a Software ISP pipeline; no measurement result is claimed.",
      "source_ids": ["vendor-assurance/measurement/benchmark"]
    },
    {
      "id": "bilingual-diagrams",
      "status": "supported",
      "reason": "The Korean and English labels and branches in both local figures preserve the supplied validation and generation contracts.",
      "source_ids": ["vendor-assurance/constraints/valid", "vendor-assurance/constraints/generate-contract"]
    },
    {
      "id": "class-relationships",
      "status": "supported",
      "reason": "Every displayed inheritance and field-reference edge matches the supplied declarations; the diagram does not claim call order.",
      "source_ids": ["structural-declaration:libcamera::Camera", "structural-declaration:libcamera::PipelineHandler", "structural-declaration:libcamera::PipelineHandlerIPU3", "structural-declaration:libcamera::PipelineHandlerRkISP1"]
    },
    {
      "id": "english-prose",
      "status": "unjudged",
      "reason": "The supplied English translations preserve the Korean meaning, and the technical claims match the available windows. The claimed excerpt endpoint for src/ipa/ipu3/algorithms/lsc.cpp cannot be checked because its source window is absent.",
      "source_ids": ["vendor-assurance/constraints/valid", "vendor-assurance/constraints/generate-contract", "vendor-assurance/constraints/configure-input", "vendor-assurance/constraints/configure-result", "vendor-assurance/measurement/benchmark"]
    }
  ],
  "items": [
    {
      "id": "constraints/invalid",
      "status": "appropriate",
      "reason": "The validation-results figure explains Invalid and its extreme-case qualification.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/invalid"],
      "unreviewed_scope": []
    },
    {
      "id": "constraints/adjusted",
      "status": "appropriate",
      "reason": "The validation-results figure states that the configuration was adjusted and is now valid.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/adjusted-state"],
      "unreviewed_scope": []
    },
    {
      "id": "constraints/adjusted-changes",
      "status": "appropriate",
      "reason": "The validation-results figure covers possible changes to any stream's parameters and possible removal of stream configurations.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/adjusted-changes"],
      "unreviewed_scope": []
    },
    {
      "id": "constraints/adjusted-review",
      "status": "appropriate",
      "reason": "The validation-results figure states the caller's duty to check the configuration carefully.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/adjusted"],
      "unreviewed_scope": []
    },
    {
      "id": "constraints/valid",
      "status": "appropriate",
      "reason": "The validation-results figure explains that Valid means the configuration was already valid and unchanged.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/valid"],
      "unreviewed_scope": []
    },
    {
      "id": "constraints/roles",
      "status": "appropriate",
      "reason": "The configuration-contract-validity figure shows the valid-configuration and null return conditions as separate branches.",
      "figures": ["configuration-contract-validity"],
      "source_ids": ["vendor-assurance/constraints/generate-contract"],
      "unreviewed_scope": []
    },
    {
      "id": "constraints/configure-input",
      "status": "omit",
      "reason": "The validated-input premise and prohibition on further validation are conveyed by a short statement; neither local figure addresses configure input.",
      "figures": [],
      "source_ids": ["vendor-assurance/constraints/configure-input"],
      "unreviewed_scope": []
    },
    {
      "id": "constraints/configure",
      "status": "omit",
      "reason": "The success and error return values are conveyed by a short statement; a separate figure is unnecessary.",
      "figures": [],
      "source_ids": ["vendor-assurance/constraints/configure-result"],
      "unreviewed_scope": []
    },
    {
      "id": "measurement/scope",
      "status": "omit",
      "reason": "The measured and excluded stages are clearly distinguished in two short sentences.",
      "figures": [],
      "source_ids": ["vendor-assurance/measurement/benchmark"],
      "unreviewed_scope": []
    },
    {
      "id": "measurement/procedure",
      "status": "omit",
      "reason": "The pipeline environment and tools are adequately stated in one sentence.",
      "figures": [],
      "source_ids": ["vendor-assurance/measurement/benchmark"],
      "unreviewed_scope": []
    },
    {
      "id": "class-relationships",
      "status": "appropriate",
      "reason": "The existing class diagram displays the supplied inheritance and field-reference relationships and explicitly disclaims call order.",
      "figures": ["class-diagram"],
      "source_ids": ["structural-declaration:libcamera::Camera", "structural-declaration:libcamera::PipelineHandler", "structural-declaration:libcamera::PipelineHandlerIPU3", "structural-declaration:libcamera::PipelineHandlerRkISP1"],
      "unreviewed_scope": []
    }
  ],
  "new_findings": [
    "The changed English excerpt description for src/ipa/ipu3/algorithms/lsc.cpp:282 says the excerpt ends at line 291, but no source window for that file was supplied to verify the endpoint."
  ],
  "limitations": [
    "This review uses only the supplied source windows and assesses documented contracts rather than proving implementation behavior.",
    "The lsc.cpp excerpt endpoint remains unverified.",
    "Actual rendering, runtime behavior, device validation, the rest of the site and human approval were outside the review scope."
  ]
}
