{
  "verdict": "insufficient-evidence",
  "checks": [
    {
      "id": "invalid-extreme",
      "status": "supported",
      "reason": "Invalid means the configuration is invalid and cannot be adjusted; the manuscript preserves the extreme-case limitation and empty configuration example.",
      "source_ids": ["vendor-assurance/constraints/invalid"]
    },
    {
      "id": "adjusted-state",
      "status": "supported",
      "reason": "Adjusted indicates that the configuration was adjusted and is now valid.",
      "source_ids": ["vendor-assurance/constraints/adjusted-state"]
    },
    {
      "id": "adjusted-changes",
      "status": "supported",
      "reason": "The manuscript preserves the possibility of changes to any stream's parameters and removal of stream configurations without claiming that all streams changed.",
      "source_ids": ["vendor-assurance/constraints/adjusted-changes"]
    },
    {
      "id": "adjusted-review",
      "status": "supported",
      "reason": "The caller is instructed to check the adjusted configuration carefully.",
      "source_ids": ["vendor-assurance/constraints/adjusted"]
    },
    {
      "id": "valid",
      "status": "supported",
      "reason": "Valid means the configuration was already valid and was not adjusted.",
      "source_ids": ["vendor-assurance/constraints/valid"]
    },
    {
      "id": "roles-valid",
      "status": "supported",
      "reason": "The valid return is conditioned on the requested roles being satisfiable.",
      "source_ids": ["vendor-assurance/constraints/generate-result", "vendor-assurance/constraints/generate-contract"]
    },
    {
      "id": "roles-null",
      "status": "supported",
      "reason": "The null return is conditioned on the requested roles being unsatisfiable.",
      "source_ids": ["vendor-assurance/constraints/generate-result", "vendor-assurance/constraints/generate-contract"]
    },
    {
      "id": "no-success-before-null",
      "status": "supported",
      "reason": "The diagram describes a request to generate a default configuration before branching; it does not assert successful generation before the null branch.",
      "source_ids": ["vendor-assurance/constraints/generate-contract"]
    },
    {
      "id": "configure-input",
      "status": "supported",
      "reason": "The manuscript states the validated-input premise and the pipeline handler's obligation not to perform further validation.",
      "source_ids": ["vendor-assurance/constraints/configure-input"]
    },
    {
      "id": "configure-result",
      "status": "supported",
      "reason": "The stated return values are zero on success and a negative error code otherwise; successful configuration is not inferred from prior validation.",
      "source_ids": ["vendor-assurance/constraints/configure-result"]
    },
    {
      "id": "measurement-scope",
      "status": "supported",
      "reason": "The benchmark measures statistics collection and debayering processing time, excluding frame capture and output.",
      "source_ids": ["vendor-assurance/measurement/benchmark"]
    },
    {
      "id": "measurement-procedure",
      "status": "supported",
      "reason": "Running cam or qcam with a pipeline using Software ISP is the documented way to use the benchmark.",
      "source_ids": ["vendor-assurance/measurement/benchmark"]
    },
    {
      "id": "bilingual-diagrams",
      "status": "supported",
      "reason": "The Korean and English labels and branches in both supplied native diagrams preserve the cited validation and generation contracts.",
      "source_ids": ["vendor-assurance/constraints/valid", "vendor-assurance/constraints/generate-contract"]
    }
  ],
  "items": [
    {
      "id": "constraints/invalid",
      "status": "appropriate",
      "reason": "The validation figure explains Invalid and its extreme-case limitation.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/invalid"],
      "unreviewed_scope": []
    },
    {
      "id": "constraints/adjusted",
      "status": "appropriate",
      "reason": "The validation figure states that the configuration was adjusted and is now valid.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/adjusted-state"],
      "unreviewed_scope": []
    },
    {
      "id": "constraints/adjusted-changes",
      "status": "appropriate",
      "reason": "The validation figure covers possible parameter changes and removed stream configurations.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/adjusted-changes"],
      "unreviewed_scope": []
    },
    {
      "id": "constraints/adjusted-review",
      "status": "appropriate",
      "reason": "The validation figure includes the caller's duty to inspect the configuration carefully.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/adjusted"],
      "unreviewed_scope": []
    },
    {
      "id": "constraints/valid",
      "status": "appropriate",
      "reason": "The validation figure explains that the configuration was already valid and unchanged.",
      "figures": ["validation-results"],
      "source_ids": ["vendor-assurance/constraints/valid"],
      "unreviewed_scope": []
    },
    {
      "id": "constraints/roles",
      "status": "appropriate",
      "reason": "The generation figure shows the separate valid and null return conditions.",
      "figures": ["configuration-contract-validity"],
      "source_ids": ["vendor-assurance/constraints/generate-result", "vendor-assurance/constraints/generate-contract"],
      "unreviewed_scope": []
    },
    {
      "id": "constraints/configure-input",
      "status": "omit",
      "reason": "The short statement directly expresses the input premise and validation prohibition; neither local figure addresses configure.",
      "figures": [],
      "source_ids": ["vendor-assurance/constraints/configure-input"],
      "unreviewed_scope": []
    },
    {
      "id": "constraints/configure",
      "status": "omit",
      "reason": "The two return values are clear in a short statement and do not need a separate figure.",
      "figures": [],
      "source_ids": ["vendor-assurance/constraints/configure-result"],
      "unreviewed_scope": []
    },
    {
      "id": "measurement/scope",
      "status": "omit",
      "reason": "The included processing and excluded frame operations are clearly distinguished in two short sentences.",
      "figures": [],
      "source_ids": ["vendor-assurance/measurement/benchmark"],
      "unreviewed_scope": []
    },
    {
      "id": "measurement/procedure",
      "status": "omit",
      "reason": "The pipeline environment and two alternative tools are clear in one sentence.",
      "figures": [],
      "source_ids": ["vendor-assurance/measurement/benchmark"],
      "unreviewed_scope": []
    }
  ],
  "new_findings": [
    "The class relationship diagram asserts inheritance and field references, but the supplied source windows do not include the declarations or definitions needed to verify those relationships."
  ],
  "limitations": [
    "The class diagram and the manuscript's associated static-analysis provenance could not be verified from the supplied windows; no error in those relationships is asserted.",
    "This review assesses supplied source text and figure meaning only. It does not verify rendered SVG, browser UI, runtime behavior, the whole site, product-specific validation, or human approval.",
    "The source windows document interface contracts; they do not establish that a particular implementation conforms to them."
  ]
}
