"""One selected public operation through the common Generator and native CLI."""
from pathlib import Path
import hashlib
import json
import subprocess
import time
import uuid

from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.generate import Generator
from sdd.impact import ImpactReport
from sdd.llm import Agent

root = Path.cwd()
work = root/'build/issue243/public-current'
cfg = load(work/'generation.yaml')
preflight = json.loads((work/'current-preflight.json').read_bytes())
assert hashlib.sha256((work/'generation.yaml').read_bytes()).hexdigest() == preflight['profiles']['generation.yaml']
model = KnowledgeModel.load(cfg.facts_path)
assert model.meta['source_commit'] == '293d751a814e0d4c34e85ad457ccd9d5eefd1a61'
assert cfg.agent.kind == 'cli' and cfg.agent.runner == 'codex' and cfg.agent.model == 'gpt-6.1-terra'
assert cfg.agent.command == [] and cfg.agent.args == ['-c', 'model_reasoning_effort="high"']
report = ImpactReport.load(cfg.build_dir/'impact.json')
assert 'vendor-assurance' in report.sections
before = {p.relative_to(cfg.sdd_dir).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
          for p in cfg.sdd_dir.rglob('*.md')}
invocation = work/'invocations'/uuid.uuid4().hex
invocation.mkdir(parents=True)
binding = dict(generator_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
               selected=['vendor-assurance'], source_commit=model.meta['source_commit'],
               profile=dict(kind=cfg.agent.kind, runner=cfg.agent.runner, command=cfg.agent.command,
                            model=cfg.agent.model, args=cfg.agent.args), before=before, human_review='pending')
(invocation/'inputs.json').write_text(json.dumps(binding, indent=2), encoding='utf-8')
start = time.perf_counter()
try:
    agent = Agent(cfg.agent, dump_dir=cfg.build_dir/'prompts')
    # Root preview filenames use a per-Agent counter; keep the original
    # human-readable previews as well as the immutable UUID receipt triples.
    agent._counter = max((int(p.name.split('_', 1)[0]) for p in agent.dump_dir.glob('*_*.md')
                          if p.name.split('_', 1)[0].isdigit()), default=0)
    written = Generator(cfg, model, agent).run(
        section_ids=['vendor-assurance'], impact=report)
    after = {p.relative_to(cfg.sdd_dir).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
             for p in cfg.sdd_dir.rglob('*.md')}
    changed = [name for name in before.keys() | after.keys() if before.get(name) != after.get(name)]
    assert changed == ['vendor-assurance.md'], changed
    result = dict(status='generated-current-checks', written=[str(p) for p in written],
                  changed=changed, unchanged_manuscripts=len(before)-len(changed), human_review='pending')
except BaseException as exc:
    result = dict(status='failed', type=type(exc).__name__, error=str(exc), human_review='pending')
    raise
finally:
    result['wall_seconds'] = time.perf_counter()-start
    (invocation/'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(dict(invocation=str(invocation), **result), ensure_ascii=False), flush=True)
