"""Verify current real CLI records and combine explicitly bounded reviews."""
from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,str(Path.cwd()/'examples/libcamera/validation/issue243'))
from native_case import load_calls
from sdd.config import load
from sdd.cli_provenance import verify_cli_receipt
from sdd.repair_diagnostics import compare_checks
from sdd.site_build import verify_site

root=Path.cwd();w=root/'build/issue243/public-current'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
restore=json.loads((w/'restoration.json').read_bytes())['restored_originals']
original_native={n:h for n,h in restore.items() if n.startswith(('build/prompts/','build/translation-prompts/'))}
assert all((w/n).is_file() and sha((w/n).read_bytes())==h for n,h in original_native.items())
original_receipts={h for n,h in original_native.items() if n.endswith('.receipt.json')}
proofs={}
for stage,directory,profile in [('generation',w/'build/prompts',w/'generation.yaml'),
                                 ('translation',w/'build/translation-prompts',w/'translation-agent.yaml')]:
    cfg=load(profile);items=[]
    for p in sorted((directory/'calls').rglob('*.receipt.json')):
        if sha(p.read_bytes()) in original_receipts:continue
        prefix=str(p).removesuffix('.receipt.json')
        req=json.loads(Path(prefix+'.request.json').read_bytes())
        response=Path(prefix+'.response.txt').read_bytes().decode('utf-8')
        receipt=json.loads(p.read_bytes())
        proof=verify_cli_receipt(req,response,receipt,directory/'calls',cfg.agent)
        items.append(dict(receipt=p.relative_to(w).as_posix(),receipt_sha256=sha(p.read_bytes()),
                          request_sha256=receipt['request_sha256'],response_sha256=receipt['response_sha256'],
                          tag=receipt['tag'],verification=proof))
    proofs[stage]=items
assert len(proofs['generation'])==23 and len(proofs['translation'])==2
cfg=load(w/'independent-review.yaml')
reviews={}
for parent in ['independent-question-reviews','independent-metadata-reviews']:
    for p in sorted((w/parent).iterdir()):
        if not (p/'review.json').exists():continue
        calls=load_calls(p,cfg.agent);assert len(calls)==1
        request,response,proof=calls[0]
        result=json.loads((p/'review.json').read_bytes());assert result==json.loads(response)
        binding=json.loads((p/'binding.json').read_bytes())
        if 'payload_sha256' in binding:assert sha(request['user'].encode())==binding['payload_sha256']
        else:assert json.loads(request['user'])==json.loads((p/'inputs.json').read_bytes())
        reviews[p.name]=dict(result=result,binding=binding,proof=proof)
assert len(reviews)==6
before=reviews['511c4ca8c30c44558b461ccecdeac8c0']
after=reviews['61de54aea43845ed89c4f41b98145d0a']
metadata=reviews['2ef967023f1345af9a3c3e73831379cf']
current_md=sha((w/'run/manuscripts/vendor-assurance.md').read_bytes())
current_catalog=sha((w/'run/english.json').read_bytes())
assert after['binding']['manuscript_sha256']==metadata['binding']['manuscript_sha256']==current_md
assert after['binding']['catalog_sha256']==metadata['binding']['catalog_sha256']==current_catalog
assert all(c['status']=='supported' for c in after['result']['checks'] if c['id']!='english-prose')
assert next(c for c in after['result']['checks'] if c['id']=='english-prose')['status']=='unjudged'
assert all(c['status']=='supported' for c in metadata['result']['checks'])
assert not after['result']['new_findings'] and not metadata['result']['findings']
assert all(i['status'] in ['appropriate','omit'] for i in after['result']['items'])
old={c['id']:c for c in before['result']['checks']}
new={c['id']:c for c in after['result']['checks']}
transitions={key:dict(before=old[key]['status'],after=new[key]['status']) for key in old}
assert sum(v['before']=='error' and v['after']=='supported' for v in transitions.values())==2
assert not any(v['after']!='supported' for v in transitions.values())
report=json.loads((w/'build/consistency-review.json').read_bytes())
assert report['status']=='passed' and report['fresh_batches']==0 and report['reused_batches']==88
assert len(report['unresolved'])==2
baseline=json.loads((w/'source-and-baseline.json').read_bytes())['baseline_manuscript_hashes']
now={n:sha((w/'run/manuscripts'/n).read_bytes()) for n in baseline}
assert [n for n in baseline if now[n]!=baseline[n]]==['vendor-assurance.md']
quality=verify_site(root/'build/issue243/public-site')
result=dict(status='source-and-static-checks-passed-ui-incomplete',source_commit='293d751a814e0d4c34e85ad457ccd9d5eefd1a61',
    new_native_calls=dict(generation=23,translation=2,independent_reviews=6,contract_review=0,total=31),
    semantic_repair=dict(initial_new_page_calls=22,repair_calls=1,reused_prose_questions_on_repair=10,
        resolved_review_checks=2,recurrence=0,new_semantic_errors=0,selected_source_scope_unjudged=0,
        limitations='Source-only aggregate. English technical fidelity and metadata closure are separately bound to the same catalog; original insufficient-evidence verdicts are retained.'),
    transitions=transitions,original_native_files_preserved=len(original_native),unchanged_manuscripts=28,
    contract_review=dict(revalidated_batches=88,fresh_calls=0,historical_insufficient_evidence=2,human_review='pending'),
    quality=quality,manuscript_sha256=current_md,catalog_sha256=current_catalog,
    browser_ui='Not completed: Computer Use stopped this turn because Windows URL could not be verified. No alternate UI control was used.',
    whole_site_reader_evaluation=False,new_camera_runtime=False,inhouse_validation=False,human_review='pending')
(w/'native-call-verification-issue243.json').write_text(json.dumps(dict(proofs=proofs,reviews=reviews),ensure_ascii=False,indent=2),encoding='utf-8')
(w/'selected-page-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='transitions'},ensure_ascii=False),flush=True)
