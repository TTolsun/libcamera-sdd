"""Archive the new public operation without duplicating historical native files."""
from pathlib import Path
import json,hashlib,tarfile,gzip,shutil

r=Path.cwd();w=r/'build/issue243/public-current';repo=r/'build/issue243/public-sdd';out=repo/'publication/issue243'
out.mkdir(parents=True,exist_ok=False)
restored=json.loads((w/'restoration.json').read_bytes())['restored_originals']
files={}
for directory in ['build/prompts','build/translation-prompts','independent-question-reviews',
                  'independent-metadata-reviews','invocations','localization-profile-failure','two-exports']:
    for p in (w/directory).rglob('*'):
        if not p.is_file() or '__pycache__' in p.parts:continue
        name=p.relative_to(w).as_posix()
        if name in restored and hashlib.sha256(p.read_bytes()).hexdigest()==restored[name]:continue
        files['operation/'+name]=p
for p in w.glob('*.json'):
    name=p.relative_to(w).as_posix()
    if name in restored and hashlib.sha256(p.read_bytes()).hexdigest()==restored[name]:continue
    files['operation/'+name]=p
for p in w.glob('*.yaml*'):
    if p.is_file():files['operation/'+p.name]=p
for directory in ['config','templates','current-style','historical-style','reader-preserved-style','prior-issue243-inputs']:
    for p in (w/directory).rglob('*'):
        if p.is_file():files['operation/'+p.relative_to(w).as_posix()]=p
for name in ['generate-current.py','review-current.py','review-metadata.py','verify-current.py','restore_current.py','package-public.py']:
    files['scripts/'+name]=r/'build/issue243'/name
for p in (r/'build/issue243').glob('ci-*.log'):files['ci/'+p.name]=p
for name in ['generator-merge.json','merged-evaluator.xml','semantic-final.xml','pr-final.xml','baseline-assets.json']:
    files['verification/'+name]=r/'build/issue243'/name
for name in ['run/english.json','run/english.before-issue243.json','run/manuscripts/vendor-assurance.md','build/consistency-review.json']:
    files['operation/'+name]=w/name
facts=gzip.compress((w/'run/facts/facts.json').read_bytes(),mtime=0);(out/'facts293.json.gz').write_bytes(facts)
index={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in sorted(files.items())}
with tarfile.open(out/'native-and-operation-evidence.tar.xz','w:xz') as archive:
    for name,path in sorted(files.items()):archive.add(path,arcname=name,recursive=False)
(out/'archive-index.json').write_bytes(json.dumps(index,indent=2).encode())
for name in ['selected-page-validation.json','native-call-verification-issue243.json','source-and-baseline.json',
             'translation-retry-observation.json']:
    shutil.copyfile(w/name,out/name)
shutil.copyfile(r/'build/issue243/generator-merge.json',out/'generator-merge.json')
shutil.copyfile(w/'two-exports/result.json',out/'two-exports.json')
shutil.copyfile(r/'build/issue243/public-site/site-manifest.json',out/'site-manifest.json')
package=dict(schema=1,files=len(files),archive_sha256=hashlib.sha256((out/'native-and-operation-evidence.tar.xz').read_bytes()).hexdigest(),
             index_sha256=hashlib.sha256((out/'archive-index.json').read_bytes()).hexdigest(),facts_sha256=hashlib.sha256(facts).hexdigest(),
             browser_ui='pending; Computer Use stopped this turn on Windows URL verification',pages='not-deployed',human_review='pending')
(out/'package.json').write_bytes(json.dumps(package,indent=2).encode());print(package)
