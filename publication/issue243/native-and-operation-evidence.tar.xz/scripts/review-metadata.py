"""Close only the factual metadata scope left unjudged by the English review."""
from pathlib import Path
import sys,json,hashlib,subprocess,uuid,re,datetime
from zoneinfo import ZoneInfo
sys.path.insert(0,str(Path.cwd()/'examples/libcamera/validation/issue243'))
from native_case import verify_calls
from sdd.config import load
from sdd.evidence import select_span
from sdd.facts.model import KnowledgeModel
from sdd.document_metadata import split_frontmatter
from sdd.generation_run import Execution
from sdd.llm import Agent

w=Path.cwd()/'build/issue243/public-current'
cfg=load(w/'independent-review.yaml')
g=load(w/'generation.yaml')
m=KnowledgeModel.load(g.facts_path)
catalog_path=w/'run/english.json'
catalog=json.loads(catalog_path.read_bytes())
catalog_hash=hashlib.sha256(catalog_path.read_bytes()).hexdigest()
prior=w/'independent-question-reviews/61de54aea43845ed89c4f41b98145d0a'
binding=json.loads((prior/'binding.json').read_bytes())
assert binding['catalog_sha256']==catalog_hash
windows={}
for key in ['ipu3-lsc-flow/metadata/process','vendor-assurance/constraints/generate-contract']:
    record=m.evidence[key]
    raw=subprocess.check_output(['git','show',m.meta['source_commit']+':./'+record['file']],cwd=g.source_root).decode('utf-8')
    begin,end=select_span(raw,record['selector'])
    assert raw[begin:end]==record['text']
    assert raw[:begin].count('\n')+1==record['line']
    assert raw[:end].count('\n')+1==record['end_line']==291
    windows[key]=record
metadata,text=split_frontmatter((g.sdd_dir/'vendor-assurance.md').read_text(encoding='utf-8'))
dates=re.findall(r'검토 상태 기록일: (\d{4}-\d{2}-\d{2}) · 사람 검토 전',text)
local_date=datetime.datetime.fromisoformat(str(metadata['generated_at'])).astimezone(ZoneInfo('Asia/Seoul')).date().isoformat()
assert dates and set(dates)=={local_date}
translations={source:dict(english=value,contexts=catalog.get('translation_contexts',{}).get(source,[]))
              for source,value in catalog['strings'].items()
              if ('종료 줄은 291' in source or source.startswith('검토 상태 기록일: '+local_date))}
assert len(translations)==2
payload=dict(task='Review ONLY the remaining metadata translations. The prior independent review supports the technical English and its Korean fidelity but lacked the excerpt endpoints and an independent date record. '
    'Do not repeat already supported page conditions. Check both inline-source occurrences of the 291 endpoint and fidelity of the review-date/human-pending label. '
    'The date is a generated record label, not proof of semantic correctness, human approval or host-clock accuracy. The literal windows were deterministically re-extracted from immutable Git and their line bounds verified.',
    translations=translations,source_windows=windows,generated_record=dict(generated_at=str(metadata['generated_at']),timezone='Asia/Seoul',local_date=local_date,literal_manuscript_review_dates=dates,semantic_review=metadata['semantic_review']),
    generator_code='\n'.join((Path.cwd()/'src/sdd/page_writer.py').read_text(encoding='utf-8').splitlines()[72:86]),
    required_checks=['lsc-excerpt-bounds','pipeline-excerpt-bounds','review-date-fidelity'],prior_review_sha256=hashlib.sha256((prior/'review.json').read_bytes()).hexdigest())
s=dict(type='string',minLength=1)
check=dict(type='object',additionalProperties=False,required=['id','status','reason'],properties=dict(id=s,status=dict(type='string',enum=['supported','error','unjudged']),reason=s))
schema=dict(type='object',additionalProperties=False,required=['checks','findings','limitations'],properties=dict(checks=dict(type='array',items=check),findings=dict(type='array',items=s),limitations=dict(type='array',items=s)))
out=w/'independent-metadata-reviews'/uuid.uuid4().hex;out.mkdir(parents=True)
(out/'inputs.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
(out/'binding.json').write_text(json.dumps(dict(catalog_sha256=catalog_hash,manuscript_sha256=binding['manuscript_sha256'],prior=str(prior),human_review='pending'),indent=2),encoding='utf-8')
e=Execution(cfg,Agent(cfg.agent,dump_dir=out/'prompts'));e.path=out/'generation-run.json'
with e.track('independent-metadata-only-review'):
    raw=e.chat('Independently compare the supplied metadata translations with the actual source records. Use only supplied data and return schema JSON. This is not human approval.',json.dumps(payload,ensure_ascii=False),tag='issue243_metadata_only_review',response_schema=schema)
(out/'review.json').write_text(raw,encoding='utf-8')
r=json.loads(raw);assert sorted(c['id'] for c in r['checks'])==sorted(payload['required_checks'])
assert hashlib.sha256(catalog_path.read_bytes()).hexdigest()==catalog_hash
(out/'provenance.json').write_text(json.dumps(verify_calls(out,cfg.agent),indent=2),encoding='utf-8')
print(json.dumps(dict(out=str(out),checks=r['checks'],findings=r['findings']),ensure_ascii=False),flush=True)
