import hashlib,json,shutil,zipfile
from pathlib import Path
from sdd.config import load
from sdd.call_records import load_record
from sdd.cli_provenance import verify_cli_receipt
root=Path.cwd();out=root/'build/review-followup';repo=root/'build/issue242-publication/libcamera-sdd';target=repo/'publication/review-followup-242';target.mkdir(parents=True,exist_ok=True);cfg=load(out/'independent-review.yaml');verified=[]
for folder,kind in [('independent-prompts','targeted-source-review'),('diff-review-prompts','generator-diff-review')]:
 calls=out/folder/'calls'
 for p in calls.rglob('*.receipt.json'):
  r=load_record(p,root=calls);v=verify_cli_receipt(r.request,r.raw,r.receipt,calls,cfg.agent);verified.append(dict(kind=kind,receipt=p.relative_to(out).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),tag=r.receipt['tag'],verification=v))
assert len(verified)==3
(out/'native-verification-final.json').write_text(json.dumps(dict(status='passed',new_review_calls=3,receipts=verified,human_review='pending'),ensure_ascii=False,indent=2),encoding='utf-8')
index={}
with zipfile.ZipFile(target/'original-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts:continue
  name=p.relative_to(out).as_posix();raw=p.read_bytes();index[name]=hashlib.sha256(raw).hexdigest();z.writestr(name,raw)
(target/'archive-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding='utf-8')
for n in ['plan-02.json','independent-review-01.json','independent-review.json','review-time-01.json','review-time.json','native-verification-final.json','diff-review.json','diff-review-time.json','probe-result-01.json','export-final.json','manuscript-preservation.json','runtime-binding.json','tests.xml','tests.log']:
 shutil.copy2(out/n,target/n)
shutil.copy2(root/'examples/libcamera/validation/issue242/glossary.yaml',target/'glossary.yaml');shutil.copy2(root/'docs/records/issue242-followup.md',target/'generator-record.md')
site=out/'probe/build/site';pubsite=repo/'docs/validation/issue242-followup';shutil.copytree(site,pubsite,dirs_exist_ok=True)
base=(repo/'docs/site-manifest.json').read_bytes();manifest=json.loads(base);assert all(hashlib.sha256((repo/'docs'/name).read_bytes()).hexdigest()==sha for name,sha in manifest['outputs'].items())
summary=dict(archive_files=len(index),archive_sha256=hashlib.sha256((target/'original-evidence.zip').read_bytes()).hexdigest(),archive_bytes=(target/'original-evidence.zip').stat().st_size,existing_main_outputs_unchanged=len(manifest['outputs']),main_manifest_sha256=hashlib.sha256(base).hexdigest(),sample_manifest_sha256=hashlib.sha256((site/'site-manifest.json').read_bytes()).hexdigest(),new_sample_prefix='validation/issue242-followup/',human_review='pending')
(target/'package.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');(out/'publication-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary))
