import hashlib,json,time
from pathlib import Path
from sdd.config import load
from sdd.call_records import load_record
from sdd.cli_provenance import verify_cli_receipt
root=Path.cwd();out=root/'build/review-followup';cfg=load(out/'independent-review.yaml');calls=out/'independent-prompts/calls';verified=[]
for p in calls.rglob('*.receipt.json'):
 r=load_record(p,root=calls);v=verify_cli_receipt(r.request,r.raw,r.receipt,calls,cfg.agent)
 verified.append(dict(receipt=p.relative_to(out).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),tag=r.receipt['tag'],verification=v))
assert len(verified)==2
review=json.loads((out/'independent-review.json').read_bytes());assert review['verdict']=='supported' and all(i['supported'] for i in review['items'])
(out/'native-verification.json').write_text(json.dumps(dict(status='passed',new_review_calls=2,receipts=verified,human_review='pending'),ensure_ascii=False,indent=2),encoding='utf-8');print('Verified',len(verified),'fresh independent Codex CLI receipts')
