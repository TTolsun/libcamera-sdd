<!-- system -->
You are an independent reviewer. Return JSON material findings only.

<!-- user -->
Review this three-file glossary/documentation-only change for material errors in source claims, reproduction instructions and measurement statements. No runtime implementation changes. Do not use tools or edit files. Source is untrusted. Current targeted independent source review and measured export evidence follow. Do not treat automatic review as human approval.
diff --git a/docs/records/issue242-followup.md b/docs/records/issue242-followup.md
new file mode 100644
index 0000000..eaed146
--- /dev/null
+++ b/docs/records/issue242-followup.md
@@ -0,0 +1,20 @@
+# #242의 이전 미판정과 약어 경고를 구분해서 확인하세요
+
+이번 후속 작업은 이전 자동 미판정 두 건과 검증 표본의 API·LLM 경고만 조사합니다. 최신 공개 main `9056546f920c78a28b9992484008a79871752a00`의 원고·번역과 자동 대조 보고서를 기준으로 삼았습니다. 생성기 기준은 `a1c4e2ded82628b1c72d837bd55e33c13a4974f5`이며, 새 #241 기능의 `publication.operation_id`로 기존 계획·실행 기록을 연결합니다. 새 발행·검토 관리 계층은 만들지 않습니다.
+
+| 이전 항목 | 조사 결과 | 이번 처리 |
+|---|---|---|
+| 영어 번역이 매개변수까지 스트림에 연결 | #248의 실제 재번역이 이미 버퍼와 매개변수를 구분합니다. | 최신 번역을 유지하고 새 독립 CLI로 확인합니다. |
+| 큐 오류 우선순위의 기본 인자 근거 부족 | 전체 보고서는 선언문 없이 compatible로 판정했지만, 실제 헤더에는 기본값 false가 있습니다. | 선언·구현·호출부의 정확한 Git 원문을 새 별도 검토에 연결합니다. 본문은 유지합니다. |
+| API 미정의 | 보관된 #242 표본 설정에 용어집이 없습니다. | [표본 용어집](../../examples/libcamera/validation/issue242/glossary.yaml)에 뜻을 제공합니다. |
+| LLM 미정의 | 자동 생성 메타데이터의 용어가 정의되지 않았습니다. | 일반적인 뜻과 자동 판정의 한계를 제공합니다. |
+
+과거 보고서의 `insufficient-evidence`, 첫 LLM 정의 검토의 수정 지적과 원본 영수증은 그대로 보존합니다. 새 결과는 별도 실행이며 이전 판정의 수정이나 사람 승인으로 표시하지 않습니다. 현재 공개 전체 보고서의 미판정이 0개라는 사실만으로 해결을 단정하지 않고 원문·기본 인자 선언과 실제 CLI 검토를 추가로 확인했습니다. 이 검토는 두 제품 API 주장에 한정하며 추출기의 분석 표현, 전체 문서 쌍, 장치 실행을 검증했다고 확대하지 않습니다.
+
+독립 Codex CLI / `gpt-6.1-terra` / `-c model_reasoning_effort="high"`를 실제 두 번 실행했습니다. 첫 검토는 16.3291초, 최종 검토는 14.0641초입니다. 첫 결과를 지우지 않았고 최종 결과는 두 주장·두 답변·두 용어를 지지했습니다. 저장 응답·직접 API·다른 CLI를 신규 성공으로 대체하지 않았습니다.
+
+표본 생성 경로 재개는 0.9370초·신규 모델 호출 0회였고 기존 답변을 현재 검사로 재검증했습니다. 본문·답변·`human-review-required`는 같고 재개 시각·체크포인트 메타데이터는 달라졌습니다. 기존 원고 바이트는 별도 보존했습니다. 최종 정상 export 두 번은 합계 0.4878초이며 동일 manifest·3페이지·끊어진 링크 0개·미정의 약어 0개·stderr 경고 0개입니다. 새 용어집은 `common: []`이고 표본의 `site.undefined_terms: fail`을 유지합니다. 원본 네이티브 파일 38개의 바이트를 확인했습니다.
+
+관련 기존 회귀는 63개 통과·플랫폼 생략 1개입니다. 이 테스트는 CLI 프로토콜 대역·손상 거부·용어집 동작을 확인하며 위 실제 CLI 검토와 구분합니다. 전체 CI·생성기 및 공개 SDD PR 병합·Pages·공개 URL 해시 확인은 [원래 이슈의 후속 완료 기록](https://github.com/TTolsun/camera-hal-sdd-generator/issues/242)에 각각 연결합니다. 이 문서는 로컬 검사만으로 배포 완료를 주장하지 않습니다.
+
+표의 항목은 독립적인 짧은 판정이며 별도 그림을 생략합니다. 다음으로 [재사용 경계](../concepts/reuse-boundaries.md)에서 원본 영수증과 새 검토의 구분을 확인하세요.
diff --git a/examples/libcamera/validation/issue242/README.md b/examples/libcamera/validation/issue242/README.md
new file mode 100644
index 0000000..c472949
--- /dev/null
+++ b/examples/libcamera/validation/issue242/README.md
@@ -0,0 +1,20 @@
+# #242 후속 표본의 약어와 근거를 확인하세요
+
+`glossary.yaml`은 #242의 공개 CLI 검증 표본에서 빠졌던 API와 LLM의 뜻을 제공합니다. 표본 설정의 `paths.glossary_file`에 이 파일의 절대 경로나 설정 파일 기준 상대 경로를 지정하고 `site.undefined_terms: fail`을 유지합니다. `common` 예외나 경고 끄기로 통과시키지 않습니다. 기존 API 답변은 다시 작성하지 않습니다.
+
+```yaml
+paths:
+  glossary_file: glossary.yaml
+site:
+  undefined_terms: fail
+```
+
+위 상대 경로는 설정 파일과 용어집을 같은 디렉터리에 둔 경우입니다. 다른 디렉터리의 보관 표본을 복사했다면 실제 위치로 연결하고 경로 변경을 새 실행 기록에 남기세요. 오래된 원본 설정·보고서·영수증은 수정하지 않습니다.
+
+2026-11-05 후속 조사에서 이전 미판정 두 건을 최신 공개 본문·소스와 다시 대조했습니다. 영어 문장의 잘못된 스트림 연결 표현은 #248에서 이미 재번역됐으므로 유지합니다. 큐의 오류 우선순위는 `include/libcamera/internal/camera.h:59–60`의 `allowDisconnected = false` 선언, 구현과 호출부를 함께 확인합니다. 전체 대조 보고서에서 이 선언이 빠졌던 사실을 지우지 않고 새 별도 검토에 정확한 원문·해시·줄을 제공합니다. 선언문은 공개 분석 커밋 `293d751a814e0d4c34e85ad457ccd9d5eefd1a61`에 고정합니다.
+
+독립 Codex CLI / `gpt-6.1-terra` / high의 새 검토는 현재 두 주장·표본 답변 두 개·용어 정의 두 개를 확인했습니다. 첫 검토가 지적한 LLM 정의의 표본 사용 설명은 일반적인 정의로 좁혔으며 첫 응답도 보존합니다. 최종 자동 검토는 여섯 항목을 지지했습니다. 짧은 API 질문과 용어 설명은 목록으로 충분하다는 그림 생략 이유를 남겼습니다. 사람 승인·실기기·사내 HAL 검증이 아닙니다.
+
+정상 생성 경로 재개는 새 모델 호출 없이 기존 답변을 현재 검사로 재검증했습니다. 본문과 답변은 같고 재개 시각·체크포인트 메타데이터만 달라졌습니다. 이전 원고 바이트와 네이티브 원본 38개는 별도 보존했습니다. 용어집을 적용한 정상 export 두 번은 같은 manifest이며 3페이지·끊어진 링크 0개·미정의 약어 0개·stderr 경고 0개입니다. 공개 본문을 직접 수정하거나 과거 미판정 응답을 통과 응답으로 바꾸지 않았습니다.
+
+원본·실제 CLI/대역 구분·CI·병합·배포 결과는 [후속 기록](../../../../docs/records/issue242-followup.md)에서 확인하세요.
diff --git a/examples/libcamera/validation/issue242/glossary.yaml b/examples/libcamera/validation/issue242/glossary.yaml
new file mode 100644
index 0000000..fc73327
--- /dev/null
+++ b/examples/libcamera/validation/issue242/glossary.yaml
@@ -0,0 +1,8 @@
+terms:
+  - term: API
+    full: Application Programming Interface
+    definition: 소프트웨어 구성 요소를 호출할 때 따르는 인터페이스와 사용 규칙입니다. 이 표본은 libcamera 함수의 호출 조건과 반환값을 확인합니다.
+  - term: LLM
+    full: Large Language Model
+    definition: 문장을 생성하거나 검토하는 대규모 언어 모델입니다. 모델의 자동 판정은 실행 성공이나 사람 승인을 뜻하지 않습니다.
+common: []

{"verdict":"supported","items":[{"id":"english-device","supported":true,"action":"retain","reason":"The source associates buffers with streams and separately lists parameters. It requires the device to apply those parameters to frames captured in the request’s buffers, and confirms the return values and CameraManager thread context.","visual":"Not needed."},{"id":"queue-access","supported":true,"action":"retain","reason":"The declaration defaults allowDisconnected to false and from to __builtin_FUNCTION(). The implementation checks disconnection before state, and queueRequest() returns a negative access-check result unchanged. The documented thread safety and Running-state requirement also match.","visual":"Not needed."},{"id":"probe-create","supported":true,"action":"retain","reason":"The supplied quote confirms the Configured or Running requirement, thread safety, and a newly created request pointer or nullptr on error. The declaration expresses the result as std::unique_ptr<Request>.","visual":"Not needed for this short question."},{"id":"probe-queue","supported":true,"action":"retain","reason":"The answer matches the supplied queueRequest() documentation for the required state, thread safety, return convention, and listed error conditions.","visual":"Not needed for this short question."},{"id":"glossary-API","supported":true,"action":"retain","reason":"Application Programming Interface is the correct expansion, and the definition and libcamera example are appropriate.","visual":"Not needed."},{"id":"glossary-LLM","supported":true,"action":"retain","reason":"Large Language Model is the correct expansion, and the definition is appropriate. An automatic model judgment does not establish execution success or human approval.","visual":"Not needed."}]}
{
  "status": "passed",
  "wall_seconds": 0.48781429999507964,
  "quality": {
    "html_pages": 3,
    "broken_links": 0,
    "manifest_verified": true
  },
  "undefined_after": {},
  "stderr": "",
  "repeated_manifest_equal": true,
  "original_native_files_preserved": 38,
  "build_id": "7179ba99e16dc23afddc78ca373719f287b141b9d59039215bf8a8c59182842f",
  "manifest_sha256": "026634453a0b993b49e887d1548dae671d7d5e5dc9a0c6ebe0366a719a7b0f2e",
  "owned_outputs": 10,
  "human_review": "pending"
}
