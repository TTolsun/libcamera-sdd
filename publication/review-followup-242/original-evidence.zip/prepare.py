import hashlib,json,shutil,subprocess,yaml
from pathlib import Path
root=Path.cwd();out=root/'build/review-followup';old=root/'build/issue242-publication/actual-probe-02';public=root/'build/issue242-publication/libcamera-sdd';probe=out/'probe'
if probe.exists():raise RuntimeError('Preserve earlier attempt: output already exists')
shutil.copytree(old,probe)
sha=lambda b:hashlib.sha256(b).hexdigest()
originals=out/'originals';originals.mkdir()
for n,p in [('old-probe-config.yaml',old/'sdd.yaml'),('old-probe.md',old/'manuscripts/probe.md'),('old-full-report.json',root/'build/issue242-publication/release-01/build/consistency-review.json'),('current-full-report.json',public/'docs/contract-consistency.json')]:shutil.copy2(p,originals/n)
archives={p.relative_to(probe).as_posix():sha(p.read_bytes()) for base in [probe/'build/prompts/calls',probe/'build/prompts/cli',probe/'independent-prompts'] for p in base.rglob('*') if p.is_file()}
config=yaml.safe_load((probe/'sdd.yaml').read_bytes());config['source']['root']=str(probe/'source');config['source']['compile_commands']=str(probe/'source/not-used.json');config['paths']['glossary_file']=str(root/'examples/libcamera/validation/issue242/glossary.yaml');config['site']['undefined_terms']='fail';config['publication']={'operation_id':'review-followup-probe-20261105'}
(probe/'sdd.yaml').write_text(yaml.safe_dump(config,allow_unicode=True,sort_keys=False),encoding='utf-8')
commit='293d751a814e0d4c34e85ad457ccd9d5eefd1a61';source=root/'build/issue242-publication/source293'
windows=[]
for file,start,end in [('include/libcamera/internal/camera.h',48,66),('src/libcamera/camera.cpp',690,708),('src/libcamera/camera.cpp',1308,1378),('src/libcamera/pipeline_handler.cpp',534,561)]:
 raw=subprocess.run(['git','-C',str(source),'show',commit+':'+file],capture_output=True,check=True).stdout;text=raw.decode().splitlines(keepends=True);excerpt=''.join(text[start-1:end]);windows.append(dict(file=file,line=start,end_line=end,text=excerpt,sha256=sha(excerpt.encode()),file_sha256=sha(raw),commit=commit))
# Select exact current claim and the source attached to it; never rewrite its old finding.
d=json.loads((public/'docs/contract-consistency.json').read_bytes());targets=[]
for contract,id in [('callbacks-synchronization','catalog/1627ee523ce59b5e/en'),('scenario-analysis','catalog/6786e86300a109c3')]:
 c=next(c for c in d['contracts'] if c['id']==contract);f=next(f for f in c['findings'] if f['claim_id']==id)
 targets.append(dict(contract=contract,claim_id=id,text=f['claim_quote'],attached_sources={s['source_id']:c['sources'][s['source_id']] for s in f['sources']}))
plan=dict(schema=1,source_commit=commit,generator_head=subprocess.run(['git','rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip(),public_base=subprocess.run(['git','-C',str(public),'rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip(),targets=targets,source_windows=windows,source_gap='The current scenario audit omits the declaration default. Review explicitly with this literal declaration; do not promote old verdicts.',expected_changes={'english_claim':'retain already repaired current text','queue_claim':'retain if declaration + helper + call site support it','probe_glossary':'define API and LLM; retain fail policy'},original_native_hashes=archives,original_manuscript_sha256=sha((probe/'manuscripts/probe.md').read_bytes()),human_review='pending')
(out/'plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8');print('Frozen',len(archives),'native files; targets',len(targets),'source windows',len(windows))
