import contextlib,hashlib,io,json,time
from pathlib import Path
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.generate import Generator
from sdd.llm import Agent
from sdd.export_site import export_site
from sdd.site_build import verify_site
from sdd import glossary
root=Path.cwd();out=root/'build/review-followup';probe=out/'probe';plan=json.loads((out/'plan-02.json').read_bytes());cfg=load(probe/'sdd.yaml');model=KnowledgeModel.load(cfg.facts_path)
texts={p.name:p.read_text(encoding='utf-8') for p in (probe/'previous-good-site').glob('*.md')}
before=glossary.undefined(glossary.Glossary([],set(),False),texts);assert set(before)=={'API','LLM'},before
assert not glossary.undefined(glossary.load(cfg),texts)
runs=set((cfg.build_dir/'generation-runs').glob('*.json'));start=time.perf_counter();stderr=io.StringIO()
try:
 with contextlib.redirect_stderr(stderr):
  Generator(cfg,model,Agent(cfg.agent,cfg.build_dir/'prompts')).run()
  site=export_site(cfg);quality=verify_site(site)
  first=(site/'site-manifest.json').read_bytes();site=export_site(cfg);assert first==(site/'site-manifest.json').read_bytes()
 assert not stderr.getvalue(),stderr.getvalue()
 for n,sha in plan['original_native_hashes'].items():assert hashlib.sha256((probe/n).read_bytes()).hexdigest()==sha,n
 current=[json.loads(p.read_bytes()) for p in set((cfg.build_dir/'generation-runs').glob('*.json'))-runs]
 result=dict(status='passed',undefined_before=before,undefined_after={},stderr=stderr.getvalue(),wall_seconds=time.perf_counter()-start,calls=[c for r in current for c in r['calls']],quality=quality,repeated_manifests_identical=True,native_originals_preserved=len(plan['original_native_hashes']),original_manuscript_bytes_equal=hashlib.sha256((probe/'manuscripts/probe.md').read_bytes()).hexdigest()==plan['original_manuscript_sha256'],human_review='pending')
 (out/'probe-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False),flush=True)
finally:(out/'probe-stderr.txt').write_text(stderr.getvalue(),encoding='utf-8')

