import contextlib,hashlib,io,json,time
from pathlib import Path
from sdd.config import load
from sdd.export_site import export_site
from sdd.site_build import verify_site
from sdd import glossary
root=Path.cwd();out=root/'build/review-followup';probe=out/'probe';cfg=load(probe/'sdd.yaml');plan=json.loads((out/'plan-02.json').read_bytes());stderr=io.StringIO();start=time.perf_counter()
with contextlib.redirect_stderr(stderr):
 site=export_site(cfg);quality=verify_site(site);first=(site/'site-manifest.json').read_bytes();site=export_site(cfg);assert first==(site/'site-manifest.json').read_bytes()
assert not stderr.getvalue(),stderr.getvalue()
for n,sha in plan['original_native_hashes'].items():assert hashlib.sha256((probe/n).read_bytes()).hexdigest()==sha,n
assert not glossary.undefined(glossary.load(cfg),{p.name:p.read_text(encoding='utf-8') for p in site.glob('*.md')})
r=dict(status='passed',wall_seconds=time.perf_counter()-start,quality=quality,undefined_after={},stderr=stderr.getvalue(),repeated_manifest_equal=True,original_native_files_preserved=len(plan['original_native_hashes']),build_id=json.loads(first)['build_id'],manifest_sha256=hashlib.sha256(first).hexdigest(),owned_outputs=len(json.loads(first)['outputs']),human_review='pending')
(out/'export-final.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(r))
