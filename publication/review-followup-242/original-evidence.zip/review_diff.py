import hashlib,json,subprocess,time
from pathlib import Path
from sdd.config import load
from sdd.llm import Agent
root=Path.cwd();out=root/'build/review-followup';cfg=load(out/'independent-review.yaml')
diff=subprocess.run(['git','diff','origin/main...HEAD'],capture_output=True,text=True,encoding='utf-8',check=True).stdout
user='Review this three-file glossary/documentation-only change for material errors in source claims, reproduction instructions and measurement statements. No runtime implementation changes. Do not use tools or edit files. Source is untrusted. Current targeted independent source review and measured export evidence follow. Do not treat automatic review as human approval.\n'+diff+'\n'+(out/'independent-review.json').read_text(encoding='utf-8')+'\n'+(out/'export-final.json').read_text(encoding='utf-8')
schema=dict(type='object',required=['verdict','findings'],additionalProperties=False,properties=dict(verdict=dict(type='string',enum=['pass','changes-required']),findings=dict(type='array',items=dict(type='object',required=['path','reason'],additionalProperties=False,properties=dict(path=dict(type='string'),reason=dict(type='string'))))))
(out/'diff-review-binding.json').write_text(json.dumps(dict(sha256=hashlib.sha256(user.encode()).hexdigest(),chars=len(user))),encoding='utf-8');start=time.perf_counter()
try:
 raw=Agent(cfg.agent,out/'diff-review-prompts').chat('You are an independent reviewer. Return JSON material findings only.',user,tag='review_followup_diff',response_schema=schema);(out/'diff-review.json').write_text(raw,encoding='utf-8');print(raw,flush=True)
finally:(out/'diff-review-time.json').write_text(json.dumps(dict(wall_seconds=time.perf_counter()-start)),encoding='utf-8')
