import hashlib,json,subprocess
from pathlib import Path
r=Path.cwd();out=r/'build/review-followup';plan=json.loads((out/'plan.json').read_bytes());source=r/'build/issue242-publication/source293'
plan['source_windows']=plan['source_windows'][:3];excluded=[]
for target in plan['targets']:
 for sid,e in list(target['attached_sources'].items()):
  if e['file'].startswith('@analysis/'):
   excluded.append(dict(source_id=sid,reason='Extractor representation; not evidence of the product API claim. Original full report and plan retain this peer context.'));del target['attached_sources'][sid];continue
  raw=subprocess.run(['git','-C',str(source),'show',plan['source_commit']+':'+e['file']],capture_output=True,check=True).stdout.decode()
  assert raw.count(e['text'])==1,sid
  start=raw[:raw.index(e['text'])].count('\n')+1;assert start==e['line'],(sid,start,e['line'])
plan.update(revision=2,previous_sha256=hashlib.sha256((out/'plan.json').read_bytes()).hexdigest(),excluded_sources=excluded,change_reason='Use exact source-attached windows; exclude analysis representation from the targeted product API check. Original report and full plan are preserved. Preflight attempt treated an analysis pseudo-path as a Git file and stopped before any model call.')
(out/'plan-02.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8');print('Plan revision 2 ready;',len(excluded),'analysis context excluded from product API review')
