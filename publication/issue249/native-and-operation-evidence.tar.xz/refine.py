from pathlib import Path
import yaml
root=Path(__file__).resolve().parents[2]
path=root/'examples/libcamera/config/sections.yaml'
text=path.read_text(encoding='utf-8')
data=yaml.safe_load(text)
topic=next(t for s in data['sections'] if s['id']=='request-lifecycle' for t in s['design_topics'] if t['id']=='resources')
topic['sources'].append(dict(id='internal-completion',file='src/libcamera/request.cpp',
 start=r'\brief Complete a buffer for the request',end=r'\brief Reset the request internal data to default values'))
parts={p['id']:p for p in topic['parts']}
for key in ('normal','out-of-order','cancel','change'):
 parts[key]['sources'].append('internal-completion')
parts['out-of-order']['question'] += ' 正常Bの状態はcancelled_がfalseの場合にRequestCompleteとなるという実装条件を明示してください。'.replace(' 正常Bの状態はcancelled_がfalseの場合にRequestCompleteとなるという実装条件を明示してください。',' 정상 B의 상태는 cancelled_가 false일 때 RequestComplete가 된다는 구현 조건을 명시하세요.')
parts['out-of-order']['answer_contract']['required_terms'].append(['RequestComplete'])
parts['cancel']['question']='앞 A/B 예에서 B를 cancelRequest로 취소하는 경우에 새로 달라지는 상태와 처리만 설명하세요. Request::Private::doCancelRequest는 pending_에 남은 버퍼를 취소하고 bufferCompleted 신호를 보낸 뒤 pending_를 비우고 cancelled_를 true로 바꿉니다. cancelRequest는 cancel 다음 completeRequest를 호출하므로 Request::Private::complete가 RequestCancelled 상태를 선택하며, 선두 A가 RequestPending인 동안 B의 애플리케이션 반환은 여전히 지연된다는 조건부 해석을 연결하세요. 버퍼 유지 기한과 반환 후 핸들러 접근 제한은 앞의 소유권 원리와 같다고 짧게 연결하되 그 의무 문장을 다시 풀어 쓰지 마세요. 취소만으로 선행 A를 건너뛰는 반환이나 즉시 버퍼 회수가 보장된다고 쓰지 마세요.'
parts['cancel']['answer_contract']['required_terms']=[['cancelRequest'],['completeRequest'],['RequestCancelled'],['RequestPending']]
parts['ownership']['question'] += ' 정상 흐름과 조건 변화에서는 이 의무 문장을 반복하지 않고 해당 조건에서 달라지는 결과에 집중하도록 이 문단이 공통 수명 규칙을 소유합니다.'
start=text.index('  - id: resources\n',text.index('- id: request-lifecycle\n'))
end=text.index('  - id: stopping\n',start)
replacement=yaml.safe_dump([topic],allow_unicode=True,sort_keys=False,width=110)
path.write_text(text[:start]+''.join('  '+line+'\n' for line in replacement.rstrip().splitlines())+text[end:],encoding='utf-8',newline='\n')
print('Added exact completion/cancellation state window; narrowed cancellation to changed results.')
