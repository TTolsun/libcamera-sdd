from pathlib import Path
root=Path(__file__).resolve().parents[2];path=root/'build/issue249/parallel_consistency.py'
source=path.read_text(encoding='utf-8').replace("'parallel-current-policy'","'parallel-final-catalog'")
exec(compile(source,str(path),'exec'))
