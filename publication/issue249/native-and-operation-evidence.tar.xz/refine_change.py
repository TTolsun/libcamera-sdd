from pathlib import Path
import yaml
root=Path(__file__).resolve().parents[2]
path=root/'examples/libcamera/config/sections.yaml'
text=path.read_text(encoding='utf-8');data=yaml.safe_load(text)
topic=next(t for s in data['sections'] if s['id']=='request-lifecycle' for t in s['design_topics'] if t['id']=='resources')
part=next(p for p in topic['parts'] if p['id']=='change')
part.update(question='변경 검토를 위한 소스 기반 조사 계획으로 두 문단 이내에 답하세요. 이 항목은 completeBuffer와 completeRequest의 호출 책임을 다른 스레드로 옮기려는 변경에서, 기존 호출자와 스레드 전달 경계를 찾아 CameraManager 스레드 호출 의무를 보존하는지 대조할 과업만 구체화합니다. 다른 스레드에서 이 API를 직접 호출하도록 옮기면 문서화된 의무와 충돌한다는 조건부 판단을 설명하세요. 마지막 버퍼 알림에서 조기 재사용하는 판단은 앞의 조건 변화 항목이 이미 설명하므로 그 점검 목록과 queuedRequests_ 관찰 순서를 다시 나열하지 마세요. Request::reuse 필드 초기화 상세는 요청 API 문서가 소유합니다. 실제 콜백 스레드·기기 DMA·캐시·실행 시간·사내 HAL은 이 조사 계획으로 검증된 결과가 아니며, 역사적 설계 이유와 대안 우열에는 별도 결정 기록이나 실행 자료가 필요함을 짧게 구별하세요. 소스에 없는 동기화 구현이나 새 스레드 전달 코드를 제안하지 마세요.',sources=['completion','internal-completion'],max_statements=2)
part['answer_contract']['required_terms']=[['CameraManager'],['completeBuffer'],['completeRequest'],['계획']]
start=text.index('  - id: resources\n',text.index('- id: request-lifecycle\n'));end=text.index('  - id: stopping\n',start)
replacement=yaml.safe_dump([topic],allow_unicode=True,sort_keys=False,width=110)
path.write_text(text[:start]+''.join('  '+line+'\n' for line in replacement.rstrip().splitlines())+text[end:],encoding='utf-8',newline='\n')
print('Change question now owns thread relocation risk; existing condition checks stay in their original items.')
