"""Complete missing standard audit units with isolated CLI calls, then re-audit normally."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,hashlib,threading
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.consistency import groups,request,batches,review_store,validate,schema,SYSTEM,policy_hash
from sdd.cli_checkpoint import Capture
from sdd.llm import Agent
from sdd.validation_stage import stage
root=Path(__file__).resolve().parents[2];work=root/'build/issue249';profile=work/'integration/independent-review.yaml';out=work/'parallel-current-policy';out.mkdir(exist_ok=False)
cfg=load(profile);model=KnowledgeModel.load(cfg.facts_path);units=[]
with stage() as inputs:
 inputs.pin(cfg,model)
 for group in groups(cfg):
  payload=request(cfg,model,group)
  for index,batch in enumerate(batches(payload,max_input_chars=cfg.agent.max_input_chars)):
   store,wire=review_store(cfg,batch);cached=store.read()
   if cached is not None:
    saved,_=cached;assert validate(batch,saved['raw'])==saved['statements']
   units.append((group['id'],index,batch,cached is not None))
rows=[];lock=threading.Lock();policy=policy_hash()
def run(unit):
 group,index,batch,cached=unit
 if cached:return dict(group=group,index=index,status='original-completed-checkpoint-revalidated')
 # Each worker has its own immutable input watch, Agent and native call UUID.
 # All use the standard UnitStore, receipt verifier and validate() unchanged.
 with stage() as inputs:
  inputs.pin(cfg,model);assert policy_hash()==policy
  store,wire=review_store(cfg,batch);assert store.read() is None
  capture=Capture(Agent(cfg.agent,cfg.build_dir/'prompts'))
  raw=capture.chat(SYSTEM,wire['user'],tag=f'consistency_{group}_{index}',response_schema=schema(batch))
  findings=validate(batch,raw);store.write(raw,findings,capture)
  checked=store.read();assert checked is not None and checked[0]['statements']==findings
  return dict(group=group,index=index,status='new-original-cli-completed',receipts=[str(p) for p in capture.receipts])
report=dict(source_commit=model.meta['source_commit'],policy_sha256=policy,profile_sha256=hashlib.sha256(profile.read_bytes()).hexdigest(),concurrency=4,units=rows,human_review='pending',status='running')
with ThreadPoolExecutor(max_workers=4) as pool:
 futures={pool.submit(run,u):u for u in units}
 for future in as_completed(futures):
  group,index,_,_=futures[future]
  try:row=future.result()
  except Exception as exc:row=dict(group=group,index=index,status='failed',error=str(exc))
  rows.append(row)
  (out/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
  print(group,index,row['status'],flush=True)
report['status']='failed' if any(r['status']=='failed' for r in rows) else 'completed-awaiting-standard-audit'
(out/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
if report['status']=='failed':raise SystemExit(1)
