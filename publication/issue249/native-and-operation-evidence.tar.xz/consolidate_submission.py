from pathlib import Path
import yaml
root=Path(__file__).resolve().parents[2]
path=root/'examples/libcamera/config/sections.yaml';text=path.read_text(encoding='utf-8')
data=yaml.safe_load(text)
topic=next(t for s in data['sections'] if s['id']=='request-lifecycle' for t in s['design_topics'] if t['id']=='journey')
topic['parts']=[p for p in topic['parts'] if p['id']!='submission']
used={sid for p in topic['parts'] for sid in p['sources']}
topic['parts'][0]['sources'] += [s['id'] for s in topic['sources'] if s['id'] not in used]
start=text.index('  - id: journey\n',text.index('- id: request-lifecycle\n'));end=text.index('  - id: resources\n',start)
replacement=yaml.safe_dump([topic],allow_unicode=True,sort_keys=False,width=110)
path.write_text(text[:start]+''.join(('  '+line).rstrip()+'\n' for line in replacement.rstrip().splitlines())+text[end:],encoding='utf-8',newline='\n')
print('Submission/completion distinction detail is owned by the representative problem stage; journey summary retained.')
