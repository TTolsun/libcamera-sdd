from pathlib import Path
import json,hashlib,re,yaml,subprocess
from sdd.document_metadata import split_frontmatter
root=Path(__file__).resolve().parents[2];work=root/'build/issue249';out=work/'evidence';out.mkdir(exist_ok=True)
def stats(path):
 m,b=split_frontmatter(path.read_text(encoding='utf-8'));a=m['generated_design']['answers']
 return dict(document_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),source_commit=m['source_commit'],topics={t:dict(statements=len(rows),prose_characters=sum(len(s['text']) for s in rows)) for t,rows in a.items()},total_statements=sum(len(v) for v in a.values()),total_prose_characters=sum(len(s['text']) for v in a.values() for s in v)),m
before,_=stats(work/'baseline/request-lifecycle.md');after,meta=stats(work/'integration/manuscripts/request-lifecycle.md')
data=dict(metric='Unicode characters in generated_design.answers[].text, including inline code; excludes metadata, citations appended by renderer, source disclosures, headings and Mermaid',before=before,after=after,question_sha256=hashlib.sha256((root/'examples/libcamera/validation/issue249/questions.json').read_bytes()).hexdigest(),ownership='resources owns conditional lifetime decisions; journey retains overview; stopping retains stop/disconnect; camera-requests, pipeline-requests and request-diagnosis retain implementation and investigation detail',selections=meta['generated_design']['integration_lineage']['whole_statement_selections'],human_review='pending')
(out/'before-after.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(dict(before=before,after=after),ensure_ascii=False),flush=True)
cfg=yaml.safe_load((work/'integration/sections.yaml').read_bytes());topic=next(t for s in cfg['sections'] if s['id']=='request-lifecycle' for t in s['design_topics'] if t['id']=='resources');visuals={
 'problem':([], '입력 검사에 성공한 제출 반환과 별도 완료 신호를 구분하는 짧은 문제 제시입니다. 다음 정상 흐름 그림이 이 경계의 후속 단계를 설명합니다.'),
 'ownership':(['request-ownership'],None), 'normal':(['completion-notification-order'],None),
 'out-of-order':(['completed-but-not-returned'],None),'cancel':(['completed-but-not-returned'], '동일 큐 반환 규칙과 cancelled_ 상태 분기를 인접 그림으로 함께 대조합니다. 이미 완료한 B의 재취소가 아닌 Pending 취소 예는 본문이 구분합니다.'),
 'fence-transfer':([], 'addBuffer 성공 시에만 소유권이 이동하고 실패 시 수정되지 않는 짧은 두 조건입니다. 별도 흐름을 중복하지 않고 실제 API 근거로 대조합니다.'),
 'fence-timeout':(['lifecycle-timeout-fence-recovery'],None),'reuse-fences':(['lifecycle-reuse-buffer-fence-distinction'],None), 'change':(['completion-change-checks'],None)}
rows=[]
for p in topic['parts']:
 figures,reason=visuals[p['id']];statements=[s for s in meta['generated_design']['answers']['resources'] if s.get('part_id')==p['id']]
 rows.append(dict(page='request-lifecycle.md',topic='resources',part=p['id'],question=p['question'],explanation_stage=next(e['id'] for e in topic['explanation'] if p['id'] in e['parts']),prose_characters=sum(len(s['text']) for s in statements),paragraphs=len(statements),figures=figures,disposition='adjacent-figure-sufficient' if figures else 'omitted-with-reason',reason=reason,sources=p['sources']))
report=dict(status='completed',stage='per-item-visualization-assessment',source_commit=after['source_commit'],scope='Only the changed representative resources items, plus preservation of existing neighbouring topic figures; not issue #215 full-site completion',items=rows,human_review='pending')
(out/'per-item-visualization.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
old=before['source_commit'];new=after['source_commit'];git=lambda *a:subprocess.check_output(['git','-C',str(work/'source'),*a],text=True).strip()
changed=git('diff','--name-only',old,new).splitlines();fixed=['src/libcamera/request.cpp','src/libcamera/camera.cpp','src/libcamera/pipeline_handler.cpp','include/libcamera/camera.h','include/libcamera/request.h','include/libcamera/internal/pipeline_handler.h']
proof=dict(analysis_source=new,previous_source=old,changed_paths=changed,representative_files_identical=not git('diff',old,new,'--',*fixed),representative_files=fixed,translation_profile='Codex CLI / gpt-6.1-terra / high',extraction=dict(translation_units=294,parse_errors=0,portable_classes=1403,baseline_classes=1412,excluded_class_delta='9 LC-compliance test-tool classes from 5 omitted translation units; build coverage change, not source deletion',pipelines=10,ipas=7,scenarios=6),historical_runtime_reexecuted=False,human_review='pending')
(out/'source-and-extraction.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
