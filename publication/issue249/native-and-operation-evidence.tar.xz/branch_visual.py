from pathlib import Path
import json,yaml,re
root=Path(__file__).resolve().parents[2];path=root/'examples/libcamera/config/visuals.yaml'
text=path.read_text(encoding='utf-8');data=yaml.safe_load(text)
rows=data['sections']['request-lifecycle'];graph=next(g for g in rows if g['id']=='completed-but-not-returned')
evidence=json.loads((root/'build/issue249/work/facts/facts.json').read_bytes())['evidence']
def ref(source,quote):
 r=evidence['request-lifecycle/resources/'+source];assert r['text'].count(quote)==1
 return dict(source='resources/'+source,sha256=r['sha256'],quote=quote)
state=ref('internal-completion','request->status_ = cancelled_ ? RequestCancelled : RequestComplete;')
call=ref('completion','request->_d()->complete();')
gate=ref('completion','if (req->status() == Request::RequestPending)\n\t\t\tbreak;')
returned=ref('completion','camera->requestComplete(req);')
order=ref('completion','This function ensures that requests will be returned to the application in\n * submission order')
access=ref('complete-access','The request is no longer managed by the pipeline\n * handler and shall not be accessed once this function returns.')
duty=ref('buffer-duty','for ensuring that the buffer will remain valid until the request complete\n * callback is called.')
def node(id,ko,en,*refs,decision=False):
 n=dict(id=id,label=ko,label_en=en,evidence=list(refs))
 if decision:n['shape']='decision'
 return n
def edge(a,b,ko,en,*refs):return dict(**{'from':a,'to':b},label=ko,label_en=en,evidence=list(refs))
graph['nodes']=[node('b','B의 처리 종료: completeRequest(B)','B processing finished: completeRequest(B)',call),
 node('flag','cancelled_ 값은?','Value of cancelled_?',state,decision=True),
 node('complete','RequestComplete','RequestComplete',state),node('cancelled','RequestCancelled','RequestCancelled',state),
 node('head','큐 선두 A가 RequestPending인가?','Is queue head A RequestPending?',gate,decision=True),
 node('wait','B의 애플리케이션 반환 지연','Application return of B is delayed',call,gate),
 node('return','완료된 선두부터 A 다음 B 반환','Return completed heads: A then B',order,returned),
 node('handler','완료 함수 반환 뒤 핸들러 접근 금지','No handler access after completion function returns',access),
 node('buffer','요청 완료 콜백까지 버퍼 유지','Keep buffer valid until request completion callback',duty)]
graph['edges']=[edge('b','flag','내부 complete에서 상태 선택','Select status in internal complete',call,state),
 edge('flag','complete','false','false',state),edge('flag','cancelled','true','true',state),
 edge('complete','head','상태 갱신 뒤 선두 검사','Check queue head after status update',call,gate),
 edge('cancelled','head','취소 상태도 같은 선두 검사','Same head check for cancelled status',call,gate),
 edge('head','wait','A가 Pending이면 break','Break while A is Pending',gate),
 edge('head','return','선두가 완료 상태이면 제거·반환','Pop and return completed heads',gate,returned),
 edge('b','handler','함수 반환 시점의 접근 경계','Access boundary when the function returns',access),
 edge('wait','buffer','콜백이 아직 없으므로 유지 의무 지속','Validity duty continues before callback',duty)]
graph['question']='A 다음 B를 제출하고 B의 모든 버퍼와 추가 처리가 끝난 조건부 예입니다. cancelled_ 값이 주어지지 않았으면 두 상태를 구분할 수 없고, 어느 상태라도 선두 A가 Pending이면 반환을 기다립니다. 수명 화살표는 접근·유효성 계약이며 실제 콜백 시각을 나타내지 않습니다.'
start=text.index('  request-lifecycle:\n');m=re.search(r'^  [a-z][a-z0-9_-]*:\n',text[start+3:],re.M);end=start+3+m.start() if m else len(text)
replacement=yaml.safe_dump({'request-lifecycle':rows},allow_unicode=True,sort_keys=False,width=110)
path.write_text(text[:start]+''.join(('  '+line).rstrip()+'\n' for line in replacement.rstrip().splitlines())+text[end:],encoding='utf-8',newline='\n')
print('A/B diagram now exposes cancelled_ true/false selection in nine source-bound nodes (limit 12).')
