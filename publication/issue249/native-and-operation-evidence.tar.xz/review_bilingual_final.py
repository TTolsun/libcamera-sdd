from pathlib import Path
root=Path(__file__).resolve().parents[2]
source=(root/'build/issue249/bilingual_review.py').read_text(encoding='utf-8').replace("build/issue249/bilingual-review'", "build/issue249/bilingual-review-v7'")
exec(compile(source,str(root/'build/issue249/bilingual_review.py'),'exec'))
