from pathlib import Path
import json,hashlib,shutil
from sdd.config import load
from sdd.llm import Agent
from sdd.translation import _single_system,_single_schema,_payload,_single_value,_validate_text
from sdd.translation_checkpoint import TranslationCall
root=Path(__file__).resolve().parents[2];work=root/'build/issue249';out=work/'translation-independent-repairs';out.mkdir();path=work/'integration/english.json';shutil.copyfile(path,out/'catalog-before.json');catalog=json.loads(path.read_bytes());payload=json.loads((work/'bilingual-review-v9/payload.json').read_bytes());cfg=load(work/'integration/sdd.yaml');agent=Agent(cfg.agent,out/'prompts');rows=[]
feedback={
 '68':'Preserve the non-author qualification for BOTH roles: the team member and the technical decision-maker. Do not imply only one role must be a non-author.',
 '28':'The measured processing is LIMITED TO collecting statistics and debayering. Do not use including or otherwise broaden this closed set. Capturing and outputting frames are excluded.',
 '30':'The question concerns determining WHETHER ALL BUFFERS HAVE COMPLETED, not every individual completion check. Preserve the collective completion predicate and the other queue/loop relationships.'}
for ident,note in feedback.items():
 pair=next(p for p in payload['pairs'] if p['id']==ident);source=pair['korean'];system=_single_system([source])+'\nIndependent source-review correction: '+note;user=_payload(catalog,{'source':source},terms={});call=TranslationCall(cfg,agent,system,user,_single_schema(),units=[source]);raw=call.chat(f'translation_{ident}_0');value=_validate_text(source,_single_value(raw));call.validated(dict(text=value));catalog['strings'][source]=value;rows.append(dict(pair_id=ident,source=source,old=pair['english'],new=value,receipt=str(agent.last_receipt)))
path.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(out/'result.json').write_text(json.dumps(dict(changes=rows,catalog_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),human_review='pending'),ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(rows,ensure_ascii=False))
