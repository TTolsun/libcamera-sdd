const { chromium } = require(process.env.ISSUE249_PLAYWRIGHT || require('path').resolve(__dirname,'pw/node_modules/playwright'));
const fs=require('fs'),path=require('path'),assert=require('assert');
const base=process.env.ISSUE249_URL || 'http://127.0.0.1:8769/';
const out=process.env.ISSUE249_BROWSER_OUT || 'build/issue249/browser-local';fs.mkdirSync(out,{recursive:true});
(async()=>{
 const browser=await chromium.launch({channel:'chrome',headless:true});const results=[];
 for(const lang of ['ko','en'])for(const width of [1440,390]){
  const page=await browser.newPage({viewport:{width,height:1000}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto(base+(lang==='en'?'en/':'')+'request-lifecycle.html',{waitUntil:'networkidle',timeout:120000});
  await page.waitForFunction(()=>[...document.querySelectorAll('.mermaid')].every(e=>e.dataset.ready==='true'),{timeout:120000});
  assert.equal(await page.locator('.diagram-error').count(),0);assert.deepEqual(errors,[]);
  const h=await page.locator('h2,h3,h4').evaluateAll(es=>es.map(e=>({tag:e.tagName,id:e.id,text:e.textContent})));
  const start=h.findIndex(x=>x.tag==='H2'&&(x.text.includes('요청·버퍼·fence')||/request.*buffer.*fence/i.test(x.text)));
  assert(start>=0,JSON.stringify(h.filter(x=>x.tag==='H2')));const end=h.findIndex((x,i)=>i>start&&x.tag==='H2');const rows=h.slice(start,end<0?undefined:end);
  assert.equal(rows.filter(x=>x.tag==='H3').length,5);assert.equal(rows.filter(x=>x.tag==='H4').length,6);
  assert(/애플리케이션 반환|completion status/i.test(rows.filter(x=>x.tag==='H4')[2].text),'The B example figure must precede the fence detail figures');
  const graph=page.locator('.mermaid').filter({has:page.locator('svg')}).filter({hasText:'completeRequest(B)'});assert.equal(await graph.count(),1);
  assert.equal(await graph.locator('.node').count(),10);
  await graph.scrollIntoViewIfNeeded();await graph.screenshot({path:path.join(out,`${lang}-${width}-inline.png`)});
  await graph.click();await page.locator('#diagram-dialog').waitFor({state:'visible'});
  const reading=await page.locator('#diagram-canvas svg').evaluate(svg=>({body:parseFloat(getComputedStyle(document.body).fontSize),min:Math.min(...[...svg.querySelectorAll('text,tspan')].filter(e=>e.textContent.trim()).map(e=>{const m=e.getScreenCTM();return parseFloat(getComputedStyle(e).fontSize)*Math.hypot(m.c,m.d)}))}));assert(reading.min>=reading.body-.5,JSON.stringify(reading));
  await page.locator('#node-search').fill('RequestPending');assert((await page.locator('#diagram-canvas .is-match').count())>=1);
  const zoom=await page.locator('#zoom-value').innerText();await page.locator('#zoom-in').click();assert.notEqual(await page.locator('#zoom-value').innerText(),zoom);
  await page.locator('#zoom-fit').click();await page.screenshot({path:path.join(out,`${lang}-${width}-dialog.png`)});
  await page.keyboard.press('Escape');assert.equal(await page.locator('#diagram-dialog').isVisible(),false);assert(await graph.evaluate(e=>e===document.activeElement));
  const ref=page.locator('main a[href^="#source-"]').first();for(const d of await ref.locator('xpath=ancestor::details').all())if(await d.getAttribute('open')===null)await d.locator(':scope > summary').click();const target=await ref.getAttribute('href');await ref.click();await page.waitForFunction(id=>{let e=document.querySelector(id);if(!e)return false;const anchor=e.parentElement?.tagName==='P'?e.parentElement:e;const panel=anchor.nextElementSibling;if(panel?.tagName!=='DETAILS'||!panel.open)return false;for(let p=panel.parentElement;p;p=p.parentElement)if(p.tagName==='DETAILS'&&!p.open)return false;return true},target);await page.locator('.evidence-return:visible').click();await page.waitForFunction(()=>!location.hash.startsWith('#source-'));
  const evidence=await page.locator('a[href^="#"]').evaluateAll(es=>es.filter(e=>/evidence|source|ev-/.test(e.getAttribute('href'))).slice(0,5).map(e=>({text:e.textContent,href:e.getAttribute('href')})));
  const anchors=await page.locator('a[href*="/blob/"]').evaluateAll(es=>es.map(e=>e.href));assert(anchors.some(x=>x.includes('/be7e83e91348250c015aad6d6f59f1468555bae8/')));
  const overflow=await page.evaluate(()=>({viewport:innerWidth,body:document.body.scrollWidth,document:document.documentElement.scrollWidth}));assert(overflow.document<=width+1,JSON.stringify(overflow));
  results.push({lang,width,stage_headings:rows.filter(x=>x.tag==='H3'),figures:rows.filter(x=>x.tag==='H4'),nodes:10,modal_search_zoom_close_focus:true,initial_reading_font:reading,source_disclosure_and_back:true,evidence_links:evidence,overflow,errors});await page.close();
 }
 const nojs=await browser.newPage({javaScriptEnabled:false,viewport:{width:390,height:900}});await nojs.goto(base+'request-lifecycle.html');assert(await nojs.locator('details').count()>0);assert(await nojs.locator('a[href$=".mmd"]').count()>0);await nojs.close();
 await browser.close();fs.writeFileSync(path.join(out,'result.json'),JSON.stringify({status:'passed',base,results,no_javascript_source_and_download_links:true,human_review:'pending'},null,2));
})().catch(e=>{console.error(e);process.exit(1)});
