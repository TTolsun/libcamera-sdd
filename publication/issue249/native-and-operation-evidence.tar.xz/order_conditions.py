from pathlib import Path
import yaml,re,shutil
root=Path(__file__).resolve().parents[2];path=root/'examples/libcamera/config/visuals.yaml';text=path.read_text(encoding='utf-8');data=yaml.safe_load(text);rows=data['sections']['request-lifecycle']
old=next(i for i,g in enumerate(rows) if g['id']=='completed-but-not-returned');graph=rows.pop(old);slot=next(i for i,g in enumerate(rows) if g['id']=='lifecycle-timeout-fence-recovery');rows.insert(slot,graph)
start=text.index('  request-lifecycle:\n');m=re.search(r'^  [a-z][a-z0-9_-]*:\n',text[start+3:],re.M);end=start+3+m.start() if m else len(text);replacement=yaml.safe_dump({'request-lifecycle':rows},allow_unicode=True,sort_keys=False,width=110)
path.write_text(text[:start]+''.join(('  '+line).rstrip()+'\n' for line in replacement.rstrip().splitlines())+text[end:],encoding='utf-8',newline='\n')
shutil.copyfile(root/'build/issue249/work/manuscripts/request-lifecycle.md',root/'build/issue249/topic-grounding-v11/document.md')
