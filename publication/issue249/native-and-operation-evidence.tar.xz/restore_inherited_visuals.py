from pathlib import Path
import yaml,json,hashlib,shutil
root=Path(__file__).resolve().parents[2];work=root/'build/issue249';out=work/'integration';path=out/'visuals.yaml'
shutil.copyfile(path,out/'visuals-before-official-cam-restoration.yaml');shutil.copyfile(work/'evidence/two-exports.json',work/'evidence/two-exports-before-inherited-visual-restoration.json')
prior_path=work/'issue243/operation/config/visuals.yaml';prior=yaml.safe_load(prior_path.read_bytes());current=yaml.safe_load(path.read_bytes());owned=[g for g in current['sections']['request-lifecycle'] if g.get('topic')=='resources']
rows=prior['sections']['request-lifecycle'];slot=next(i for i,g in enumerate(rows) if g.get('topic')=='resources');rows[:]=[g for g in rows if g.get('topic')!='resources'];rows[slot:slot]=owned
path.write_text(yaml.safe_dump(prior,allow_unicode=True,sort_keys=False),encoding='utf-8')
record=dict(inherited_config_sha256=hashlib.sha256(prior_path.read_bytes()).hexdigest(),restored_official_cam_figures=[g['id'] for g in prior['sections']['official-cam-validation']],scope='Preserve all prior public visual definitions; only request-lifecycle/resources is replaced by the new reviewed representative diagrams',new_inference=False,human_review='pending')
(work/'evidence/inherited-visual-preservation.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8');print(record)
