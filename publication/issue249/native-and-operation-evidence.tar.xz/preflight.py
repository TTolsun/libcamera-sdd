from pathlib import Path
import json
from sdd.config import load
from sdd.validation_stage import stage
from sdd.publication_plan import check_baseline,check_catalog
from sdd.document_health import enforce
root=Path(__file__).resolve().parents[2]
with stage() as inputs:
 cfg=load(root/'build/issue249/integration/sdd.yaml');inputs.pin(cfg)
 print(check_baseline(cfg));check_catalog(cfg);enforce(cfg)
print('baseline, catalog and document health passed')
