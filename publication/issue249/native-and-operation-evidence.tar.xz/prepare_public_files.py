from pathlib import Path
import shutil,json,re
root=Path(__file__).resolve().parents[2];work=root/'build/issue249';public=work/'public';dest=public/'publication/issue249';dest.mkdir(parents=True,exist_ok=True)
attribute=public/'.gitattributes';text=attribute.read_text(encoding='utf-8');rule='publication/issue249/** -text -whitespace'
if rule not in text:attribute.write_text(text.rstrip()+'\n'+rule+'\n',encoding='utf-8',newline='\n')
readme=public/'README.md';text=readme.read_text(encoding='utf-8');text=re.sub(r'Analysis and original trial:.*?\n\n','Configured source analysis and official upstream mirror:be7e83e91348250c015aad6d6f59f1468555bae8. The configured build was extracted again across 294 translation units, with no parsing errors. LC-compliance test-tool units were excluded; the resulting class inventory is 1,403 rather than the previous 1,412. Original virtual CPU trials remain at 293d751a814e0d4c34e85ad457ccd9d5eefd1a61 and were not rerun. Automatic checks remain separate from human approval and hardware/internal HAL validation.\n\n',text)
link='- [Conditional completion, ownership and reuse decisions — representative automatic evaluation](publication/issue249/README.md)'
if link not in text:text=text.rstrip()+'\n'+link+'\n'
readme.write_text(text,encoding='utf-8',newline='\n')
for p in (work/'evidence').iterdir():
 if p.is_file() and p.suffix in {'.json','.xz'}:shutil.copyfile(p,dest/p.name)
for name in ['questions.json','rubric.json','independent-review.yaml']:
 shutil.copyfile(root/'examples/libcamera/validation/issue249'/name,dest/name)
for source,name in [(work/'integration/sdd.yaml','publication.yaml'),(work/'integration/reader-paths.yaml','reader-paths.yaml'),(work/'integration/english.json','english.json'),(work/'public/docs/site-manifest.json','site-manifest.json')]:shutil.copyfile(source,dest/name)
for directory in ['browser-final-local','handler-question-review-v2']:
 source=work/directory
 if source.exists():
  for p in source.iterdir():
   if p.is_file() and p.suffix in {'.json','.png'}:
    target=dest/directory/p.name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
print('Public evidence prepared:',dest)
