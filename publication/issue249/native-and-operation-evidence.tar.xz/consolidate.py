from pathlib import Path
import yaml
root=Path(__file__).resolve().parents[2]
path=root/'examples/libcamera/config/sections.yaml'
text=path.read_text(encoding='utf-8')
data=yaml.safe_load(text)
section=next(s for s in data['sections'] if s['id']=='request-lifecycle')
journey=next(t for t in section['design_topics'] if t['id']=='journey')
removed={'buffer-notification','buffer-complete','request-complete'}
journey['parts']=[p for p in journey['parts'] if p['id'] not in removed]
used={s for p in journey['parts'] for s in p['sources']}
journey['parts'][0]['sources'] += [s['id'] for s in journey['sources'] if s['id'] not in used]
journey['prompt']='제출·대기·장치 전달을 이 절에서 소유합니다. 완료 내부 추적·스레드 의무·제출 순서별 자원 수명은 요청·버퍼·fence의 수명 절에서 통합 설명하므로 이 절은 첫 요약의 결론만 보존하고 같은 상세를 반복하지 마세요.'
start=text.index('  - id: journey\n',text.index('- id: request-lifecycle\n'))
end=text.index('  - id: resources\n',start)
replacement=yaml.safe_dump([journey],allow_unicode=True,sort_keys=False,width=110)
path.write_text(text[:start]+''.join('  '+line+'\n' for line in replacement.rstrip().splitlines())+text[end:],encoding='utf-8',newline='\n')
print('Moved completion detail ownership to resources; kept high-level summary and all source windows.')
