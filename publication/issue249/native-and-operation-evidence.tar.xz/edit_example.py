from pathlib import Path
import copy, yaml

root=Path(__file__).resolve().parents[2]
path=root/'examples/libcamera/config/sections.yaml'
text=path.read_text(encoding='utf-8')
data=yaml.safe_load(text)
sections=data['sections']
section=next(s for s in sections if s['id']=='request-lifecycle')
topic=next(t for t in section['design_topics'] if t['id']=='resources')
old=copy.deepcopy(topic)
parts={p['id']:copy.deepcopy(p) for p in old['parts']}
def part(id,question,sources,terms,maximum=2,basis='description'):
    return dict(id=id,question=question,sources=sources,max_statements=maximum,
                answer_contract=dict(basis=basis,required_terms=[[t] for t in terms]))
topic['question']='提出成功・バッファ完了・リクエスト完了とアプリケーションへの返却を区別し、バッファを回収できる境界をソースで判断します。'.replace('提出成功・バッファ完了・リクエスト完了とアプリケーションへの返却を区別し、バッファを回収できる境界をソースで判断します。','제출 성공·버퍼 완료·요청 완료와 애플리케이션 반환을 구분하고 버퍼 회수 경계를 근거로 판단하세요. 문제, 수명 원리, 정상 흐름, 조건 변화, 변경 확인을 연결하세요. 요청 소유권·버퍼 유지 기한·fence 이동과 실패·타임아웃 회수·ReuseBuffers의 should not 권고·핸들러 접근 금지를 보존하세요. 필드 초기화 상세는 요청 API 문서가 담당합니다.')
topic['sources'].append(dict(id='queue',file='src/libcamera/camera.cpp',start=r'\brief Queue a request to the camera',end=r'\brief Start capture from camera'))
topic['parts']=[
part('problem','요청을 제출해 0을 받았지만 버퍼를 회수할 수 있는가라는 문제를 먼저 한두 문장으로 설명하세요. Camera::queueRequest의 0은 ConnectionTypeQueued invokeMethod 뒤 반환이며 요청 완료 콜백과 구별하세요. 버퍼 유지 기한의 상세 의무와 내부 큐는 뒤 항목에 맡기세요.', ['queue','buffer-duty'], ['queueRequest','0','완료'],1),
part('ownership','createRequest 호출자가 반환된 Request를 소유하고 삭제를 책임지며 완료 핸들러에서 삭제하거나 reuse로 상태 초기화 후 재사용할 수 있다는 계약을 설명하세요. 별도 문단에서 addBuffer 호출자가 버퍼를 요청 완료 콜백이 호출될 때까지 유효하게 유지해야 한다는 의무와 파이프라인 핸들러가 completeRequest 또는 cancelRequest 반환 뒤 요청에 접근해서는 안 된다는 경계를 연결하세요. 두 호출자를 동일 주체로 단정하지 마세요. 버퍼 참조 저장을 배타적 저장이라고 쓰지 마세요.', ['create','reuse','buffer','buffer-duty','complete-access','cancel-rules'], ['createRequest','호출자','버퍼','완료','completeRequest','cancelRequest','파이프라인 핸들러'],2),
parts['fence-transfer'],
part('normal','정상 경로에서 completeBuffer는 bufferCompleted를 먼저 emit한 다음 요청의 내부 버퍼 추적을 갱신한다는 순서를 설명하세요. 마지막 버퍼가 끝나도 요청은 자동 완료되지 않고 핸들러가 필요한 추가 처리를 마친 뒤 completeRequest로 완료를 명시 통지해야 한다는 계약을 연결하세요. completeRequest는 상태를 완료로 갱신하고 제출 순서대로 반환하므로, 정상 반환 후 호출자는 삭제 또는 reuse로 상태 초기화 후 재요청할 수 있음을 설명하세요. CameraManager 호출 의무와 실제 콜백 스레드 미검증을 구별하세요. 각 문단에 관련 근거를 모두 연결하세요.', ['completion','create','reuse'], ['completeBuffer','bufferCompleted','completeRequest','CameraManager','reuse'],3),
part('early-buffer','조건 하나만 바꾼 예를 설명하세요. 마지막 bufferCompleted를 받았어도 요청 완료 콜백이 아직 없으면, addBuffer 호출자의 버퍼 유지 기한이 끝나지 않습니다. 알림 emit 뒤에 내부 completeBuffer 호출이 있다는 구현과 요청 자동 완료가 아니라는 계약 때문에 이 알림만으로 버퍼 해제나 다음 요청에 넘기는 결정을 해서는 안 된다는 조건부 판단을 설명하세요. 다음으로 completeBuffer의 반환과 명시 completeRequest 호출, 실제 요청 완료 콜백을 확인하도록 소스 기반 조사 계획임을 밝히세요. 존재하지 않는 로그나 기기 결과를 만들지 마세요.', ['completion','buffer-duty'], ['bufferCompleted','completeBuffer','completeRequest','콜백'],2),
part('out-of-order','소스에서 유도한 조건부 예라고 명시하세요. A 다음 B를 제출했고 A가 RequestPending이며 B의 모든 버퍼와 추가 처리가 끝났다면 completeRequest(B)는 B를 완료 상태로 바꾸어도 queuedRequests_ 선두 A에서 break하므로 B의 애플리케이션 반환은 아직 이뤄지지 않습니다. 그동안 addBuffer 호출자는 B의 버퍼를 요청 완료 콜백까지 유지해야 하지만 파이프라인 핸들러는 completeRequest(B) 반환 뒤 B에 접근해서는 안 됩니다. 이후 A가 완료되어 completeRequest가 실행되고 나머지 선두도 완료 상태이면 A, B 순으로 반환된다는 조건과 다음 확인할 큐 선두·상태·pending 버퍼·콜백을 연결하세요. 하드웨어 처리 순서 보장이나 실제 실험 결과로 쓰지 마세요.', ['completion','buffer-duty','complete-access'], ['RequestPending','queuedRequests_','completeRequest','A','B','콜백'],3),
part('cancel','앞의 A/B 예에서 B만 cancelRequest 경로로 바꾼 조건부 해석을 설명하세요. cancelRequest가 Request::Private::cancel 뒤 completeRequest를 부르므로 같은 제출 순서·반환 뒤 핸들러 접근 제한이 적용되며 취소만으로 A를 건너뛰는 즉시 애플리케이션 반환을 주장할 수 없다는 점을 설명하세요. addBuffer 호출자의 버퍼 유지 기한도 요청 완료 콜백 기준으로 대조하세요. 앞 항목의 정상 순서를 다시 풀어 쓰지 마세요.', ['completion','cancel-rules','buffer-duty','complete-access'], ['cancelRequest','completeRequest','콜백'],2),
parts['fence-timeout'],parts['reuse-fences'],
part('change','변경 검토를 위한 소스 기반 조사 계획이라고 명시하세요. 마지막 bufferCompleted에서 조기 재사용하도록 바꾸기 전에 알림 이후 내부 추적 갱신, 모든 버퍼 완료와 명시 요청 완료, 제출 순서 queuedRequests_, 요청 완료 콜백까지 버퍼 유지와 completeRequest/cancelRequest 반환 후 핸들러 접근 금지를 함께 확인할 항목으로 연결하세요. completeRequest 또는 completeBuffer 호출 책임을 다른 스레드로 옮기려면 두 API의 CameraManager 스레드 호출 의무와 호출자·콜백·큐·Request::reuse 경계를 검토해야 합니다. 실제 콜백 스레드·장치 DMA·캐시·실행 시간과 사내 HAL은 이 소스 검토로 검증되지 않았음을 짧게 명시하세요. 현재 코드가 역사적 설계 이유나 대안 우열을 증명한다고 쓰지 말고 필요하면 결정 기록·실행 자료가 추가로 필요하다고 구별하세요. 실제 없는 함수·로그·명령을 만들지 마세요.', ['completion','create','reuse','buffer-duty','complete-access','cancel-rules'], ['CameraManager','completeBuffer','completeRequest','cancelRequest','queuedRequests_','reuse','계획'],3,basis='investigation')]
topic['explanation']=[dict(id=id,title=title,parts=ids) for id,title,ids in [
 ('problem','제출 성공 뒤에도 남는 수명 문제',['problem']),
 ('principle','소유권과 두 완료 경계',['ownership']),
 ('normal','정상 완료와 다음 요청 준비',['fence-transfer','normal']),
 ('conditions','알림 순서와 취소가 달라질 때',['early-buffer','out-of-order','cancel','fence-timeout','reuse-fences']),
 ('change','완료 책임을 변경하기 전에',['change'])]]
topic['design_prompt']='standard'
start=text.index('  - id: resources\n',text.index('- id: request-lifecycle\n'))
end=text.index('  - id: stopping\n',start)
replacement=yaml.safe_dump([topic],allow_unicode=True,sort_keys=False,width=110)
path.write_text(text[:start]+''.join('  '+line+'\n' for line in replacement.rstrip().splitlines())+text[end:],encoding='utf-8',newline='\n')
print('Updated existing resources topic; retained all original source windows.')
