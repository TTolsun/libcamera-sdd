from pathlib import Path
import json,hashlib,re
from sdd.site_localization import display_pairs,source_hash,selector
root=Path(__file__).resolve().parents[2];work=root/'build/issue249';base=work/'bilingual_review.py';prefix=base.read_text(encoding='utf-8').split('agent=Agent(',1)[0];scope={'__file__':str(base)};exec(compile(prefix,str(base),'exec'),scope)
payload=scope['payload'];catalog=scope['catalog'];old=json.loads((work/'bilingual-review-v10/payload.json').read_bytes());old_report=json.loads((work/'bilingual-review-v10/result.json').read_bytes());previous={p['korean']:p for p in old['pairs']};assert len(previous)==len(payload['pairs'])
shown={}
for page in (work/'preview-final-context').rglob('*.html'):
 rel=page.relative_to(work/'preview-final-context').as_posix()
 if rel.startswith('en/'):continue
 text=page.read_text(encoding='utf-8')
 raw=re.sub(r'<details class="language-selector">.*?</details>','',text,count=1,flags=re.S)
 raw=re.sub(r'<link rel="alternate"[^>]*>','',raw)
 assert selector(raw,rel,False)==text and source_hash(raw)==catalog['pages'][rel],rel
 for pair in display_pairs(text,catalog['strings']):
  value={'source':pair['source'],'translated':pair['translated']};values=shown.setdefault(pair['key'],[])
  if value not in values:values.append(value)
changed=[];retained=[]
for pair in payload['pairs']:
 pair['actual_english_displays']=shown.get(pair['korean'],[]);before=previous[pair['korean']]
 if pair!=before:changed.append(pair)
 else:retained.append(dict(id=pair['id'],sha256=hashlib.sha256(json.dumps(pair,ensure_ascii=False,sort_keys=True).encode()).hexdigest()))
assert {p['id'] for p in changed}=={'77','110'},[p['id'] for p in changed]
ids={sid for p in changed for c in p['contexts'] for sid in c['source_ids']};focused={**payload,'pairs':changed,'pinned_sources':{k:v for k,v in payload['pinned_sources'].items() if k in ids}}
out=work/'bilingual-review-v11';out.mkdir();agent=scope['Agent'](scope['load'](root/'examples/libcamera/validation/issue249/independent-review.yaml').agent,out/'prompts')
result=json.loads(agent.chat('Independent bilingual source reviewer. Automatic review is not human approval. Return JSON.','Review every supplied pair against its full pinned contexts and actual rendered English. Preserve individual investigation points and the general release scope. These are the only changed units since the previous complete review; no new assessment of unchanged units is requested.\n'+json.dumps(focused,ensure_ascii=False),tag='bilingual-source-review-scoped',response_schema=scope['schema']))
report=dict(result=result,catalog_sha256=hashlib.sha256((work/'integration/english.json').read_bytes()).hexdigest(),receipt=str(agent.last_receipt),changed_pairs=len(payload['pairs']),newly_reviewed_pairs=[p['id'] for p in changed],retained_unmodified_pairs=retained,previous_complete_review=str(work/'bilingual-review-v10/result.json'),previous_review_sha256=hashlib.sha256((work/'bilingual-review-v10/result.json').read_bytes()).hexdigest(),assessment='Current full coverage combines the unchanged complete-review units with fresh independent review of all changed units; the previous needs-revision result is preserved, not rewritten.',human_review='pending')
(out/'payload.json').write_text(json.dumps(focused,ensure_ascii=False,indent=2),encoding='utf-8');(out/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False));assert result['verdict']=='pass'
