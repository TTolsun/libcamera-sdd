from pathlib import Path
root=Path(__file__).resolve().parents[2];path=root/'build/issue249/repair_bilingual_semantics.py';text=path.read_text(encoding='utf-8').replace("'translation-independent-repairs'","'translation-independent-repairs-v2'").replace('bilingual-review-v9/payload.json','bilingual-review-v10/payload.json')
start=text.index('feedback={');end=text.index('\nfor ident,note',start)
text=text[:start]+'''feedback={
 '77':'Preserve an instrumentation plan that distinguishes EACH of these five investigation points individually: submission return values, request state, preparation/readiness waiting, device queue, and completion callbacks. Do not group the first two against the other three.',
 '110':'Translate 해제 순서 as release order. Do not narrow this general release wording to unlocking only.'}'''+text[end:]
exec(compile(text,str(path),'exec'))
