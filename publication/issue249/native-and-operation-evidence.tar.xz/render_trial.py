from pathlib import Path
import sys,yaml
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'src'))
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.visuals import render,place
from sdd.document_metadata import split_frontmatter
from sdd.generated_design import digest
from sdd.export_site import export_site
from sdd.site_build import verify_site
cfg=load(root/'build/issue249/work/sdd.yaml')
model=KnowledgeModel.load(cfg.facts_path)
source=yaml.safe_load((root/'examples/libcamera/config/visuals.yaml').read_text(encoding='utf-8'))
rows=[r for r in source['sections']['request-lifecycle'] if r['topic']=='resources']
(cfg.root/'visuals.yaml').write_text(yaml.safe_dump(dict(schema=1,sections={'request-lifecycle':rows}),allow_unicode=True,sort_keys=False),encoding='utf-8')
section=cfg.sections()[0]
path=cfg.sdd_dir/'request-lifecycle.md'
meta,body=split_frontmatter(path.read_text(encoding='utf-8'))
body=place(body,render(cfg,model,section),section)
meta['generated_design']['body_sha256']=digest(body.strip())
path.write_text('---\n'+yaml.safe_dump(meta,allow_unicode=True,sort_keys=False)+'---\n'+body,encoding='utf-8')
site=export_site(cfg,root/'build/issue249/trial-site')
print(verify_site(site))
