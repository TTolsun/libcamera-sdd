from pathlib import Path
import yaml,json,hashlib,shutil
root=Path(__file__).resolve().parents[2];work=root/'build/issue249';out=work/'integration';public=work/'public'
prior=json.loads((work/'issue243/operation/run/english.json').read_bytes());latest_path=public/'publication/issue248/english.json';latest=json.loads(latest_path.read_bytes());manifest=json.loads((public/'docs/site-manifest.json').read_bytes())
assert hashlib.sha256(latest_path.read_bytes()).hexdigest()==manifest['inputs']['english_catalog']
catalog=json.loads((out/'english.json').read_bytes());shutil.copyfile(out/'english.json',out/'english-before-issue248.json')
changes=[]
for source,target in latest['strings'].items():
 if prior['strings'].get(source)!=target:
  changes.append(dict(source=source,old_translation=catalog['strings'].get(source),preserved_public_translation=target));catalog['strings'][source]=target
(out/'english.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
latest_cfg=yaml.safe_load((public/'publication/issue248/publication.yaml').read_bytes());edits=latest_cfg['site']['coverage_question_edits']
for name in ['sdd.yaml','independent-review.yaml']:
 path=out/name;raw=yaml.safe_load(path.read_bytes());raw['site']['coverage_question_edits']=edits;path.write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
(out/'issue248-preservation.json').write_text(json.dumps(dict(source_public_commit='9ff02041c62c06dd2602ee4b0514d4cd4a5bbfd8',preserved_catalog_changes=changes,coverage_question_edits=edits,new_inference=False,human_review='pending'),ensure_ascii=False,indent=2),encoding='utf-8')
print(len(changes),'original public translations and',len(edits),'page question-label policies preserved')
