from pathlib import Path
import yaml,json,copy,hashlib
from sdd.config import load
from sdd.render_profiles import for_page
from sdd.facts.model import KnowledgeModel
from sdd import generated_visuals,generated_design
from sdd.generate import Generator
from sdd.design_types import DesignResult
from sdd.document_metadata import split_frontmatter
from sdd.llm import Agent
root=Path(__file__).resolve().parents[2];work=root/'build/issue249';out=work/'integration';cfg=load(out/'sdd.yaml');model=KnowledgeModel.load(cfg.facts_path);section=next(s for s in cfg.sections() if s['id']=='pipeline-handler');selected=for_page(cfg,'pipeline-handler.md')
visualpath=out/'visuals.yaml';visuals=yaml.safe_load(visualpath.read_bytes());canonical=yaml.safe_load((root/'examples/libcamera/config/visuals.yaml').read_bytes());plan=next(g for g in visuals['sections']['pipeline-handler'] if g['id']=='handler-device-ownership');updated=next(g for g in canonical['sections']['pipeline-handler'] if g['id']==plan['id']);plan.update({k:updated[k] for k in ['question','prompt']});visualpath.write_text(yaml.safe_dump(visuals,allow_unicode=True,sort_keys=False),encoding='utf-8')
path=cfg.sdd_dir/'pipeline-handler.md';before=path.read_text(encoding='utf-8');(out/'pipeline-handler-before-question-fix.md').write_text(before,encoding='utf-8');meta,_=split_frontmatter(before)
agent=Agent(selected.agent,work/'handler-question-generation/prompts');visual=generated_visuals.generate(selected,model,section,agent,previous=before)
pinned,resolved,report=generated_design.validate_answers(model,section,meta['generated_design']['answers'])
class NoCalls:
 def chat(self,*a,**k):raise RuntimeError('A figure-only correction cannot substitute prose inference')
gen=Generator(selected,model,NoCalls());gen.generated_designs[section['id']]=DesignResult(pinned,resolved,report,copy.deepcopy(meta['generated_design']));gen.generated_visuals[section['id']]=visual;gen._prose(section)
after,body=split_frontmatter(path.read_text(encoding='utf-8'))
for key in ['generated_at','agent','generation_method','revalidated_from']:
 if key in meta:after[key]=meta[key]
path.write_text('---\n'+yaml.safe_dump(after,allow_unicode=True,sort_keys=False)+'---\n'+body,encoding='utf-8');assert after['generated_design']['answers']==meta['generated_design']['answers']
generated_design.verify(model,section,path.read_text(encoding='utf-8'),cfg=selected);generated_visuals.from_manuscript(selected,model,section,path.read_text(encoding='utf-8'))
_,records,_,_,_=generated_visuals.inputs(selected,model,section,plan)
payload=dict(question=plan['question'],graph=visual['records'][plan['id']]['graph'],pinned_sources=records,scope='Only the changed ownership graph and its question; unchanged prose and other graphs are preserved, not newly approved.')
review=work/'handler-question-review';review.mkdir();(review/'payload.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
schema=dict(type='object',additionalProperties=False,required=['verdict','findings','reviewed_scope','unreviewed'],properties={'verdict':{'enum':['pass','needs-revision']},'findings':dict(type='array',items={'type':'string'}),'reviewed_scope':{'type':'string'},'unreviewed':dict(type='array',items={'type':'string'})})
reviewer=Agent(load(root/'examples/libcamera/validation/issue249/independent-review.yaml').agent,review/'prompts');result=json.loads(reviewer.chat('Independent bilingual source-grounding reviewer. Automatic review is not human approval. Return JSON.','Review every node, edge and caption against pinned source only. Distinguish releasing a stored MediaDevice from destruction of the device, handler destructor timing, factory creation/reference lifetime, match duties and execution versus ownership relations.\n'+json.dumps(payload,ensure_ascii=False),tag='handler-ownership-grounding',response_schema=schema))
(review/'result.json').write_text(json.dumps(dict(result=result,receipt=str(reviewer.last_receipt),manuscript_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),prose_answers_unchanged=True,human_review='pending'),ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False));assert result['verdict']=='pass'
