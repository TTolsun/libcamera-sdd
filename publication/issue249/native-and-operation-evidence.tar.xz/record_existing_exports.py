from pathlib import Path
root=Path(__file__).resolve().parents[2];path=root/'build/issue249/export_final.py'
text=path.read_text(encoding='utf-8').replace("first=export_site(cfg,work/'release/site');one=verify_site(first)","first=work/'release/site';one=verify_site(first)").replace("second=export_site(cfg,work/'public/docs');two=verify_site(second)","second=work/'public/docs';two=verify_site(second)")
exec(compile(text,str(path),'exec'))
