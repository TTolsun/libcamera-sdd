from pathlib import Path
import sys,json,hashlib
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'src'))
from sdd.config import load
from sdd.document_metadata import split_frontmatter
from sdd.llm import Agent
rubric=root/'examples/libcamera/validation/issue249/rubric.json'
questions=root/'examples/libcamera/validation/issue249/questions.json'
schema=dict(type='object',additionalProperties=False,required=['verdict','questions','limitations'],properties={
 'verdict':{'enum':['pass','needs-revision']},
 'questions':dict(type='array',items=dict(type='object',additionalProperties=False,required=['id','passed','reason'],properties={'id':{'type':'string'},'passed':{'type':'boolean'},'reason':{'type':'string'}})),
 'limitations':dict(type='array',items={'type':'string'})})
for label,answerpath,docpath in [
 ('baseline',root/'build/issue249/baseline-reading/result.json',root/'build/issue249/baseline/request-lifecycle.md'),
 ('final',root/'build/issue249/final-reading/result.json',root/'build/issue249/integration/manuscripts/request-lifecycle.md')]:
 answers=json.loads(answerpath.read_bytes())
 assert answers['questions_sha256']==hashlib.sha256(questions.read_bytes()).hexdigest()
 assert answers['document_sha256']==hashlib.sha256(docpath.read_bytes()).hexdigest()
 ids=[q['id'] for q in json.loads(questions.read_bytes())['questions']]
 assert [a['id'] for a in answers['result']['answers']]==ids
 _,doc=split_frontmatter(docpath.read_text(encoding='utf-8'))
 out=root/'build/issue249'/f'{label}-grading-v2'
 agent=Agent(load(root/'examples/libcamera/validation/issue249/independent-review.yaml').agent,out/'prompts')
 user=('Grade the document-only reading answers against the fixed questions and source-based criteria. '
       'Do not assume author intent, hidden code or a device test. Distinguish a normal-path description '
       'from an asserted current-time guarantee. Report actual missing or incorrect decisions; do not '
       'fail merely on wording when condition, actor and modality are preserved.\nQUESTIONS\n'+questions.read_text(encoding='utf-8')+
       '\nCRITERIA (not supplied to the reader)\n'+rubric.read_text(encoding='utf-8')+
       '\nREADER ANSWERS\n'+json.dumps(answers['result'],ensure_ascii=False)+'\nDOCUMENT\n'+doc)
 result=json.loads(agent.chat('Independent source-based reading grader. This is automatic CLI evaluation, never a human comprehension study. Return JSON.',user,tag='reading-grading',response_schema=schema))
 assert {r['id'] for r in result['questions']}==set(ids)
 assert (result['verdict']=='pass')==all(r['passed'] for r in result['questions'])
 report=dict(result=result,answer_sha256=hashlib.sha256(answerpath.read_bytes()).hexdigest(),rubric_sha256=hashlib.sha256(rubric.read_bytes()).hexdigest(),document_sha256=answers['document_sha256'],receipt=str(agent.last_receipt),human_review='pending')
 (out/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 print(label,json.dumps(result,ensure_ascii=False),flush=True)
