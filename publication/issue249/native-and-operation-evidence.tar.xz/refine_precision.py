from pathlib import Path
import yaml
root=Path(__file__).resolve().parents[2]
path=root/'examples/libcamera/config/sections.yaml'
text=path.read_text(encoding='utf-8');data=yaml.safe_load(text)
topic=next(t for s in data['sections'] if s['id']=='request-lifecycle' for t in s['design_topics'] if t['id']=='resources')
parts={p['id']:p for p in topic['parts']}
parts['normal']['question'] += ' 상태 선택은 cancelled_가 false일 때 RequestComplete, true일 때 RequestCancelled라는 실제 조건식으로 설명하세요. 취소된 버퍼가 없다는 사실만으로 cancelled_가 false라고 치환하지 마세요. cancelRequest는 남은 버퍼가 없어도 cancelled_를 true로 만들 수 있으므로 정상 경로와 취소 경로를 혼합하지 마세요.'
parts['early-buffer']['question']='조건 하나만 바꾼 예입니다. 마지막 bufferCompleted 알림이 왔지만 요청 완료 콜백은 아직 없다고 가정하세요. addBuffer 호출자의 버퍼 유효성 유지 의무가 끝났다고 판단할 근거가 없다는 결론과, bufferCompleted emit 뒤 내부 버퍼 추적을 갱신하며 마지막 버퍼만으로 요청이 자동 완료되지 않는 관계를 설명하세요. 유효성 의무를 깨뜨리는 버퍼 해제는 이 계약을 위반하지만, 그 기간 모든 버퍼 재사용이나 다른 요청 연결을 일괄 금지하는 소스 계약으로 확대하지 마세요. 다른 요청 연결 가능성은 유효성 유지와 해당 API·동기화 계약을 별도로 대조해야 하며 이 알림만으로 안전을 판정할 수 없다고 구별하세요. 다음 확인은 기존 completeBuffer 반환, 명시 completeRequest와 실제 요청 완료 콜백을 관찰하는 소스 기반 조사 계획으로 짧게 제안하세요. 기기 결과나 새 동기화 동작을 만들지 마세요.'
start=text.index('  - id: resources\n',text.index('- id: request-lifecycle\n'));end=text.index('  - id: stopping\n',start)
replacement=yaml.safe_dump([topic],allow_unicode=True,sort_keys=False,width=110)
path.write_text(text[:start]+''.join(('  '+line).rstrip()+'\n' for line in replacement.rstrip().splitlines())+text[end:],encoding='utf-8',newline='\n')
vp=root/'examples/libcamera/config/visuals.yaml'
v=vp.read_text(encoding='utf-8').replace('B는 완료 상태로 큐에 남음','B는 RequestComplete 또는 RequestCancelled로 큐에 남음').replace('B remains completed in queue','B remains queued as RequestComplete or RequestCancelled')
vp.write_text(v,encoding='utf-8',newline='\n')
print('Preserved actual cancelled_ condition and validity duty without inventing a blanket reuse prohibition.')
