from pathlib import Path
import yaml,shutil
root=Path(__file__).resolve().parents[2]
for source,target in [('integration/manuscripts/request-lifecycle.md','final-reading/document.md'),('accepted-topic.md','accepted-topic-v5.md'),('repeat.json','repeat-v5.json')]:
 src=root/'build/issue249'/source;dst=root/'build/issue249'/target
 if src.exists() and not dst.exists():shutil.copyfile(src,dst)
path=root/'examples/libcamera/config/sections.yaml';text=path.read_text(encoding='utf-8');data=yaml.safe_load(text)
topic=next(t for s in data['sections'] if s['id']=='request-lifecycle' for t in s['design_topics'] if t['id']=='resources')
part=next(p for p in topic['parts'] if p['id']=='out-of-order')
part['question']='ソースから導く条件付きの例であることを明示してください。'.replace('ソースから導く条件付きの例であることを明示してください。','소스에서 유도한 조건부 예라고 명시하세요. A 다음 B를 제출했고 A는 선두 RequestPending이며 B의 모든 버퍼와 추가 처리가 끝나 completeRequest(B)를 호출한 조건입니다. 이 조건만으로 B의 cancelled_ 값이 false라고 가정하지 마세요. 상태 대입은 cancelled_가 false이면 RequestComplete, true이면 RequestCancelled이므로 값이 주어지지 않으면 두 상태 분기를 함께 설명해야 합니다. 버퍼 처리가 끝났다는 사실만으로 비취소를 뜻하지 않는다는 점을 간단히 구별하세요. 두 상태 모두 queuedRequests_ 선두 A가 Pending이면 애플리케이션 반환이 지연됩니다. 그동안 addBuffer 호출자의 B 버퍼 유효성 기한은 요청 완료 콜백이고, 파이프라인 핸들러는 completeRequest(B) 반환 뒤 B에 접근해서는 안 됩니다. A가 완료되고 이어지는 선두들이 완료 상태이면 A, B 순으로 반환된다는 조건을 연결하세요. 다음 확인은 Private::complete의 상태 대입 지점에서 cancelled_와 상태를 대조하고, 제출 큐의 선두·pending 버퍼·완료 콜백을 관찰하는 조사 계획으로만 제시하세요. 핸들러가 completeRequest 반환 뒤 B를 읽도록 제안하지 마세요. 실제 기기 결과나 하드웨어 처리 순서를 보장하지 마세요.')
for term in ['RequestComplete','RequestCancelled','cancelled_']:
 if [term] not in part['answer_contract']['required_terms']:part['answer_contract']['required_terms'].append([term])
start=text.index('  - id: resources\n',text.index('- id: request-lifecycle\n'));end=text.index('  - id: stopping\n',start)
replacement=yaml.safe_dump([topic],allow_unicode=True,sort_keys=False,width=110)
path.write_text(text[:start]+''.join(('  '+line).rstrip()+'\n' for line in replacement.rstrip().splitlines())+text[end:],encoding='utf-8',newline='\n')
print('The fixed A/B question now has both cancelled_ state branches explicitly in its owned example.')
