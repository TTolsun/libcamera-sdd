from pathlib import Path
import hashlib,json,os,tarfile
root=Path(__file__).resolve().parents[2];work=root/'build/issue249';out=work/'evidence';archive=out/'native-and-operation-evidence.tar.xz';index={}
excluded={'source','public','issue243','issue250','.venv','trial-site','release'}
files=[]
for folder,dirs,names in os.walk(work):
 if Path(folder)==work:dirs[:]=[d for d in dirs if d not in excluded and not d.startswith(('pytest','preview'))]
 dirs[:]=[d for d in dirs if d not in {'.git','__pycache__','node_modules','trial-site'} and not d.startswith('.site-')]
 for name in names:
  p=Path(folder)/name;rel=p.relative_to(work)
  if p==archive or name in {'archive-index.json','package.json'} or p.suffix in {'.html','.js','.css','.woff2','.map','.pyc','.lock','.xz','.gz','.zip'}:continue
  if p.is_symlink():raise RuntimeError('Unexpected linked evidence file: '+str(p))
  files.append((p,rel.as_posix()))
for folder in ['src/sdd','templates','style']:
 for p in (root/folder).rglob('*'):
  if p.is_file() and p.suffix in {'.py','.md','.j2','.js','.css'} and '__pycache__' not in p.parts:files.append((p,'generator/'+p.relative_to(root).as_posix()))
for name in ['pyproject.toml','uv.lock','AGENTS.md','DESIGN.md']:
 files.append((root/name,'generator/'+name))
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for p,rel in sorted(files,key=lambda x:x[1]):
  data=p.read_bytes();index[rel]=hashlib.sha256(data).hexdigest();tar.add(p,arcname=rel,recursive=False)
(out/'archive-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding='utf-8')
report=dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),index_sha256=hashlib.sha256((out/'archive-index.json').read_bytes()).hexdigest(),files=len(index),bytes=archive.stat().st_size,excluded='Public/issue243/issue250 inherited archives, source Git clone, pytest doubles, rendered HTML/assets, caches and local CLI executables are excluded. Referenced original inherited publication artifacts remain in libcamera-sdd.',human_review='pending')
(out/'package.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False))
