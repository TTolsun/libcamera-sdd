from pathlib import Path
import yaml
root=Path(__file__).resolve().parents[2]
path=root/'examples/libcamera/config/sections.yaml'
text=path.read_text(encoding='utf-8');data=yaml.safe_load(text)
topic=next(t for s in data['sections'] if s['id']=='request-lifecycle' for t in s['design_topics'] if t['id']=='resources')
parts={p['id']:p for p in topic['parts']}
normal=parts['normal']
normal.update(question='정상 처리의 일반 호출 순서와 관측 시점의 판단을 구분해 세 문단 이내로 설명하세요. completeBuffer는 bufferCompleted를 emit한 뒤 요청 내부 버퍼 추적을 갱신하고, 마지막 버퍼만으로 요청이 자동 완료되지 않으므로 핸들러가 필요한 처리를 마친 뒤 completeRequest로 명시 통지해야 한다는 계약을 설명하세요. 두 API의 CameraManager 스레드 의무와 실제 콜백 실행 스레드의 미검증을 구별하세요. completeRequest가 호출하는 내부 complete의 실제 상태 선택은 cancelled_가 false이면 RequestComplete, true이면 RequestCancelled입니다. 취소된 버퍼가 없다는 사실만으로 cancelled_가 false라고 바꾸지 마세요. 다음 문단은 마지막 버퍼 알림을 관찰했지만 요청 완료 콜백은 아직 관찰하지 못한 조건부 예입니다. 이 관측만으로 현재 내부 추적 갱신이나 completeRequest 호출이 아직 남았다고 단정하지 마세요. 앞의 수명 원리에서 정한 기한이 끝났다는 근거도 되지 않으며, 알림만으로 버퍼 해제나 다른 요청 연결의 안전성을 판정할 수 없다고 설명하세요. 유효성을 깨뜨리는 해제와 모든 재사용의 일괄 금지를 구별하고 다른 요청 연결 가능성은 API·동기화 계약과 유효성 유지를 별도로 대조해야 한다고 설명하세요. 공통 버퍼 유지 의무·핸들러 접근 금지·재사용 책임 문장은 반복하지 마세요. 다음 확인은 기존 completeBuffer 반환과 completeRequest, 제출 순서 지연 여부, 요청 완료 콜백을 관찰할 소스 기반 조사 계획으로 짧게 연결하세요. 실제 실행 결과나 두 사건의 관측되지 않은 시간 순서를 만들지 마세요.',sources=['completion','internal-completion','buffer-duty'],max_statements=3)
normal['answer_contract']['required_terms']=[['completeBuffer'],['bufferCompleted'],['completeRequest'],['CameraManager'],['cancelled_'],['RequestComplete'],['RequestCancelled']]
if ['reuse'] not in parts['ownership']['answer_contract']['required_terms']:parts['ownership']['answer_contract']['required_terms'].append(['reuse'])
start=text.index('  - id: resources\n',text.index('- id: request-lifecycle\n'));end=text.index('  - id: stopping\n',start)
replacement=yaml.safe_dump([topic],allow_unicode=True,sort_keys=False,width=110)
path.write_text(text[:start]+''.join(('  '+line).rstrip()+'\n' for line in replacement.rstrip().splitlines())+text[end:],encoding='utf-8',newline='\n')
print('Separated API call ordering from the current state inferred from an observed notification.')
