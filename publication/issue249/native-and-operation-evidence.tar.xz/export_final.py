from pathlib import Path
import json,hashlib
from sdd.config import load
from sdd.export_site import export_site
from sdd.site_build import verify_site
from sdd.facts.model import KnowledgeModel
root=Path(__file__).resolve().parents[2];work=root/'build/issue249';cfg=load(work/'integration/sdd.yaml')
first=export_site(cfg,work/'release/site');one=verify_site(first)
before=(first/'site-manifest.json').read_bytes();manifest=json.loads(before)
second=export_site(cfg,work/'public/docs');two=verify_site(second)
assert before==(second/'site-manifest.json').read_bytes(),'Identical publication inputs changed the manifest'
for rel,digest in manifest['outputs'].items():
 assert hashlib.sha256((first/rel).read_bytes()).hexdigest()==hashlib.sha256((second/rel).read_bytes()).hexdigest()==digest,rel
report=dict(status='passed',source_commit=KnowledgeModel.load(cfg.facts_path).meta['source_commit'],first_site=str(first),public_site=str(second),build_id=manifest['build_id'],manifest_sha256=hashlib.sha256(before).hexdigest(),owned_outputs=len(manifest['outputs']),same_manifest_and_outputs=True,first_verification=one,public_verification=two,human_review='pending')
(work/'evidence/two-exports.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False))
