from pathlib import Path
import yaml,json,re,shutil
root=Path(__file__).resolve().parents[2]
shutil.copyfile(root/'build/issue249/work/manuscripts/request-lifecycle.md',root/'build/issue249/topic-grounding-v7/document.md')
path=root/'examples/libcamera/config/visuals.yaml';text=path.read_text(encoding='utf-8');data=yaml.safe_load(text)
rows=data['sections']['request-lifecycle'];graph=next(g for g in rows if g['id']=='completed-but-not-returned')
records=json.loads((root/'build/issue249/work/facts/facts.json').read_bytes())['evidence'];record=records['request-lifecycle/resources/completion']
quote='while (!data->queuedRequests_.empty()) {';assert record['text'].count(quote)==1
loop=dict(source='resources/completion',sha256=record['sha256'],quote=quote)
byid={n['id']:n for n in graph['nodes']}
byid['head'].update(label='현재 큐 선두가 RequestPending인가?',label_en='Is the current queue head RequestPending?')
byid['wait'].update(label='선두 Pending에서 반환 루프 중단',label_en='Stop the return loop at a Pending head')
byid['return'].update(label='현재 선두를 제거하고 앱에 반환',label_en='Pop the current head and return it to the app')
graph['nodes'].append(dict(id='end',label='이 반환 루프 종료',label_en='End this return loop',evidence=[loop]))
for edge in graph['edges']:
 if edge['from']=='head' and edge['to']=='wait':edge.update(label='선두가 Pending이면 break',label_en='Break if the head is Pending')
 if edge['from']=='head' and edge['to']=='return':edge.update(label='Pending 아님: ASSERT 뒤 제거·반환',label_en='Not Pending: pop and return after ASSERT')
graph['edges'] += [dict(**{'from':'return','to':'head'},label='큐가 남으면 다음 선두를 다시 검사',label_en='Recheck the next head if the queue is nonempty',evidence=[loop]),dict(**{'from':'return','to':'end'},label='큐가 비었으면 이 루프 종료',label_en='End this loop if the queue is empty',evidence=[loop]),dict(**{'from':'wait','to':'end'},label='break로 루프 종료',label_en='Exit the loop via break',evidence=[next(e['evidence'][0] for e in graph['edges'] if e['from']=='head' and e['to']=='wait')])]
graph['question']='A 다음 B를 제출한 조건부 예이며 두 요청 사이에 다른 요청이 있을 수도 있습니다. cancelled_가 B의 상태를 정하고, 반환 루프는 현재 선두를 하나씩 검사합니다. 중간 Pending 요청에서도 중단하므로 A가 끝났다는 사실만으로 B 반환을 보장하지 않습니다. 수명 화살표는 접근·유효성 계약이며 실제 콜백 시각이나 함수 전체의 종료 순서가 아닙니다.'
start=text.index('  request-lifecycle:\n');m=re.search(r'^  [a-z][a-z0-9_-]*:\n',text[start+3:],re.M);end=start+3+m.start() if m else len(text)
replacement=yaml.safe_dump({'request-lifecycle':rows},allow_unicode=True,sort_keys=False,width=110)
path.write_text(text[:start]+''.join(('  '+line).rstrip()+'\n' for line in replacement.rstrip().splitlines())+text[end:],encoding='utf-8',newline='\n')
print('Added the actual per-head return loop and its Pending/empty exits; ten nodes remain under limit 12.')
