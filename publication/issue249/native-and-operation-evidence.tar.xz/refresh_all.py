from pathlib import Path
import sys,json,yaml,hashlib
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'src'))
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.carryover import carry_forward
from sdd.generate import Generator
out=root/'build/issue249/integration';cfg=load(out/'sdd.yaml');model=KnowledgeModel.load(cfg.facts_path)
class NoCalls:
 def chat(self,*a,**k):raise RuntimeError('Source carryover cannot supply substitute inference')
generator=Generator(cfg,model,NoCalls())
written=[cfg.sdd_dir/'request-lifecycle.md']
for section in cfg.sections():
 if section.get('kind')=='per-package' and section.get('narration','facts')=='facts':
  written.append(generator._per_package(section,None))
promoted,stale=carry_forward(cfg,model,written)
report=dict(source_commit=model.meta['source_commit'],promoted=[str(p.relative_to(out)) for p in promoted],
 stale=[dict(path=str(p.relative_to(out)),reasons=why) for p,why in stale],
 build_scope=dict(translation_units=model.meta['translation_units'],classes=len(model.classes),
 lc_compliance='disabled in the actual new build; its 5 translation units and 9 test-tool classes are outside this extraction'),
 new_runtime_results=False,human_review='pending')
(out/'source-carryover.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
if stale:raise SystemExit('Unresolved source carryover; publication blocked.')
raw=yaml.safe_load((out/'sdd.yaml').read_text(encoding='utf-8'))
raw['paths']['consistency_review_config']=str(out/'independent-review.yaml')
(out/'sdd.yaml').write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
(out/'independent-review.yaml').write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
