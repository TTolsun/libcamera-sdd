from pathlib import Path
root=Path(__file__).resolve().parents[2];path=root/'build/issue249/bilingual_review_batch.py'
text=path.read_text(encoding='utf-8').replace('bilingual-review-v8','bilingual-review-v10')
marker="payload,schema,out=scope['payload'],scope['schema'],scope['out'];out.mkdir(parents=True,exist_ok=False)"
extra='''
from sdd.site_localization import display_pairs
displayed={}
for page in (root/'build/issue249/preview-final-context').rglob('*.html'):
 if 'en' in page.relative_to(root/'build/issue249/preview-final-context').parts:continue
 for pair in display_pairs(page.read_text(encoding='utf-8'),scope['catalog']['strings']):
  value={'source':pair['source'],'translated':pair['translated']}
  values=displayed.setdefault(pair['key'],[])
  if value not in values:values.append(value)
for pair in payload['pairs']:
 pair['actual_english_displays']=displayed.get(pair['korean'],[])
'''
assert marker in text;text=text.replace(marker,marker+'\n'+extra)
text=text.replace("Preserve global pair IDs in findings.","Preserve global pair IDs in findings. actual_english_displays comes from the normal DisplayText renderer, which translates inline children before substituting placeholders. Original inline_tokens describe Korean source labels, not unresolved English labels. Use supplied actual displays for rendered-label findings. Visible-text units may concatenate separate HTML elements; do not infer visual spacing from concatenation alone.")
exec(compile(text,str(path),'exec'))
