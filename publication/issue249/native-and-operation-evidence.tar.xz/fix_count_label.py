from pathlib import Path
import json,hashlib,shutil
from sdd.config import load
from sdd.llm import Agent
from sdd.translation import _validate_text
root=Path(__file__).resolve().parents[2];path=root/'build/issue249/integration/english.json'
out=root/'build/issue249/count-label-translation';out.mkdir()
shutil.copyfile(path,out/'catalog-before.json')
source='절 전체 근거 {{1}}개'
agent=Agent(load(root/'examples/libcamera/validation/issue249/independent-review.yaml').agent,out/'prompts')
schema=dict(type='object',additionalProperties=False,required=['text'],properties={'text':{'type':'string'}})
result=json.loads(agent.chat('Translate the UI label into clear English, preserving the opaque placeholder. Return JSON.',json.dumps({'source':source,'context':'Shared section-wide evidence count. The count can be 1 or more. Use a count-neutral label valid for every count. Independent review rejected the previous plural-only items label.'}),tag='count-neutral-label',response_schema=schema))
text=_validate_text(source,result['text']);catalog=json.loads(path.read_bytes());catalog['strings'][source]=text
path.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'result.json').write_text(json.dumps(dict(source=source,text=text,receipt=str(agent.last_receipt),catalog_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),human_review='pending'),ensure_ascii=False,indent=2),encoding='utf-8')
print(text)
