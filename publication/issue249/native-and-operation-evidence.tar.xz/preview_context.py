from pathlib import Path
from sdd.config import load
from sdd.export_site import _render_site
root=Path(__file__).resolve().parents[2]
print(_render_site(load(root/'build/issue249/integration/sdd.yaml'),root/'build/issue249/preview-final-context',check_consistency=False))
