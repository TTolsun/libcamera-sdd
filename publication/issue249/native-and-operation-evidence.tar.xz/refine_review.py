from pathlib import Path
import yaml
root=Path(__file__).resolve().parents[2]
path=root/'examples/libcamera/config/sections.yaml'
text=path.read_text(encoding='utf-8')
data=yaml.safe_load(text)
topic=next(t for s in data['sections'] if s['id']=='request-lifecycle' for t in s['design_topics'] if t['id']=='resources')
parts={p['id']:p for p in topic['parts']}
parts['problem']['question']='요청 제출 함수의 성공 반환만으로 버퍼 회수 가능 여부를 판단할 수 있는가라는 문제를 한두 문장으로 설명하세요. Camera::queueRequest의 0은 ConnectionTypeQueued invokeMethod 호출 뒤의 성공 반환값이고, 완료 여부는 별도의 requestCompleted 통지로 판단한다는 의미를 구분하세요. 반환 시점에 콜백이 아직 없다고 단정하거나 콜백이 반환 이후에만 발생한다고 쓰지 마세요. 소스는 성공 반환값과 완료 판정의 차이를 보여 주며 두 사건의 실제 시간 순서를 보장하지 않습니다.'
parts['problem']['answer_contract']['reject_patterns']=[dict(pattern=r'콜백이?\s*아직|아직[^.]{0,25}콜백|반환[^.]{0,15}(?:후에만|이후에만)',message='0 반환만으로 완료 여부를 판단할 수 없다고 쓰고 반환·콜백의 실제 시간 순서를 단정하지 마세요.')]
parts['cancel']['question']='앞의 정상 완료 예와 분리된 대안 조건부 경로입니다. A가 선두에서 RequestPending이고 B도 아직 RequestPending인 시점에 정상 completeRequest(B) 대신 cancelRequest(B)를 선택한 경우만 설명하세요. 이미 완료한 B를 다시 취소하는 예로 이어 쓰지 마세요. Request::Private::doCancelRequest는 pending_ 버퍼를 취소하고 bufferCompleted를 emit한 다음 pending_를 비우며 cancelled_를 true로 설정합니다. cancelRequest가 cancel 다음 completeRequest를 호출하면 Request::Private::complete는 RequestCancelled를 선택하고, 선두 A가 RequestPending이면 B의 애플리케이션 반환은 지연됩니다. 수명과 접근 규칙은 앞의 공통 원리를 따른다고 짧게 연결하고 의무 문장은 반복하지 마세요. 취소 즉시 A를 건너뛰는 반환이나 버퍼 회수를 보장하지 마세요.'
start=text.index('  - id: resources\n',text.index('- id: request-lifecycle\n'))
end=text.index('  - id: stopping\n',start)
replacement=yaml.safe_dump([topic],allow_unicode=True,sort_keys=False,width=110)
path.write_text(text[:start]+''.join('  '+line+'\n' for line in replacement.rstrip().splitlines())+text[end:],encoding='utf-8',newline='\n')
print('Bound authoring to independent grounding findings; evaluation questions unchanged.')
