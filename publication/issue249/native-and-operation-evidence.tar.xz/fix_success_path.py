from pathlib import Path
import yaml,shutil
root=Path(__file__).resolve().parents[2]
src=root/'build/issue249/work/manuscripts/request-lifecycle.md'
if src.exists():shutil.copyfile(src,root/'build/issue249/topic-grounding-v6/document.md')
path=root/'examples/libcamera/config/sections.yaml';text=path.read_text(encoding='utf-8');data=yaml.safe_load(text)
topic=next(t for s in data['sections'] if s['id']=='request-lifecycle' for t in s['design_topics'] if t['id']=='resources')
part=next(p for p in topic['parts'] if p['id']=='problem')
part['question']='요청 제출의 성공 반환과 실제 완료를 혼동하는 문제를 두 문장 이내로 소개하세요. 설명의 적용 범위는 Camera::queueRequest가 입력 검사를 통과해 0을 반환하는 성공 경로로 명시적으로 한정합니다. 이 성공 경로에서는 ConnectionTypeQueued invokeMethod 호출 뒤 0을 반환하며, 요청 완료는 별도 requestCompleted로 통지된다는 차이만 설명하세요. 여러 검증 실패에서 음수를 반환할 수 있으므로 모든 호출이 invokeMethod까지 도달하거나 항상 0을 반환하는 것처럼 쓰지 마세요. 버퍼 유지 의무의 주체·기한은 다음 항목이 소유하므로 반복하지 마세요. 성공 반환 순간의 실제 콜백 진행 상태나 콜백이 반드시 반환 뒤 발생한다는 시간 보장을 만들지 마세요. 첫 문장에 성공 경로라는 조건을 포함하세요.'
part['answer_contract']['required_terms'].append(['성공 경로'])
start=text.index('  - id: resources\n',text.index('- id: request-lifecycle\n'));end=text.index('  - id: stopping\n',start)
replacement=yaml.safe_dump([topic],allow_unicode=True,sort_keys=False,width=110)
path.write_text(text[:start]+''.join(('  '+line).rstrip()+'\n' for line in replacement.rstrip().splitlines())+text[end:],encoding='utf-8',newline='\n')
print('Problem paragraph explicitly scopes invokeMethod/0 to the successful validation path.')
