from pathlib import Path
import yaml,re,shutil
root=Path(__file__).resolve().parents[2];path=root/'examples/libcamera/config/visuals.yaml'
shutil.copyfile(root/'build/issue249/accepted-topic-final-v10.md',root/'build/issue249/topic-grounding-v10/document.md')
text=path.read_text(encoding='utf-8');data=yaml.safe_load(text);rows=data['sections']['request-lifecycle'];g=next(g for g in rows if g['id']=='completed-but-not-returned')
for e in g['edges']:
 if (e['from'],e['to'])==('head','return'):e.update(label='Pending 아님',label_en='Not Pending')
 if (e['from'],e['to'])==('return','head'):e.update(label='다음 선두',label_en='Next head')
start=text.index('  request-lifecycle:\n');m=re.search(r'^  [a-z][a-z0-9_-]*:\n',text[start+3:],re.M);end=start+3+m.start() if m else len(text)
replacement=yaml.safe_dump({'request-lifecycle':rows},allow_unicode=True,sort_keys=False,width=110)
path.write_text(text[:start]+''.join(('  '+line).rstrip()+'\n' for line in replacement.rstrip().splitlines())+text[end:],encoding='utf-8',newline='\n')
