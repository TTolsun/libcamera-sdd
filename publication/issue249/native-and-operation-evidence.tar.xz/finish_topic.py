from pathlib import Path
import subprocess,sys,json,os
root=Path(__file__).resolve().parents[2]
os.environ['PYTHONUTF8']='1'
def run(*args):
 subprocess.run([sys.executable,*map(str,args)],cwd=root,check=True)
run(root/'build/issue249/fix_success_path.py')
run(root/'build/issue249/prepare.py')
run('-m','sdd.cli','--config','build/issue249/work/sdd.yaml','generate','--sections','request-lifecycle')
run(root/'build/issue249/render_trial.py')
run(root/'examples/libcamera/validation/issue249/evaluate.py','--document','build/issue249/work/manuscripts/request-lifecycle.md','--mode','grounding','--sources','build/issue249/work/source-windows.json','--out','build/issue249/topic-grounding-v7')
result=json.loads((root/'build/issue249/topic-grounding-v7/result.json').read_bytes())
if result['result']['verdict']!='pass':raise SystemExit('Independent topic grounding requires revision; integration not promoted.')
run(root/'build/issue249/integrate.py')
run(root/'examples/libcamera/validation/issue249/evaluate.py','--document','build/issue249/integration/manuscripts/request-lifecycle.md','--mode','reading','--out','build/issue249/final-reading-v2')
print('TOPIC GROUNDED; integrated document-only reading completed. Separate grading and publication remain.')
