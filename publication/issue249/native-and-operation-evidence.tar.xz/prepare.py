from pathlib import Path
import sys, json, shutil, yaml, hashlib
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'src'))
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.evidence import collect
from sdd.document_metadata import split_frontmatter

out=root/'build/issue249/work'
out.mkdir(exist_ok=True)
cfg=load(out/'sdd.yaml') if (out/'sdd.yaml').exists() else load(root/'examples/libcamera/sdd.yaml')
current=load(root/'examples/libcamera/sdd.yaml')
section=next(s for s in current.sections() if s['id']=='request-lifecycle')
topic=next(t for t in section['design_topics'] if t['id']=='resources')
selected={**section,'design_topics':[topic], 'design_requirements':[r for r in section['design_requirements'] if r['id']=='resources']}
selected.pop('reader_profile',None)
selected.pop('reader_family',None)
selected.pop('reader_scope',None)
selected.pop('routes',None)
selected['next']=dict(title='요청 수명',link='request-lifecycle.md')
(out/'sections.yaml').write_text(yaml.safe_dump({'sections':[selected]},allow_unicode=True,sort_keys=False),encoding='utf-8')
raw=dict(source=dict(root=str(root/'build/issue249/source'),compile_commands=str(cfg.compile_commands)),
 output=dict(facts_dir='facts',sdd_dir='manuscripts',diagrams_dir='manuscripts/diagrams'),
 paths=dict(sections_file='sections.yaml',prompts=str(current.prompts_dir),templates=str(current.templates_dir),style=str(current.style_dir)),
 agent=dict(kind='cli',runner='codex',model='gpt-6.1-terra',args=['-c','model_reasoning_effort="high"'],max_input_chars=100000,timeout_sec=600,full_style_guides=False),
 review=dict(require_citations=True,design_grounding=True,cli_checkpoint=True,max_retries=1,design_revision=False,max_calls=100,max_seconds=14400),
 site=dict(enabled=False),diagrams=dict(enabled=False),visuals=dict(file='visuals.yaml',max_nodes=12,on_stale='error'))
(out/'sdd.yaml').write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
(out/'visuals.yaml').write_text('schema: 1\nsections: {}\n',encoding='utf-8')
trial=load(out/'sdd.yaml')
stable=root/'build/issue249/baseline/full-facts.json'
if not stable.exists():
 stable.parent.mkdir(exist_ok=True)
 shutil.copyfile(root/'build/issue249/integration/facts/facts.json',stable)
model=KnowledgeModel.load(stable)
collect(trial,model)
bad={k:v.get('reason') for k,v in model.evidence.items() if v['status']!='available'}
assert not bad,bad
model.save(trial.facts_path)
baseline=root/'build/issue249/baseline'
baseline.mkdir(exist_ok=True)
for name in ('site-manifest.json','request-lifecycle.md','request-lifecycle.html'):
 shutil.copyfile(root/'build/issue249/public/docs'/name,baseline/name)
(baseline/'source-windows.json').write_text(json.dumps(model.evidence,ensure_ascii=False,indent=2),encoding='utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(baseline/'freeze.json').write_text(json.dumps(dict(source_commit=model.meta['source_commit'],manuscript_sha256=sha(baseline/'request-lifecycle.md'),questions_sha256=sha(root/'examples/libcamera/validation/issue249/questions.json'),reviewed_windows={k:dict(file=v['file'],line=v['line'],end_line=v['end_line'],sha256=v['sha256']) for k,v in model.evidence.items()},unreviewed=['individual hardware pipeline DMA/cache/timing','historical rationale and alternative designs','inhouse HAL','human comprehension']),indent=2),encoding='utf-8')
print('Prepared source-bound independent CLI generation:',model.meta['source_commit'])
