from pathlib import Path
import json,shutil
root=Path(__file__).resolve().parents[2]
path=root/'examples/libcamera/validation/issue249/rubric.json'
shutil.copyfile(path,root/'build/issue249/rubric-initial.json')
data=json.loads(path.read_bytes())
data['criteria']['buffer-first']='버퍼 알림만으로 유효성 의무 종료나 해제·재연결의 안전성을 판정할 수 없다고 답해야 합니다. 버퍼 알림과 요청 완료의 관계, 실제 문서 근거와 다음 확인을 찾아야 합니다. 현재 추적 갱신이나 completeRequest 호출이 아직 남았다는 보장을 만들거나 모든 재사용의 일괄 금지로 확대하면 안 됩니다. 질문에서 지정하지 않은 스트림 조건·addBuffer 반환값의 상세 나열은 필수가 아닙니다.'
data['criteria']['out-of-order']='A가 선두 Pending인 조건에서 B의 내부 상태 갱신과 애플리케이션 반환 지연을 구분해야 합니다. 정상 비취소 상태와 취소 상태를 구분할 근거가 문서에 있는지 밝혀야 하며, 없는 근거를 만들어내면 안 됩니다. B 버퍼의 콜백까지 유효성 유지와 완료 함수 반환 뒤 핸들러 접근 금지는 서로 다른 경계입니다. A 완료 후의 조건부 반환 순서와 다음 확인을 찾아야 합니다. 식별자 철자 자체는 채점 기준이 아니며, 필수 상태 판단이 실제로 미발견이면 미충족입니다.'
data['criteria']['cancel']='정상 완료 대신 취소한 별도 조건에서 취소·완료 호출과 같은 반환 순서·접근 제한·버퍼 기한을 찾아야 합니다. 이미 완료된 B를 다시 취소하는 경로라고 잘못 해석하면 안 됩니다. fence의 실제 상태 확인, 미신호 타임아웃 뒤 releaseFence 회수와 ReuseBuffers의 fence 사용 시 부정형 권고를 찾아야 합니다. 권고를 절대 금지나 실행 결과로 바꾸면 안 됩니다. 질문에 명시되지 않은 상태 열거 이름을 적지 않았다는 이유만으로 오답 처리하지 않습니다.'
data['pass_rule'] += ' 첫 채점에서 발생한 질문 밖 상세 요구를 제외합니다. 출처·조건·결과·다음 확인이라는 최초 평가 요소를 양쪽 문서에 동일하게 적용합니다.'
path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Kept fixed questions and original pass dimensions; excluded unasked lexical/API-detail grading requirements.')
