from pathlib import Path
import sys,json,yaml,copy,shutil
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'src'))
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.carryover import carry_forward
from sdd.render_profiles import for_page
from sdd.document_metadata import split_frontmatter
from sdd import generated_visuals,generated_design
from sdd.evidence import fingerprint
from sdd.design_types import DesignResult
from sdd.generate import Generator
from sdd.llm import Agent
out=root/'build/issue249/integration';cfg=load(out/'sdd.yaml');model=KnowledgeModel.load(cfg.facts_path)
shutil.copyfile(out/'source-carryover.json',out/'source-carryover-initial.json')
paths=list(cfg.sdd_dir.rglob('*.md'))
for name in ['official-cam-validation.md','request-diagnosis.md']:
 selected=for_page(cfg,name)
 promoted,stale=carry_forward(selected,model,[p for p in paths if p!=cfg.sdd_dir/name])
 assert not stale,(name,stale)
 print('Historical profile source carryover:',name,flush=True)
section=next(s for s in cfg.sections() if s['id']=='vendor-assurance')
path=cfg.sdd_dir/'vendor-assurance.md';original=path.read_text(encoding='utf-8');meta,_=split_frontmatter(original)
agent=Agent(cfg.agent,out/'vendor-visual-generation')
visual=generated_visuals.generate(cfg,model,section,agent,previous=original)
pinned,resolved,report=generated_design.validate_answers(model,section,meta['generated_design']['answers'])
artifact=copy.deepcopy(meta['generated_design'])
artifact.update(input_fingerprint=fingerprint(model,section),generated_topics=[],reused_topics=list(artifact['answers']))
artifact['source_carryover']=dict(original_source_commit=meta['source_commit'],current_source_commit=model.meta['source_commit'],new_prose_inference=False,human_review='pending')
class NoCalls:
 def chat(self,*a,**k):raise RuntimeError('Graph-only assembly cannot substitute prose inference')
generator=Generator(cfg,model,NoCalls());generator.generated_designs[section['id']]=DesignResult(pinned,resolved,report,artifact)
generator.generated_visuals[section['id']]=visual
generator._prose(section)
updated,body=split_frontmatter(path.read_text(encoding='utf-8'))
for key in ['generated_at','agent','generation_method']:
 if key in meta:updated[key]=meta[key]
updated['revalidated_from']=meta['source_commit']
path.write_text('---\n'+yaml.safe_dump(updated,allow_unicode=True,sort_keys=False)+'---\n'+body,encoding='utf-8')
generated_design.verify(model,section,path.read_text(encoding='utf-8'),cfg=cfg)
generated_visuals.from_manuscript(cfg,model,section,path.read_text(encoding='utf-8'))
(out/'vendor-source-windows.json').write_text(json.dumps({k:v for k,v in model.evidence.items() if k.startswith('vendor-assurance/')},ensure_ascii=False,indent=2),encoding='utf-8')
print('Fresh native Codex/Terra High figure; original prose producer and timestamp retained.',flush=True)
raw=yaml.safe_load((out/'sdd.yaml').read_text(encoding='utf-8'))
raw['paths']['consistency_review_config']=str(out/'independent-review.yaml')
(out/'sdd.yaml').write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
(out/'independent-review.yaml').write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
(out/'carry-resolution.json').write_text(json.dumps(dict(source_commit=model.meta['source_commit'],historical_profile_carryover=['official-cam-validation.md','request-diagnosis.md'],new_native_figure_document='vendor-assurance.md',new_prose_inference=False,human_review='pending'),indent=2),encoding='utf-8')
