from pathlib import Path
import yaml,json
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.carryover import carry_forward
from sdd.render_profiles import for_page
root=Path(__file__).resolve().parents[2];out=root/'build/issue249/integration';previous=root/'build/issue249/issue243/operation'
profile=yaml.safe_load((previous/'vendor-assurance-current-authentication.yaml').read_bytes());profile['paths']['style']=str(previous/'current-style')
target=out/'vendor-issue243-authentication.yaml';target.write_text(yaml.safe_dump(profile,allow_unicode=True,sort_keys=False),encoding='utf-8')
for name in ['sdd.yaml','independent-review.yaml']:
 raw=yaml.safe_load((out/name).read_bytes());raw['site']['manuscript_profiles']['vendor-assurance.md']=str(target)
 (out/name).write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
cfg=load(out/'sdd.yaml');model=KnowledgeModel.load(cfg.facts_path)
promoted,stale=carry_forward(for_page(cfg,'vendor-assurance.md'),model,[p for p in cfg.sdd_dir.rglob('*.md') if p.name!='vendor-assurance.md'])
report=dict(source_commit=model.meta['source_commit'],upstream_public_commit='0f8e6e43',promoted=[str(p) for p in promoted],stale=[(str(p),e) for p,e in stale],native_inference=False,verification_profile='Relocated exact #243 agent/style profile; producer, generation time and original source preserved',human_review='pending')
(out/'issue243-preservation-final.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False));assert not stale
