from pathlib import Path
import shutil
root=Path(__file__).resolve().parents[2];source=root/'build/issue249/fix_handler_question.py'
shutil.copyfile(root/'build/issue249/integration/manuscripts/pipeline-handler.md',root/'build/issue249/handler-question-review/document.md')
text=source.read_text(encoding='utf-8').replace("'handler-question-generation/prompts'","'handler-question-generation-v2/prompts'").replace("'handler-question-review'","'handler-question-review-v2'")
exec(compile(text,str(source),'exec'))
