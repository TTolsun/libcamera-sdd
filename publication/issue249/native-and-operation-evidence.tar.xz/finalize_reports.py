from pathlib import Path
import json,yaml,hashlib,shutil
from sdd.document_metadata import split_frontmatter
root=Path(__file__).resolve().parents[2];work=root/'build/issue249';out=work/'integration';evidence=work/'evidence';source='be7e83e91348250c015aad6d6f59f1468555bae8'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
document=out/'manuscripts/request-lifecycle.md';reading=read(work/'final-reading-v5/result.json');graded=read(work/'final-grading-v6/result.json');grounded=read(work/'topic-grounding-v12/result.json')
assert reading['document_sha256']==graded['document_sha256']==sha(document)
assert graded['result']['verdict']=='pass' and len(graded['result']['questions'])==5 and all(q['passed'] for q in graded['result']['questions'])
assert grounded['result']['verdict']=='pass' and grounded['document_sha256']==sha(work/'topic-grounding-v12/document.md')
current_meta,_=split_frontmatter(document.read_text(encoding='utf-8'));prototype,_=split_frontmatter((work/'topic-grounding-v12/document.md').read_text(encoding='utf-8'))
assert current_meta['generated_design']['answers']['resources']==prototype['generated_design']['answers']['resources']
catalog=out/'english.json';bilinguals=[p for p in work.glob('bilingual-review*/result.json') if read(p).get('catalog_sha256')==sha(catalog) and read(p)['result']['verdict']=='pass'];assert bilinguals,'Current catalog needs a fresh independent bilingual review'
consistency=out/'build/consistency-review.json';audit=read(consistency);assert audit['status']=='passed' and audit['source_commit']==source
assert read(evidence/'native-call-verification.json')['status']=='verified'
assert all(j['conclusion']=='success' for j in read(evidence/'regression.json')['jobs'])
acceptance=dict(status='passed',stage='issue249-representative-automatic-review',source_commit=source,manuscript_sha256=sha(document),catalog_sha256=sha(catalog),fixed_questions_sha256=sha(root/'examples/libcamera/validation/issue249/questions.json'),rubric_sha256=sha(root/'examples/libcamera/validation/issue249/rubric.json'),reader_result_sha256=sha(work/'final-reading-v5/result.json'),grader_result_sha256=sha(work/'final-grading-v6/result.json'),source_review_sha256=sha(work/'topic-grounding-v12/result.json'),source_review_original_commit=prototype['source_commit'],source_identical_revalidation=read(evidence/'source-and-extraction.json'),bilingual_result=str(bilinguals[-1].relative_to(work)),bilingual_result_sha256=sha(bilinguals[-1]),baseline_automatic_questions_passed=4,final_automatic_questions_passed=5,human_review='pending',human_study='not conducted; issue and Goal remain open',consistency_unresolved=audit['unresolved'])
(evidence/'acceptance.json').write_text(json.dumps(acceptance,ensure_ascii=False,indent=2),encoding='utf-8')
# Preserve historical benchmark and access-default gates as historical records;
# replace regression/visual/native/consistency prerequisites with current proofs.
raw=yaml.safe_load((out/'sdd.yaml').read_bytes());inherited=[];prereq=out/'historical-prerequisites';prereq.mkdir(exist_ok=True)
for row in raw['publication']['reports']:
 if row['producer'] not in {'inherited-historical-fixed-policy-benchmark-not-remeasured','independent-codex-header-default-review'}:continue
 target=prereq/Path(row['path']).name
 if Path(row['path']).resolve()!=target.resolve():shutil.copyfile(row['path'],target)
 assert sha(target)==row['sha256'];inherited.append({**row,'path':str(target)})
def gate(path,producer,keys):
 data=read(path);return dict(path=str(path),gate='before-export',producer=producer,sha256=sha(path),bindings={k:data[k] for k in keys})
reports=inherited+[
 gate(evidence/'regression.json','generator-ci',['status','stage','source_commit']),
 gate(evidence/'per-item-visualization.json','source-bound-per-item-assessment',['status','stage','source_commit']),
 gate(evidence/'native-call-verification.json','original-native-receipt-verifier',['status','stage','source_commit']),
 gate(consistency,'independent-codex-cli-audit',['status','source_commit','human_review']),
 gate(evidence/'acceptance.json','independent-source-and-document-only-reading',['status','stage','source_commit','manuscript_sha256','catalog_sha256','human_review'])]
for name in ['sdd.yaml','independent-review.yaml']:
 path=out/name;data=yaml.safe_load(path.read_bytes());data['publication']['reports']=reports
 latest=yaml.safe_load((work/'issue250/baseline/publication.yaml').read_bytes())['publication'].get('allowed_contract_changes',{})
 data['publication']['allowed_contract_changes']={**latest,**data['publication'].get('allowed_contract_changes',{})}
 path.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
print('Current publication reports bound:',len(reports),'unresolved inherited/global claims:',len(audit['unresolved']))
