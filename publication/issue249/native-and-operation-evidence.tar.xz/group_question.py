from pathlib import Path
import yaml
root=Path(__file__).resolve().parents[2]
path=root/'examples/libcamera/config/sections.yaml'
text=path.read_text(encoding='utf-8');data=yaml.safe_load(text)
topic=next(t for s in data['sections'] if s['id']=='request-lifecycle' for t in s['design_topics'] if t['id']=='resources')
parts={p['id']:p for p in topic['parts']}
parts['problem']['sources']=['queue']
parts['problem']['question']='요청 제출의 성공 반환과 실제 완료를 혼동하면 수명 판단을 할 수 없다는 문제를 한두 문장으로 소개하세요. Camera::queueRequest의 0은 ConnectionTypeQueued invokeMethod 호출 뒤 성공 반환이며, 요청 완료는 별도 requestCompleted로 통지한다는 차이를 설명하세요. 버퍼 유지 의무의 주체와 기한은 다음 항목이 소유하므로 여기서 반복하지 마세요. 0이 반환되는 순간에 콜백이 아직 없다고 단정하거나 콜백이 반드시 반환 뒤 발생한다고 쓰지 마세요.'
normal=parts['normal']
normal['sources'].append('buffer-duty')
normal['question'] += ' 같은 묶음에서 마지막 bufferCompleted만 받았고 요청 완료 콜백은 아직 없다는 조건을 적용하세요. 알림 emit 뒤 내부 추적 갱신과 명시 완료 호출이 남는다는 방금 설명한 관계 때문에, 이 알림만으로 수명 의무가 끝났다는 결론은 나오지 않는다고 설명하세요. 공통 버퍼 유지 의무 문장을 다시 쓰지 마세요. 유효성을 깨뜨리는 해제와 모든 재사용의 일괄 금지를 구별하고, 다른 요청 연결 가능성은 해당 API·동기화 계약과 유효성 유지를 별도로 대조해야 한다고 설명하세요. 실행 결과가 아니라 소스에 따른 조건부 판단이며, 확인 위치는 기존 completeBuffer 반환·completeRequest·요청 완료 콜백으로 제한하세요.'
normal['max_statements']=4
topic['parts']=[parts[p] for p in ['problem','ownership','normal','out-of-order','cancel','fence-transfer','fence-timeout','reuse-fences','change']]
for stage in topic['explanation']:
 if stage['id']=='normal':stage['parts']=['normal']
 if stage['id']=='conditions':stage['parts']=['out-of-order','cancel','fence-transfer','fence-timeout','reuse-fences']
start=text.index('  - id: resources\n',text.index('- id: request-lifecycle\n'));end=text.index('  - id: stopping\n',start)
replacement=yaml.safe_dump([topic],allow_unicode=True,sort_keys=False,width=110)
path.write_text(text[:start]+''.join(('  '+line).rstrip()+'\n' for line in replacement.rstrip().splitlines())+text[end:],encoding='utf-8',newline='\n')
print('Grouped normal completion and buffer-only notification in one causal question; removed repeated premises.')
