from pathlib import Path
import yaml,re,shutil
root=Path(__file__).resolve().parents[2];path=root/'examples/libcamera/config/visuals.yaml'
shutil.copyfile(root/'build/issue249/accepted-topic-final.md',root/'build/issue249/topic-grounding-v9/document.md')
text=path.read_text(encoding='utf-8');data=yaml.safe_load(text);rows=data['sections']['request-lifecycle']
rows[:]=[g for g in rows if g['id']!='fence-reuse-conditions']
for g in rows:
 if g['id'] in {'lifecycle-timeout-fence-recovery','lifecycle-reuse-buffer-fence-distinction'}:g['stage']='conditions'
start=text.index('  request-lifecycle:\n');m=re.search(r'^  [a-z][a-z0-9_-]*:\n',text[start+3:],re.M);end=start+3+m.start() if m else len(text)
replacement=yaml.safe_dump({'request-lifecycle':rows},allow_unicode=True,sort_keys=False,width=110)
path.write_text(text[:start]+''.join(('  '+line).rstrip()+'\n' for line in replacement.rstrip().splitlines())+text[end:],encoding='utf-8',newline='\n')
