from pathlib import Path
import sys,json,subprocess
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'src'))
from sdd.config import load
from sdd.llm import Agent
out=root/'build/issue249/code-review'
base=subprocess.run(['git','merge-base','HEAD','origin/main'],cwd=root,capture_output=True,text=True,check=True).stdout.strip()
diff=subprocess.run(['git','diff',base,'--','src','tests'],cwd=root,capture_output=True,text=True,encoding='utf-8',check=True).stdout
for name in ['explanation','contract_schema','design_request','design_response','evidence','visuals','answer_contracts','generated_design','cli_checkpoint']:
 path=root/'src/sdd'/f'{name}.py'
 diff+='\nCOMPLETE CURRENT MODULE '+str(path.relative_to(root))+'\n'+path.read_text(encoding='utf-8')
schema=dict(type='object',additionalProperties=False,required=['verdict','findings','limitations'],properties={'verdict':{'enum':['pass','needs-revision']},'findings':dict(type='array',items={'type':'string'}),'limitations':dict(type='array',items={'type':'string'})})
agent=Agent(load(root/'examples/libcamera/validation/issue249/independent-review.yaml').agent,out/'prompts')
result=json.loads(agent.chat('Independent code reviewer. Review correctness and regression risks, not style preferences. Return JSON.','Review the optional explanation stages and stage-local diagrams. Check strict configuration errors, preserved source/quote/part coverage, assembly/publication validation, unchanged legacy behavior, fingerprint invalidation and meaningful tests. Evaluate the complete call path: shared configuration validators may own required fields and run before context/rendering. Identify a reachable failure before reporting a lower-level helper issue. Do not claim tests were run.\n'+diff,tag='generator-review',response_schema=schema))
out.mkdir(exist_ok=True)
(out/'result.json').write_text(json.dumps(dict(result=result,receipt=str(agent.last_receipt)),ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
