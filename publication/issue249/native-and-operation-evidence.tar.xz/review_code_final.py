from pathlib import Path
root=Path(__file__).resolve().parents[2]
source=(root/'build/issue249/review_code.py').read_text(encoding='utf-8').replace("build/issue249/code-review'", "build/issue249/code-review-final-v2'")
exec(compile(source,str(root/'build/issue249/review_code.py'),'exec'))
