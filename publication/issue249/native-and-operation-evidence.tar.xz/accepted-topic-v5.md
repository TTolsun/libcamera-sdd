---
generated_at: 2026-11-04 19:42:31+00:00
source_commit: 293d751a814e0d4c34e85ad457ccd9d5eefd1a61
status: ok
section: request-lifecycle
generation_method: facts-and-llm
evidence_fingerprint: 65426f4b505107d37659028107709f684b0d9ffe00759e7d72a256d361302d72
semantic_review: human-review-required
agent: cli/codex/gpt-6.1-terra
generated_design:
  schema: 1
  input_fingerprint: 65426f4b505107d37659028107709f684b0d9ffe00759e7d72a256d361302d72
  answers:
    resources:
    - text: '`Camera::queueRequest`는 `ConnectionTypeQueued`로 `invokeMethod`를 호출한 뒤
        성공을 뜻하는 `0`을 반환하며, 요청 완료는 별도의 `requestCompleted` 신호로 통지합니다. 따라서 제출 성공 반환만으로
        요청의 완료 여부와 수명을 판단할 수는 없습니다.'
      evidence:
      - queue
      covers:
      - resources
      kind: behavior
      quote: "d->pipe_->invokeMethod(&PipelineHandler::queueRequest,\n\t\t\t     \
        \  ConnectionTypeQueued, request);"
      part_id: problem
    - text: '`Camera::createRequest`가 반환한 `Request`의 소유권은 호출자에게 넘어가며, 호출자가 삭제해야 합니다.
        호출자는 완료 핸들러에서 요청을 삭제하거나 `Request::reuse`로 상태를 초기화한 뒤 재사용할 수 있습니다.'
      evidence:
      - create
      - reuse
      covers:
      - resources
      kind: behavior
      quote: "\\brief Create a request object for the camera\n * \\param[in] cookie\
        \ Opaque cookie for application use\n *\n * This function creates an empty\
        \ request for the application to fill with\n * buffers and parameters, and\
        \ queue for capture.\n *\n * The \\a cookie is stored in the request and is\
        \ accessible through the\n * Request::cookie() function at any time. It is\
        \ typically used by applications\n * to map the request to an external resource\
        \ in the request completion\n * handler, and is completely opaque to libcamera.\n\
        \ *\n * The ownership of the returned request is passed to the caller, which\
        \ is\n * responsible for deleting it. The request may be deleted in the completion\n\
        \ * handler, or reused after resetting its state with Request::reuse().\n\
        \ *\n * \\context This function is \\threadsafe. It may only be called when\
        \ the camera\n * is in the Configured or Running state as defined in \\ref\
        \ camera_operation.\n *\n * \\return A pointer to the newly created request,\
        \ or nullptr on error\n */\nstd::unique_ptr<Request> Camera::createRequest(uint64_t\
        \ cookie)"
      part_id: ownership
    - text: '`Request::addBuffer`는 버퍼 참조를 요청에 저장하며, 호출자는 요청 완료 콜백이 호출될 때까지 버퍼가 유효하도록
        유지해야 합니다. 파이프라인 핸들러는 `completeRequest` 또는 `cancelRequest`가 반환된 뒤 해당 요청에 접근해서는
        안 됩니다.'
      evidence:
      - buffer-duty
      - complete-access
      - cancel-rules
      covers:
      - resources
      kind: behavior
      quote: "A reference to the buffer is stored in the request. The caller is responsible\n\
        \ * for ensuring that the buffer will remain valid until the request complete\n\
        \ * callback is called."
      part_id: ownership
    - text: '`PipelineHandler::completeBuffer`는 `bufferCompleted`를 emit한 뒤 요청 내부 버퍼
        추적을 갱신하고, 모든 버퍼가 완료되었으면 `true`, 아니면 `false`를 반환합니다. 마지막 버퍼가 완료되어도 요청은 자동으로
        완료되지 않으므로 파이프라인 핸들러는 필요한 처리를 마친 뒤 `completeRequest`로 명시적으로 완료를 통지해야 합니다. 두
        API는 `CameraManager` 스레드에서 호출해야 하며, 제공된 소스는 실제 콜백 실행 스레드를 확인하지 않습니다. `completeRequest`가
        호출하는 내부 `complete`는 `cancelled_`가 `false`이면 `RequestComplete`, `true`이면 `RequestCancelled`를
        선택합니다.'
      evidence:
      - completion
      - internal-completion
      covers:
      - resources
      kind: behavior
      quote: "\\brief Complete a buffer for a request\n * \\param[in] request The\
        \ request the buffer belongs to\n * \\param[in] buffer The buffer that has\
        \ completed\n *\n * This function shall be called by pipeline handlers to\
        \ signal completion of\n * the \\a buffer part of the \\a request. It notifies\
        \ applications of buffer\n * completion and updates the request's internal\
        \ buffer tracking. The request\n * is not completed automatically when the\
        \ last buffer completes to give\n * pipeline handlers a chance to perform\
        \ any operation that may still be\n * needed. They shall complete requests\
        \ explicitly with completeRequest().\n *\n * \\context This function shall\
        \ be called from the CameraManager thread.\n *\n * \\return True if all buffers\
        \ contained in the request have completed, false\n * otherwise\n */\nbool\
        \ PipelineHandler::completeBuffer(Request *request, FrameBuffer *buffer)\n\
        {\n\tCamera *camera = request->_d()->camera();\n\tcamera->bufferCompleted.emit(request,\
        \ buffer);\n\treturn request->_d()->completeBuffer(buffer);\n}"
      part_id: normal
    - text: 마지막 버퍼 알림은 관찰했지만 요청 완료 콜백은 아직 관찰하지 못한 경우를 가정합니다. 이 관측만으로 내부 추적 갱신이나 `completeRequest`
        호출이 아직 남았다고 단정할 수 없으며, 앞서 정한 버퍼 유효성 유지 기한이 끝났다고 판단할 수도 없습니다. 알림만으로 버퍼 해제나
        다른 요청 연결의 안전성을 판정할 수는 없으며, 유효성을 깨뜨리는 해제와 모든 재사용을 일괄 금지하는 판단은 다릅니다. 다른 요청에
        연결할 수 있는지는 해당 API와 동기화 계약 및 버퍼 유효성 유지를 별도로 대조해야 합니다.
      evidence:
      - buffer-duty
      - completion
      covers:
      - resources
      kind: behavior
      quote: "A reference to the buffer is stored in the request. The caller is responsible\n\
        \ * for ensuring that the buffer will remain valid until the request complete\n\
        \ * callback is called."
      part_id: normal
    - text: 조사 계획에서는 기존 `completeBuffer` 호출의 반환값과 `completeRequest` 호출을 관찰합니다. 제출
        순서에 따라 선두 요청에서 반환이 지연되는지와 요청 완료 콜백도 확인합니다.
      evidence:
      - completion
      covers:
      - resources
      kind: behavior
      quote: "while (!data->queuedRequests_.empty()) {\n\t\tRequest *req = data->queuedRequests_.front();\n\
        \t\tif (req->status() == Request::RequestPending)\n\t\t\tbreak;"
      part_id: normal
    - text: 소스에서 유도한 조건부 예입니다. `A` 다음에 `B`를 제출하고 `A`가 `RequestPending`이며 `B`의 모든 버퍼와
        추가 처리가 끝난 상태에서 `completeRequest(B)`를 호출한다고 가정합니다. `cancelled_`가 false이면 `B`의
        상태는 `RequestComplete`가 되지만, `queuedRequests_` 선두의 `A`가 아직 `RequestPending`이므로
        반복문이 중단되어 `B`는 아직 애플리케이션에 반환되지 않습니다.
      evidence:
      - completion
      - internal-completion
      covers:
      - resources
      kind: behavior
      quote: "while (!data->queuedRequests_.empty()) {\n\t\tRequest *req = data->queuedRequests_.front();\n\
        \t\tif (req->status() == Request::RequestPending)\n\t\t\tbreak;"
      part_id: out-of-order
    - text: 이때 `addBuffer` 호출자는 `B`의 버퍼를 요청 완료 콜백이 호출될 때까지 유효하게 유지해야 합니다. 파이프라인 핸들러는
        `completeRequest(B)`가 반환된 뒤 `B`에 접근해서는 안 됩니다.
      evidence:
      - buffer-duty
      - complete-access
      covers:
      - resources
      kind: behavior
      quote: "A reference to the buffer is stored in the request. The caller is responsible\n\
        \ * for ensuring that the buffer will remain valid until the request complete\n\
        \ * callback is called."
      part_id: out-of-order
    - text: 이후 `A`가 완료되어 `completeRequest`가 실행되고 큐에서 확인하는 나머지 선두도 완료 상태이면 `A`, `B`
        순으로 애플리케이션에 반환됩니다. 조사 계획으로는 큐의 선두와 요청 상태, 대기 중인 버퍼, 요청 완료 콜백을 확인합니다.
      evidence:
      - completion
      covers:
      - resources
      kind: behavior
      quote: "ASSERT(!req->hasPendingBuffers());\n\t\tdata->queuedRequests_.pop_front();\n\
        \t\tcamera->requestComplete(req);\n\t}"
      part_id: out-of-order
    - text: 앞의 정상 완료 예와 별도로, 큐 선두의 A와 B가 모두 `RequestPending`인 시점에 B에 대해 정상 `completeRequest(B)`
        대신 `cancelRequest(B)`를 선택하는 경우입니다. `Request::Private::doCancelRequest`는 B의
        `pending_` 버퍼를 각각 취소하고 `bufferCompleted`를 emit한 뒤 `cancelled_`를 true로 설정하고
        `pending_`를 비웁니다. `cancelRequest`가 `cancel` 다음 `completeRequest`를 호출하면 `Request::Private::complete`는
        B의 상태로 `RequestCancelled`를 선택하지만, 큐 선두 A가 여전히 `RequestPending`이면 순회가 중단되어
        B의 애플리케이션 반환은 지연됩니다. 이 경로에도 앞에서 설명한 공통 수명과 접근 규칙이 적용됩니다.
      evidence:
      - completion
      - internal-completion
      - cancel-rules
      - buffer-duty
      - complete-access
      covers:
      - resources
      kind: behavior
      quote: "/**\n * \\brief Cancel request and signal its completion\n * \\param[in]\
        \ request The request to cancel\n *\n * This function cancels and completes\
        \ the request. The same rules as for\n * completeRequest() apply.\n */\nvoid\
        \ PipelineHandler::cancelRequest(Request *request)\n{\n\trequest->_d()->cancel();\n\
        \tcompleteRequest(request);\n}"
      part_id: cancel
    - text: '`Request::addBuffer()`는 성공하면 전달된 유효한 `Fence`의 소유권을 `buffer`로 이동하며, 실패하면
        전달된 `fence`를 수정하지 않고 소유권도 넘겨받지 않습니다.'
      evidence:
      - fence-move
      covers:
      - resources
      kind: behavior
      quote: "When a valid Fence is provided to this function, \\a fence is moved\
        \ to \\a\n * buffer and this Request will only be queued to the device once\
        \ the\n * fences of all its buffers have been correctly signalled. Ownership\
        \ of the\n * fence will only be taken in case of success, otherwise the fence\
        \ will\n * be left unmodified."
      part_id: fence-transfer
    - text: 버퍼에 연결된 펜스가 신호되지 않으면 요청은 타임아웃 후 실패하고 버퍼에는 펜스가 그대로 남습니다. 애플리케이션은 다른 요청에
        버퍼를 재사용하기 전에 `FrameBuffer::releaseFence()`로 펜스를 회수해야 합니다.
      evidence:
      - fence-expiry
      covers:
      - resources
      kind: behavior
      quote: "If the \\a fence associated with \\a buffer isn't signalled, the request\
        \ will\n * fail after a timeout. The buffer will still contain the fence,\
        \ which\n * applications must retrieve with FrameBuffer::releaseFence() before\
        \ the buffer\n * can be reused in another request."
      part_id: fence-timeout
    - text: '`ReuseBuffers`는 `addBuffer()`로 이전에 추가한 버퍼를 유지하여 재사용하지만, 버퍼에 연결된 fence는
        재사용하지 않습니다. fence를 사용하는 경우 이 플래그를 사용하지 않아야 한다고 권고합니다(`should not be used`).'
      evidence:
      - reuse-flags
      - reuse-advice
      covers:
      - resources
      kind: behavior
      quote: "\\enum Request::ReuseFlag\n * Flags to control the behavior of Request::reuse()\n\
        \ * \\var Request::Default\n * Don't reuse buffers\n * \\var Request::ReuseBuffers\n\
        \ * Reuse the buffers that were previously added by addBuffer()\n *\n * \\\
        note Fences associated with the buffers are not reused.\n *  This flag should\
        \ not be used if fences are used.\n */"
      part_id: reuse-fences
    - text: 조사 계획에서는 `completeBuffer`와 `completeRequest`의 기존 호출자와 스레드 전달 경계를 찾아 변경
        전후의 호출 위치를 대조합니다. 파이프라인 핸들러는 두 함수를 `CameraManager` 스레드에서 호출해야 하므로, 변경으로 다른
        스레드에서 이 API를 직접 호출하면 문서화된 의무와 충돌합니다. 이 계획은 실제 콜백 스레드, 기기 DMA, 캐시, 실행 시간이나
        사내 HAL의 검증 결과가 아닙니다. 역사적 설계 이유와 대안의 우열을 판단하려면 별도 결정 기록이나 실행 자료가 필요합니다.
      evidence:
      - completion
      covers:
      - resources
      kind: behavior
      quote: "\\brief Complete a buffer for a request\n * \\param[in] request The\
        \ request the buffer belongs to\n * \\param[in] buffer The buffer that has\
        \ completed\n *\n * This function shall be called by pipeline handlers to\
        \ signal completion of\n * the \\a buffer part of the \\a request. It notifies\
        \ applications of buffer\n * completion and updates the request's internal\
        \ buffer tracking. The request\n * is not completed automatically when the\
        \ last buffer completes to give\n * pipeline handlers a chance to perform\
        \ any operation that may still be\n * needed. They shall complete requests\
        \ explicitly with completeRequest().\n *\n * \\context This function shall\
        \ be called from the CameraManager thread.\n *\n * \\return True if all buffers\
        \ contained in the request have completed, false\n * otherwise\n */\nbool\
        \ PipelineHandler::completeBuffer(Request *request, FrameBuffer *buffer)\n\
        {\n\tCamera *camera = request->_d()->camera();\n\tcamera->bufferCompleted.emit(request,\
        \ buffer);\n\treturn request->_d()->completeBuffer(buffer);\n}"
      part_id: change
  topic_inputs:
    resources: 188cc6b19755f1edd323676cb950a0852ddb19c10f5802e89e28ba9488b075a1
  reused_topics: []
  replayed_units: []
  generated_topics:
  - resources
  topic_agents:
    resources: cli/codex/gpt-6.1-terra
  grounding_review: passed
  grounding_policy: 3c9673abb403dee9aa554ee5b3c549ebfe95bb18ec0e9cd7bf6e495e060439c2
  validation_policy:
    manuscript: 367d18b95f8f0d01a15ae0f4d1b70f7e13e4d0298df4215e2c449ac4905db6f9
    semantic: 571896e4854c21322a1ce4580107c235cae5a9f94e71adc8c97a7e2897405968
    duplicates: 93f0e8b5bdc1b40bf4ab38168e92c2772aa36747bec6add25921fbb90b909e38
    design_contracts: 9f54ecddce57c7a9caa6c02af77904b57eff2471f2a052951c1cffd18256a4f0
    validate: 78d29ffd1bf6235067edf5a0c7d9b1290f1f11e90599605a0e192e90be5f3372
    reader_profiles: ad9005d08295212371f59e8934ace86786c0683f7a4c416301ee0e0cadc8b797
    contract_schema: d0f7ab4c48fcf52409935931eb9b93aacd48af4b19e9bb816fa496f1214fdb2f
    answer_contracts: a39c9a8818afc47e059141d486337c0f12a7fd34319e2b6f7674fc428bc83e2b
    reader_scope: 1b9c26b10b74ae8cf034f5863cbac2114e1d844e5d8332eb1f10562a18371782
    product_context: 050c20aa2fdcceae10c6275fbb5f850f616ab5051bb67ccbcb4a204877a238d9
    explanation: 1772e7af4dcc7f1e084073e711a4c47131b08a1c422261e4a5d150357d85d384
    design_response: a7c199bc52bcc0e749ef01186e50bca98107473d5c82e2248712f465d02e1e69
    design_validation: a4edf8364d73d169c3f10ecbadf487a8a4dc10328622d07578b281eae810c3aa
  validation_model: b26084fcf4d1a892b9f145cd06e890ff459e76e739633c5d26f7aa69320295a2
  style_policy:
    fluent-korean.md: ce5aa71e58371e3fc02ff8cb165e07c9234f5166f6541423a91cc4cb40878975
    i-have-adhd.md: 3170b16ace00aecb0dd7feb54c0b5aa642e7502acda06ecd24fd89a11c7127e9
    README.md: b87a84b1bc31079837dc4dc4527ce02c9dc2cbc3a26ff7e99e0872941d213995
  body_sha256: a400be99a050729e02fc3fc9a774e1c1707c0d74b518739100c33cc4543e5a5a
---

# 요청 처리와 문제 진단

**요청의 제출 성공과 촬영 완료를 구분하고, 버퍼를 유지할 기간과 오류가 난 위치를 확인하세요.**



## 요청·버퍼·fence의 수명

### 제출 성공 뒤에도 남는 수명 문제

`Camera::queueRequest`는 `ConnectionTypeQueued`로 `invokeMethod`를 호출한 뒤 성공을 뜻하는 `0`을 반환하며, 요청 완료는 별도의 `requestCompleted` 신호로 통지합니다. 따라서 제출 성공 반환만으로 요청의 완료 여부와 수명을 판단할 수는 없습니다. `src/libcamera/camera.cpp:1308`

<!-- sdd:visual:lifecycle-timeout-fence-recovery -->
#### 타임아웃 뒤 펜스 회수

```mermaid
flowchart TB
%% sdd:translations {"다른 요청의 재사용에 필요한 <br/>회수 조건": "Required retrieval <br/>condition for reuse in <br/>another request", "버퍼에 펜스가 남음": "Buffer still contains its <br/>fence", "애플리케이션이 <br/>releaseFence#40;#41;로 회수": "Application retrieves with <br/>releaseFence#40;#41;", "요청 실패 뒤에도 유지": "Remains after request <br/>failure", "재사용 전 회수 의무": "Must retrieve before reuse", "펜스 미신호: 요청 타임아웃": "Unsignalled fence: request <br/>times out", "회수는 필요한 선행 조건": "Retrieval is a necessary <br/>precondition"}
  v_timeout["펜스 미신호: 요청 타임아웃"]
  v_retained["버퍼에 펜스가 남음"]
  v_retrieve["애플리케이션이 <br/>releaseFence#40;#41;로 회수"]
  v_reuse["다른 요청의 재사용에 필요한 <br/>회수 조건"]
  v_timeout -->|"요청 실패 뒤에도 유지"| v_retained
  v_retained -->|"재사용 전 회수 의무"| v_retrieve
  v_retrieve -->|"회수는 필요한 선행 조건"| v_reuse
```

[Mermaid 원문](request-lifecycle.lifecycle-timeout-fence-recovery.mmd)

??? note "그림 근거와 확인 범위"
    신호되지 않은 펜스로 타임아웃이 나면 다른 요청에 재사용하기 전에 무엇을 해야 합니까?
    
    소스에 연결한 설계 해석입니다. 자동 연결 검사는 의미 승인이나 기기 실행 검증이 아닙니다.
    
    | 요소·전이 | 소스 근거 |
    |---|---|
    | <span data-sdd-label-en="Unsignalled fence: request times out">펜스 미신호: 요청 타임아웃</span> | [src/libcamera/request.cpp:462](#source-d8cf34a75a4333a7) |
    | <span data-sdd-label-en="Buffer still contains its fence">버퍼에 펜스가 남음</span> | [src/libcamera/request.cpp:462](#source-d8cf34a75a4333a7) |
    | <span data-sdd-label-en="Application retrieves with releaseFence()">애플리케이션이 releaseFence&#40;&#41;로 회수</span> | [src/libcamera/request.cpp:462](#source-d8cf34a75a4333a7) |
    | <span data-sdd-label-en="Required retrieval condition for reuse in another request">다른 요청의 재사용에 필요한 회수 조건</span> | [src/libcamera/request.cpp:462](#source-d8cf34a75a4333a7) |
    | <span data-sdd-label-en="Remains after request failure">요청 실패 뒤에도 유지</span> | [src/libcamera/request.cpp:462](#source-d8cf34a75a4333a7) |
    | <span data-sdd-label-en="Must retrieve before reuse">재사용 전 회수 의무</span> | [src/libcamera/request.cpp:462](#source-d8cf34a75a4333a7) |
    | <span data-sdd-label-en="Retrieval is a necessary precondition">회수는 필요한 선행 조건</span> | [src/libcamera/request.cpp:462](#source-d8cf34a75a4333a7) |
<!-- /sdd:visual:lifecycle-timeout-fence-recovery -->

<!-- sdd:visual:lifecycle-reuse-buffer-fence-distinction -->
#### 버퍼 재사용과 펜스 권고

```mermaid
flowchart TB
%% sdd:translations {"API의 should not 권고": "API should-not <br/>recommendation", "ReuseBuffers": "ReuseBuffers", "버퍼와 펜스의 범위 구분": "Distinguish buffer and <br/>fence reuse", "앞서 addBuffer로 넣은 버퍼 <br/>재사용": "Reuse buffers previously <br/>added by addBuffer", "연결된 펜스는 재사용하지 <br/>않음": "Associated fences are not <br/>reused", "펜스를 쓰면 이 플래그를 <br/>피하도록 권고": "Should not use this flag <br/>with fences", "플래그의 재사용 범위": "Flag reuse scope"}
  v_flag["ReuseBuffers"]
  v_buffers["앞서 addBuffer로 넣은 버퍼 <br/>재사용"]
  v_fences["연결된 펜스는 재사용하지 <br/>않음"]
  v_advice["펜스를 쓰면 이 플래그를 <br/>피하도록 권고"]
  v_flag -->|"플래그의 재사용 범위"| v_buffers
  v_buffers -->|"버퍼와 펜스의 범위 구분"| v_fences
  v_fences -->|"API의 should not 권고"| v_advice
```

[Mermaid 원문](request-lifecycle.lifecycle-reuse-buffer-fence-distinction.mmd)

??? note "그림 근거와 확인 범위"
    ReuseBuffers가 재사용하는 대상과 펜스 사용 시 권고는 무엇입니까?
    
    소스에 연결한 설계 해석입니다. 자동 연결 검사는 의미 승인이나 기기 실행 검증이 아닙니다.
    
    | 요소·전이 | 소스 근거 |
    |---|---|
    | <span data-sdd-label-en="ReuseBuffers">ReuseBuffers</span> | [src/libcamera/request.cpp:326](#source-447804db33308244) |
    | <span data-sdd-label-en="Reuse buffers previously added by addBuffer">앞서 addBuffer로 넣은 버퍼 재사용</span> | [src/libcamera/request.cpp:326](#source-447804db33308244) |
    | <span data-sdd-label-en="Associated fences are not reused">연결된 펜스는 재사용하지 않음</span> | [src/libcamera/request.cpp:326](#source-447804db33308244) |
    | <span data-sdd-label-en="Should not use this flag with fences">펜스를 쓰면 이 플래그를 피하도록 권고</span> | [src/libcamera/request.cpp:326](#source-447804db33308244) |
    | <span data-sdd-label-en="Flag reuse scope">플래그의 재사용 범위</span> | [src/libcamera/request.cpp:326](#source-447804db33308244) |
    | <span data-sdd-label-en="Distinguish buffer and fence reuse">버퍼와 펜스의 범위 구분</span> | [src/libcamera/request.cpp:326](#source-447804db33308244) |
    | <span data-sdd-label-en="API should-not recommendation">API의 should not 권고</span> | [src/libcamera/request.cpp:326](#source-447804db33308244) |
<!-- /sdd:visual:lifecycle-reuse-buffer-fence-distinction -->

### 소유권과 두 완료 경계

`Camera::createRequest`가 반환한 `Request`의 소유권은 호출자에게 넘어가며, 호출자가 삭제해야 합니다. 호출자는 완료 핸들러에서 요청을 삭제하거나 `Request::reuse`로 상태를 초기화한 뒤 재사용할 수 있습니다. `Request::addBuffer`는 버퍼 참조를 요청에 저장하며, 호출자는 요청 완료 콜백이 호출될 때까지 버퍼가 유효하도록 유지해야 합니다. 파이프라인 핸들러는 `completeRequest` 또는 `cancelRequest`가 반환된 뒤 해당 요청에 접근해서는 안 됩니다. `src/libcamera/camera.cpp:1243`, `src/libcamera/request.cpp:376`, `src/libcamera/request.cpp:447`, `src/libcamera/pipeline_handler.cpp:575`, `src/libcamera/pipeline_handler.cpp:610`

<!-- sdd:visual:request-ownership -->
#### 요청과 버퍼를 유지할 기간

```mermaid
flowchart TB
%% sdd:translations {"addBuffer 호출자: 버퍼 <br/>유효성 책임": "addBuffer caller: buffer <br/>validity duty", "cancelRequest 반환 경계": "cancelRequest return <br/>boundary", "completeRequest 반환 경계": "completeRequest return <br/>boundary", "createRequest 호출자: <br/>Request 소유": "createRequest caller: owns <br/>Request", "동일한 규칙 적용": "Same rules apply", "반환 후 접근 금지": "No access once it returns", "상태 초기화 후 Request <br/>재사용": "Reuse Request after <br/>resetting state", "소유자가 삭제 책임을 짐": "Owner is responsible for <br/>deletion", "소유자가 상태 초기화 후 <br/>재사용을 선택": "Owner may reuse after <br/>resetting state", "애플리케이션 요청 완료 콜백 <br/>호출": "Application <br/>request-completion callback <br/>is called", "완료 핸들러에서 삭제 가능": "May delete in completion <br/>handler", "요청 삭제": "Delete request", "콜백이 호출될 때까지 버퍼 <br/>유효성 유지": "Keep buffer valid until <br/>callback is called", "핸들러 관리 종료; 반환 후 <br/>요청 접근 금지": "Handler management ends; <br/>must not access request <br/>after return"}
  v_caller["createRequest 호출자: <br/>Request 소유"]
  v_buffer["addBuffer 호출자: 버퍼 <br/>유효성 책임"]
  v_callback["애플리케이션 요청 완료 콜백 <br/>호출"]
  v_delete["요청 삭제"]
  v_reuse["상태 초기화 후 Request <br/>재사용"]
  v_complete["completeRequest 반환 경계"]
  v_cancel["cancelRequest 반환 경계"]
  v_ban["핸들러 관리 종료; 반환 후 <br/>요청 접근 금지"]
  v_buffer -->|"콜백이 호출될 때까지 버퍼 <br/>유효성 유지"| v_callback
  v_callback -->|"완료 핸들러에서 삭제 가능"| v_delete
  v_complete -->|"반환 후 접근 금지"| v_ban
  v_cancel -->|"동일한 규칙 적용"| v_ban
  v_caller -->|"소유자가 상태 초기화 후 <br/>재사용을 선택"| v_reuse
  v_caller -->|"소유자가 삭제 책임을 짐"| v_delete
```

[Mermaid 원문](request-lifecycle.request-ownership.mmd)

??? note "그림 근거와 확인 범위"
    createRequest와 addBuffer 호출자의 책임 및 completeRequest·cancelRequest 반환 뒤 핸들러의 접근 경계는 어떻게 구분됩니까?
    
    소스에 연결한 설계 해석입니다. 자동 연결 검사는 의미 승인이나 기기 실행 검증이 아닙니다.
    
    | 요소·전이 | 소스 근거 |
    |---|---|
    | <span data-sdd-label-en="createRequest caller: owns Request">createRequest 호출자: Request 소유</span> | [src/libcamera/camera.cpp:1243](#source-0ae00d77839f61cb) |
    | <span data-sdd-label-en="addBuffer caller: buffer validity duty">addBuffer 호출자: 버퍼 유효성 책임</span> | [src/libcamera/request.cpp:442](#source-95ae69eeb085e3b1) |
    | <span data-sdd-label-en="Application request-completion callback is called">애플리케이션 요청 완료 콜백 호출</span> | [src/libcamera/request.cpp:442](#source-95ae69eeb085e3b1) |
    | <span data-sdd-label-en="Delete request">요청 삭제</span> | [src/libcamera/camera.cpp:1243](#source-0ae00d77839f61cb) |
    | <span data-sdd-label-en="Reuse Request after resetting state">상태 초기화 후 Request 재사용</span> | [src/libcamera/request.cpp:376](#source-38494771cb29cc8c) |
    | <span data-sdd-label-en="completeRequest return boundary">completeRequest 반환 경계</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="cancelRequest return boundary">cancelRequest 반환 경계</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="Handler management ends; must not access request after return">핸들러 관리 종료; 반환 후 요청 접근 금지</span> | [src/libcamera/pipeline_handler.cpp:575](#source-d93a02e9220fa760) |
    | <span data-sdd-label-en="Keep buffer valid until callback is called">콜백이 호출될 때까지 버퍼 유효성 유지</span> | [src/libcamera/request.cpp:442](#source-95ae69eeb085e3b1) |
    | <span data-sdd-label-en="May delete in completion handler">완료 핸들러에서 삭제 가능</span> | [src/libcamera/camera.cpp:1243](#source-0ae00d77839f61cb) |
    | <span data-sdd-label-en="No access once it returns">반환 후 접근 금지</span> | [src/libcamera/pipeline_handler.cpp:575](#source-d93a02e9220fa760) |
    | <span data-sdd-label-en="Same rules apply">동일한 규칙 적용</span> | [src/libcamera/pipeline_handler.cpp:610](#source-52fb58c8956b1a91) · [src/libcamera/pipeline_handler.cpp:575](#source-d93a02e9220fa760) |
    | <span data-sdd-label-en="Owner may reuse after resetting state">소유자가 상태 초기화 후 재사용을 선택</span> | [src/libcamera/camera.cpp:1243](#source-0ae00d77839f61cb) |
    | <span data-sdd-label-en="Owner is responsible for deletion">소유자가 삭제 책임을 짐</span> | [src/libcamera/camera.cpp:1243](#source-0ae00d77839f61cb) |
<!-- /sdd:visual:request-ownership -->

### 정상 완료와 다음 요청 준비

`PipelineHandler::completeBuffer`는 `bufferCompleted`를 emit한 뒤 요청 내부 버퍼 추적을 갱신하고, 모든 버퍼가 완료되었으면 `true`, 아니면 `false`를 반환합니다. 마지막 버퍼가 완료되어도 요청은 자동으로 완료되지 않으므로 파이프라인 핸들러는 필요한 처리를 마친 뒤 `completeRequest`로 명시적으로 완료를 통지해야 합니다. 두 API는 `CameraManager` 스레드에서 호출해야 하며, 제공된 소스는 실제 콜백 실행 스레드를 확인하지 않습니다. `completeRequest`가 호출하는 내부 `complete`는 `cancelled_`가 `false`이면 `RequestComplete`, `true`이면 `RequestCancelled`를 선택합니다. `src/libcamera/pipeline_handler.cpp:547`, `src/libcamera/request.cpp:91`

<!-- sdd:visual:completion-notification-order -->
#### 버퍼 알림에서 요청 반환까지

```mermaid
flowchart TB
%% sdd:translations {"bufferCompleted 알림": "bufferCompleted notification", "emit 뒤 갱신": "Update after emit", "마지막 버퍼만으로 자동 <br/>완료되지 않음": "Last buffer does not <br/>automatically complete <br/>request", "명시적 completeRequest": "Explicit completeRequest", "완료된 선두부터 반환": "Return completed queue heads", "요청 내부 버퍼 추적 갱신": "Update internal buffer <br/>tracking", "제출 순서로 애플리케이션 <br/>반환": "Return to application in <br/>submission order"}
  v_notice["bufferCompleted 알림"]
  v_tracking["요청 내부 버퍼 추적 갱신"]
  v_complete["명시적 completeRequest"]
  v_return["제출 순서로 애플리케이션 <br/>반환"]
  v_notice -->|"emit 뒤 갱신"| v_tracking
  v_tracking -->|"마지막 버퍼만으로 자동 <br/>완료되지 않음"| v_complete
  v_complete -->|"완료된 선두부터 반환"| v_return
```

[Mermaid 원문](request-lifecycle.completion-notification-order.mmd)

??? note "그림 근거와 확인 범위"
    정상 경로의 호출·추적 순서입니다. 모든 버퍼와 필요한 추가 처리가 끝난 뒤 요청 완료를 통지하며, 실제 실행 시간이나 애플리케이션 콜백 스레드를 나타내지 않습니다.
    
    소스에 연결한 설계 해석입니다. 자동 연결 검사는 의미 승인이나 기기 실행 검증이 아닙니다.
    
    | 요소·전이 | 소스 근거 |
    |---|---|
    | <span data-sdd-label-en="bufferCompleted notification">bufferCompleted 알림</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="Update internal buffer tracking">요청 내부 버퍼 추적 갱신</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="Explicit completeRequest">명시적 completeRequest</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="Return to application in submission order">제출 순서로 애플리케이션 반환</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="Update after emit">emit 뒤 갱신</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="Last buffer does not automatically complete request">마지막 버퍼만으로 자동 완료되지 않음</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="Return completed queue heads">완료된 선두부터 반환</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
<!-- /sdd:visual:completion-notification-order -->

마지막 버퍼 알림은 관찰했지만 요청 완료 콜백은 아직 관찰하지 못한 경우를 가정합니다. 이 관측만으로 내부 추적 갱신이나 `completeRequest` 호출이 아직 남았다고 단정할 수 없으며, 앞서 정한 버퍼 유효성 유지 기한이 끝났다고 판단할 수도 없습니다. 알림만으로 버퍼 해제나 다른 요청 연결의 안전성을 판정할 수는 없으며, 유효성을 깨뜨리는 해제와 모든 재사용을 일괄 금지하는 판단은 다릅니다. 다른 요청에 연결할 수 있는지는 해당 API와 동기화 계약 및 버퍼 유효성 유지를 별도로 대조해야 합니다. `src/libcamera/request.cpp:447`, `src/libcamera/pipeline_handler.cpp:547`

조사 계획에서는 기존 `completeBuffer` 호출의 반환값과 `completeRequest` 호출을 관찰합니다. 제출 순서에 따라 선두 요청에서 반환이 지연되는지와 요청 완료 콜백도 확인합니다. `src/libcamera/pipeline_handler.cpp:547`

### 알림 순서와 취소가 달라질 때

소스에서 유도한 조건부 예입니다. `A` 다음에 `B`를 제출하고 `A`가 `RequestPending`이며 `B`의 모든 버퍼와 추가 처리가 끝난 상태에서 `completeRequest(B)`를 호출한다고 가정합니다. `cancelled_`가 false이면 `B`의 상태는 `RequestComplete`가 되지만, `queuedRequests_` 선두의 `A`가 아직 `RequestPending`이므로 반복문이 중단되어 `B`는 아직 애플리케이션에 반환되지 않습니다. `src/libcamera/pipeline_handler.cpp:547`, `src/libcamera/request.cpp:91`

<!-- sdd:visual:completed-but-not-returned -->
#### 완료 상태와 애플리케이션 반환의 차이

```mermaid
flowchart TB
%% sdd:translations {"A가 Pending이면 break": "Break while A is Pending", "B 완료 또는 취소 처리": "Complete or cancel B", "B는 RequestComplete 또는 <br/>RequestCancelled로 큐에 남음": "B remains queued as <br/>RequestComplete or <br/>RequestCancelled", "상태 갱신 뒤 선두 검사": "Check queue head after <br/>status update", "선두가 완료 상태이면 <br/>제거·반환": "Pop and return completed <br/>heads", "애플리케이션 반환 여부와 <br/>다른 경계": "Separate boundary from <br/>application return", "완료 함수 반환 뒤 핸들러 <br/>접근 금지": "No handler access after <br/>completion function returns", "완료된 선두부터 A 다음 B <br/>반환": "Return completed heads: A <br/>then B", "요청 완료 콜백까지 버퍼 유지": "Keep buffer valid until <br/>request completion callback", "콜백이 아직 없으므로 유지 <br/>의무 지속": "Validity duty continues <br/>before callback", "큐 선두 A가 <br/>RequestPending인가?": "Is queue head A <br/>RequestPending?"}
  v_b["B 완료 또는 취소 처리"]
  v_head["큐 선두 A가 <br/>RequestPending인가?"]
  v_wait["B는 RequestComplete 또는 <br/>RequestCancelled로 큐에 남음"]
  v_return["완료된 선두부터 A 다음 B <br/>반환"]
  v_handler["완료 함수 반환 뒤 핸들러 <br/>접근 금지"]
  v_buffer["요청 완료 콜백까지 버퍼 유지"]
  v_b -->|"상태 갱신 뒤 선두 검사"| v_head
  v_head -->|"A가 Pending이면 break"| v_wait
  v_head -->|"선두가 완료 상태이면 <br/>제거·반환"| v_return
  v_b -->|"애플리케이션 반환 여부와 <br/>다른 경계"| v_handler
  v_wait -->|"콜백이 아직 없으므로 유지 <br/>의무 지속"| v_buffer
```

[Mermaid 원문](request-lifecycle.completed-but-not-returned.mmd)

??? note "그림 근거와 확인 범위"
    A 다음 B를 제출하고 B의 완료 처리가 끝났다는 조건부 예입니다. B 정상 완료 또는 취소도 선두 A가 Pending이면 반환을 기다립니다. 파이프라인 핸들러의 반환 뒤 접근 제한과 호출자의 버퍼 유지 의무는 서로 다른 경계입니다.
    
    소스에 연결한 설계 해석입니다. 자동 연결 검사는 의미 승인이나 기기 실행 검증이 아닙니다.
    
    | 요소·전이 | 소스 근거 |
    |---|---|
    | <span data-sdd-label-en="Complete or cancel B">B 완료 또는 취소 처리</span> | [src/libcamera/request.cpp:91](#source-c78836578026f078) · [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="Is queue head A RequestPending?">큐 선두 A가 RequestPending인가?</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="B remains queued as RequestComplete or RequestCancelled">B는 RequestComplete 또는 RequestCancelled로 큐에 남음</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="Return completed heads: A then B">완료된 선두부터 A 다음 B 반환</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="No handler access after completion function returns">완료 함수 반환 뒤 핸들러 접근 금지</span> | [src/libcamera/pipeline_handler.cpp:575](#source-d93a02e9220fa760) |
    | <span data-sdd-label-en="Keep buffer valid until request completion callback">요청 완료 콜백까지 버퍼 유지</span> | [src/libcamera/request.cpp:447](#source-4cdce80c57526221) |
    | <span data-sdd-label-en="Check queue head after status update">상태 갱신 뒤 선두 검사</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="Break while A is Pending">A가 Pending이면 break</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="Pop and return completed heads">선두가 완료 상태이면 제거·반환</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="Separate boundary from application return">애플리케이션 반환 여부와 다른 경계</span> | [src/libcamera/pipeline_handler.cpp:575](#source-d93a02e9220fa760) |
    | <span data-sdd-label-en="Validity duty continues before callback">콜백이 아직 없으므로 유지 의무 지속</span> | [src/libcamera/request.cpp:447](#source-4cdce80c57526221) |
<!-- /sdd:visual:completed-but-not-returned -->

<!-- sdd:visual:fence-reuse-conditions -->
#### fence가 있는 버퍼를 다시 요청에 연결할 때

```mermaid
flowchart TB
%% sdd:translations {"addBuffer 성공": "addBuffer succeeds", "addBuffer 실패": "addBuffer fails", "fence 사용 시 ReuseBuffers <br/>사용하지 않도록 권고": "Do not use ReuseBuffers <br/>with fences: recommendation", "fence가 신호되지 않고 <br/>타임아웃": "Timeout with unsignalled <br/>fence", "다른 요청 재사용 전 <br/>releaseFence": "releaseFence before reuse <br/>in another request", "미신호 타임아웃: 버퍼에 <br/>fence 남음": "Unsignalled timeout: fence <br/>remains on buffer", "성공: 버퍼로 Fence 소유권 <br/>이동": "Success: Fence ownership <br/>moves to buffer", "실패: Fence 수정·소유권 <br/>이전 없음": "Failure: Fence unchanged, <br/>no ownership transfer", "유효 Fence를 addBuffer에 <br/>전달": "Pass valid Fence to <br/>addBuffer", "재사용 전에 회수": "Release before reuse", "재요청 플래그 조건도 확인": "Also check reuse-flag <br/>condition"}
  v_add["유효 Fence를 addBuffer에 <br/>전달"]
  v_moved["성공: 버퍼로 Fence 소유권 <br/>이동"]
  v_unchanged["실패: Fence 수정·소유권 <br/>이전 없음"]
  v_timeout["미신호 타임아웃: 버퍼에 <br/>fence 남음"]
  v_release["다른 요청 재사용 전 <br/>releaseFence"]
  v_flag["fence 사용 시 ReuseBuffers <br/>사용하지 않도록 권고"]
  v_add -->|"addBuffer 성공"| v_moved
  v_add -->|"addBuffer 실패"| v_unchanged
  v_moved -->|"fence가 신호되지 않고 <br/>타임아웃"| v_timeout
  v_timeout -->|"재사용 전에 회수"| v_release
  v_release -->|"재요청 플래그 조건도 확인"| v_flag
```

[Mermaid 원문](request-lifecycle.fence-reuse-conditions.mmd)

??? note "그림 근거와 확인 범위"
    addBuffer 성공·실패와 신호되지 않은 fence의 타임아웃 조건을 나눕니다. ReuseBuffers의 should not 권고는 의무로 강화하지 않습니다.
    
    소스에 연결한 설계 해석입니다. 자동 연결 검사는 의미 승인이나 기기 실행 검증이 아닙니다.
    
    | 요소·전이 | 소스 근거 |
    |---|---|
    | <span data-sdd-label-en="Pass valid Fence to addBuffer">유효 Fence를 addBuffer에 전달</span> | [src/libcamera/request.cpp:456](#source-86a8d784a8348122) |
    | <span data-sdd-label-en="Success: Fence ownership moves to buffer">성공: 버퍼로 Fence 소유권 이동</span> | [src/libcamera/request.cpp:456](#source-86a8d784a8348122) |
    | <span data-sdd-label-en="Failure: Fence unchanged, no ownership transfer">실패: Fence 수정·소유권 이전 없음</span> | [src/libcamera/request.cpp:456](#source-86a8d784a8348122) |
    | <span data-sdd-label-en="Unsignalled timeout: fence remains on buffer">미신호 타임아웃: 버퍼에 fence 남음</span> | [src/libcamera/request.cpp:462](#source-d8cf34a75a4333a7) |
    | <span data-sdd-label-en="releaseFence before reuse in another request">다른 요청 재사용 전 releaseFence</span> | [src/libcamera/request.cpp:462](#source-d8cf34a75a4333a7) |
    | <span data-sdd-label-en="Do not use ReuseBuffers with fences: recommendation">fence 사용 시 ReuseBuffers 사용하지 않도록 권고</span> | [src/libcamera/request.cpp:334](#source-d9944a69f2dd6758) |
    | <span data-sdd-label-en="addBuffer succeeds">addBuffer 성공</span> | [src/libcamera/request.cpp:456](#source-86a8d784a8348122) |
    | <span data-sdd-label-en="addBuffer fails">addBuffer 실패</span> | [src/libcamera/request.cpp:456](#source-86a8d784a8348122) |
    | <span data-sdd-label-en="Timeout with unsignalled fence">fence가 신호되지 않고 타임아웃</span> | [src/libcamera/request.cpp:462](#source-d8cf34a75a4333a7) |
    | <span data-sdd-label-en="Release before reuse">재사용 전에 회수</span> | [src/libcamera/request.cpp:462](#source-d8cf34a75a4333a7) |
    | <span data-sdd-label-en="Also check reuse-flag condition">재요청 플래그 조건도 확인</span> | [src/libcamera/request.cpp:334](#source-d9944a69f2dd6758) |
<!-- /sdd:visual:fence-reuse-conditions -->

이때 `addBuffer` 호출자는 `B`의 버퍼를 요청 완료 콜백이 호출될 때까지 유효하게 유지해야 합니다. 파이프라인 핸들러는 `completeRequest(B)`가 반환된 뒤 `B`에 접근해서는 안 됩니다. 이후 `A`가 완료되어 `completeRequest`가 실행되고 큐에서 확인하는 나머지 선두도 완료 상태이면 `A`, `B` 순으로 애플리케이션에 반환됩니다. 조사 계획으로는 큐의 선두와 요청 상태, 대기 중인 버퍼, 요청 완료 콜백을 확인합니다. `src/libcamera/request.cpp:447`, `src/libcamera/pipeline_handler.cpp:575`, `src/libcamera/pipeline_handler.cpp:547`

앞의 정상 완료 예와 별도로, 큐 선두의 A와 B가 모두 `RequestPending`인 시점에 B에 대해 정상 `completeRequest(B)` 대신 `cancelRequest(B)`를 선택하는 경우입니다. `Request::Private::doCancelRequest`는 B의 `pending_` 버퍼를 각각 취소하고 `bufferCompleted`를 emit한 뒤 `cancelled_`를 true로 설정하고 `pending_`를 비웁니다. `cancelRequest`가 `cancel` 다음 `completeRequest`를 호출하면 `Request::Private::complete`는 B의 상태로 `RequestCancelled`를 선택하지만, 큐 선두 A가 여전히 `RequestPending`이면 순회가 중단되어 B의 애플리케이션 반환은 지연됩니다. 이 경로에도 앞에서 설명한 공통 수명과 접근 규칙이 적용됩니다. `src/libcamera/pipeline_handler.cpp:547`, `src/libcamera/request.cpp:91`, `src/libcamera/pipeline_handler.cpp:610`, `src/libcamera/request.cpp:447`, `src/libcamera/pipeline_handler.cpp:575`

`Request::addBuffer()`는 성공하면 전달된 유효한 `Fence`의 소유권을 `buffer`로 이동하며, 실패하면 전달된 `fence`를 수정하지 않고 소유권도 넘겨받지 않습니다. 버퍼에 연결된 펜스가 신호되지 않으면 요청은 타임아웃 후 실패하고 버퍼에는 펜스가 그대로 남습니다. 애플리케이션은 다른 요청에 버퍼를 재사용하기 전에 `FrameBuffer::releaseFence()`로 펜스를 회수해야 합니다. `src/libcamera/request.cpp:456`, `src/libcamera/request.cpp:462`

`ReuseBuffers`는 `addBuffer()`로 이전에 추가한 버퍼를 유지하여 재사용하지만, 버퍼에 연결된 fence는 재사용하지 않습니다. fence를 사용하는 경우 이 플래그를 사용하지 않아야 한다고 권고합니다(`should not be used`). `src/libcamera/request.cpp:326`, `src/libcamera/request.cpp:334`

### 완료 책임을 변경하기 전에

조사 계획에서는 `completeBuffer`와 `completeRequest`의 기존 호출자와 스레드 전달 경계를 찾아 변경 전후의 호출 위치를 대조합니다. 파이프라인 핸들러는 두 함수를 `CameraManager` 스레드에서 호출해야 하므로, 변경으로 다른 스레드에서 이 API를 직접 호출하면 문서화된 의무와 충돌합니다. 이 계획은 실제 콜백 스레드, 기기 DMA, 캐시, 실행 시간이나 사내 HAL의 검증 결과가 아닙니다. 역사적 설계 이유와 대안의 우열을 판단하려면 별도 결정 기록이나 실행 자료가 필요합니다. `src/libcamera/pipeline_handler.cpp:547`

<!-- sdd:visual:completion-change-checks -->
#### 완료 책임 변경에서 함께 대조할 계약

```mermaid
flowchart TB
%% sdd:translations {"CameraManager 스레드 호출 <br/>의무": "Must call from <br/>CameraManager thread", "선두 상태·반환 경로 확인": "Check queue head and return <br/>path", "연동 호출자 수명 확인": "Check integration caller <br/>lifetime", "완료 책임 변경": "Change completion <br/>responsibility", "완료 함수 반환 뒤 핸들러 <br/>접근 금지": "No handler access after <br/>completion function returns", "요청 완료 콜백까지 버퍼 유효": "Buffer valid until request <br/>completion callback", "제출 순서로 요청 반환": "Return requests in <br/>submission order", "핸들러 수명 경계 확인": "Check handler lifetime <br/>boundary", "호출자 문맥 확인": "Check caller context"}
  v_api["완료 책임 변경"]
  v_thread["CameraManager 스레드 호출 <br/>의무"]
  v_order["제출 순서로 요청 반환"]
  v_lifetime["완료 함수 반환 뒤 핸들러 <br/>접근 금지"]
  v_buffer["요청 완료 콜백까지 버퍼 유효"]
  v_api -->|"호출자 문맥 확인"| v_thread
  v_api -->|"선두 상태·반환 경로 확인"| v_order
  v_api -->|"핸들러 수명 경계 확인"| v_lifetime
  v_api -->|"연동 호출자 수명 확인"| v_buffer
```

[Mermaid 원문](request-lifecycle.completion-change-checks.mmd)

??? note "그림 근거와 확인 범위"
    변경 검토의 확인 관계입니다. 화살표는 실행 순서나 기기 보장이 아니라 completeRequest 책임을 바꿀 때 함께 보존할 소스 계약을 가리킵니다.
    
    소스에 연결한 설계 해석입니다. 자동 연결 검사는 의미 승인이나 기기 실행 검증이 아닙니다.
    
    | 요소·전이 | 소스 근거 |
    |---|---|
    | <span data-sdd-label-en="Change completion responsibility">완료 책임 변경</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="Must call from CameraManager thread">CameraManager 스레드 호출 의무</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="Return requests in submission order">제출 순서로 요청 반환</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="No handler access after completion function returns">완료 함수 반환 뒤 핸들러 접근 금지</span> | [src/libcamera/pipeline_handler.cpp:575](#source-d93a02e9220fa760) |
    | <span data-sdd-label-en="Buffer valid until request completion callback">요청 완료 콜백까지 버퍼 유효</span> | [src/libcamera/request.cpp:447](#source-4cdce80c57526221) |
    | <span data-sdd-label-en="Check caller context">호출자 문맥 확인</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="Check queue head and return path">선두 상태·반환 경로 확인</span> | [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) |
    | <span data-sdd-label-en="Check handler lifetime boundary">핸들러 수명 경계 확인</span> | [src/libcamera/pipeline_handler.cpp:575](#source-d93a02e9220fa760) |
    | <span data-sdd-label-en="Check integration caller lifetime">연동 호출자 수명 확인</span> | [src/libcamera/request.cpp:447](#source-4cdce80c57526221) |
<!-- /sdd:visual:completion-change-checks -->

근거 원문: [src/libcamera/camera.cpp:1243](#source-0ae00d77839f61cb) · [src/libcamera/request.cpp:376](#source-38494771cb29cc8c) · [src/libcamera/pipeline_handler.cpp:547](#source-01ad7c6605c3296a) · [src/libcamera/request.cpp:326](#source-447804db33308244) · [src/libcamera/request.cpp:456](#source-86a8d784a8348122) · [src/libcamera/request.cpp:462](#source-d8cf34a75a4333a7) · [src/libcamera/request.cpp:447](#source-4cdce80c57526221) · [src/libcamera/pipeline_handler.cpp:575](#source-d93a02e9220fa760) · [src/libcamera/pipeline_handler.cpp:610](#source-52fb58c8956b1a91) · [src/libcamera/request.cpp:334](#source-d9944a69f2dd6758) · [src/libcamera/request.cpp:442](#source-95ae69eeb085e3b1) · [src/libcamera/camera.cpp:1308](#source-28d007de6ad1a8a5) · [src/libcamera/request.cpp:91](#source-c78836578026f078)

??? note "설계 질문과 검증 범위"
    질문별 답변과 근거 연결을 검사했습니다. 의미와 실행 결과는 사람 검토가 필요합니다.
    
    | 설계 질문 | 설명 위치 | 확인 범위 |
    |---|---|---|
    | 어떤 자원을 누가 유지하고 완료 후 무엇을 초기화해야 합니까? | [요청·버퍼·fence의 수명](#요청버퍼fence의-수명) | 코드 근거와 설명 연결 |

## 소스 근거

같은 발췌는 한 번만 싣습니다. 필요한 원문을 펼쳐 설명과 대조하세요.

<a id="source-0ae00d77839f61cb"></a>

??? note "소스 근거: src/libcamera/camera.cpp:1243"
    `src/libcamera/camera.cpp:1243`에서 시작하는 발췌입니다. 종료 줄은 1263이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `9f251ecf5ba569606e9753d3619b88e1aef5a4ce15f816ae97efd283e34b823b`
    
    ```text
    \brief Create a request object for the camera
     * \param[in] cookie Opaque cookie for application use
     *
     * This function creates an empty request for the application to fill with
     * buffers and parameters, and queue for capture.
     *
     * The \a cookie is stored in the request and is accessible through the
     * Request::cookie() function at any time. It is typically used by applications
     * to map the request to an external resource in the request completion
     * handler, and is completely opaque to libcamera.
     *
     * The ownership of the returned request is passed to the caller, which is
     * responsible for deleting it. The request may be deleted in the completion
     * handler, or reused after resetting its state with Request::reuse().
     *
     * \context This function is \threadsafe. It may only be called when the camera
     * is in the Configured or Running state as defined in \ref camera_operation.
     *
     * \return A pointer to the newly created request, or nullptr on error
     */
    std::unique_ptr<Request> Camera::createRequest(uint64_t cookie)
    ```

<a id="source-38494771cb29cc8c"></a>

??? note "소스 근거: src/libcamera/request.cpp:376"
    `src/libcamera/request.cpp:376`에서 시작하는 발췌입니다. 종료 줄은 407이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `22294a6809bd4c6655824af9603fb3879603cec256c6845e00d3d2a0e6bf7679`
    
    ```text
    \brief Reset the request for reuse
     * \param[in] flags Indicate whether or not to reuse the buffers
     *
     * Reset the status and controls associated with the request, to allow it to
     * be reused and requeued without destruction. This function shall be called
     * prior to queueing the request to the camera, in lieu of constructing a new
     * request. The application can reuse the buffers that were previously added
     * to the request via addBuffer() by setting \a flags to ReuseBuffers.
     */
    void Request::reuse(ReuseFlag flags)
    {
    	LIBCAMERA_TRACEPOINT(request_reuse, this);
    
    	_d()->reset();
    
    	if (flags & ReuseBuffers) {
    		for (const auto &[stream, buffer] : bufferMap_) {
    			buffer->_d()->setRequest(this);
    			_d()->pending_.insert(buffer);
    		}
    	} else {
    		bufferMap_.clear();
    	}
    
    	status_ = RequestPending;
    
    	controls_.clear();
    	_d()->metadata_.clear();
    }
    
    /**
     * \fn Request::controls()
    ```

<a id="source-01ad7c6605c3296a"></a>

??? note "소스 근거: src/libcamera/pipeline_handler.cpp:547"
    `src/libcamera/pipeline_handler.cpp:547`에서 시작하는 발췌입니다. 종료 줄은 620이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `514288cc958de9ff5fd19d46393cec3bb3088f4f08486528d4559071138638c9`
    
    ```text
    \brief Complete a buffer for a request
     * \param[in] request The request the buffer belongs to
     * \param[in] buffer The buffer that has completed
     *
     * This function shall be called by pipeline handlers to signal completion of
     * the \a buffer part of the \a request. It notifies applications of buffer
     * completion and updates the request's internal buffer tracking. The request
     * is not completed automatically when the last buffer completes to give
     * pipeline handlers a chance to perform any operation that may still be
     * needed. They shall complete requests explicitly with completeRequest().
     *
     * \context This function shall be called from the CameraManager thread.
     *
     * \return True if all buffers contained in the request have completed, false
     * otherwise
     */
    bool PipelineHandler::completeBuffer(Request *request, FrameBuffer *buffer)
    {
    	Camera *camera = request->_d()->camera();
    	camera->bufferCompleted.emit(request, buffer);
    	return request->_d()->completeBuffer(buffer);
    }
    
    /**
     * \brief Signal request completion
     * \param[in] request The request that has completed
     *
     * The pipeline handler shall call this function to notify the \a camera that
     * the request has completed. The request is no longer managed by the pipeline
     * handler and shall not be accessed once this function returns.
     *
     * This function ensures that requests will be returned to the application in
     * submission order, the pipeline handler may call it on any complete request
     * without any ordering constraint.
     *
     * \context This function shall be called from the CameraManager thread.
     */
    void PipelineHandler::completeRequest(Request *request)
    {
    	Camera *camera = request->_d()->camera();
    
    	request->_d()->complete();
    
    	Camera::Private *data = camera->_d();
    
    	while (!data->queuedRequests_.empty()) {
    		Request *req = data->queuedRequests_.front();
    		if (req->status() == Request::RequestPending)
    			break;
    
    		ASSERT(!req->hasPendingBuffers());
    		data->queuedRequests_.pop_front();
    		camera->requestComplete(req);
    	}
    
    	/* Allow any waiting requests to be queued to the pipeline. */
    	doQueueRequests(camera);
    }
    
    /**
     * \brief Cancel request and signal its completion
     * \param[in] request The request to cancel
     *
     * This function cancels and completes the request. The same rules as for
     * completeRequest() apply.
     */
    void PipelineHandler::cancelRequest(Request *request)
    {
    	request->_d()->cancel();
    	completeRequest(request);
    }
    
    /**
     * \brief Retrieve the absolute path to a platform configuration file
    ```

<a id="source-447804db33308244"></a>

??? note "소스 근거: src/libcamera/request.cpp:326"
    `src/libcamera/request.cpp:326`에서 시작하는 발췌입니다. 종료 줄은 338이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `9e55d8335a38080c0af78cf267bac78c573636447425e25d394e5b206217e7fe`
    
    ```text
    \enum Request::ReuseFlag
     * Flags to control the behavior of Request::reuse()
     * \var Request::Default
     * Don't reuse buffers
     * \var Request::ReuseBuffers
     * Reuse the buffers that were previously added by addBuffer()
     *
     * \note Fences associated with the buffers are not reused.
     *  This flag should not be used if fences are used.
     */
    
    /**
     * \typedef Request::BufferMap
    ```

<a id="source-86a8d784a8348122"></a>

??? note "소스 근거: src/libcamera/request.cpp:456"
    `src/libcamera/request.cpp:456`에서 시작하는 발췌입니다. 종료 줄은 460이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `e7cc6e59b5401c6d2ef2bef1cceef1090d9bdd058ea8ce00a74bc573f5e4fdc2`
    
    ```text
    When a valid Fence is provided to this function, \a fence is moved to \a
     * buffer and this Request will only be queued to the device once the
     * fences of all its buffers have been correctly signalled. Ownership of the
     * fence will only be taken in case of success, otherwise the fence will
     * be left unmodified.
    ```

<a id="source-d8cf34a75a4333a7"></a>

??? note "소스 근거: src/libcamera/request.cpp:462"
    `src/libcamera/request.cpp:462`에서 시작하는 발췌입니다. 종료 줄은 465이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `ebb24de716cdebb7c0c82cfddf05e91d7d2fb938eda24fe5027d3e9efcf62104`
    
    ```text
    If the \a fence associated with \a buffer isn't signalled, the request will
     * fail after a timeout. The buffer will still contain the fence, which
     * applications must retrieve with FrameBuffer::releaseFence() before the buffer
     * can be reused in another request.
    ```

<a id="source-4cdce80c57526221"></a>

??? note "소스 근거: src/libcamera/request.cpp:447"
    `src/libcamera/request.cpp:447`에서 시작하는 발췌입니다. 종료 줄은 449이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `996424643a0de2ec5fbd8b8491639ae1afea030ab989179410e7a1eaa48c1673`
    
    ```text
    A reference to the buffer is stored in the request. The caller is responsible
     * for ensuring that the buffer will remain valid until the request complete
     * callback is called.
    ```

<a id="source-d93a02e9220fa760"></a>

??? note "소스 근거: src/libcamera/pipeline_handler.cpp:575"
    `src/libcamera/pipeline_handler.cpp:575`에서 시작하는 발췌입니다. 종료 줄은 576이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `d2c64999e07c4a9df08f21b514cd8480e6ccc091f1aeef3ebaf44522d8fb0961`
    
    ```text
    The request is no longer managed by the pipeline
     * handler and shall not be accessed once this function returns.
    ```

<a id="source-52fb58c8956b1a91"></a>

??? note "소스 근거: src/libcamera/pipeline_handler.cpp:610"
    `src/libcamera/pipeline_handler.cpp:610`에서 시작하는 발췌입니다. 종료 줄은 611이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `048bc649f307f0f41b7702b59be24a5fba9f7a48ff6a266bfbe458df4a5bdc8d`
    
    ```text
    This function cancels and completes the request. The same rules as for
     * completeRequest() apply.
    ```

<a id="source-d9944a69f2dd6758"></a>

??? note "소스 근거: src/libcamera/request.cpp:334"
    `src/libcamera/request.cpp:334`에서 시작하는 발췌입니다. 종료 줄은 334이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `7b740fbb97fdbfb9b7d270aa48ba5e7902f04d691349b58981ea011f324282d5`
    
    ```text
    This flag should not be used if fences are used.
    ```

<a id="source-95ae69eeb085e3b1"></a>

??? note "소스 근거: src/libcamera/request.cpp:442"
    `src/libcamera/request.cpp:442`에서 시작하는 발췌입니다. 종료 줄은 475이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `65cd8b0501b7f6545dd10eaaec4a4fe46c52a096a3bbd94ea6b4813e4a670876`
    
    ```text
    \brief Add a FrameBuffer with its associated Stream to the Request
     * \param[in] stream The stream the buffer belongs to
     * \param[in] buffer The FrameBuffer to add to the request
     * \param[in] fence The optional fence
     *
     * A reference to the buffer is stored in the request. The caller is responsible
     * for ensuring that the buffer will remain valid until the request complete
     * callback is called.
     *
     * A request can only contain one buffer per stream. If a buffer has already
     * been added to the request for the same stream, this function returns -EEXIST.
     *
     * A Fence can be optionally associated with the \a buffer.
     *
     * When a valid Fence is provided to this function, \a fence is moved to \a
     * buffer and this Request will only be queued to the device once the
     * fences of all its buffers have been correctly signalled. Ownership of the
     * fence will only be taken in case of success, otherwise the fence will
     * be left unmodified.
     *
     * If the \a fence associated with \a buffer isn't signalled, the request will
     * fail after a timeout. The buffer will still contain the fence, which
     * applications must retrieve with FrameBuffer::releaseFence() before the buffer
     * can be reused in another request. Attempting to add a buffer that still
     * contains a fence to a request will result in this function returning -EEXIST.
     *
     * \sa FrameBuffer::releaseFence()
     *
     * \return 0 on success or a negative error code otherwise
     * \retval -EEXIST The request already contains a buffer for the stream
     *  or the buffer still references a fence
     * \retval -EINVAL The buffer does not reference a valid Stream
     */
    int Request::addBuffer(const Stream *stream, FrameBuffer *buffer,
    ```

<a id="source-28d007de6ad1a8a5"></a>

??? note "소스 근거: src/libcamera/camera.cpp:1308"
    `src/libcamera/camera.cpp:1308`에서 시작하는 발췌입니다. 종료 줄은 1383이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `96db61baeb32065c966b20942f97518ddbd3a43b36b64e8083eb29a90ecb7f4b`
    
    ```text
    \brief Queue a request to the camera
     * \param[in] request The request to queue to the camera
     *
     * This function queues a \a request to the camera for capture.
     *
     * After allocating the request with createRequest(), the application shall
     * fill it with at least one capture buffer before queuing it. Requests that
     * contain no buffers are invalid and are rejected without being queued.
     *
     * Once the request has been queued, the camera will notify its completion
     * through the \ref requestCompleted signal.
     *
     * \context This function is \threadsafe. It may only be called when the camera
     * is in the Running state as defined in \ref camera_operation.
     *
     * \return 0 on success or a negative error code otherwise
     * \retval -ENODEV The camera has been disconnected from the system
     * \retval -EACCES The camera is not running so requests can't be queued
     * \retval -EXDEV The request does not belong to this camera
     * \retval -EINVAL The request is invalid
     * \retval -ENOMEM No buffer memory was available to handle the request
     */
    int Camera::queueRequest(Request *request)
    {
    	Private *const d = _d();
    
    	int ret = d->isAccessAllowed(Private::CameraRunning);
    	if (ret < 0)
    		return ret;
    
    	/* Requests can only be queued to the camera that created them. */
    	if (request->_d()->camera() != this) {
    		LOG(Camera, Error) << "Request was not created by this camera";
    		return -EXDEV;
    	}
    
    	if (request->status() != Request::RequestPending) {
    		LOG(Camera, Error) << request->toString() << " is not valid";
    		return -EINVAL;
    	}
    
    	/* Make sure the Request has a valid control list. */
    	if (request->controls().infoMap() != &controls()) {
    		LOG(Camera, Error) << "Overwriting Request::controls() is not allowed";
    		return -EINVAL;
    	}
    
    	/*
    	 * The camera state may change until the end of the function. No locking
    	 * is however needed as PipelineHandler::queueRequest() will handle
    	 * this.
    	 */
    
    	if (request->buffers().empty()) {
    		LOG(Camera, Error) << "Request contains no buffers";
    		return -EINVAL;
    	}
    
    	for (const auto &[stream, buffer] : request->buffers()) {
    		if (d->activeStreams_.find(stream) == d->activeStreams_.end()) {
    			LOG(Camera, Error) << "Invalid request";
    			return -EINVAL;
    		}
    	}
    
    	/* Pre-process AeEnable. */
    	patchControlList(request->controls());
    
    	d->pipe_->invokeMethod(&PipelineHandler::queueRequest,
    			       ConnectionTypeQueued, request);
    
    	return 0;
    }
    
    /**
     * \brief Start capture from camera
    ```

<a id="source-c78836578026f078"></a>

??? note "소스 근거: src/libcamera/request.cpp:91"
    `src/libcamera/request.cpp:91`에서 시작하는 발췌입니다. 종료 줄은 173이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `8498bd73d69b1968ec400ec4ac12b473ec4ded1098969af3318c7238fe9d68b8`
    
    ```text
    \brief Complete a buffer for the request
     * \param[in] buffer The buffer that has completed
     *
     * A request tracks the status of all buffers it contains through a set of
     * pending buffers. This function removes the \a buffer from the set to mark it
     * as complete. All buffers associate with the request shall be marked as
     * complete by calling this function once and once only before reporting the
     * request as complete with the complete() function.
     *
     * \return True if all buffers contained in the request have completed, false
     * otherwise
     */
    bool Request::Private::completeBuffer(FrameBuffer *buffer)
    {
    	LIBCAMERA_TRACEPOINT(request_complete_buffer, this, buffer);
    
    	int ret = pending_.erase(buffer);
    	ASSERT(ret == 1);
    
    	buffer->_d()->setRequest(nullptr);
    
    	if (buffer->metadata().status == FrameMetadata::FrameCancelled)
    		cancelled_ = true;
    
    	return !hasPendingBuffers();
    }
    
    /**
     * \brief Complete a queued request
     *
     * Mark the request as complete by updating its status to RequestComplete,
     * unless buffers have been cancelled in which case the status is set to
     * RequestCancelled.
     */
    void Request::Private::complete()
    {
    	Request *request = _o<Request>();
    
    	ASSERT(request->status() == RequestPending);
    	ASSERT(!hasPendingBuffers());
    
    	request->status_ = cancelled_ ? RequestCancelled : RequestComplete;
    
    	LOG(Request, Debug) << request->toString();
    
    	LIBCAMERA_TRACEPOINT(request_complete, this);
    }
    
    void Request::Private::doCancelRequest()
    {
    	Request *request = _o<Request>();
    
    	for (FrameBuffer *buffer : pending_) {
    		buffer->_d()->cancel();
    		camera_->bufferCompleted.emit(request, buffer);
    	}
    
    	cancelled_ = true;
    	pending_.clear();
    	notifiers_.clear();
    	timer_.reset();
    }
    
    /**
     * \brief Cancel a queued request
     *
     * Mark the request and its associated buffers as cancelled and complete it.
     *
     * Set each pending buffer in error state and emit the buffer completion signal
     * before completing the Request.
     */
    void Request::Private::cancel()
    {
    	LIBCAMERA_TRACEPOINT(request_cancel, this);
    
    	Request *request = _o<Request>();
    	ASSERT(request->status() == RequestPending);
    
    	doCancelRequest();
    }
    
    /**
     * \brief Reset the request internal data to default values
    ```

??? note "근거와 검토 정보"
    - 생성 방식: 추출 사실과 LLM 설명
    - 검증 범위: 표·그림은 facts로 만들고 설명은 LLM이 작성합니다. 인용·문장 및 설정된 구조 검사를 적용합니다.
    - 근거 파일: `include/libcamera/camera.h`, `include/libcamera/internal/pipeline_handler.h`, `include/libcamera/request.h`, `src/libcamera/camera.cpp`, `src/libcamera/pipeline_handler.cpp`, `src/libcamera/request.cpp`
    - 근거 수준: 코드 확인 (정적 분석, simple_compdb 구성, commit `293d751a81`)
    - 자동 검사 (인용·문장 및 설정된 구조 검사): 통과
    - 검토 상태 기록일: 2026-11-05 · 사람 검토 전

다음 단계: [요청 수명](request-lifecycle.md)
