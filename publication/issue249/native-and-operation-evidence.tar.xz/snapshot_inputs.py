from pathlib import Path
import hashlib,json,shutil,yaml
from sdd.config import load
from sdd.render_profiles import paths,for_page
root=Path(__file__).resolve().parents[2];work=root/'build/issue249';cfg=load(work/'integration/sdd.yaml');out=work/'evidence/inputs';out.mkdir(parents=True,exist_ok=True);index=[]
def copy(path,label):
 path=Path(path);target=out/label;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target)
 index.append(dict(original_path=str(path),snapshot=label,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));return target
for key,path in cfg.paths.items():
 path=Path(path)
 if path.is_file():copy(path,'paths/'+key+'/'+path.name)
 elif path.is_dir() and key in {'style','prompts','templates'}:
  for p in path.rglob('*'):
   if p.is_file() and p.suffix in {'.md','.j2','.yaml','.yml'}:copy(p,'paths/'+key+'/'+p.relative_to(path).as_posix())
for page,path in paths(cfg).items():
 copy(path,'profiles/'+page+'/'+path.name)
 for p in for_page(cfg,page).style_dir.glob('*.md'):copy(p,'profiles/'+page+'/style/'+p.name)
if cfg.site.intro:copy(cfg.root/cfg.site.intro,'site-intro.md')
baseline=load(cfg.root/cfg.publication['baseline_config']);copy(baseline.path,'baseline-original.yaml') if hasattr(baseline,'path') else copy(cfg.root/cfg.publication['baseline_config'],'baseline-original.yaml')
copy(baseline.sections_file,'baseline/sections.yaml')
glossary=baseline.paths.get('glossary_file')
if glossary:copy(glossary,'baseline/glossary.yaml')
for n,row in enumerate(cfg.publication['reports']):copy(cfg.root/row['path'],'inherited-reports/'+str(n)+'-'+Path(row['path']).name)
(out/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding='utf-8');print(len(index),'snapshotted input files')
