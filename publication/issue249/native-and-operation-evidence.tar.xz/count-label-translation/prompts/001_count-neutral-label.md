<!-- system -->
Translate the UI label into clear English, preserving the opaque placeholder. Return JSON.

<!-- user -->
{"source": "\uc808 \uc804\uccb4 \uadfc\uac70 {{1}}\uac1c", "context": "Shared section-wide evidence count. The count can be 1 or more. Use a count-neutral label valid for every count. Independent review rejected the previous plural-only items label."}
