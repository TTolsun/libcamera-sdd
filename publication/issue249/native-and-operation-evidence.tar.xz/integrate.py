from pathlib import Path
import sys,json,shutil,yaml,copy,hashlib
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'src'))
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.evidence import collect,fingerprint
from sdd.document_metadata import split_frontmatter
from sdd import generated_design
from sdd.generate import Generator
from sdd.design_types import DesignResult
from sdd.generated_design import digest
from sdd.cli_checkpoint import validation_policy,validation_model,style_policy

out=root/'build/issue249/integration'
out.mkdir(exist_ok=True)
oldroot=Path('C:/Users/baboe/.codex/worktrees/cb18/camera-hal-sdd-generator/build/issue211-virtual/current-main-integration')
base=load(oldroot/'publication.yaml')
data=yaml.safe_load(base.sections_file.read_text(encoding='utf-8'))
new=load(root/'examples/libcamera/sdd.yaml')
topic=next(t for s in new.sections() if s['id']=='request-lifecycle' for t in s['design_topics'] if t['id']=='resources')
section=next(s for s in data['sections'] if s['id']=='request-lifecycle')
section['design_topics']=[topic if t['id']=='resources' else t for t in section['design_topics']]
removed={'journey':{'submission','buffer-notification','buffer-complete','request-complete'},'stopping':{'completion'}}
for t in section['design_topics']:
 if t['id'] in removed:
  t['parts']=[p for p in t['parts'] if p['id'] not in removed[t['id']]]
  used={sid for p in t['parts'] for sid in p['sources']}
  t['parts'][0]['sources'] += [s['id'] for s in t['sources'] if s['id'] not in used]
(out/'sections.yaml').write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
preserve=(out/'carry-resolution.json').exists()
raw=copy.deepcopy(load(out/'sdd.yaml').raw if preserve else base.raw)
raw['paths']['sections_file']=str(out/'sections.yaml')
raw['paths']['translation_profile']=str(root/'examples/libcamera/validation/issue249/independent-review.yaml')
raw['output']=dict(facts_dir=str(out/'facts'),sdd_dir=str(out/'manuscripts'),diagrams_dir=str(out/'manuscripts/diagrams'))
raw['source']['root']=str(root/'build/issue249/source')
raw['source']['compile_commands']=str(root/'build/issue249/compile_commands.json')
raw['agent']=yaml.safe_load((root/'examples/libcamera/validation/issue249/independent-review.yaml').read_text(encoding='utf-8'))['agent']
raw['agent']['full_style_guides']=False
raw['visuals']['file']=str(root/'examples/libcamera/config/visuals.yaml')
raw['site']['enabled']=False
raw['site']['english_catalog']=str(out/'english.json')
raw['publication']=copy.deepcopy(base.raw.get('publication',{}))
raw['publication']['baseline_config']=str(oldroot/'publication.yaml')
raw['publication']['operation_id']='issue249-explanation-depth'
# Historical successful gates remain historical inputs; new document changes
# require fresh consistency/translation reviews before publication.
(out/'sdd.yaml').write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
cfg=load(out/'sdd.yaml')
if not preserve:
 shutil.copytree(base.sdd_dir,cfg.sdd_dir,dirs_exist_ok=True)
 for p in (root/'build/issue249/public/docs').rglob('*.md'):
  target=cfg.sdd_dir/p.relative_to(root/'build/issue249/public/docs')
  target.parent.mkdir(parents=True,exist_ok=True)
  shutil.copyfile(p,target)
latest=root/'build/issue249/latest-facts/facts.json'
model=KnowledgeModel.load(latest if latest.exists() else base.facts_path)
collect(cfg,model)
model.save(cfg.facts_path)
oldmeta,oldbody=split_frontmatter((cfg.sdd_dir/'request-lifecycle.md').read_text(encoding='utf-8'))
newmeta,newbody=split_frontmatter((root/'build/issue249/work/manuscripts/request-lifecycle.md').read_text(encoding='utf-8'))
selected=next(s for s in cfg.sections() if s['id']=='request-lifecycle')
from sdd.publication_plan import _requirements
before=_requirements(base.sections())
after=_requirements(cfg.sections())
raw['publication']['allowed_contract_changes']={key:'Issue #249 explicitly consolidates lifetime and completion questions; preserve source-bound conditions in resources and record whole-statement selections.' for key,value in before.items() if after.get(key)!=value}
(out/'sdd.yaml').write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
cfg=load(out/'sdd.yaml')
answers=copy.deepcopy(oldmeta['generated_design']['answers'])
selection=copy.deepcopy(oldmeta['generated_design'].get('integration_lineage',{}).get('whole_statement_selections',[]))
for tid,pids in removed.items():
 rows=answers[tid]
 selection += [dict(topic=tid,part_id=s.get('part_id'),statement_sha256=digest(json.dumps(s,ensure_ascii=False,sort_keys=True)),reason='Detail moved to source-bound resources explanation; same condition retained there') for s in rows if s.get('part_id') in pids]
 answers[tid]=[s for s in rows if s.get('part_id') not in pids]
answers['resources']=newmeta['generated_design']['answers']['resources']
pinned,resolved,report=generated_design.validate_answers(model,selected,answers)
artifact=copy.deepcopy(oldmeta['generated_design'])
artifact.update(answers=answers,input_fingerprint=fingerprint(model,selected),
 validation_policy=validation_policy(),validation_model=validation_model(model),style_policy=style_policy(cfg))
artifact['topic_inputs']['resources']=newmeta['generated_design']['topic_inputs']['resources']
artifact['topic_agents']['resources']=newmeta['generated_design']['topic_agents']['resources']
artifact['generated_topics']=['resources']
artifact['reused_topics']=[t for t in answers if t!='resources' and t not in removed]
artifact['selected_historical_topics']=list(removed)
artifact['integration_lineage']=dict(mode='new-native-cli-topic-and-retained-source-identical-topics',
 old_page_sha256=hashlib.sha256((cfg.sdd_dir/'request-lifecycle.md').read_bytes()).hexdigest(),
 new_topic_page_sha256=hashlib.sha256((root/'build/issue249/work/manuscripts/request-lifecycle.md').read_bytes()).hexdigest(),
 source_commit=model.meta['source_commit'],retained_topics=artifact['reused_topics'],human_review='pending')
artifact['integration_lineage']['whole_statement_selections']=selection
artifact['integration_lineage']['new_topic_original_source_commit']=newmeta['source_commit']
artifact['integration_lineage']['current_source_revalidation']='every retained quote, condition and source selector revalidated at current source commit; no substitute inference'
for tid in removed:
 artifact['topic_inputs'].pop(tid,None)
class NoCalls:
 def chat(self,*args,**kwargs):raise RuntimeError('Integration cannot create substitute model responses')
generator=Generator(cfg,model,NoCalls())
generator.generated_designs['request-lifecycle']=DesignResult(pinned,resolved,report,artifact)
path=generator._prose(selected)
generated_design.verify(model,selected,path.read_text(encoding='utf-8'),cfg=cfg)
manifest=json.loads((root/'build/issue249/public/docs/site-manifest.json').read_bytes())
wanted=manifest['inputs']['english_catalog']
catalogs=[p for p in (root/'build/issue249/public').rglob('english.json') if hashlib.sha256(p.read_bytes()).hexdigest()==wanted]
assert catalogs,'Exact current public translation catalog is required'
if not preserve:shutil.copyfile(catalogs[0],out/'english.json')
print('Integrated real CLI resources; retained other source-identical topic provenance:',path)
