from pathlib import Path
import json,yaml,copy,hashlib,difflib
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.document_metadata import split_frontmatter
from sdd.generate import Generator
from sdd import generated_design
from sdd.design_types import DesignResult
root=Path(__file__).resolve().parents[2];out=root/'build/issue249/integration'
canonical=yaml.safe_load((root/'examples/libcamera/config/visuals.yaml').read_bytes());path=out/'visuals.yaml';visuals=yaml.safe_load(path.read_bytes());visuals['sections']['request-lifecycle']=canonical['sections']['request-lifecycle'];path.write_text(yaml.safe_dump(visuals,allow_unicode=True,sort_keys=False),encoding='utf-8')
cfg=load(out/'sdd.yaml');model=KnowledgeModel.load(cfg.facts_path);section=next(s for s in cfg.sections() if s['id']=='request-lifecycle');target=cfg.sdd_dir/'request-lifecycle.md';before=target.read_text(encoding='utf-8');meta,body=split_frontmatter(before)
pinned,resolved,report=generated_design.validate_answers(model,section,meta['generated_design']['answers'])
class NoCalls:
 def chat(self,*a,**k):raise RuntimeError('Layout-only assembly cannot substitute new inference')
gen=Generator(cfg,model,NoCalls());gen.generated_designs['request-lifecycle']=DesignResult(pinned,resolved,report,copy.deepcopy(meta['generated_design']));gen._prose(section)
after=target.read_text(encoding='utf-8');newmeta,newbody=split_frontmatter(after);assert newmeta['generated_design']['answers']==meta['generated_design']['answers'];generated_design.verify(model,section,after,cfg=cfg)
(out/'layout-only.diff').write_text(''.join(difflib.unified_diff(body.splitlines(True),newbody.splitlines(True))),encoding='utf-8')
(out/'layout-only.json').write_text(json.dumps(dict(new_model_calls=0,answer_text_and_evidence_equal=True,before_sha256=hashlib.sha256(before.encode()).hexdigest(),after_sha256=hashlib.sha256(after.encode()).hexdigest(),human_review='pending'),indent=2),encoding='utf-8')
print((out/'layout-only.diff').read_text(encoding='utf-8'))
