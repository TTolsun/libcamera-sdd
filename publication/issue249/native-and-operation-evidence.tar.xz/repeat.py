from pathlib import Path
import sys,json,hashlib,shutil
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'src'))
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.generate import Generator
from sdd.impact import ImpactReport
from sdd.document_metadata import split_frontmatter
from sdd.visuals import render
cfg=load(root/'build/issue249/work/sdd.yaml');model=KnowledgeModel.load(cfg.facts_path)
path=cfg.sdd_dir/'request-lifecycle.md';before=path.read_text(encoding='utf-8')
shutil.copyfile(path,root/'build/issue249/accepted-topic.md')
meta,body=split_frontmatter(before);figures=render(cfg,model,cfg.sections()[0])
class NoCalls:
 calls=0
 def chat(self,*a,**k):
  self.calls+=1
  raise RuntimeError('Unchanged-input repeat unexpectedly requested new inference')
agent=NoCalls();Generator(cfg,model,agent).run(impact=ImpactReport(model.meta['source_commit'],model.meta['source_commit'],sections={'request-lifecycle':['fixed-input repeat']}))
after_meta,after_body=split_frontmatter(path.read_text(encoding='utf-8'))
assert body==after_body
assert meta['generated_design']['answers']==after_meta['generated_design']['answers']
assert figures==render(cfg,model,cfg.sections()[0])
assert agent.calls==0
report=dict(status='passed',scope='Unchanged-input validated manuscript reuse and assembly, not deterministic fresh LLM sampling',source_commit=model.meta['source_commit'],body_sha256=hashlib.sha256(body.encode()).hexdigest(),new_model_calls=agent.calls,answers_equal=True,figures_and_evidence_equal=True,human_review='pending')
(root/'build/issue249/repeat.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
