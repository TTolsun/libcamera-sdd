from pathlib import Path
root=Path(__file__).resolve().parents[2]
source=(root/'build/issue249/grade.py').read_text(encoding='utf-8')
source=source.replace("build/issue249/final-reading/result.json", "build/issue249/final-reading-v3/result.json")
source=source.replace("f'{label}-grading-v2'", "f'{label}-grading-v4'")
exec(compile(source,str(root/'build/issue249/grade.py'),'exec'))
