from pathlib import Path
root=Path(__file__).resolve().parents[2];path=root/'build/issue249/bilingual_review_batch.py'
exec(compile(path.read_text(encoding='utf-8').replace('bilingual-review-v8','bilingual-review-v9'),str(path),'exec'))
