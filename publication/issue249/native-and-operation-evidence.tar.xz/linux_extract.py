from pathlib import Path
import sys,yaml
import shutil
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'src'))
from sdd.config import load
from sdd.extract import run
from sdd.evidence import collect
base=root/'examples/libcamera'
cfg=load(base/'sdd.yaml')
raw=yaml.safe_load((base/'sdd.yaml').read_text(encoding='utf-8'))
raw['source']['root']='/home/baboess/work/sdd-issue249/source'
raw['source']['compile_commands']=str(root/'build/issue249/compile_commands.json')
raw['output']=dict(facts_dir=str(root/'build/issue249/latest-facts'),sdd_dir=str(root/'build/issue249/latest-manuscripts'),diagrams_dir=str(root/'build/issue249/latest-manuscripts/diagrams'))
raw['paths']={**raw['paths'],'sections_file':str(cfg.sections_file),'scenarios_file':str(cfg.scenarios_file),'consistency_file':str(cfg.paths['consistency_file']),'prompts':str(cfg.prompts_dir),'templates':str(cfg.templates_dir),'style':str(cfg.style_dir)}
raw['products']['file']=str(base/'config/products.yaml')
raw['visuals']['file']=str(base/'config/visuals.yaml')
raw['site']['enabled']=False
runroot=root/'build/issue249/extract-run'
runroot.mkdir(exist_ok=True)
shutil.copytree(base/'config',runroot/'config',dirs_exist_ok=True)
raw['paths']['sections_file']='config/sections.yaml'
raw['paths']['scenarios_file']='config/scenarios.yaml'
raw['paths']['consistency_file']='config/contracts.yaml'
raw['products']['file']='config/products.yaml'
raw['visuals']['file']='config/visuals.yaml'
path=runroot/'sdd.yaml'
path.write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
prepared=load(path)
prepared.sections()  # Validate all local product/config paths before Clang work.
import sdd.evidence
original=sdd.evidence.collect
def checkpoint(cfg,model):
 model.save(root/'build/issue249/extracted-before-evidence.json')
 original(cfg,model)
sdd.evidence.collect=checkpoint
model=run(prepared)
print('SOURCE',model.meta['source_commit'],'CLASSES',len(model.classes))
