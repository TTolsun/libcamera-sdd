from pathlib import Path
import yaml,json,hashlib,shutil
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.evidence import collect
from sdd.carryover import carry_forward
from sdd.render_profiles import for_page
root=Path(__file__).resolve().parents[2];work=root/'build/issue249';out=work/'integration';prior=work/'issue250/baseline';public=work/'public';manifest=json.loads((public/'docs/site-manifest.json').read_bytes())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(prior/'config/sections.yaml')==manifest['inputs']['sections']
assert sha(prior/'config/visuals.yaml')==manifest['inputs']['visuals']
old_sections=yaml.safe_load((out/'sections.yaml').read_bytes());section=next(s for s in old_sections['sections'] if s['id']=='request-lifecycle')
latest=yaml.safe_load((prior/'config/sections.yaml').read_bytes());latest['sections']=[section if s['id']=='request-lifecycle' else s for s in latest['sections']]
(out/'sections.yaml').write_text(yaml.safe_dump(latest,allow_unicode=True,sort_keys=False),encoding='utf-8')
current=yaml.safe_load((out/'visuals.yaml').read_bytes());owned=[g for g in current['sections']['request-lifecycle'] if g.get('topic')=='resources'];visuals=yaml.safe_load((prior/'config/visuals.yaml').read_bytes());rows=visuals['sections']['request-lifecycle'];slot=next(i for i,g in enumerate(rows) if g.get('topic')=='resources');rows[:]=[g for g in rows if g.get('topic')!='resources'];rows[slot:slot]=owned
(out/'visuals.yaml').write_text(yaml.safe_dump(visuals,allow_unicode=True,sort_keys=False),encoding='utf-8')
shutil.copyfile(prior/'config/glossary.yaml',out/'glossary-issue250.yaml')
reader=yaml.safe_load((public/'publication/issue250/reader-paths.yaml').read_bytes());changes=[]
for claim in reader['claims']:
 for ref in claim.get('sources',[]):
  if ref==dict(section='request-lifecycle',topic='resources',part='summary'):
   ref['part']='ownership';changes.append(dict(claim=claim['id'],old='resources/summary',new='resources/ownership',reason='The complete ownership part replaces the former summary, preserving all selected behavior statements and their conditions.'))
(out/'reader-paths.yaml').write_text(yaml.safe_dump(reader,allow_unicode=True,sort_keys=False),encoding='utf-8')
profile=yaml.safe_load((prior/'pipeline-authentication.yaml').read_bytes());profile['paths']['style']=str(prior/'current-pipeline-style');profilepath=out/'pipeline-issue250-authentication.yaml';profilepath.write_text(yaml.safe_dump(profile,allow_unicode=True,sort_keys=False),encoding='utf-8')
catalog=json.loads((out/'english.json').read_bytes());baseline=json.loads((public/'publication/issue248/english.json').read_bytes());latest_catalog=json.loads((work/'issue250/english.json').read_bytes());assert sha(work/'issue250/english.json')==manifest['inputs']['english_catalog']
catalog_changes=[]
for source,target in latest_catalog['strings'].items():
 if baseline['strings'].get(source)!=target:
  catalog['strings'][source]=target;catalog_changes.append(source)
(out/'english.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
latest_raw=yaml.safe_load((prior/'publication.yaml').read_bytes());intro=Path(latest_raw['site']['intro']);shutil.copyfile(intro,out/'site-intro-issue250.md')
for name in ['sdd.yaml','independent-review.yaml']:
 path=out/name;raw=yaml.safe_load(path.read_bytes());raw['site']['reader_paths']=str(out/'reader-paths.yaml');raw['site']['intro']=str(out/'site-intro-issue250.md');raw['site']['manuscript_profiles']['pipeline-handler.md']=str(profilepath);raw['paths']['glossary_file']=str(out/'glossary-issue250.yaml');path.write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
shutil.copyfile(out/'manuscripts/pipeline-handler.md',out/'pipeline-handler-before-issue250.md');shutil.copyfile(public/'docs/pipeline-handler.md',out/'manuscripts/pipeline-handler.md')
cfg=load(out/'sdd.yaml');model=KnowledgeModel.load(cfg.facts_path);collect(cfg,model);model.save(cfg.facts_path)
promoted,stale=carry_forward(for_page(cfg,'pipeline-handler.md'),model,[p for p in cfg.sdd_dir.rglob('*.md') if p.name!='pipeline-handler.md'])
proof=dict(public_source_commit='866f3007a4d10f9f2747e38ba7ee9a0090c5a9d3',current_source_commit=model.meta['source_commit'],reader_path_changes=changes,preserved_public_catalog_values=len(catalog_changes),preserved_pipeline_source_sha256=sha(public/'docs/pipeline-handler.md'),promoted=[str(p) for p in promoted],stale=[(str(p),v) for p,v in stale],new_inference=False,human_review='pending')
(out/'issue250-preservation.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(proof,ensure_ascii=False),flush=True);assert not stale
