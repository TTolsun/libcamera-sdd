from pathlib import Path
import gzip, hashlib, json, shutil, tarfile
from sdd.config import load
from sdd.export_site import export_site
from sdd.site_build import verify_site
from sdd.cli_provenance import verify_cli_receipt
root=Path(__file__).resolve().parent;repo=root.parent.parent
cfg=load(root/'baseline/publication.yaml')
report=json.loads((cfg.build_dir/'consistency-review.json').read_bytes())
assert report.get('status')=='passed', 'Current independent contract review is not complete'
public_manifest=json.loads((root/'public/docs/site-manifest.json').read_bytes())
observed=json.loads((root/'live-baseline/site-manifest.json').read_bytes())
unexpected=[name for name,digest in public_manifest['outputs'].items()
            if name not in observed['outputs'] or observed['outputs'][name]!=digest]
assert not unexpected, 'New public changes need integration before export: '+str(unexpected)
site=export_site(cfg,root/'site')
before=(site/'site-manifest.json').read_bytes()
export_site(cfg,site)
assert (site/'site-manifest.json').read_bytes()==before
validation={'site':verify_site(site),'repeat_manifest_identical':True,
 'build_id':json.loads(before)['build_id'],'human_review':'pending','actual_human_role_evaluation':'not performed',
 'actual_executive_evaluation':'not performed','internal_HAL':'not validated'}
(root/'site-verification.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS repeated gated bilingual export',validation['build_id'],flush=True)

expected=load(root/'review.yaml').agent
new=[]
seen={}
for directory in [root/'baseline/build',*root.glob('*implementation'),root/'review-grounding',root/'glossary-writer',root/'bilingual-review',root/'bilingual-final-review',root/'bilingual-release-review',root/'bilingual-final-acceptance',root/'bilingual-248-integrated-review',root/'bilingual-bound-final-review',root/'pipeline-review',root/'pipeline-final-review',root/'independent-contract-groups']:
    if not directory.is_dir():continue
    for receipt_path in directory.rglob('*.receipt.json'):
        receipt=json.loads(receipt_path.read_bytes())
        if receipt.get('completed_at','')<'2026-11-04T18:30:00':continue
        prefix=receipt_path.with_name(receipt_path.name.removesuffix('.receipt.json'))
        request=json.loads(prefix.with_suffix('.request.json').read_bytes())
        response=prefix.with_suffix('.response.txt').read_text(encoding='utf-8')
        calls=receipt_path.parent.parent
        result=verify_cli_receipt(request,response,receipt,calls,expected)
        digest=hashlib.sha256(receipt_path.read_bytes()).hexdigest()
        relative=str(receipt_path.relative_to(root)).replace('\\','/')
        if digest in seen:
            seen[digest]['aliases'].append(relative)
        else:
            row={'receipt':relative,'aliases':[],'receipt_sha256':digest,
                 'tag':receipt['tag'],'completed_at':receipt['completed_at'],'verification':result}
            seen[digest]=row;new.append(row)
assert new
(root/'native-verification.json').write_text(json.dumps(new,ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS fresh independent native CLI receipt integrity',len(new),flush=True)

out=export_site(cfg,root/'public/docs')
assert (out/'site-manifest.json').read_bytes()==before
print('PASS exact public release staging',flush=True)
