from pathlib import Path
import copy,hashlib,json,shutil,yaml
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.generate import Generator
from sdd.impact import ImpactReport
from sdd.llm import Agent
from sdd.document_metadata import split_frontmatter
root=Path(__file__).resolve().parent;repo=root.parent.parent
base=root/'baseline'
report=base/'build/consistency-review.json'
old=json.loads(report.read_bytes())
assert old.get('status') in ['failed','passed'], 'Wait for the frozen review to finish before changing inputs'
shutil.copyfile(report,root/'consistency-before-correction.json')
config=base/'config/sections.yaml'
shutil.copyfile(config,root/'sections-before-correction.yaml')
sections=yaml.safe_load(config.read_text(encoding='utf-8'))
topic=next(t for s in sections['sections'] if s['id']=='pipeline-handler' for t in s['design_topics'] if t['id']=='shutdown')
part=next(p for p in topic['parts'] if p['id']=='reentry')
example=yaml.safe_load((repo/'examples/libcamera/config/sections.yaml').read_text(encoding='utf-8'))
spec=next(p for s in example['sections'] if s['id']=='pipeline-handler' for t in s['design_topics'] if t['id']=='shutdown' for p in t['parts'] if p['id']=='reentry')
part['prompt']=spec['prompt']
config.write_text(yaml.safe_dump(sections,allow_unicode=True,sort_keys=False),encoding='utf-8')
visual_path=base/'config/visuals.yaml'
shutil.copyfile(visual_path,root/'visuals-before-correction.yaml')
visuals=yaml.safe_load(visual_path.read_text(encoding='utf-8'))
public_visuals=yaml.safe_load((repo/'examples/libcamera/config/visuals.yaml').read_text(encoding='utf-8'))
visuals['sections']['pipeline-handler']=public_visuals['sections']['pipeline-handler']
visual_path.write_text(yaml.safe_dump(visuals,allow_unicode=True,sort_keys=False),encoding='utf-8')
raw=yaml.safe_load((base/'publication.yaml').read_text(encoding='utf-8'))
raw['agent']['command']=[]
raw['agent'].update(kind='cli',runner='codex',model='gpt-6.1-terra',args=['-c','model_reasoning_effort="high"'])
raw['site']['enabled']=False
(base/'reentry-generation.yaml').write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
cfg=load(base/'reentry-generation.yaml');model=KnowledgeModel.load(cfg.facts_path)
before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in cfg.sdd_dir.glob('*.md')}
page=cfg.sdd_dir/'pipeline-handler.md';shutil.copyfile(page,root/'pipeline-handler-before-correction.md')
meta=split_frontmatter(page.read_text(encoding='utf-8'))[0]
impact=ImpactReport(base=model.meta['source_commit'],head=model.meta['source_commit'],
 sections={'pipeline-handler':['Fresh independent review found a less-than inference where source tests equality; correct the reentry drafting question only.']})
impact.save(root/'editorial-impact.json')
Generator(cfg,model,Agent(cfg.agent,cfg.build_dir/'prompts')).run(['pipeline-handler'],impact)
after=split_frontmatter(page.read_text(encoding='utf-8'))[0]
changed=[p.name for p in cfg.sdd_dir.glob('*.md') if before.get(p.name)!=hashlib.sha256(p.read_bytes()).hexdigest()]
assert changed==['pipeline-handler.md'],changed
for tid,answers in meta['generated_design']['answers'].items():
    if tid!='shutdown':assert answers==after['generated_design']['answers'][tid],tid
(root/'reentry-correction.json').write_text(json.dumps({'changed_manuscripts':changed,
 'same_facts_commit':model.meta['source_commit'],'generator_method':'normal impact-driven Generator with independent Codex CLI/Terra High',
 'before':meta['generated_design']['answers']['shutdown'],'after':after['generated_design']['answers']['shutdown'],
 'human_approval':'not granted'},ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS native reentry correction; unrelated topics and all other manuscripts preserved',flush=True)
