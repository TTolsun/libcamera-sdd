from pathlib import Path
import json
from sdd.config import load
from sdd.llm import Agent
root=Path(__file__).resolve().parent
cfg=load(root/'review.yaml')
schema={'type':'object','additionalProperties':False,'required':['definition_ko','definition_en'],
 'properties':{k:{'type':'string'} for k in ['definition_ko','definition_en']}}
agent=Agent(cfg.agent,root/'glossary-writer')
result=agent.chat('Write a concise glossary definition from the supplied definition only; return JSON. Do not invent measurements or claim review approval.',
 'Term ROI. Full name Return on Investment. Define it as comparing return with investment cost. Explicitly state that ROI is not measured in this public libcamera documentation example. Produce one Korean sentence and its faithful English translation. Do not provide a formula, numbers, improvement rates or internal organization assumptions.',tag='issue250-roi-definition',response_schema=schema)
(root/'glossary-definition.json').write_text(result,encoding='utf-8')
print(result)
