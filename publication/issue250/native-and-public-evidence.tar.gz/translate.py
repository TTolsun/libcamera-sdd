from pathlib import Path
import json
from sdd.config import load
from sdd.localization_cli import prepare_catalog
root=Path(__file__).resolve().parent
cfg=load(root/'baseline/publication.yaml')
catalog=Path(cfg.site.english_catalog)
print(prepare_catalog(cfg,catalog,translate=True),flush=True)
print('missing',sum(not x for x in json.loads(catalog.read_bytes())['strings'].values()))
