from pathlib import Path
import sys
from sdd.runtime_evidence import run_recorded,require_success
root=Path(__file__).resolve().parent
hooks=root/'empty-hooks';hooks.mkdir(exist_ok=True)
env={'GIT_CONFIG_COUNT':'3','GIT_CONFIG_KEY_0':'commit.gpgsign','GIT_CONFIG_VALUE_0':'false',
 'GIT_CONFIG_KEY_1':'core.hooksPath','GIT_CONFIG_VALUE_1':str(hooks),
 'GIT_CONFIG_KEY_2':'core.fsmonitor','GIT_CONFIG_VALUE_2':'false','PYTHONUNBUFFERED':'1'}
run_recorded(root/'executions/full-tests',[sys.executable,'-X','utf8','-u','-m','pytest','-q','--tb=short',
 '--basetemp='+str(root/'fulltests-isolated')],timeout=1200,cwd=root.parent.parent,environment=env)
require_success(root/'executions/full-tests')
print((root/'executions/full-tests/stdout.txt').read_text(encoding='utf-8')[-2500:])
