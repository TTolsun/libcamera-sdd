from pathlib import Path
import hashlib,json,os,sys,uuid
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd import consistency as c
from sdd.cli_checkpoint import UnitStore
from sdd.cli_provenance import _stdout_file
root=Path(__file__).resolve().parent
cfg=load(root/'baseline/independent-review.yaml');model=KnowledgeModel.load(cfg.facts_path)
name=sys.argv[1];source_cfg=load(root/'independent-contract-groups'/name/'review.yaml')
report=json.loads((source_cfg.build_dir/'consistency-review.json').read_bytes())
assert report['status']=='passed',report.get('status')
group=next(g for g in c.groups(cfg) if g['id']==name)
payload=c.request(cfg,model,group)
assert report['contracts'][0]['input_sha256']==c.identity(payload)
src=source_cfg.build_dir/'prompts';dst=cfg.build_dir/'prompts'
files=[]
def copy_exact(source,target):
    raw=source.read_bytes()
    if target.exists():
        assert target.read_bytes()==raw,('Archive collision',target)
        return
    target.parent.mkdir(parents=True,exist_ok=True)
    temporary=target.with_name(target.name+'.import-'+uuid.uuid4().hex)
    temporary.write_bytes(raw)
    try:temporary.rename(target)
    except FileExistsError:
        temporary.unlink();assert target.read_bytes()==raw
    files.append({'path':str(target.relative_to(root)).replace('\\','/'),'sha256':hashlib.sha256(raw).hexdigest()})
imported=0;existing=0
for batch in c.batches(payload,max_input_chars=cfg.agent.max_input_chars):
    target,_=c.review_store(cfg,batch)
    if target.path.exists():existing+=1;continue
    source=UnitStore(source_cfg,target.identity)
    cached=source.read();assert cached is not None
    saved,_=cached;assert c.validate(batch,saved['raw'])==saved['statements']
    for receipt_name in saved['receipts']:
        receipt=src/'calls'/receipt_name
        prefix=receipt.name.removesuffix('.receipt.json')
        for artifact in receipt.parent.glob(prefix+'.*'):copy_exact(artifact,dst/artifact.relative_to(src))
        data=json.loads(receipt.read_bytes());stdout=_stdout_file(src/'calls',data['provider']['stdout_path'])
        prefix=stdout.name.split('.stdout')[0]
        for artifact in stdout.parent.glob(prefix+'*'):
            if artifact.is_file():copy_exact(artifact,dst/artifact.relative_to(src))
    # On Windows rename is atomic and refuses an existing destination. Never replace a live auditor checkpoint.
    temporary=target.canonical_path.with_name(target.canonical_path.name+'.import-'+uuid.uuid4().hex)
    temporary.write_bytes(source.path.read_bytes())
    try:temporary.rename(target.canonical_path);imported+=1
    except FileExistsError:temporary.unlink();existing+=1
    print('Verified original native checkpoint',name,imported,existing,flush=True)
(root/('imported-'+name+'.json')).write_text(json.dumps({'group':name,'input_sha256':c.identity(payload),
 'imported_original_checkpoints':imported,'existing_preserved':existing,'archive_files':files,
 'new_calls_claimed_by_import':0,'acceptance':'unmodified full audit must revalidate every checkpoint'},indent=2),encoding='utf-8')
