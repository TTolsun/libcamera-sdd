from pathlib import Path
import json, subprocess, yaml, hashlib
from sdd.config import load
from sdd.facts.model import KnowledgeModel
root=Path(__file__).resolve().parent; repo=root.parent.parent
cfg=load(root/'baseline/publication.yaml'); model=KnowledgeModel.load(cfg.facts_path)
claims=yaml.safe_load((repo/'examples/libcamera/reader-paths.yaml').read_text(encoding='utf-8'))['claims']
topics={(r['section'],r['topic']) for c in claims for r in c['sources']}
source=root/'source'
git=lambda *args:subprocess.check_output(['git','-C',str(source),*args])
latest=git('rev-parse','upstream-master').decode().strip()
baseline=model.meta['source_commit']; windows=[]; paths={}
for key,record in model.evidence.items():
    if tuple(key.split('/')[:2]) not in topics:continue
    entry={k:record.get(k) for k in ['file','line','end_line','sha256','commit']};entry['id']=key
    name=record.get('file','')
    if name and not name.startswith('@'):
        old=git('show',f'{baseline}:{name}'); new=git('show',f'{latest}:{name}')
        paths[name]={'baseline_sha256':hashlib.sha256(old).hexdigest(),'latest_sha256':hashlib.sha256(new).hexdigest(),'unchanged':old==new}
        entry['upstream_file_unchanged']=old==new
    else:entry['upstream_comparison']='Historical non-library evidence; not a new upstream or runtime result'
    windows.append(entry)
assert all(p['unchanged'] for p in paths.values())
report={'schema':1,'official_upstream':latest,'public_mirror_status':'already-current at the independently observed official SHA',
 'document_facts_commit':baseline,'fresh_facts_extraction':False,'new_runtime':False,
 'scope':'Configured canonical topics referenced by the two role entrances only; not whole-site or internal HAL verification',
 'changed_upstream_paths':git('diff','--name-only',baseline,latest).decode().splitlines(),
 'examined_windows':windows,'source_files':paths,
 'not_reviewed':'Changed AGC estimation, Python configuration API and version declaration are outside this representative request-path review; full source extraction and hardware execution at the new SHA have not been performed.'}
(root/'source-scope.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS',len(windows),'evidence windows;',len(paths),'unchanged library files; current upstream',latest)
