from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,urllib.request,time
root=Path(__file__).resolve().parent
base='https://ttolsun.github.io/libcamera-sdd/'
expected=(root/'site/site-manifest.json').read_bytes();manifest=json.loads(expected)
query='?issue250='+manifest['build_id']
def get(name):
    request=urllib.request.Request(base+name+query,headers={'User-Agent':'camera-hal-sdd-public-verification'})
    with urllib.request.urlopen(request,timeout=45) as response:return response.status,response.read()
status,before=get('site-manifest.json')
assert status==200 and before==expected,'Public manifest is not the staged release'
def check(item):
    name,digest=item;status,raw=get(name);actual=hashlib.sha256(raw).hexdigest()
    assert status==200 and actual==digest,(name,status,actual,digest)
    return {'path':name,'status':status,'sha256':actual,'bytes':len(raw)}
# The marker configures hosting and is not a reader-facing artifact.
items=[x for x in manifest['outputs'].items() if x[0]!='.nojekyll']
with ThreadPoolExecutor(max_workers=6) as pool:rows=list(pool.map(check,items))
status,after=get('site-manifest.json');assert after==before
report={'status':'passed','base_url':base,'build_id':manifest['build_id'],
 'manifest_exactly_matches_staged_release':True,'manifest_stable_before_after':True,
 'checked_public_outputs':len(rows),'excluded_hosting_marker':['.nojekyll'],
 'actual_human_evaluation':'not performed','actual_executive_evaluation':'not performed','internal_HAL':'not validated',
 'outputs':rows}
(root/'live-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS actual public bytes',len(rows),'build',manifest['build_id'])
