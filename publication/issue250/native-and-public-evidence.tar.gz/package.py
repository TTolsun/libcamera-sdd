from pathlib import Path
import gzip,hashlib,json,shutil,tarfile,re
root=Path(__file__).resolve().parent;repo=root.parent.parent
proof=root/'release-evidence';proof.mkdir(parents=True,exist_ok=True)
stage=root/'evidence-package';stage.mkdir(exist_ok=True)
records=json.loads((root/'native-verification.json').read_bytes())
files=set()
for row in records:
    receipt=root/row['receipt'];prefix=receipt.name.removesuffix('.receipt.json')
    for p in receipt.parent.glob(prefix+'.*'):
        if p.is_file():files.add(p)
    data=json.loads(receipt.read_bytes())
    calls=receipt.parent.parent
    stdout=calls.parent/data['provider']['stdout_path']
    if stdout.is_file():files.add(stdout)
    # Keep every archived CLI execution artifact beside the bound stdout.
    for p in stdout.parent.glob(stdout.stem+'*'):
        if p.is_file():files.add(p)
for p in (root/'baseline/config').rglob('*'):
    if p.is_file():files.add(p)
for p in (root/'baseline/run/manuscripts').glob('*.md'):files.add(p)
for p in (root/'baseline').glob('*.yaml'):files.add(p)
for p in (root/'baseline/current-pipeline-style').rglob('*'):
    if p.is_file():files.add(p)
for p in root.glob('*.py'):files.add(p)
for p in root.glob('*.cjs'):files.add(p)
for p in root.glob('*.json'):files.add(p)
for p in root.glob('*.log'):files.add(p)
for directory in [root/'executions',root/'browser-preview-host02',root/'browser-final',root/'independent-contract-groups']:
    if directory.exists():files.update(p for p in directory.rglob('*') if p.is_file())
for p in root.glob('*implementation.json'):files.add(p)
files.add(root/'review-grounding.json')
with gzip.open(stage/'facts.json.gz','wb') as stream:stream.write((root/'baseline/run/facts/facts.json').read_bytes())
files.add(stage/'facts.json.gz')
archive=proof/'native-and-public-evidence.tar.gz'
index={}
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(files):
        if not p.is_file():continue
        name=str(p.relative_to(root)).replace('\\','/')
        tar.add(p,arcname=name,recursive=False)
        index[name]=hashlib.sha256(p.read_bytes()).hexdigest()
(proof/'archive-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding='utf-8')
for name in ['site-verification.json','native-verification.json','source-scope.json']:
    shutil.copyfile(root/name,proof/name)
shutil.copyfile(repo/'examples/libcamera/reader-paths.yaml',proof/'reader-paths.yaml')
for name in ['evaluation-final-work.json','evaluation-final-decision.json','final-evaluation-tasks.json','generator-merge.json','concurrent-248-integration.json']:
    assert (root/name).is_file(),name
    shutil.copyfile(root/name,proof/name)
shutil.copyfile(root/'browser-final/summary.json',proof/'browser-verification.json')
(proof/'package.json').write_text(json.dumps({'schema':1,'archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'archive_bytes':archive.stat().st_size,'archive_index_sha256':hashlib.sha256((proof/'archive-index.json').read_bytes()).hexdigest(),
    'public_source_only':True,'actual_humans':0,'internal_HAL':'not validated'},indent=2),encoding='utf-8')

record=(repo/'docs/records/issue250.md').read_text(encoding='utf-8')
def public_link(match):
    target=match.group(2)
    if not target.startswith('../'):return match.group(0)
    file,_,anchor=target.partition('#')
    relative=(repo/'docs/records'/file).resolve().relative_to(repo.resolve()).as_posix()
    return '['+match.group(1)+'](https://github.com/TTolsun/camera-hal-sdd-generator/blob/main/'+relative+('#'+anchor if anchor else '')+')'
(proof/'record.md').write_text(re.sub(r'\[([^\]]+)\]\(([^)]+)\)',public_link,record),encoding='utf-8')
public=root/'public/publication/issue250'
shutil.copytree(proof,public,dirs_exist_ok=True)
print('Packaged public-only evidence',len(index),'files; bytes',archive.stat().st_size)
