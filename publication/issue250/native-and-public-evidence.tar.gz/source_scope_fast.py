from pathlib import Path
import json, yaml, subprocess
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.runtime_evidence import run_recorded, require_success
root=Path(__file__).resolve().parent;repo=root.parent.parent
cfg=load(root/'baseline/publication.yaml'); model=KnowledgeModel.load(cfg.facts_path)
base=model.meta['source_commit']; latest='be7e83e91348250c015aad6d6f59f1468555bae8'
directory=root/'executions/official-diff-integrated-final'
run_recorded(directory,['git','-C',str(root/'source'),'diff','--name-only',base,latest],timeout=120,cwd=repo)
require_success(directory)
changed=set((directory/'stdout').read_text(encoding='utf-8').splitlines())
claims=yaml.safe_load((repo/'examples/libcamera/reader-paths.yaml').read_text(encoding='utf-8'))['claims']
topics={(r['section'],r['topic']) for c in claims for r in c['sources']}
topics.update(('pipeline-handler',t['id']) for sec in cfg.sections() if sec['id']=='pipeline-handler' for t in sec['design_topics'])
windows=[]
for key,row in model.evidence.items():
    if tuple(key.split('/')[:2]) not in topics:continue
    item={k:row.get(k) for k in ['file','line','end_line','sha256','commit']};item['id']=key
    name=row.get('file','')
    if name and not name.startswith('@'):
        assert name not in changed, name
        item['upstream_comparison']='File is absent from the complete Git changed-path set, so its baseline source window is unchanged at the observed upstream SHA.'
    else:item['upstream_comparison']='Historical non-library evidence; not a new upstream or runtime result.'
    windows.append(item)
report={'schema':1,'official_upstream':latest,'document_facts_commit':base,
 'public_mirror_status':'already current at the independently observed official SHA',
 'fresh_facts_extraction':False,'new_runtime':False,'changed_upstream_paths':sorted(changed),
 'examined_windows':windows,'scope':'Canonical role-entry topics and four regenerated Pipeline Handler topics; not whole-site or internal HAL verification',
 'not_reviewed':'Changed AGC estimation, Python configuration API and version declaration; full extraction and hardware execution at the new SHA were not performed.'}
(root/'source-scope.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS',len(windows),'unchanged source windows; changed paths:',sorted(changed))
