from pathlib import Path
import subprocess,json,hashlib
root=Path(__file__).resolve().parent
manifest=json.loads((root/'site/site-manifest.json').read_bytes())
p=subprocess.Popen(['git','-C',str(root/'public'),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
rows=[]
for name,digest in manifest['outputs'].items():
    p.stdin.write((':docs/'+name+'\n').encode());p.stdin.flush()
    header=p.stdout.readline().decode().split();assert len(header)==3,header
    size=int(header[2]);raw=p.stdout.read(size);assert p.stdout.read(1)==b'\n'
    actual=hashlib.sha256(raw).hexdigest();assert actual==digest,(name,actual,digest)
    rows.append({'path':name,'sha256':actual,'bytes':size})
p.stdin.close();assert p.wait()==0
report={'status':'passed','build_id':manifest['build_id'],'index_blobs_equal_staged_site':True,'outputs':rows}
(root/'git-staged-output-verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('PASS every staged Git output blob',len(rows))
