from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.llm import Agent
from sdd.generation_run import Execution
from sdd.cli_checkpoint import Capture
from sdd import consistency as c
from sdd.validation_stage import staged
root=Path(__file__).resolve().parent
@staged
def warm(cfg,model,group):
    payload=c.request(cfg,model,group)
    batches=list(c.batches(payload,max_input_chars=cfg.agent.max_input_chars))
    keys=[f"consistency_{group['id']}_{i}" for i in range(len(batches))]
    agent=Execution(cfg,Agent(cfg.agent,cfg.build_dir/'prompts'),model=model)
    with agent.track('contract-audit'),agent.document('consistency',keys):
        for key,batch in zip(keys,batches):
            agent.unit(key,'running');agent.check_time()
            store,request=c.review_store(cfg,batch)
            cached=store.read()
            if cached is not None:
                saved,_=cached
                assert c.validate(batch,saved['raw'])==saved['statements']
                agent.unit(key,'checkpoint-reused')
            else:
                capture=Capture(agent)
                raw=capture.chat(c.SYSTEM,request['user'],tag=key,response_schema=c.schema(batch))
                checked=c.validate(batch,raw)
                store.write(raw,checked,capture)
                assert capture.receipts
                agent.unit(key,'completed')
            print(group['id'],key,'native receipt-bound checkpoint ready',flush=True)
    return group['id']
# These later groups cannot be reached by the serial auditor until its first three groups finish.
# No shared consistency report is written here; the unmodified audit revalidates every checkpoint.
cfg=load(root/'baseline/independent-review.yaml')
model=KnowledgeModel.load(cfg.facts_path)
groups=[g for g in c.groups(cfg) if g['id'] in ['callbacks-synchronization','scenario-analysis','submission-checks']]
with ThreadPoolExecutor(max_workers=2) as pool:
    jobs=[pool.submit(warm,cfg,model,g) for g in groups]
    for job in jobs:print('COMPLETED',job.result(),flush=True)
