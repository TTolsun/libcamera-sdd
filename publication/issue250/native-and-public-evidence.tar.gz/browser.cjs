const {chromium}=require('C:/Users/baboe/.codex/worktrees/cb18/camera-hal-sdd-generator/build/pan-20261105/pw/node_modules/playwright');
const fs=require('node:fs/promises');
const path=require('node:path');
const assert=require('node:assert/strict');
const root=__dirname;
const base=process.argv[2]||'http://127.0.0.1:60550/';
(async()=>{
 const out=path.join(root,process.argv[3]||'browser-preview');await fs.mkdir(out,{recursive:true});
 const browser=await chromium.launch({channel:'chrome',headless:true});const results=[];
 for(const [name,width,height] of [['desktop',1440,1000],['mobile',390,844]]){
  const context=await browser.newContext({viewport:{width,height},isMobile:width===390,hasTouch:width===390});
  const page=await context.newPage();
  for(const edition of (process.argv.includes('--bilingual')?['','en/']:['']))for(const role of ['work','decision']){
   const response=await page.goto(base+edition+`reader-${role}.html`,{waitUntil:'networkidle'});assert.equal(response.status(),200);
   assert.equal(await page.locator('main h1').count(),1);
   const content=await page.locator('main').innerText();
   if(!edition)assert(content.includes('사내 HAL')&&content.includes('미측정')&&content.includes('결정 요청'));
   else assert(!/[가-힣]/.test(content));
   const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1);assert.equal(overflow,false);
   for(const a of await page.locator('main a[href*=".html#"]').evaluateAll(nodes=>nodes.map(a=>a.getAttribute('href')))){
    const target=new URL(a,page.url());const fetched=await page.request.get(target.href);assert(fetched.ok(),a);
   }
   await page.screenshot({path:path.join(out,`${name}-${edition?'en':'ko'}-${role}.png`),fullPage:true});
   results.push({viewport:name,edition:edition||'ko',role,overflow,title:await page.locator('main h1').innerText()});
  }
  for(const edition of (process.argv.includes('--bilingual')?['','en/']:[''])){
   await page.goto(base+edition+'pipeline-handler.html',{waitUntil:'networkidle'});
   const figures=page.locator('.mermaid');await figures.first().waitFor();
   await page.waitForFunction(()=>[...document.querySelectorAll('.mermaid')].every(x=>x.dataset.ready==='true'));
   const buttons=page.getByRole('button',{name:edition?'Enlarge diagram':'다이어그램 확대',exact:true});
   assert.equal(await buttons.count(),6);
   for(let i=0;i<5;i++){
    await buttons.nth(i).click();const dialog=page.locator('#diagram-dialog');await dialog.waitFor({state:'visible'});
    const nodes=dialog.locator('svg .node');assert(await nodes.count()>0);
    const label=(await nodes.first().textContent()).trim().split(/\s+/)[0];
    await page.locator('#node-search').fill(label);assert(await dialog.locator('.is-match').count()>0);
    if(i===3)await page.screenshot({path:path.join(out,`${name}-${edition?'en':'ko'}-pipeline-stop.png`)});
    await page.keyboard.press('Escape');await dialog.waitFor({state:'hidden'});
   }
   assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);
   results.push({viewport:name,edition:edition||'ko',page:'pipeline-handler',figures:6,questionFiguresEnlargedAndSearched:5});
  }
  await page.goto(base,{waitUntil:'networkidle'});
  assert.equal(await page.locator('main a[href="reader-work.html"]').count(),1);
  assert.equal(await page.locator('main a[href="reader-decision.html"]').count(),1);
  assert(await page.locator('#sidebar nav').innerText().then(t=>t.includes('For Vendor')&&t.includes('For Developer')));
  await page.locator('main a[href="reader-work.html"]').focus();await page.keyboard.press('Enter');await page.waitForURL('**/reader-work.html');
  if(width===390){await page.locator('#menu-toggle').click();assert.equal(await page.locator('#menu-toggle').getAttribute('aria-expanded'),'true');await page.keyboard.press('Escape');}
  await context.close();
 }
 await browser.close();await fs.writeFile(path.join(out,'summary.json'),JSON.stringify({status:'passed',base,results},null,2));console.log('PASS desktop/mobile role paths, keyboard entry, source links, existing navigation');
})().catch(e=>{console.error(e);process.exit(1)});
