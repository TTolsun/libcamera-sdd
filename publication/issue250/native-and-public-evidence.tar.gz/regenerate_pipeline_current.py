from pathlib import Path
import hashlib,json,shutil,yaml
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.generate import Generator
from sdd.impact import ImpactReport
from sdd.llm import Agent
from sdd.document_metadata import split_frontmatter
root=Path(__file__).resolve().parent;repo=root.parent.parent;base=root/'baseline'
example=yaml.safe_load((repo/'examples/libcamera/config/sections.yaml').read_text(encoding='utf-8'))
new=next(s for s in example['sections'] if s['id']=='pipeline-handler')
path=base/'config/sections.yaml';data=yaml.safe_load(path.read_text(encoding='utf-8'))
current=next(s for s in data['sections'] if s['id']=='pipeline-handler')
for topic in current['design_topics']:
    spec=next(t for t in new['design_topics'] if t['id']==topic['id'])
    if 'prompt' in spec:topic['prompt']=spec['prompt']
    if topic['id']=='input-search-boundary':topic['sources']=spec['sources']
    for part in topic.get('parts',[]):
        other=next(p for p in spec['parts'] if p['id']==part['id'])
        if 'prompt' in other:part['prompt']=other['prompt']
        if topic['id']=='input-search-boundary':
            part['answer_contract']=other['answer_contract']
            part['sources']=other['sources']
path.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
path=base/'config/visuals.yaml';data=yaml.safe_load(path.read_text(encoding='utf-8'))
data['sections']['pipeline-handler']=yaml.safe_load((repo/'examples/libcamera/config/visuals.yaml').read_text(encoding='utf-8'))['sections']['pipeline-handler']
path.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
style=base/'current-pipeline-style';shutil.copytree(repo/'style',style,dirs_exist_ok=True)
raw=yaml.safe_load((base/'publication.yaml').read_text(encoding='utf-8'))
raw['site']['manuscript_profiles']['pipeline-handler.md']=str(base/'pipeline-authentication.yaml')
(base/'publication.yaml').write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
raw['agent'].update(kind='cli',runner='codex',command=[],model='gpt-6.1-terra',args=['-c','model_reasoning_effort="high"'],full_style_guides=True,max_input_chars=128000)
raw['paths']['style']=str(style)
(base/'current-pipeline.yaml').write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
(base/'pipeline-authentication.yaml').write_text(yaml.safe_dump({'agent':raw['agent'],'paths':{'style':str(style)}},allow_unicode=True,sort_keys=False),encoding='utf-8')
cfg=load(base/'current-pipeline.yaml');model=KnowledgeModel.load(cfg.facts_path)
before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in cfg.sdd_dir.glob('*.md')}
impact=ImpactReport(base=model.meta['source_commit'],head=model.meta['source_commit'],sections={'pipeline-handler':['Use current Codex/Terra High and current writing policy, restore independently identified source conditions and add one source-bound figure per regenerated topic.']})
impact.save(root/'editorial-impact-current.json')
Generator(cfg,model,Agent(cfg.agent,cfg.build_dir/'prompts')).run(['pipeline-handler'],impact)
changed=[p.name for p in cfg.sdd_dir.glob('*.md') if before[p.name]!=hashlib.sha256(p.read_bytes()).hexdigest()]
assert changed==['pipeline-handler.md'],changed
meta=split_frontmatter((cfg.sdd_dir/'pipeline-handler.md').read_text(encoding='utf-8'))[0]
(root/'reentry-correction.json').write_text(json.dumps({'changed_manuscripts':changed,'other_manuscripts_preserved':len(before)-1,
 'scope':'All four topics regenerated because the historical writer was Claude and the selected current writer is Codex; not a one-part reuse result.',
 'style':'Current repository writing policy, copied and hash-bound for this page only; historical profiles of other pages retained.',
 'source_commit':model.meta['source_commit'],'generated_visuals':list(meta.get('generated_visuals',{}).get('records',{})),
 'human_approval':'not granted'},ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS four-topic native regeneration, source-bound figures and 28 other manuscripts preserved',flush=True)
