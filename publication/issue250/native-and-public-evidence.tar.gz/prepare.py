from pathlib import Path
import hashlib, json, shutil, yaml
from sdd.config import load
from sdd.export_site import export_site
from sdd.site_build import verify_site
from sdd.localization_cli import prepare_catalog

root=Path(__file__).resolve().parent
repo=root.parent.parent
original=Path('C:/Users/baboe/.codex/worktrees/cb18/camera-hal-sdd-generator/build/issue211-virtual/current-main-integration')
base=root/'baseline'
if not base.exists():
    shutil.copytree(original,base)
raw=yaml.safe_load((original/'publication.yaml').read_text(encoding='utf-8'))
def relocate(value):
    if isinstance(value,str): return value.replace(str(original),str(base))
    if isinstance(value,list): return [relocate(v) for v in value]
    if isinstance(value,dict): return {k:relocate(v) for k,v in value.items()}
    return value
raw=relocate(raw)
for profile in base.glob('*.yaml'):
    value=yaml.safe_load(profile.read_text(encoding='utf-8'))
    profile.write_text(yaml.safe_dump(relocate(value),allow_unicode=True,sort_keys=False),encoding='utf-8')
raw['site'].update(reader_paths=str(repo/'examples/libcamera/reader-paths.yaml'),title='libcamera 설계 문서')
catalog=base/'run/english.json'
if not (root/'translation-started').exists():
    shutil.copyfile(root/'public/publication/diagram-pan/english.json',catalog)
profile={'agent':{'kind':'cli','runner':'codex','model':'gpt-6.1-terra',
    'args':['-c','model_reasoning_effort="high"'],'command':[],
    'max_input_chars':128000,'timeout_sec':600,'full_style_guides':True}}
(base/'translation-agent.yaml').write_text(yaml.safe_dump(profile),encoding='utf-8')
raw['paths']['translation_profile']=str(base/'translation-agent.yaml')
(base/'publication.yaml').write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
cfg=load(base/'publication.yaml')
public=json.loads((root/'public/docs/site-manifest.json').read_bytes())
assert hashlib.sha256(cfg.facts_path.read_bytes()).hexdigest()==public['inputs']['facts']
assert all(hashlib.sha256((cfg.sdd_dir/name[9:]).read_bytes()).hexdigest()==sha for name,sha in public['inputs'].items() if name.startswith('markdown/'))
prepare_catalog(cfg,catalog)
(root/'translation-started').write_text('native translation required',encoding='utf-8')
print('PASS exact canonical baseline; catalog prepared; missing',sum(not v for v in json.loads(catalog.read_bytes())['strings'].values()),flush=True)
prepare_catalog(cfg,catalog,translate=True)
site=export_site(cfg,root/'site')
(root/'site-verification.json').write_text(json.dumps(verify_site(site),indent=2),encoding='utf-8')
print('PASS bilingual role paths rendered')
