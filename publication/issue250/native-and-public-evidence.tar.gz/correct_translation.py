from pathlib import Path
from dataclasses import replace
import json,shutil
from sdd.config import load
from sdd.llm import Agent
from sdd.generation_run import Execution
from sdd.translation import _batch_system,_batch_schema,_payload,_retry_feedback,_batch_values,_validate_text
from sdd.translation_checkpoint import TranslationCall
root=Path(__file__).resolve().parent
publication=load(root/'baseline/publication.yaml')
cfg=replace(publication,agent=load(root/'baseline/translation-agent.yaml').agent)
path=Path(cfg.site.english_catalog)
catalog=json.loads(path.read_bytes())
shutil.copyfile(path,root/'english-before-semantic-correction.json')
findings=json.loads((root/'bilingual-review.json').read_bytes())['findings']
stream_sources=[source for source,value in catalog['strings'].items() if 'parameter set connected to a stream' in value]
assert len(stream_sources)==1,stream_sources
findings.append({'source':stream_sources[0],'problem':'The Korean associates streams with the buffer set and separately identifies a parameter set. The English must not attach connected to a stream to the parameter set. Preserve the implementer obligation, return values and call thread.'})
changes=[]
for index,finding in enumerate(findings):
    source=finding['source'];before=catalog['strings'][source]
    pending={'0':source}
    system=_batch_system(catalog['strings'])
    user=_payload(catalog,pending)+_retry_feedback(finding['problem'],batch=True)
    schema=_batch_schema(pending)
    error=''
    for attempt in range(3):
        agent=Execution(cfg,Agent(cfg.agent,cfg.build_dir/'translation-prompts'))
        with agent.track('translation'),agent.document('translation',{source:''}):
            agent.units({source:'pending'})
            prompt=user+_retry_feedback(error,batch=True) if error else user
            call=TranslationCall(cfg,agent,system,prompt,schema,fresh=True,units=[source])
            raw=call.chat(f'issue250_semantic_translation_correction_{index}_{attempt}')
            try:
                translated=_validate_text(source,_batch_values(raw,pending)['0'])
            except ValueError as exc:
                error=str(exc);print('Rejected CLI correction',index,attempt,error,flush=True)
                continue
            call.validated({'0':translated})
            break
    else:raise ValueError('Selected CLI correction still invalid: '+error)
    catalog['strings'][source]=translated
    changes.append({'source':source,'before':before,'after':translated})
path.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(root/'bilingual-correction.json').write_text(json.dumps({'changes':changes,
 'method':'fresh selected Codex CLI/Terra High TranslationCall with independent review feedback; no manual replacement'},ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS fresh semantic translation corrections',len(changes),flush=True)
