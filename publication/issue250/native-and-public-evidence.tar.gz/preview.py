from pathlib import Path
from sdd.config import load
from sdd.export_site import _render_site
from sdd.site_build import build_site
import json
root=Path(__file__).resolve().parent
cfg=load(root/'baseline/publication.yaml')
cfg.raw['site'].pop('english_catalog',None)
def render(cfg,out,mermaid):
    result=_render_site(cfg,out,mermaid,check_consistency=False)
    (out/'contract-consistency.json').write_text(json.dumps({'status':'incomplete','human_review':'pending','scope':'PRIVATE role reading preview; not for publication'}),encoding='utf-8')
    return result
build_site(cfg,root/'preview',render,None)
print('PRIVATE preview only; consistency pending; not a public release')
