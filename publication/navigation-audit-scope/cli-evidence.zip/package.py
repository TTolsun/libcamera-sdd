from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
from sdd.site_build import verify_site
root=Path(__file__).resolve().parent;repo=root.parents[1];work=root/'workspace';old=repo/'build/queue-cancelled-exception/workspace';public=repo/'build/issue194/publication';pkg=public/'publication/navigation-audit-scope';pkg.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
manifest=public/'docs/site-manifest.json';m=json.loads(manifest.read_bytes());assert manifest.read_bytes()==(root/'first-manifest.json').read_bytes();checks=verify_site(public/'docs')
pins=json.loads((root/'baseline/manuscript-hashes.json').read_bytes());assert all(sha(work/'manuscripts'/n)==v for n,v in pins.items());assert sha(work/'english.json')==sha(old/'english.json');assert sha(work/'facts/facts.json')==sha(old/'facts/facts.json')
audit=json.loads((work/'build/consistency-review.json').read_bytes());assert audit['status']=='passed';assert not any(f['status']=='contradiction' for c in audit['contracts'] for f in c['findings'])
assert not any('scenarios/queue_request.md/paragraph/28' in c['claims'] for c in audit['contracts'])
nav=[r for c in audit['contracts'] for r in c['excluded_navigation'] if r['document']=='scenarios/queue_request.md'];assert nav and all(r['target_sha256']==sha(work/'manuscripts'/r['target']) for r in nav)
for name in ('preflight.json','scope-investigation.json','approval-state.json','browser-validation.json'):shutil.copy2(root/name,pkg/name)
shutil.copy2(root/'baseline/consistency-review.json',pkg/'previous-consistency-review.json')
if not (pkg/'previous-run.json').exists():shutil.copy2(public/'run.json',pkg/'previous-run.json')
shutil.copytree(work/'config',pkg/'config',dirs_exist_ok=True);(pkg/'profiles').mkdir(exist_ok=True)
for n in ('sdd.yaml','sdd.review.yaml','sdd.render.yaml'):shutil.copy2(work/n,pkg/'profiles'/n)
shutil.copy2(work/'english.json',pkg/'english.json');shutil.copy2(work/'site-intro.md',pkg/'site-intro.md')
write(pkg/'input-preservation.json',dict(schema=1,all_manuscripts_byte_identical=True,manuscript_hashes=pins,english_catalog_sha256=sha(work/'english.json'),facts_sha256=sha(work/'facts/facts.json'),manuscript_generation_performed=False,translation_performed=False,approval_state=json.loads((root/'approval-state.json').read_bytes()),callback_runtime_validation='not-run',internal_hal_validation='not-run'))
write(pkg/'facts-reference.json',dict(schema=1,facts_sha256=sha(work/'facts/facts.json'),archive='../callback-observation/structural-facts.zip',record='../callback-observation/structural-facts.json',retained_byte_identical=True,new_extraction_performed=False))
files=[p for p in (work/'build').rglob('*') if p.is_file()]+[p for p in (root/'preflight').rglob('*') if p.is_file()]+[p for p in root.glob('*.log') if not p.name.startswith(('server','package'))]+list(root.glob('*.py'))+[root/'claude-help.txt'];index={};receipts=[];historical=0
with zipfile.ZipFile(pkg/'cli-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files):
  n=p.relative_to(root).as_posix();assert not any(t in p.name.lower() for t in ('credentials','auth.json','.env'));z.write(p,n);index[n]=dict(sha256=sha(p),bytes=p.stat().st_size)
  if p.name.endswith('.receipt.json'):
   d=json.loads(p.read_bytes());assert d['model'] in ('claude-haiku-5-5','gpt-6.1-terra');args=d['provider']['arguments']
   if d['model']=='claude-haiku-5-5':assert args[args.index('--effort')+1]=='high' and set(d['provider']['provider']['modelUsage'])=={'claude-haiku-5-5'}
   else:assert 'model_reasoning_effort="high"' in args
   previous=old/p.relative_to(work) if p.is_relative_to(work) else None
   if previous and previous.exists() and sha(previous)==sha(p):historical+=1
   else:receipts.append(dict(path=n,sha256=sha(p),tag=d['tag'],runner=d['provider']['runner'],model=d['model']))
write(pkg/'cli-evidence-index.json',dict(schema=1,archive_sha256=sha(pkg/'cli-evidence.zip'),files=index));write(pkg/'new-receipts.json',dict(schema=1,new_receipts=receipts,retained_historical_receipts=historical,authoring_calls=0,translation_calls=0,author_preflight_calls=1,human_review='pending'))
generator=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();source=json.loads((root/'scope-investigation.json').read_bytes())['source_commit'];original=json.loads((pkg/'previous-run.json').read_bytes())
run=dict(schema=1,source_repository=original['source_repository'],source_commit=source,generator_repository=original['generator_repository'],generator_behavior_commit=generator,generator_pr=207,build_id=m['build_id'],manifest_sha256=sha(manifest),manifest_outputs=len(m['outputs']),facts_sha256=sha(work/'facts/facts.json'),english_catalog_sha256=sha(work/'english.json'),author_profile=dict(kind='cli',runner='claude',model='claude-haiku-5-5',args=['--effort','high','--setting-sources','project,local']),independent_review_profile=dict(kind='cli',runner='codex',model='gpt-6.1-terra',args=['-c','model_reasoning_effort="high"']),manuscript_generation_performed=False,translation_performed=False,facts_extraction_performed=False,reason='Official upstream unchanged; all document/catalog/facts bytes preserved. Corrected automatic audit scope and freshly reviewed current runtime/analysis claims.',validation=checks,repeat_build_identical=True,automatic_unresolved=len(audit['unresolved']),human_review='pending',callback_runtime_validation='not-run',internal_hal_validation='not-run',evidence='publication/navigation-audit-scope/README.md',post_deployment='Actual Pages and public hash verification are recorded in the release PR after merge.')
write(public/'run.json',run);write(pkg/'build-validation.json',dict(build_id=m['build_id'],manifest_sha256=sha(manifest),repeat_identical=True,**checks));(pkg/'.gitattributes').write_text('** -text whitespace=cr-at-eol\n',encoding='utf-8')
(pkg/'README.md').write_text(f'''# Generated navigation and contract-review scope

The remaining finding was a review-scope problem, not a manuscript defect. The final next-step
link in the request-queue scenario names the completeRequest document; it does not assert an
execution order or completion guarantee. Its target exists with the expected title and same
source commit. [Investigation](scope-investigation.json) preserves the exact link/target hash,
and the [previous report](previous-consistency-review.json) preserves the original native
insufficient-evidence finding unchanged. No old verdict was relabelled compatible.

Generator [PR207](https://github.com/TTolsun/camera-hal-sdd-generator/pull/207), commit `{generator}`,
recognizes only the exact final default-template link selected by current section/scenario
configuration and a matching current local Markdown document title. It records these links in
excluded_navigation with target hashes. Missing/stale targets fail before model review. Mixed
prose, custom hints/templates, nonterminal links, fenced examples, fragment links and generated
LLM answers remain in the ordinary claim path. Publication enforcement recomputes the scope
records and rejects tampering. Final HTML link/anchor checks remain with verify-site.
This is deterministic navigation integrity, not a model/runtime verdict or human approval.

The [current report](../../docs/contract-consistency.json) freshly reviews the retained runtime
and analysis claims through independent Codex `gpt-6.1-terra`,
`-c model_reasoning_effort="high"`. It has no contradiction and {len(audit['unresolved'])} automatic
unresolved findings in its configured scope. Every previous report and native receipt remains
preserved. A DIFFERENT English stop/completion-condition claim (catalog/298a01caad3d54f6/en)
remains automatically ambiguous and stays in runtime review; the scope fix does not suppress
this uncertainty or force a zero count. See scope-investigation.json for the exact current finding. This is not an exhaustive all-pairs proof or hardware/callback verification.

All manuscript, English-catalog and source-facts bytes are unchanged; see
[input preservation](input-preservation.json). There was no new prose generation, translation,
manual manuscript correction or fresh structural extraction. Official libcamera HEAD remains
`{source}`; the exact previous Meson/Ninja/libclang snapshot remains authenticated through
[facts reference](facts-reference.json). Source excerpts and document links remain intact.
The generation profile remains independent Claude Code 2.1.314, exact `claude-haiku-5-5`,
`--effort high --setting-sources project,local`; [native preflight](preflight.json) confirms actual
modelUsage and high support. Global defaults are unchanged. No alternate model/CLI, direct API,
saved response or manual prose substituted for new generation or review.
[Profiles](profiles/), [new receipts](new-receipts.json), [native archive](cli-evidence.zip) and
[hash index](cli-evidence-index.json) distinguish fresh review/preflight calls from retained history.

The [effective human approval state](approval-state.json) is unchanged: both inputs have no
approval ledger or accepted entries; no accept command ran. The callback investigation plan is
byte-identical and actual callback execution/internal HAL validation remain not-run.
[Build validation](build-validation.json) records 60 HTML pages, 257 owned outputs, zero broken
links and identical repeated manifests. [Browser checks](browser-validation.json) verify the
request-queue navigation in both languages. No generated HTML was edited manually.
Post-merge Pages and public manifest/all-output hash checks are recorded in the release PR.
''',encoding='utf-8',newline='\n')
p=public/'README.md';lines=p.read_text(encoding='utf-8').splitlines();lines[2]=f'Current release: [navigation audit scope](publication/navigation-audit-scope/README.md), generator [PR207](https://github.com/TTolsun/camera-hal-sdd-generator/pull/207), build `{m["build_id"]}`, official public libcamera `{source}`. [Korean and English site](https://ttolsun.github.io/libcamera-sdd/). Manuscripts and human approval state are preserved; actual callback execution remains unverified.';p.write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n');print(json.dumps(dict(**run,new_receipts=len(receipts),historical_receipts=historical,archive_files=len(index)),ensure_ascii=False))
