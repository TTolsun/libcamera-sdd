from pathlib import Path
import hashlib
import json
import subprocess

from sdd.config import load
from sdd.document_metadata import split_frontmatter

r = Path(__file__).resolve().parent
cfg = load(r / 'base/publication.yaml')
public = r.parent / 'issue250/public'
baseline = json.loads((r / 'baseline-consistency.json').read_bytes())
audit = json.loads((cfg.build_dir / 'consistency-review.json').read_bytes())
assert audit['status'] == 'passed' and audit['human_review'] == 'pending'
targets = json.loads((r / 'targets.json').read_bytes())
targets.append(dict(section='pipeline-requests', topic='completion', part='cancel'))
assert len(targets) == 10
docs = {x['section'] + '.md' for x in targets}
changed = set()
retained = 0
for p in cfg.sdd_dir.rglob('*.md'):
    rel = p.relative_to(cfg.sdd_dir).as_posix()
    before = subprocess.check_output(['git', '-C', str(public), 'show', 'HEAD:docs/' + rel])
    raw = p.read_bytes()
    if rel not in docs:
        assert before.replace(b'\r\n', b'\n') == raw.replace(b'\r\n', b'\n'), rel
        continue
    sid = p.stem
    old, _ = split_frontmatter(before.decode('utf-8').replace('\r\n', '\n'))
    new, _ = split_frontmatter(p.read_text(encoding='utf-8'))
    old_answers, new_answers = old['generated_design']['answers'], new['generated_design']['answers']
    assert old_answers.keys() == new_answers.keys()
    for topic, rows in old_answers.items():
        assert len(rows) == len(new_answers[topic])
        for previous, current in zip(rows, new_answers[topic]):
            assert previous.get('part_id') == current.get('part_id')
            if previous == current:
                retained += 1
            else:
                changed.add((sid, topic, current.get('part_id')))
assert changed == {(x['section'], x['topic'], x['part']) for x in targets}, changed

original_cases = [(x['contract'], x['claim_id']) for x in baseline['unresolved']]
assert len(original_cases) == 4
evidence = json.loads(cfg.facts_path.read_bytes())['evidence']
sources = {k: {field: evidence[k][field] for field in ('file', 'line', 'end_line', 'sha256')}
           for k in ('camera-requests/request/queue-code',
                     'request-diagnosis/configuration-failure/validation-check',
                     'pipeline-requests/completion/buffer-contract',
                     'pipeline-requests/completion/request-contract',
                     'pipeline-requests/completion/cancel-contract',
                     'pipeline-requests/completion/pending-cancel-code')}
results = []
for group, previous_id in original_cases:
    if previous_id.startswith('catalog/9d141e4b7ca20344'):
        doc, lang = 'camera-requests.md', 'en' if previous_id.endswith('/en') else 'ko'
        kind = 'queue'
    elif previous_id == 'catalog/948d857e662479be/en':
        doc, lang, kind = 'request-diagnosis.md', 'en', 'plan'
    else:
        doc, lang, kind = 'pipeline-requests.md', 'ko', 'completion'
    selected = []
    for contract in audit['contracts']:
        for row in contract['findings']:
            claim = contract['claims'][row['claim_id']]
            if claim.get('document') != doc or claim.get('language') != lang:
                continue
            text = claim['text']
            include = ((kind == 'queue' and '-EINVAL' in text and ('activeStreams_' in text or 'buffers' in text))
                       or (kind == 'plan' and 'validate' in text and '-EINVAL' in text and
                           'limitation' in claim.get('statement_kinds', []))
                       or (kind == 'completion' and 'completeBuffer' in text and 'completeRequest' in text and
                           'CameraManager' in text))
            if include:
                selected.append(dict(contract=contract['id'], id=row['claim_id'], status=row['status'],
                                     text=text, evidence=claim.get('evidence'), reason=row['reason']))
    assert selected and all(row['status'] == 'compatible' for row in selected), previous_id
    results.append(dict(original_contract=group, original_id=previous_id, witness_kind=kind, current_witnesses=selected))

data = dict(source_commit=audit['source_commit'], original_unresolved=4, current_unresolved=len(audit['unresolved']),
            current_unresolved_entries=audit['unresolved'], fresh_batches=audit['fresh_batches'],
            revalidated_previous_batches=audit['reused_batches'], selected_units=targets,
            exact_retained_answer_rows=retained, canonical_manuscripts_changed=sorted(docs),
            other_canonical_manuscripts_verified=True, current_witnesses=results, sources=sources,
            human_review='pending', actual_executive_evaluation='unverified', internal_HAL='unverified')
(r / 'resolution.json').write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
print('Original/current unresolved', 4, len(audit['unresolved']), 'retained answers', retained,
      'current witness counts', [len(row['current_witnesses']) for row in results])
