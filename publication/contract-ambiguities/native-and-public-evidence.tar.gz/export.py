from pathlib import Path
import hashlib
import json
import yaml
from sdd.config import load
from sdd.export_site import export_site
from sdd.site_build import verify_site

r = Path(__file__).resolve().parent
config = r / 'base/publication.yaml'
public = r.parent / 'issue250/public'
assert (public / 'docs/site-manifest.json').read_bytes() == (r / 'baseline-site-manifest.json').read_bytes()
report = r / 'base/build/consistency-review.json'
review = json.loads(report.read_bytes())
assert review['status'] == 'passed' and review['human_review'] == 'pending'
settings = yaml.safe_load(config.read_bytes())
for row in settings['publication']['reports']:
    if row['producer'] == 'independent-selected-cli-standard-audit':
        assert Path(row['path']) == report
        row['sha256'] = hashlib.sha256(report.read_bytes()).hexdigest()
config.write_text(yaml.safe_dump(settings, allow_unicode=True, sort_keys=False), encoding='utf-8')
cfg = load(config)
site = export_site(cfg, r / 'site')
before = (site / 'site-manifest.json').read_bytes()
export_site(cfg, site)
assert before == (site / 'site-manifest.json').read_bytes()
manifest = json.loads(before)
result = dict(site=verify_site(site), build_id=manifest['build_id'], outputs=len(manifest['outputs']),
              repeat_manifest_identical=True, unresolved=len(review['unresolved']), actual_human=False,
              actual_executive=False, internal_HAL='unverified')
(r / 'site-verification.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(result, flush=True)
