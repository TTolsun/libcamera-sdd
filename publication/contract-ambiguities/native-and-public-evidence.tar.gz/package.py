from pathlib import Path
import gzip
import hashlib
import json
import shutil
import tarfile

from sdd.config import load

r = Path(__file__).resolve().parent
proof = r / 'release-evidence'
proof.mkdir(exist_ok=True)
cfg = load(r / 'base/publication.yaml')
manifest = json.loads((r / 'site/site-manifest.json').read_bytes())
for role in ('work', 'decision'):
    data = json.loads((r / f'evaluation-{role}.json').read_bytes())
    assert data['evaluator_type'] == 'agent_proxy'
    assert data['actual_human'] is False and data['actual_executive'] is False
    build = data['build_identity']
    assert build['before'] == build['after'] == build['expected'] == manifest['build_id']

native = json.loads((r / 'native-verification.json').read_bytes())
assert len(native['selected_units']) == 10
files = {r / p for p in native['evidence_files']}
original_index = json.loads((r.parent / 'issue250/public/publication/issue253-reader-followup/archive-index.json').read_bytes())
for folder in (r / 'base/build/prompts/cli', r / 'base/build/translation-prompts/cli',
               r / 'cancel-window/build/prompts/cli', r / 'cancel-window/build/translation-prompts/cli',
               r / 'native-repair-01/prompts/cli'):
    for p in folder.rglob('*'):
        if p.is_file():
            relative = p.relative_to(r).as_posix()
            historical = original_index.get('run-05/' + relative.removeprefix('base/')) if relative.startswith('base/') else None
            if historical is None or hashlib.sha256(p.read_bytes()).hexdigest() != historical['sha256']:
                files.add(p)
for glob in ('*.py', '*.cjs', '*.json', '*.yaml', '*.log', '*.md'):
    files.update(p for p in r.glob(glob) if p.is_file())
for pattern in ('native-repair-*/*.md', 'native-repair-*/*.json', 'cancel-window/*.yaml',
                'cancel-window/*.json', 'cancel-window/*.log', 'cancel-window/native/*.json',
                'cancel-window/figure-assembly/*.json', 'browser-*-preview/*.json', 'browser-*-preview/*.png'):
    files.update(p for p in r.glob(pattern) if p.is_file())
for p in cfg.sdd_dir.rglob('*'):
    if p.is_file():
        files.add(p)
for folder in (r / 'base/profiles', r / 'base/historical-prerequisites'):
    files.update(p for p in folder.rglob('*') if p.is_file())
files.update([r / 'base/publication.yaml', r / 'base/review.yaml', r / 'base/translation.yaml',
              r / 'base/config/sections.yaml', r / 'base/config/visuals.yaml',
              r / 'base/config/contracts.yaml', r / 'base/reader-paths.yaml',
              Path(cfg.site.english_catalog), cfg.build_dir / 'consistency-review.json',
              r / 'site/site-manifest.json'])
for folder in (r / 'base/build/generation-runs', r / 'cancel-window/build/generation-runs'):
    for p in folder.glob('*.json'):
        data = json.loads(p.read_bytes())
        if str(data.get('operation_id', '')).startswith('public-contract-ambiguities'):
            files.add(p)
for folder in (r / 'base/build/cli-checkpoints', r / 'cancel-window/build/cli-checkpoints'):
    for p in folder.glob('*.json'):
        relative = p.relative_to(r).as_posix()
        historical = original_index.get('run-05/' + relative.removeprefix('base/')) if relative.startswith('base/') else None
        if historical is None or hashlib.sha256(p.read_bytes()).hexdigest() != historical['sha256']:
            files.add(p)
for name in ('site-verification.json', 'resolution.json', 'evaluation-plan.json',
             'evaluation-work.json', 'evaluation-decision.json', 'consistency-review.json'):
    p = r / 'before-merged-generator' / name
    if p.is_file():
        files.add(p)
prior_manifest = r / 'before-merged-generator/site/site-manifest.json'
if prior_manifest.is_file():
    files.add(prior_manifest)
for folder in (r / 'merged-audit-groups').iterdir() if (r / 'merged-audit-groups').is_dir() else ():
    files.update(p for p in folder.glob('*.yaml') if p.is_file())
    files.update(p for p in folder.glob('*.log') if p.is_file())
    files.update(p for p in (folder / 'build/generation-runs').glob('*.json') if p.is_file())
    report = folder / 'build/consistency-review.json'
    if report.is_file():
        files.add(report)
with gzip.open(r / 'facts.json.gz', 'wb') as f:
    f.write(cfg.facts_path.read_bytes())
files.add(r / 'facts.json.gz')
source_recipe = r / 'repair_units.py'
shutil.copyfile(Path('examples/libcamera/validation/contract-uncertainties/repair_units.py'), source_recipe)
files.add(source_recipe)
archive = proof / 'native-and-public-evidence.tar.gz'
index = {}
with tarfile.open(archive, 'w:gz') as out:
    for p in sorted(files):
        assert p.is_file() and not p.is_symlink(), p
        name = p.relative_to(r).as_posix()
        out.add(p, arcname=name, recursive=False)
        index[name] = hashlib.sha256(p.read_bytes()).hexdigest()
with tarfile.open(archive) as inp:
    assert len(inp.getmembers()) == len(index)
    for name, digest in index.items():
        assert hashlib.sha256(inp.extractfile(name).read()).hexdigest() == digest
(proof / 'archive-index.json').write_text(json.dumps(index, indent=2), encoding='utf-8')
for name in ('resolution.json', 'evaluation-plan.json', 'evaluation-work.json', 'evaluation-decision.json',
             'site-verification.json', 'native-verification.json', 'upstream-scope.json', 'figure-evidence.json',
             'publication-review-corrected.json', 'figure-review-context.json', 'per-item-contracts.json',
             'merged-build-comparison.json', 'merged-generator-ci.json', 'git-staged-output-verification.json'):
    shutil.copyfile(r / name, proof / name)
for role in ('role', 'contract'):
    shutil.copyfile(r / f'browser-{role}-preview/summary.json', proof / f'browser-{role}.json')
(proof / 'package.json').write_text(json.dumps(dict(
    schema=1, build_id=manifest['build_id'], archive=archive.name,
    archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), entries=len(index),
    public_source_only=True, actual_human=False, actual_executive=False, internal_HAL='unverified'), indent=2),
    encoding='utf-8')
print('Verified evidence archive', len(index), 'files', archive.stat().st_size, 'bytes')
