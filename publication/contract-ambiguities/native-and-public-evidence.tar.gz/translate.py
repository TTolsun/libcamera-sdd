from pathlib import Path
import json
import sys
from sdd.config import load
from sdd.localization_cli import prepare_catalog

r = Path(__file__).resolve().parent
config_path = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else r / 'base/publication.yaml'
cfg = load(config_path)
profile = load(cfg.paths['translation_profile'])
assert profile.agent.kind == 'cli' and profile.agent.runner == 'codex'
assert profile.agent.model == 'gpt-6.1-terra'
assert 'model_reasoning_effort="high"' in profile.agent.args
print('Actual translation profile', profile.agent.runner, profile.agent.command,
      profile.agent.model, profile.agent.args, flush=True)
result = prepare_catalog(cfg, Path(cfg.site.english_catalog), translate=True)
result_path = (config_path.parent if len(sys.argv) > 1 else r) / 'translation-result.json'
result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(result, flush=True)
