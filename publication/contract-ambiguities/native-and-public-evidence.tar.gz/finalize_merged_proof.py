from pathlib import Path
import datetime
import json

r = Path(__file__).resolve().parent
old = r / 'before-merged-generator'
previous = json.loads((old / 'site/site-manifest.json').read_bytes())
current = json.loads((r / 'site/site-manifest.json').read_bytes())
report = json.loads((r / 'base/build/consistency-review.json').read_bytes())
assert report['status'] == 'passed' and 'audit_run' in report
groups = json.loads((r / 'merged-group-audits.json').read_bytes())
all_batches = report['fresh_batches'] + report['reused_batches']
delta = {name: [previous['outputs'].get(name), current['outputs'].get(name)]
         for name in sorted(previous['outputs'].keys() | current['outputs'].keys())
         if previous['outputs'].get(name) != current['outputs'].get(name)}
result = dict(prior_build=previous['build_id'], current_build=current['build_id'],
              changed_outputs=delta, identical_output_count=len(current['outputs']) - len(delta),
              final_audit_run=report['audit_run'], final_fresh_batches=report['fresh_batches'],
              final_reused_batches=report['reused_batches'],
              independent_group_fresh_batches=sum(x['fresh'] for x in groups),
              current_unresolved=len(report['unresolved']))
(r / 'merged-build-comparison.json').write_text(json.dumps(result, indent=2), encoding='utf-8')

plan = r / 'evaluation-plan.json'
data = json.loads(plan.read_bytes())
data.update(frozen_build=current['build_id'], registered_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            prior_evaluated_build=previous['build_id'],
            repeat_reason='Concurrent merged contract policy; final audit and manifest changed.')
plan.write_text(json.dumps(data, indent=2), encoding='utf-8')

items = r / 'per-item-contracts.json'
data = json.loads(items.read_bytes())
assert all(figure in current['outputs'] for item in data['items'] for figure in item['figures'])
data['build_id'] = current['build_id']
items.write_text(json.dumps(data, indent=2), encoding='utf-8')

readme = r / 'release-evidence/README.md'
text = readme.read_text(encoding='utf-8').replace(previous['build_id'], current['build_id'])
text += ('\n생성기 PR #286은 `29317f421da5b4b5674bccee54b4121127505731`로 병합됐습니다. '
         '동시 반영된 #284와 #287의 검사 정책을 적용해 계약 그룹별로 실제 독립 CLI 검토를 수행했습니다. '
         f'병합 정책의 최종 표준 감사에서 {all_batches}개 배치를 확인했습니다. '
         f'최종 전체 실행의 새 호출은 {report["fresh_batches"]}개이며, '
         f'원본 영수증을 재검증한 배치는 {report["reused_batches"]}개입니다. '
         f'현재 보고서의 자동 미판정은 {len(report["unresolved"])}건입니다. '
         '병합 전 평가와 병합 후 평가, 각 그룹의 원본 실행 및 최종 실행 장부를 보관합니다.\n')
readme.write_text(text, encoding='utf-8')
print('Merged build', current['build_id'], 'changed outputs', list(delta), 'unresolved', len(report['unresolved']))
