from pathlib import Path
import copy
import json
import shutil
import sys

import yaml
from sdd.cli_checkpoint import UnitStore
from sdd.config import load
from sdd.consistency import policy_hash
from sdd.execution_lock import alive

r = Path(__file__).resolve().parent
base = load(r / 'base/publication.yaml')
root = r / 'merged-audit-groups'

def current_checkpoints(cfg):
    for path in (cfg.build_dir / 'cli-checkpoints').glob('*.json'):
        payload = json.loads(path.read_bytes())['payload']
        identity = payload['identity']
        if identity.get('purpose') == 'cross-document-consistency' and identity.get('policy') == policy_hash():
            store = UnitStore(cfg, identity)
            saved, _ = store.read()
            assert store.path == path
            yield path, saved

def copy_verified(source, dest):
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        assert source.read_bytes() == dest.read_bytes(), str(dest)
    else:
        shutil.copyfile(source, dest)

def transfer(source, dest):
    for checkpoint, saved in current_checkpoints(source):
        origin = source.build_dir / 'prompts'
        target = dest.build_dir / 'prompts'
        for name in saved['receipts']:
            receipt = origin / 'calls' / name
            raw = json.loads(receipt.read_bytes())
            stem = receipt.name.removesuffix('.receipt.json')
            for suffix in ('.receipt.json', '.request.json', '.response.txt'):
                p = receipt.with_name(stem + suffix)
                copy_verified(p, target / p.relative_to(origin))
            for key in ('stdout_path', 'stderr_path'):
                if value := raw['provider'].get(key):
                    p = origin / value
                    if p.exists():
                        copy_verified(p, target / value)
        copy_verified(checkpoint, dest.build_dir / 'cli-checkpoints' / checkpoint.name)

def require_idle(cfg):
    path = cfg.build_dir / 'execution-locks/consistency.json'
    if path.is_file():
        state = json.loads(path.read_bytes())
        assert state['status'] != 'running' or not any(alive(state.get(key)) for key in ('owner_pid', 'worker_pid')), state

if sys.argv[1] == 'prepare':
    require_idle(base)
    root.mkdir(exist_ok=False)
    raw = yaml.safe_load((r / 'base/publication.yaml').read_bytes())
    contracts = yaml.safe_load(base.paths['consistency_file'].read_bytes())
    for group in contracts['contracts']:
        folder = root / group['id']
        folder.mkdir()
        contract = folder / 'contracts.yaml'
        contract.write_text(yaml.safe_dump({'contracts': [group]}, allow_unicode=True, sort_keys=False), encoding='utf-8')
        settings = copy.deepcopy(raw)
        settings['paths']['consistency_file'] = str(contract)
        settings['publication']['operation_id'] = 'public-contract-ambiguities-merged-' + group['id']
        profile = folder / 'audit.yaml'
        profile.write_text(yaml.safe_dump(settings, allow_unicode=True, sort_keys=False), encoding='utf-8')
        cfg = load(profile)
        transfer(base, cfg)
    print('Prepared isolated normal audits:', ', '.join(p.name for p in root.iterdir()))
else:
    require_idle(base)
    rows = []
    for folder in sorted(root.iterdir()):
        source = load(folder / 'audit.yaml')
        require_idle(source)
        report = json.loads((source.build_dir / 'consistency-review.json').read_bytes())
        assert 'audit_run' in report and report['status'] in ('passed', 'failed')
        transfer(source, base)
        rows.append(dict(group=folder.name, status=report['status'], fresh=report['fresh_batches'],
                         reused=report['reused_batches'], unresolved=len(report['unresolved']), audit_run=report['audit_run']))
    (r / 'merged-group-audits.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    print('Transferred actual verified checkpoints and original native receipts from', len(rows), 'groups')
