from pathlib import Path
import hashlib
import json

from sdd.cli_provenance import verify_cli_receipt
from sdd.config import load
from sdd.document_metadata import split_frontmatter

r = Path(__file__).resolve().parent
cfg = load(r / 'base/publication.yaml')
archive = r.parent / 'issue250/public/publication/issue253-reader-followup/archive-index.json'
imported = {row['sha256'] for name, row in json.loads(archive.read_bytes()).items()
            if name.endswith('.receipt.json')}
roots = [r / 'base/build/prompts', r / 'base/build/translation-prompts',
         r / 'cancel-window/build/prompts', r / 'cancel-window/build/translation-prompts',
         r / 'native-repair-01/prompts']
roots += [p for p in r.iterdir() if (p / 'calls').is_dir()]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

records = {}
files = set()

def receipt(path):
    digest = sha(path)
    if digest in records:
        return digest
    stem = path.name.removesuffix('.receipt.json')
    request_path = path.with_name(stem + '.request.json')
    response_path = path.with_name(stem + '.response.txt')
    metadata = json.loads(path.read_bytes())
    verification = verify_cli_receipt(json.loads(request_path.read_bytes()),
                                      response_path.read_text(encoding='utf-8'), metadata,
                                      path.parent.parent, cfg.agent)
    records[digest] = dict(path=path.relative_to(r).as_posix(), tag=metadata['tag'],
                           origin='imported' if digest in imported else 'this-work', verification=verification)
    files.update((path, request_path, response_path))
    for name in ('stdout_path', 'stderr_path'):
        if value := metadata['provider'].get(name):
            p = path.parent.parent.parent / value
            if p.is_file():
                files.add(p)
    return digest

for root in roots:
    for path in (root / 'calls').rglob('*.receipt.json'):
        if sha(path) not in imported:
            receipt(path)

selected = []
for sid in ('camera-requests', 'pipeline-requests', 'request-diagnosis'):
    meta, _ = split_frontmatter((cfg.sdd_dir / (sid + '.md')).read_text(encoding='utf-8'))
    artifact = meta['generated_design']
    seen = set()
    revision = artifact.get('partial_revision')
    while revision:
        for row in revision.get('changed_units', []):
            key = row['topic'], row['part']
            if key in seen or 'verified_checkpoint' not in row:
                continue
            seen.add(key)
            path = Path(row['verified_checkpoint'])
            assert sha(path) == row['checkpoint_sha256']
            payload = json.loads(path.read_bytes())['payload']
            answer = next(a for a in artifact['answers'][key[0]] if a.get('part_id') == key[1])
            assert payload['statements'] == [answer]
            assert payload['receipts'] == row['native_receipts']
            assert payload['identity']['grounding_policy']
            linked = [receipt(path.parent.parent / 'prompts/calls' / name) for name in payload['receipts']]
            selected.append(dict(section=sid, topic=key[0], part=key[1], action=row['action'],
                                 checkpoint=path.relative_to(r).as_posix(), receipt_sha256s=linked))
            files.add(path)
        revision = revision.get('prior_revision')

assert len(selected) == 10, selected
result = dict(status='verified', selected_units=selected,
              own_completed_receipts=sum(x['origin'] == 'this-work' for x in records.values()),
              imported_selected_receipts=sum(x['origin'] == 'imported' for x in records.values()),
              records=records, evidence_files=sorted(p.relative_to(r).as_posix() for p in files),
              scope='Completed real CLI receipt integrity and exact final selected statement binding. Intermediate calls are included. Reuse is not fresh execution.',
              human_review='pending')
(r / 'native-verification.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print('Verified selected statements', len(selected), 'own completed receipts', result['own_completed_receipts'])
