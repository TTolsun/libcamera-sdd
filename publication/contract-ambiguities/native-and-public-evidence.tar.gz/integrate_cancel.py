from pathlib import Path
import json
import shutil

r = Path(__file__).resolve().parent
base = r / 'base'
candidate = r / 'cancel-window'
report = base / 'build/consistency-review.json'
before = json.loads(report.read_bytes())
assert before['status'] in ('passed', 'failed') and before['fresh_batches'] > 0
assert json.loads((candidate / 'native/result.json').read_bytes())['status'] == 'selected-native-units-validated-and-assembled'
assert json.loads((candidate / 'translation-result.json').read_bytes())['missing_translations'] == 0
old_facts = json.loads((base / 'facts/facts.json').read_bytes())
new_facts = json.loads((candidate / 'facts/facts.json').read_bytes())
source = 'pipeline-requests/completion/pending-cancel-code'
assert set(new_facts['evidence']) - set(old_facts['evidence']) == {source}
record = new_facts['evidence'].pop(source)
assert new_facts == old_facts
assert record['status'] == 'available' and record['commit'] == old_facts['meta']['source_commit']
shutil.copyfile(report, r / 'consistency-before-cancel-window.json')
shutil.copyfile(base / 'manuscripts/pipeline-requests.md', r / 'pipeline-before-cancel-window.md')
shutil.copyfile(candidate / 'manuscripts/pipeline-requests.md', base / 'manuscripts/pipeline-requests.md')
shutil.copyfile(candidate / 'facts/facts.json', base / 'facts/facts.json')
shutil.copyfile(candidate / 'sections.yaml', base / 'config/sections.yaml')
shutil.copyfile(candidate / 'english.json', base / 'english-v11.json')
print('Integrated one pinned evidence window, its actual native manuscript and translated catalog')
