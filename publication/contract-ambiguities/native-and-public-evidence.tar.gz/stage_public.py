from pathlib import Path
import hashlib
import json
import shutil
import subprocess

from sdd.config import load
from sdd.export_site import export_site

r = Path(__file__).resolve().parent
public = r.parent / 'issue250/public'
docs = public / 'docs'
assert (docs / 'site-manifest.json').read_bytes() == (r / 'baseline-site-manifest.json').read_bytes()
cfg = load(r / 'base/publication.yaml')

def validation_hashes():
    return {p.relative_to(docs).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (docs / 'validation').rglob('*') if p.is_file()}

before = validation_hashes()
export_site(cfg, docs)
assert (docs / 'site-manifest.json').read_bytes() == (r / 'site/site-manifest.json').read_bytes()
assert before == validation_hashes()
old = json.loads((r / 'baseline-site-manifest.json').read_bytes())['outputs']
new = json.loads((docs / 'site-manifest.json').read_bytes())['outputs']
changed_diagrams = {p for p, digest in new.items() if p.endswith('.mmd') and old.get(p) != digest}
assert changed_diagrams == {'pipeline-requests.buffer-request-completion.mmd',
                            'en/pipeline-requests.buffer-request-completion.mmd'}
attrs = public / '.gitattributes'
line = 'publication/contract-ambiguities/** -text -whitespace'
if line not in attrs.read_text(encoding='utf-8').splitlines():
    with attrs.open('a', encoding='utf-8') as f:
        f.write('\n' + line + '\n')
readme = public / 'README.md'
text = readme.read_text(encoding='utf-8')
text = text.replace('Configured source analysis and official upstream mirror:be7e83e91348250c015aad6d6f59f1468555bae8.',
                    'The documents use analysis source `be7e83e91348250c015aad6d6f59f1468555bae8`. '
                    'The official upstream mirror is `c19d05128f3ae1f0ebe63acb4deaca9fbb1dde78`. '
                    'The four source files for this contract review are byte-identical across those commits.')
link = '- [Public request contract corrections and verification](publication/contract-ambiguities/README.md)'
if link not in text:
    text += '\n' + link + '\n'
readme.write_text(text, encoding='utf-8')
shutil.copytree(r / 'release-evidence', public / 'publication/contract-ambiguities', dirs_exist_ok=True)
subprocess.run(['git', '-C', str(public), 'add', '.gitattributes', 'README.md', 'docs',
                'publication/contract-ambiguities'], check=True)
(r / 'staging-preservation.json').write_text(json.dumps(dict(
    verified_staged_manifest=True, existing_validation_files_identical=len(before),
    changed_mermaid=sorted(changed_diagrams)), indent=2), encoding='utf-8')
print('Staged verified site and preserved validation files', len(before))
