from pathlib import Path
import copy
import json
import shutil

import yaml
from sdd.config import load
from sdd.evidence import collect
from sdd.facts.model import KnowledgeModel

r = Path(__file__).resolve().parent
base = r / 'base'
candidate = r / 'cancel-window'
candidate.mkdir(exist_ok=False)
profile = yaml.safe_load((base / 'publication.yaml').read_bytes())
sections = yaml.safe_load((base / 'config/sections.yaml').read_bytes())
tracked = yaml.safe_load(Path('examples/libcamera/config/sections.yaml').read_bytes())

def completion(document):
    return next(t for s in document['sections'] if s['id'] == 'pipeline-requests'
                for t in s['design_topics'] if t['id'] == 'completion')

topic, reviewed = completion(sections), completion(tracked)
selector = copy.deepcopy(next(x for x in reviewed['sources'] if x['id'] == 'pending-cancel-code'))
topic['sources'].append(selector)
parts = ('buffer', 'buffer-not-request', 'cancel')
for part in topic['parts']:
    if part['id'] in parts:
        current = next(x for x in reviewed['parts'] if x['id'] == part['id'])
        part.update(question=current['question'], sources=current['sources'])
section_path = candidate / 'sections.yaml'
section_path.write_text(yaml.safe_dump(sections, allow_unicode=True, sort_keys=False), encoding='utf-8')
shutil.copytree(base / 'manuscripts', candidate / 'manuscripts')
(candidate / 'facts').mkdir()
profile['output'].update(facts_dir=str(candidate / 'facts'), sdd_dir=str(candidate / 'manuscripts'),
                         diagrams_dir=str(candidate / 'manuscripts/diagrams'))
profile['paths']['sections_file'] = str(section_path)
profile['publication']['operation_id'] = 'public-contract-ambiguities-pending-cancellation'
profile_path = candidate / 'repair.yaml'
profile_path.write_text(yaml.safe_dump(profile, allow_unicode=True, sort_keys=False), encoding='utf-8')
cfg = load(profile_path)
subset = copy.deepcopy(cfg)
subset.raw['documentation'] = {'enabled': False}
scope = candidate / 'source-selection.yaml'
scope.write_text(yaml.safe_dump({'sections': [{'id': 'pipeline-requests', 'design_topics': [
    {'id': 'completion', 'question': 'Which pending buffers are cancelled before request completion?',
     'sources': [selector]}]}]}, allow_unicode=True, sort_keys=False), encoding='utf-8')
subset.paths['sections_file'] = scope
original = KnowledgeModel.load(base / 'facts/facts.json')
new = KnowledgeModel(meta=copy.deepcopy(original.meta))
collect(subset, new)
key = 'pipeline-requests/completion/pending-cancel-code'
assert list(new.evidence) == [key] and new.evidence[key]['status'] == 'available'
assert key not in original.evidence
original.evidence[key] = new.evidence[key]
original.save(cfg.facts_path)
(candidate / 'new-source.json').write_text(json.dumps(new.evidence[key], ensure_ascii=False, indent=2), encoding='utf-8')
(candidate / 'targets.json').write_text(json.dumps([
    {'section': 'pipeline-requests', 'topic': 'completion', 'part': part} for part in parts], indent=2), encoding='utf-8')
print('Bound pending cancellation source', new.evidence[key]['line'], new.evidence[key]['end_line'])
