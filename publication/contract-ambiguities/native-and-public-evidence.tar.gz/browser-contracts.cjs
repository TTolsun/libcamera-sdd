const {chromium} = require('C:/Users/baboe/.codex/worktrees/cb18/camera-hal-sdd-generator/build/pan-20261105/pw/node_modules/playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');

async function verify() {
  const [base, output, build] = process.argv.slice(2);
  const dir = path.join(__dirname, output);
  await fs.mkdir(dir, {recursive: true});
  const browser = await chromium.launch({channel: 'chrome', headless: true});
  const results = [];
  try {
    for (const width of [1440, 390]) {
      const page = await browser.newPage({viewport: {width, height: 900}});
      const start = await (await page.request.get(base + 'site-manifest.json')).json();
      assert.equal(start.build_id, build);
      for (const en of [false, true]) {
        const prefix = en ? 'en/' : '';
        for (const document of ['camera-requests', 'request-diagnosis', 'pipeline-requests']) {
          const response = await page.goto(base + prefix + document + '.html', {waitUntil: 'networkidle'});
          assert.equal(response.status(), 200);
          const main = page.locator('main');
          const text = await main.innerText();
          assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth + 1), false);
          if (document === 'camera-requests') {
            assert(text.includes('activeStreams_') && text.includes('-EINVAL') && text.includes('requestCompleted'));
            assert(en ? /preceding.+checks/s.test(text) : /앞선.+검사를 통과/s.test(text));
          }
          if (document === 'request-diagnosis') {
            const paragraphs = await main.locator('p').allTextContents();
            const plan = paragraphs.find(p => p.includes(en ? 'Execution verification item' : '실행 확인 항목') &&
                                               p.includes('config->validate()') && p.includes('-EINVAL'));
            assert(plan, 'Proposed configuration observation must be rendered separately');
          }
          if (document === 'pipeline-requests') {
            assert(text.includes('CameraManager') && text.includes('bufferCompleted'));
            assert(en ? /internal cancellation cancels each pending buffer/i.test(text) : text.includes('내부 취소는 각 대기 버퍼를 취소'));
            assert((await main.textContent()).includes('Request::Private::doCancelRequest()'));
            const edge = en ? 'All buffers complete' : '모든 버퍼 완료';
            const target = main.locator('.mermaid').filter({hasText: edge});
            await target.waitFor();
            const index = await target.evaluate(el => [...document.querySelectorAll('main .mermaid')].indexOf(el));
            const buttons = main.getByRole('button', {name: en ? 'Enlarge diagram' : '다이어그램 확대', exact: true});
            await buttons.nth(index).click();
            const dialog = page.locator('#diagram-dialog');
            await dialog.waitFor({state: 'visible'});
            const figure = await dialog.locator('svg').textContent();
            assert(figure.includes(edge) && figure.includes('completeRequest()'));
            const compact = value => value.replace(/\s+/g, '');
            assert(compact(figure).includes(compact(en ? 'if needed' : '필요한 작업이 있으면')));
            await page.screenshot({path: path.join(dir, `${width}-${en ? 'en' : 'ko'}-completion.png`)});
            await page.keyboard.press('Escape');
            await dialog.waitFor({state: 'hidden'});
          }
          results.push({width, language: en ? 'en' : 'ko', document, status: 'passed'});
        }
      }
      const end = await (await page.request.get(base + 'site-manifest.json')).json();
      assert.equal(end.build_id, build);
      await page.close();
    }
  } finally {
    await browser.close();
  }
  await fs.writeFile(path.join(dir, 'summary.json'), JSON.stringify({status: 'passed', build, base, results}, null, 2));
  console.log('PASS changed pages and localized completion figure', results.length);
}

verify().catch(error => {console.error(error); process.exitCode = 1;});
