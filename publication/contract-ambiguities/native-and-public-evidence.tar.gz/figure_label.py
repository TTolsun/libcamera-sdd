from pathlib import Path
import json
from sdd.config import load
from sdd.llm import Agent

r = Path(__file__).resolve().parent
cfg = load(r / 'independent-review.yaml')
assert cfg.agent.kind == 'cli' and cfg.agent.runner == 'codex'
assert cfg.agent.model == 'gpt-6.1-terra'
assert 'model_reasoning_effort="high"' in cfg.agent.args
facts = json.loads((r / 'base/facts/facts.json').read_bytes())
source = facts['evidence']['pipeline-requests/completion/buffer-contract']['text']
schema = {'type': 'object', 'additionalProperties': False, 'required': ['label', 'label_en'],
          'properties': {'label': {'type': 'string'}, 'label_en': {'type': 'string'}}}
agent = Agent(cfg.agent, r / 'figure-label')
raw = agent.chat('Write one concise Korean/English arrow label from buffer tracking to explicit '
                 'completeRequest() for the existing ordinary completion figure. Include that all buffers '
                 'have completed, any remaining work is conditional, and the handler explicitly calls '
                 'completeRequest(). The node already names the function, so the label may say explicitly calls. '
                 'Do not claim mandatory post-processing, automatic request completion or any cancellation '
                 'behavior. Follow the supplied source. Return only the two equivalent labels as JSON.',
                 source, tag='ordinary-completion-edge-label', response_schema=schema)
(r / 'figure-label.json').write_text(raw, encoding='utf-8')
print(raw, flush=True)
