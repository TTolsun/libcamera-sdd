import hashlib
import json
import shutil
import zipfile
from pathlib import Path
from sdd.config import AgentConfig
from sdd.call_records import load_record
from sdd.cli_provenance import verify_cli_receipt
from sdd.publication import copy_site
from sdd.site_build import verify_site
area=Path(__file__).resolve().parent;trial=area/'final-readers'
publication=area/'public-evaluation-release';packet=publication/'publication/issue248/fresh-automatic'
out=packet/'post-merge';out.mkdir(parents=True,exist_ok=True)
site=json.loads((trial/'post-merge/site-verification.json').read_text(encoding='utf-8'))
for name in ['catalog.json','translation-delta.json','site-verification.json']:
    shutil.copyfile(trial/'post-merge'/name,out/name)
shutil.copyfile(trial/'post-merge/review/assessment.json',out/'translation-review.json')
expected=AgentConfig(kind='cli',runner='codex',command=[shutil.which('codex')],model='gpt-6.1-terra',args=['-c','model_reasoning_effort="high"'])
old=json.loads((packet/'native-verification.json').read_text(encoding='utf-8'))
old_hashes={row['sha256'] for row in old['calls']}
original_index=json.loads(__import__('subprocess').check_output(['git','show','origin/main:publication/issue249/archive-index.json'],cwd=area/'public'))
receipts=list((trial/'post-merge/review').rglob('*.receipt.json'))
receipts += [p for p in (trial/'inherited-249/integration/build/translation-prompts').rglob('*.receipt.json')
    if hashlib.sha256(p.read_bytes()).hexdigest() not in old_hashes
    and original_index.get(p.relative_to(trial/'inherited-249').as_posix())!=hashlib.sha256(p.read_bytes()).hexdigest()]
assert len(receipts)==2,len(receipts)
records=[];files={}
for path in receipts:
    record=load_record(path);calls=path.parent.parent
    checked=verify_cli_receipt(record.request,record.raw,record.receipt,calls,expected)
    records.append(dict(path=path.relative_to(trial).as_posix(),verified=checked,receipt_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    for p in [path,record.request_path,record.response_path,calls.parent/record.receipt['provider']['stdout_path']]:files[p.relative_to(trial).as_posix()]=p
with zipfile.ZipFile(out/'native-additional.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for name,path in sorted(files.items()):archive.writestr(name,path.read_bytes())
    for name in ['postmerge_catalog.py','postmerge_review.py','postmerge_export.py','package_postmerge.py']:
        archive.writestr('operators/'+name,(area/name).read_bytes())
proof=dict(schema=1,additional_new_cli_calls=2,total_new_cli_calls=15,actual_human_participants=0,calls=records,
    archive_sha256=hashlib.sha256((out/'native-additional.zip').read_bytes()).hexdigest())
(out/'native-verification.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
base=trial/'inherited-249/integration'
for name in ['publication-repair.yaml','independent-review.yaml','translation-repair.yaml']:
    shutil.copyfile(base/name,packet/'operation'/name)
shutil.copyfile(base/'english.json',packet/'operation/english.json')
copy_site(trial/'site-final',publication/'docs',scratch=trial/'sync-scratch')
assert (publication/'docs/site-manifest.json').read_bytes()==(trial/'site-final/site-manifest.json').read_bytes()
print(json.dumps(dict(quality=verify_site(publication/'docs'),build_id=site['build_id'],changed=site['changes_from_initial_label_candidate'])),flush=True)
