import hashlib
import json
from pathlib import Path
from sdd.config import load
from sdd.trial_workspace import write_snapshot
from sdd.export_site import export_site
from sdd.site_build import verify_site
area=Path(__file__).resolve().parent/'final-readers';out=area/'post-merge'
path=area/'inherited-249/integration/publication-repair.yaml';cfg=load(path)
report=area/'inherited-249/integration/build/consistency-review.json'
contracts=json.loads(report.read_text(encoding='utf-8'));assert contracts['status']=='passed'
for entry in cfg.raw['publication']['reports']:
    if str(entry['path']).replace('\\','/').endswith('/consistency-review.json'):
        entry.update(path=str(report),sha256=hashlib.sha256(report.read_bytes()).hexdigest())
review=out/'review/assessment.json'
assert json.loads(review.read_text(encoding='utf-8'))['verdict']=='faithful'
if not any(entry['path']==str(review) for entry in cfg.raw['publication']['reports']):
    cfg.raw['publication']['reports'].append(dict(path=str(review),sha256=hashlib.sha256(review.read_bytes()).hexdigest(),
        producer='independent-codex-cli-merged-UI-review',gate='before-export',bindings={'verdict':'faithful'}))
write_snapshot(cfg,path);cfg=load(path)
first=export_site(cfg,area/'site-final');second=export_site(cfg,area/'site-final-repeat')
raw=(first/'site-manifest.json').read_bytes();assert raw==(second/'site-manifest.json').read_bytes()
manifest=json.loads(raw)
previous=json.loads((area/'site-after/site-manifest.json').read_text(encoding='utf-8'))
before=json.loads((area/'site/site-manifest.json').read_text(encoding='utf-8'))
md=[name for name in manifest['outputs'] if name.endswith('.md')]
assert all((first/name).read_bytes()==(area/'site'/name).read_bytes() for name in md)
assert all(manifest['outputs'][name]==before['outputs'][name] for name in manifest['outputs'] if name.endswith('.mmd'))
result=dict(schema=1,build_id=manifest['build_id'],manifest_sha256=hashlib.sha256(raw).hexdigest(),
    quality=verify_site(first),repeat_quality=verify_site(second),repeat_identical=True,
    outputs=len(manifest['outputs']),unchanged_manuscripts=len(md),all_mermaid_bytes_preserved=True,
    changes_from_initial_label_candidate=[name for name,sha in manifest['outputs'].items() if previous['outputs'].get(name)!=sha],
    changes_from_frozen_reader_site=[name for name,sha in manifest['outputs'].items() if before['outputs'].get(name)!=sha],
    contract_new_calls=contracts['fresh_batches'],contract_revalidated=contracts['reused_batches'],
    inherited_unresolved=len(contracts['unresolved']),generator_merge='1174e60fdb5b252e8c9266e8feb2be9b36cec04a',
    human_completion='not-established')
(out/'site-verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result),flush=True)
