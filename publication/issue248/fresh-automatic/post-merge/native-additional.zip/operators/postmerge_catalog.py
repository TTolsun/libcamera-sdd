import json
import shutil
from pathlib import Path
from sdd.config import load
from sdd.localization_cli import prepare_catalog
area=Path(__file__).resolve().parent/'final-readers'
out=area/'post-merge';out.mkdir(exist_ok=True)
before=area.parent/'public-evaluation-release/publication/issue248/fresh-automatic/operation/english.json'
if not (out/'english-before.json').exists():shutil.copyfile(before,out/'english-before.json')
cfg=load(area/'inherited-249/integration/publication-repair.yaml')
result=prepare_catalog(cfg,Path(cfg.site.english_catalog),translate=True)
(out/'catalog.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
assert result['missing_translations']==0,result
print(json.dumps(result),flush=True)
