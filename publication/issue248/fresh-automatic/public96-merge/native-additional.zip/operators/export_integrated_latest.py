import argparse
import hashlib
import json
import subprocess
from pathlib import Path
from sdd.config import load
from sdd.trial_workspace import write_snapshot
from sdd.export_site import export_site
from sdd.site_build import verify_site
parser=argparse.ArgumentParser();parser.add_argument('--config',type=Path,required=True)
args=parser.parse_args()
area=Path(__file__).resolve().parent/'final-readers';out=area/'public96-merge';out.mkdir(exist_ok=True)
cfg=load(args.config)
report=cfg.build_dir/'consistency-review.json'
contracts=json.loads(report.read_text(encoding='utf-8'));assert contracts['status']=='passed'
for entry in cfg.raw.get('publication',{}).get('reports',[]):
    if str(entry['path']).replace('\\','/').endswith('/build/consistency-review.json') and Path(entry['path']).exists():
        entry.update(sha256=hashlib.sha256(Path(entry['path']).read_bytes()).hexdigest())
review=area/'guide-repair/english-review/assessment.json'
assert json.loads(review.read_text(encoding='utf-8'))['verdict']=='faithful'
if not any(entry['path']==str(review) for entry in cfg.raw['publication']['reports']):
    cfg.raw['publication']['reports'].append(dict(path=str(review),sha256=hashlib.sha256(review.read_bytes()).hexdigest(),
        producer='independent-codex-cli-overview-guide-review',gate='before-export',bindings={'verdict':'faithful'}))
write_snapshot(cfg,args.config);cfg=load(args.config)
first=export_site(cfg,area/'site-release');second=export_site(cfg,area/'site-release-repeat')
raw=(first/'site-manifest.json').read_bytes();assert raw==(second/'site-manifest.json').read_bytes()
manifest=json.loads(raw)
repo=area.parent/'public'
prior_raw=subprocess.check_output(['git','show','origin/main:docs/site-manifest.json'],cwd=repo)
prior=json.loads(prior_raw);(out/'latest-public-manifest.json').write_bytes(prior_raw)
md=[name for name in manifest['outputs'] if name.endswith('.md')]
assert all(manifest['outputs'][name]==prior['outputs'][name] for name in md)
assert all(manifest['outputs'][name]==prior['outputs'][name] for name in manifest['outputs'] if name.endswith('.mmd'))
result=dict(schema=1,build_id=manifest['build_id'],manifest_sha256=hashlib.sha256(raw).hexdigest(),
    quality=verify_site(first),repeat_quality=verify_site(second),repeat_identical=True,
    outputs=len(manifest['outputs']),unchanged_manuscripts_vs_latest_public=len(md),all_mermaid_bytes_preserved_vs_latest_public=True,
    changes_vs_latest_public=[name for name,sha in manifest['outputs'].items() if prior['outputs'].get(name)!=sha],
    contract_new_calls=contracts['fresh_batches'],contract_revalidated=contracts['reused_batches'],
    unresolved=len(contracts['unresolved']),generator_merge='1174e60fdb5b252e8c9266e8feb2be9b36cec04a',
    public_base=subprocess.check_output(['git','rev-parse','origin/main'],cwd=repo,text=True).strip(),
    human_completion='not-established')
(out/'site-verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result),flush=True)
