import hashlib
import json
import shutil
import subprocess
import zipfile
from pathlib import Path
from sdd.config import AgentConfig
from sdd.call_records import load_record
from sdd.cli_provenance import verify_cli_receipt
from sdd.publication import copy_site
from sdd.site_build import verify_site
area=Path(__file__).resolve().parent;trial=area/'final-readers';repo=area/'public'
publication=area/'public-evaluation-release';packet=publication/'publication/issue248/fresh-automatic'
out=packet/'public96-merge';shutil.copytree(trial/'public96-merge',out,dirs_exist_ok=True)
shutil.copyfile(trial/'inherited-96/integration.json',out/'integration.json')
base=trial/'inherited-96/workspace/publication'
old_hashes=set()
for folder in ['issue249','issue243-followup','issue250-followup']:
    index=json.loads(subprocess.check_output(['git','show',f'origin/main:publication/{folder}/archive-index.json'],cwd=repo))
    old_hashes.update(index.values())
expected=AgentConfig(kind='cli',runner='codex',command=[shutil.which('codex')],model='gpt-6.1-terra',args=['-c','model_reasoning_effort="high"'])
receipts=[p for p in (base/'build/prompts/calls').rglob('*.receipt.json') if hashlib.sha256(p.read_bytes()).hexdigest() not in old_hashes]
assert len(receipts)==3,len(receipts)
records=[];files={}
for path in receipts:
    record=load_record(path);calls=path.parent.parent
    checked=verify_cli_receipt(record.request,record.raw,record.receipt,calls,expected)
    records.append(dict(path=path.relative_to(trial).as_posix(),receipt_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),verified=checked))
    for item in [path,record.request_path,record.response_path,calls.parent/record.receipt['provider']['stdout_path']]:files[item.relative_to(trial).as_posix()]=item
with zipfile.ZipFile(out/'native-additional.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for name,path in sorted(files.items()):archive.writestr(name,path.read_bytes())
    for name in ['export_integrated_latest.py','package_public96.py']:
        archive.writestr('operators/'+name,(area/name).read_bytes())
proof=dict(schema=1,additional_new_contract_calls=3,previous_new_calls=15,total_new_calls=18,
    archive_sha256=hashlib.sha256((out/'native-additional.zip').read_bytes()).hexdigest(),
    calls=records,source_kind='agent',actual_human_participants=0,human_approval='unchanged')
(out/'native-verification.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
op=packet/'operation'
for source,target in [('publication.yaml','publication-repair.yaml'),('independent-review.yaml','independent-review.yaml'),('translation-248.yaml','translation-repair.yaml'),('english.json','english.json')]:
    shutil.copyfile(base/source,op/target)
# Resolve generated merge conflicts from canonical public inputs; the normal
# generator synchronization then writes the new coherent manifest and outputs.
conflicts=subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=publication,text=True).splitlines()
assert all(name.startswith('docs/') for name in conflicts),conflicts
for name in conflicts:(publication/name).write_bytes(subprocess.check_output(['git','show','origin/main:'+name],cwd=publication))
copy_site(trial/'site-release',publication/'docs',scratch=trial/'sync-scratch')
print(json.dumps(verify_site(publication/'docs')),flush=True)
