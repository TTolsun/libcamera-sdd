"""Preserve independently merged #243 inputs; do not modify its source tree."""
import copy
import hashlib
import json
import shutil
import zipfile
from pathlib import Path
from sdd.config import load
from sdd.trial_workspace import write_snapshot
from sdd.localization_cli import prepare_catalog

area=Path(__file__).resolve().parent
render=area/'render'
current=load(render/'sdd.yaml')
review=load(render/'independent-review.yaml')
latest_path=Path('C:/Users/baboe/.codex/worktrees/bb29/camera-hal-sdd-generator/build/issue243/public-current/publication.yaml')
latest=load(latest_path)
prior=area/'before-public-main-integration';prior.mkdir(exist_ok=True)
for name in ['sdd.yaml','independent-review.yaml','english.json']:
    shutil.copyfile(render/name,prior/name)
shutil.copyfile(render/'build/consistency-review.json',prior/'consistency-review.json')
with zipfile.ZipFile(area/'intermediate-0f-site.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for path in sorted((area/'candidate').rglob('*')):
        if path.is_file():archive.write(path,path.relative_to(area/'candidate').as_posix())

# Every current manuscript must match the actual latest public merge.
changed=[]
for path in sorted(latest.sdd_dir.rglob('*')):
    if not path.is_file():continue
    relative=path.relative_to(latest.sdd_dir)
    target=current.sdd_dir/relative;target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists() and target.read_bytes()!=path.read_bytes():changed.append(relative.as_posix())
    shutil.copyfile(path,target)
for path in (area/'release/docs').rglob('*.md'):
    relative=path.relative_to(area/'release/docs')
    assert (current.sdd_dir/relative).read_bytes()==path.read_bytes(),relative
old_facts=json.loads(current.facts_path.read_text(encoding='utf-8'))
new_facts=json.loads(latest.facts_path.read_text(encoding='utf-8'))
assert {k:v for k,v in old_facts.items() if k!='evidence'}=={k:v for k,v in new_facts.items() if k!='evidence'}
fact_additions=[key for key in new_facts['evidence'] if key not in old_facts['evidence']]
assert fact_additions==['vendor-assurance/constraints/generate-contract']
assert all(new_facts['evidence'][key]==value for key,value in old_facts['evidence'].items())
shutil.copyfile(current.facts_path,prior/'facts.json')
shutil.copyfile(latest.facts_path,current.facts_path)

# Retain #243 translations and their metadata; overlay only the source-reviewed
# English correction and six actual CLI-translated reader labels from #248.
ours=json.loads((render/'english.json').read_text(encoding='utf-8'))
combined=json.loads(Path(latest.site.english_catalog).read_text(encoding='utf-8'))
keys=json.loads((area/'translation-preservation.json').read_text(encoding='utf-8'))['changed']
keys += [row['reader_label'] for row in json.loads((area/'question-label-sources.json').read_text(encoding='utf-8'))]
for key in keys:
    assert key in ours['strings'],key
    combined['strings'][key]=ours['strings'][key]
    for field in ['translation_contexts','source_contexts']:
        if key in ours[field]:combined[field][key]=ours[field][key]
(render/'english.json').write_text(json.dumps(combined,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')

cfg=copy.deepcopy(latest)
cfg.root=render
cfg.facts_dir=current.facts_dir;cfg.sdd_dir=current.sdd_dir;cfg.diagrams_dir=current.diagrams_dir
cfg.paths['consistency_review_config']=render/'independent-review.yaml'
cfg.paths['translation_profile']=render/'translation.yaml'
cfg.raw['site']['english_catalog']=str(render/'english.json')
cfg.raw['site']['coverage_question_edits']=current.raw['site']['coverage_question_edits']
for page,profile in cfg.raw['site']['manuscript_profiles'].items():
    cfg.raw['site']['manuscript_profiles'][page]=str((latest.root/profile).resolve())
cfg.raw['publication']['operation_id']='issue248-reader-question-integration'
cfg.raw['publication']['baseline_config']=str(latest_path)
write_snapshot(cfg,render/'sdd.yaml')
cfg.agent=review.agent
cfg.raw['review']=review.raw.get('review',{})
write_snapshot(cfg,render/'independent-review.yaml')

# Preserve actual inherited receipt files, without classifying them as new calls.
copied=[]
for relative in ['prompts/calls','translation-prompts']:
    origin=latest.build_dir/relative
    for path in origin.rglob('*'):
        if not path.is_file():continue
        target=current.build_dir/relative/path.relative_to(origin)
        target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():assert target.read_bytes()==path.read_bytes(),target
        else:shutil.copyfile(path,target);copied.append(str(target.relative_to(current.build_dir)))

result=prepare_catalog(load(render/'sdd.yaml'),render/'english.json',translate=False)
report=dict(schema=1,public_base='3a8fbfd93aab233282712eefaa32be9a3c13cc63',
    inherited_input= str(latest_path),changed_manuscript_inputs=changed,inherited_evidence_additions=fact_additions,
    manuscript_bytes_match_current_public=True,overlaid_248_translation_keys=keys,
    inherited_receipt_files=copied,catalog=result,human_reader_status='pending')
(area/'public-main-integration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
assert result['missing_translations']==0,result
print(json.dumps(result),flush=True)
