"""Run independent current-policy CLI units, then let ordinary audit verify them.

No verdict is fabricated or changed. The final standard audit and site export
still enforce every source, policy, schema and native-receipt binding.
"""
import hashlib
import json
import shutil
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict
from pathlib import Path
from sdd.config import load
from sdd.consistency import groups, request, batches, review_store, validate, SYSTEM, policy_hash
from sdd.cli_checkpoint import Capture
from sdd.facts.model import KnowledgeModel
from sdd.llm import Agent
from sdd.validation_stage import staged

root=Path(__file__).resolve().parents[2];area=root/'build/issue248'
out=area/'current-policy-parallel-review';out.mkdir(parents=True,exist_ok=True)

@staged
def execute(cfg, model):
    assert cfg.agent.kind=='cli' and cfg.agent.runner=='codex' and cfg.agent.model=='gpt-6.1-terra'
    assert not any([cfg.review.max_calls,cfg.review.max_seconds,cfg.review.document_max_calls,cfg.review.document_max_seconds])
    assert not cfg.publication.get('budget'), 'Do not bypass an explicitly configured operation budget.'
    tasks=[]
    for group in groups(cfg):
        payload=request(cfg,model,group)
        for index,batch in enumerate(batches(payload,max_input_chars=cfg.agent.max_input_chars)):
            store,envelope=review_store(cfg,batch)
            tasks.append((group['id'],index,batch,store,envelope))
    report=dict(schema=1,source_commit=model.meta['source_commit'],policy_sha256=policy_hash(),
                profile=asdict(cfg.agent),concurrency=4,units=[],human_review='pending')
    def save():
        (out/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    save()
    def unit(task):
        group,index,batch,store,envelope=task
        start=time.monotonic()
        row=dict(group=group,index=index,checkpoint=store.path.name)
        try:
            cached=store.read()
            if cached is not None:
                saved,_=cached
                checked=validate(batch,saved['raw'])
                assert checked==saved['statements']
                row.update(status='checkpoint-revalidated',receipts=[])
            else:
                capture=Capture(Agent(cfg.agent,cfg.build_dir/'prompts'))
                raw=capture.chat(SYSTEM,envelope['user'],tag=f'current_policy_{group}_{index}',response_schema=envelope['response_schema'])
                checked=validate(batch,raw)
                store.write(raw,checked,capture)
                assert capture.receipts
                row.update(status='new-cli-completed',receipts=[str(path.relative_to(cfg.build_dir)) for path in capture.receipts])
            row['verdicts']={state:sum(item['status']==state for item in checked)
                             for state in ['compatible','ambiguous','insufficient-evidence','contradiction']}
        except Exception as error:
            row.update(status='failed',error=str(error))
        row['elapsed_seconds']=round(time.monotonic()-start,3)
        return row
    with ThreadPoolExecutor(max_workers=4) as pool:
        for future in as_completed([pool.submit(unit,task) for task in tasks]):
            report['units'].append(future.result());save()
            print(f"Completed {len(report['units'])}/{len(tasks)} current-policy CLI units",flush=True)
    report['status']='failed' if any(row['status']=='failed' for row in report['units']) else 'completed'
    save()
    if report['status']=='failed':raise RuntimeError('Current-policy CLI units failed; see original records. No substitute was used.')
    return report

cfg=load(area/'render/independent-review.yaml')
shutil.copyfile(cfg.build_dir/'consistency-review.json',area/'consistency-before-late-integration.json')
model=KnowledgeModel.load(cfg.facts_path)
result=execute(cfg,model)
print(json.dumps(dict(status=result['status'],units=len(result['units']))),flush=True)
