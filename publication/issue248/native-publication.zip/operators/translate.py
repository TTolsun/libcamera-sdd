import copy
import json
import shutil
from pathlib import Path
from sdd.config import load, AgentConfig
from sdd.trial_workspace import write_snapshot
from sdd.localization_cli import prepare_catalog

root=Path(__file__).resolve().parents[2]
out=root/'build/issue248/render'
cfg=load(out/'sdd.yaml')
translator=copy.deepcopy(cfg)
translator.agent=AgentConfig(kind='cli',runner='codex',command=[shutil.which('codex')],model='gpt-6.1-terra',
                            args=['-c','model_reasoning_effort="high"'],max_input_chars=48000,timeout_sec=600)
write_snapshot(translator,out/'translation.yaml')
cfg.paths['translation_profile']=out/'translation.yaml'
write_snapshot(cfg,out/'sdd.yaml')
print(json.dumps(prepare_catalog(load(out/'sdd.yaml'),out/'english.json',translate=True),ensure_ascii=False),flush=True)
