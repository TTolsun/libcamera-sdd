import hashlib
import json
import subprocess
from pathlib import Path
from sdd.site_build import verify_site
root=Path(__file__).resolve().parents[2]
area=root/'build/issue248'
site=area/'candidate'
repeated=area/'candidate-repeat'
a=(site/'site-manifest.json').read_bytes()
b=(repeated/'site-manifest.json').read_bytes()
assert a==b,'Repeated exports differ.'
manifest=json.loads(a)
original=area/'release/docs'
prior=json.loads((original/'site-manifest.json').read_text(encoding='utf-8'))
changed=[name for name,digest in manifest['outputs'].items() if prior['outputs'].get(name)!=digest]
md=[name for name in manifest['outputs'] if name.endswith('.md')]
assert all((original/name).read_bytes()==(site/name).read_bytes() for name in md),'Original manuscripts changed.'
report=dict(schema=1,build_id=manifest['build_id'],site=verify_site(site),
            repeat=verify_site(repeated),repeated_manifest_identical=True,
            manifest_sha256=hashlib.sha256(a).hexdigest(),outputs=len(manifest['outputs']),
            changed_outputs=changed,unchanged_manuscripts=len(md),source_commit='293d751a814e0d4c34e85ad457ccd9d5eefd1a61',
            generator_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=area/'generator-release',text=True).strip(),human_reader_status='pending',human_approval='unchanged')
(area/'site-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
