import json
import shutil
from pathlib import Path
from sdd.config import load
from sdd.localization_cli import prepare_catalog
area=Path(__file__).resolve().parent
latest=load(Path('C:/Users/baboe/.codex/worktrees/bb29/camera-hal-sdd-generator/build/issue243/public-current/publication.yaml'))
cfg=load(area/'render/sdd.yaml')
copied=[]
for relative in ['prompts/calls','translation-prompts/calls']:
    origin=latest.build_dir/relative
    for path in origin.rglob('*'):
        if not path.is_file():continue
        target=cfg.build_dir/relative/path.relative_to(origin)
        target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():assert target.read_bytes()==path.read_bytes(),target
        else:shutil.copyfile(path,target);copied.append(str(target.relative_to(cfg.build_dir)))
result=prepare_catalog(cfg,area/'render/english.json',translate=False)
report=dict(schema=1,public_base='3a8fbfd93aab233282712eefaa32be9a3c13cc63',
    inherited_input=str(latest.root/'publication.yaml'),
    inherited_manuscript_change='vendor-assurance.md',
    inherited_evidence_additions=['vendor-assurance/constraints/generate-contract'],
    manuscript_bytes_match_current_public=True,overlaid_248_translations='six reader labels and one source-reviewed English correction',
    inherited_receipt_files=copied,catalog=result,
    original_failed_attempt='integrate-public-main.log',
    human_reader_status='pending')
(area/'public-main-integration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
assert result['missing_translations']==0,result
print(json.dumps(result),flush=True)
