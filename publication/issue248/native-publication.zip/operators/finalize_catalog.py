import hashlib
import json
from pathlib import Path
from sdd.config import load
from sdd.trial_workspace import write_snapshot
from sdd.localization_cli import prepare_catalog
root=Path(__file__).resolve().parents[2]
area=root/'build/issue248'
report=area/'render/build/consistency-review.json'
assert json.loads(report.read_text(encoding='utf-8'))['status']=='passed'
for name in ['sdd.yaml','independent-review.yaml']:
    path=area/'render'/name
    cfg=load(path)
    for entry in cfg.raw.get('publication',{}).get('reports',[]):
        if entry['path'].replace('\\','/').endswith('/consistency-review.json'):
            entry['path']=str(report)
            entry['sha256']=hashlib.sha256(report.read_bytes()).hexdigest()
    write_snapshot(cfg,path)
cfg=load(area/'render/sdd.yaml')
result=prepare_catalog(cfg,area/'render/english.json',translate=False)
assert result['missing_translations']==0,result
(area/'final-catalog.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result),flush=True)
