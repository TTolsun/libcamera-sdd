import copy
import json
from pathlib import Path
from sdd.config import load
from sdd.translation import translate_missing
from sdd.trial_workspace import write_snapshot
root=Path(__file__).resolve().parents[2]
area=root/'build/issue248'
out=area/'translation-repair'
out.mkdir(parents=True,exist_ok=True)
cfg=load(area/'render/translation.yaml')
cfg.root=out
write_snapshot(cfg,out/'sdd.yaml')
catalog=json.loads((area/'render/english.json').read_text(encoding='utf-8'))
targets=[key for key,value in catalog['strings'].items()
         if 'a buffer set and a parameter set connected to a stream' in value]
assert len(targets)==1, targets
(out/'before.json').write_text(json.dumps({key:catalog['strings'][key] for key in targets},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for key in targets:
    catalog['strings'][key]=''
updated=translate_missing(cfg,catalog)
(out/'english.json').write_text(json.dumps(updated,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'delta.json').write_text(json.dumps({key:updated['strings'][key] for key in targets},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:updated['strings'][key] for key in targets},ensure_ascii=False),flush=True)
