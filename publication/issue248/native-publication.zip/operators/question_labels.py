import hashlib
import json
import re
from pathlib import Path
import yaml
from sdd.site_markdown import _render
from sdd.document_metadata import split_frontmatter
root=Path(__file__).resolve().parents[2]
area=root/'build/issue248'
labels={
 'ca76a601ba35d124ae6ea8d501b931cf47bc636d61797d77775ae3d847a22a9b': '카메라를 시작할 때 controls, 반환값, 실행 스레드와 ASSERT 조건을 어떻게 확인합니까?',
 '05ad064f41e1930d03fb45929b6f2aefd2855edfa75764ca94bc0ad3529a9cd1': '카메라 정지는 상태·연결·진행 중인 요청에 따라 어떻게 처리됩니까?',
 'b70bb7d3da3d7b0ee4cc270eb1d1fdb2e231ff3732714ef20b9548581179a7eb': '정지 중 대기 요청은 어떤 순서로 취소·반환되며 재큐잉을 어떻게 막습니까?'}
old=json.loads((area/'question-edits.json').read_text(encoding='utf-8'))
mapping={}
sources=[]
for rel,values in old.items():
    _,body=split_frontmatter((area/'render/manuscripts'/rel).read_text(encoding='utf-8'))
    html,_,_=_render(body,rel,set(),None,'','')
    questions=[q for note in re.findall(r'<ul class="coverage-links">(.*?)</ul>',html,re.S) for q in re.findall(r'<li><p>(.*?)</p>',note,re.S)]
    for q in questions:
        key=hashlib.sha256(q.encode()).hexdigest()
        if key not in values:continue
        if key in labels:label=labels[key]
        elif rel.endswith('configure.md'):label='구성을 적용하기 전에 무엇을 준비하고, 상태·연결 오류를 어떻게 구분합니까?'
        elif 'Camera::queueRequest()의 캡처용' in q:label='Camera::queueRequest()의 요청 조건을 확인하고 반환값과 완료 알림을 어떻게 구분합니까?'
        else:label='접수된 요청은 언제 장치로 전달되며, 대기·취소·큐잉 실패는 어떻게 처리됩니까?'
        mapping.setdefault(rel,{})[key]={'label':label}
        sources.append(dict(page=rel,sha256=key,original_question_html=q,reader_label=label))
assert len(sources)==6
config=area/'render/sdd.yaml'
raw=yaml.safe_load(config.read_text(encoding='utf-8'));raw['site']['coverage_question_edits']=mapping
config.write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf-8')
example=area/'generator-release/examples/libcamera/sdd.yaml'
text=example.read_text(encoding='utf-8')
start=text.index('  coverage_question_edits:\n');end=text.index('  overview_visual:',start)
block=yaml.safe_dump(dict(coverage_question_edits=mapping),allow_unicode=True,sort_keys=False)
text=text[:start]+''.join('  '+line+'\n' for line in block.splitlines())+text[end:]
example.write_text(text,encoding='utf-8',newline='\n')
(area/'question-label-sources.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(pages=len(mapping),questions=len(sources))))
