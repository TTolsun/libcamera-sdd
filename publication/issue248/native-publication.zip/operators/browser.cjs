const {chromium}=require('playwright');
const fs=require('node:fs/promises');
const path=require('node:path');
const assert=require('node:assert/strict');
let base=process.argv[2];const out=path.resolve(process.argv[3]);
(async()=>{
 await fs.mkdir(out,{recursive:true});
 let server;
 if(base==='local'){
  const root=path.resolve(process.argv[4]);
  server=require('node:http').createServer(async(req,res)=>{
   try{
    const file=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://local').pathname));
    if(!file.startsWith(root+path.sep))throw Error('Outside preview root');
    const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.json':'application/json','.svg':'image/svg+xml'};
    res.setHeader('Content-Type',types[path.extname(file)]||'application/octet-stream');res.end(await fs.readFile(file));
   }catch(e){res.statusCode=404;res.end('Not found');}
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));base=`http://127.0.0.1:${server.address().port}/`;
 }
 const browser=await chromium.launch({channel:'chrome',headless:true});
 const report={base,engine:browser.version(),scope:'Fresh Chromium contexts; mobile emulation; automatic UI regression, not human reading evaluation',runs:[]};
 try{
  for(const mobile of [false,true])for(const lang of ['ko','en']){
   const context=await browser.newContext({viewport:mobile?{width:390,height:844}:{width:1280,height:900},isMobile:mobile,hasTouch:mobile});
   const page=await context.newPage(),errors=[];
   page.on('pageerror',e=>errors.push(String(e)));
   await page.goto(base+(lang==='en'?'en/':'')+'scenarios/queue_request.html',{waitUntil:'networkidle'});
   const summary=page.locator('details.note:has(ul.coverage-links) > summary').first();
   await summary.focus();await page.keyboard.press('Enter');
   const note=summary.locator('..'),text=await note.innerText();
   for(const removed of ['세 문단 이내로 작성하세요.','소스 한 줄마다 문단을 만들지 마세요.'])assert(!text.includes(removed));
   assert(text.includes('queueRequest'));
   assert(!/설명하세요|작성하세요|문단|다시 요약하지|explain once|paragraph|do not repeat/i.test(text));
   assert((await page.locator('main').innerText()).includes('ConnectionTypeQueued'));
   await page.screenshot({path:path.join(out,`${lang}-${mobile?'mobile':'desktop'}.png`)});
   const link=note.locator('.coverage-links a').first();await link.click();
   assert(new URL(page.url()).hash);
   const trigger=page.getByRole('button',{name:lang==='ko'?'다이어그램 확대':'Enlarge diagram',exact:true}).first();
   await trigger.click();await page.locator('#diagram-dialog').waitFor({state:'visible'});
   await page.keyboard.press('Escape');
   assert(await trigger.evaluate(el=>document.activeElement===el));
   const width=await page.evaluate(()=>({screen:innerWidth,page:document.documentElement.scrollWidth}));
   assert(width.page<=width.screen+1);
   assert.equal(errors.length,0);
   report.runs.push({lang,mobile,coverageLinks:await note.locator('.coverage-links a').count(),width,errors,diagramEscapeFocus:true});
   await context.close();
  }
  await fs.writeFile(path.join(out,'report.json'),JSON.stringify(report,null,2));
 }finally{await browser.close();if(server)await new Promise(resolve=>server.close(resolve));}
 console.log(JSON.stringify(report));
})().catch(e=>{console.error(e);process.exitCode=1});
