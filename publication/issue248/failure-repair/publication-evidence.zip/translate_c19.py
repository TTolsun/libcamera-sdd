from pathlib import Path
import json
from sdd.config import load
from sdd.localization_cli import prepare_catalog

root = Path(__file__).resolve().parent
base = root / 'inherited-c19/workspace/release'
config = load(base / 'issue248-publication.yaml')
original = load(base / 'publication.yaml')
old = json.loads(Path(original.site.english_catalog).read_text(encoding='utf-8'))['strings']
report = prepare_catalog(config, Path(config.site.english_catalog), translate=True)
new = json.loads(Path(config.site.english_catalog).read_text(encoding='utf-8'))['strings']
assert report['missing_translations'] == 0
assert all(new[key] == old[key] for key in new.keys() & old.keys())
report['new_pairs'] = {key: new[key] for key in new.keys() - old.keys()}
report['removed_keys'] = sorted(old.keys() - new.keys())
report['retained_pairs'] = len(new.keys() & old.keys())
(root / 'translation-c19.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in report.items() if k != 'new_pairs'}, ensure_ascii=False), flush=True)
