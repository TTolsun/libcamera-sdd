"""Run the generator's current citation checks on inherited native graph records."""
import hashlib
import json
from pathlib import Path
import sys

from sdd import generated_visuals
from sdd.config import load, section_output
from sdd.document_metadata import split_frontmatter
from sdd.facts.model import KnowledgeModel
from sdd.render_profiles import for_page

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root.parents[2] / 'examples/libcamera/validation/issue252'))
from revalidate_visuals import NoInference, replace_visual_metadata

base = root / 'inherited-c19/workspace/release'
config = load(base / 'issue248-publication.yaml')
model = KnowledgeModel.load(config.facts_path)
rows = []
pending = {}
for section in config.sections():
    page = section_output(section)
    path = config.sdd_dir / page
    if not path.is_file() or not generated_visuals.plans(config, section):
        continue
    selected = for_page(config, page)
    original = path.read_bytes()
    text = original.decode('utf-8').replace('\r\n', '\n')
    metadata, body = split_frontmatter(text)
    try:
        generated_visuals.resolve(selected, model, section, metadata.get('generated_visuals'))
    except ValueError as error:
        if 'needs recorded citation revalidation' not in str(error):
            raise
        artifact = generated_visuals.generate(selected, model, section, NoInference(), text)
        assert all(row['reused'] for row in artifact['records'].values())
        artifact['body_sha256'] = hashlib.sha256(body.strip().encode()).hexdigest()
        generated_visuals.resolve(selected, model, section, artifact)
        updated = replace_visual_metadata(original, artifact)
        assert split_frontmatter(updated.decode('utf-8').replace('\r\n', '\n'))[1] == body
        pending[path] = updated
        rows.append(dict(page=page, before_sha256=hashlib.sha256(original).hexdigest(),
                         after_sha256=hashlib.sha256(updated).hexdigest(),
                         graph_records=len(artifact['records']), body_unchanged=True, new_inference=False))
for path, updated in pending.items():
    path.write_bytes(updated)
report = dict(status='passed', source_commit=model.meta['source_commit'], pages=rows, new_cli_calls=0,
              citation_binding_policy=generated_visuals.CITATION_BINDING_POLICY, human_review='pending')
(root / 'visual-revalidation-c19.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, ensure_ascii=False), flush=True)
