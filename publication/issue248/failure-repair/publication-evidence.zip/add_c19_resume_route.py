from pathlib import Path
import json

from sdd.config import load
from sdd.localization_cli import prepare_catalog
from sdd.trial_workspace import write_snapshot

root = Path(__file__).resolve().parent
base = root / 'inherited-c19/workspace/release'
path = base / 'issue248-publication-final.yaml'
config = load(path)
target = dict(section='request-diagnosis', topic='diagnosis', label='제보와 관측을 구분해 조사 메모 남기기')
links = config.raw['site']['topic_links']['request-lifecycle.md']['journey']
if target not in links:
    links.append(target)
for name in ('issue248-publication-final.yaml', 'issue248-review-final.yaml', 'issue248-translation-final.yaml'):
    write_snapshot(config, base / name)
config = load(path)
catalog = Path(config.site.english_catalog)
report = prepare_catalog(config, catalog, translate=True)
assert report['missing_translations'] == 0
values = json.loads(catalog.read_text(encoding='utf-8'))['strings']
report['resume_route'] = {target['label']: values[target['label']]}
(root / 'c19-resume-route-catalog.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, ensure_ascii=False), flush=True)
