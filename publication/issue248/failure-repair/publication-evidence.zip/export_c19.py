from pathlib import Path
import datetime
import hashlib
import json
import shutil

from sdd.config import load
from sdd.export_site import export_site
from sdd.site_build import verify_site
from sdd.trial_workspace import write_snapshot

root = Path(__file__).resolve().parent
base = root / 'inherited-c19/workspace/release'
path = base / 'issue248-publication-final.yaml'
config = load(path)
audit_path = config.build_dir / 'consistency-review.json'
audit = json.loads(audit_path.read_text(encoding='utf-8'))
assert audit['status'] == 'passed' and audit['human_review'] == 'pending'
for row in config.raw['publication']['reports']:
    if (config.root / row['path']).resolve() == audit_path:
        row['sha256'] = hashlib.sha256(audit_path.read_bytes()).hexdigest()
for name, key, value, producer in (
    ('review-c19-language/final/review.json', 'verdict', 'faithful', 'independent-bilingual-review-c19'),
    ('visual-revalidation-c19.json', 'status', 'passed', 'current-citation-policy-revalidation'),
    ('candidate-c19.json', 'status', 'prepared', 'source-window-equivalence-and-managed-visual-refresh'),
):
    file = root / name
    data = json.loads(file.read_text(encoding='utf-8'))
    assert data[key] == value
    row = dict(path=str(file), sha256=hashlib.sha256(file.read_bytes()).hexdigest(), gate='before-export',
               producer=producer, bindings={key: value})
    if row not in config.raw['publication']['reports']:
        config.raw['publication']['reports'].append(row)
write_snapshot(config, path)
config = load(path)
first = export_site(config, root / 'site-release')
second = export_site(config, root / 'site-release-repeat')
raw = (first / 'site-manifest.json').read_bytes()
assert raw == (second / 'site-manifest.json').read_bytes()
manifest = json.loads(raw)
prior = json.loads((root / 'inherited-c19/public-site-manifest.json').read_text(encoding='utf-8'))
changed = [name for name, sha in manifest['outputs'].items() if prior['outputs'].get(name) != sha]
expected = {'overview.md'} | {row['page'] for row in json.loads((root / 'visual-revalidation-c19.json').read_text(encoding='utf-8'))['pages']}
assert {name for name in changed if name.endswith('.md')} == expected
assert manifest['outputs'].keys() == prior['outputs'].keys()
report = dict(status='verified', build_id=manifest['build_id'], manifest_sha256=hashlib.sha256(raw).hexdigest(),
              source_commit=audit['source_commit'], owned_outputs=len(manifest['outputs']),
              changed_outputs=changed, manuscript_bytes_changed=sorted(expected),
              quality=verify_site(first), repeat_quality=verify_site(second), identical_repeat_manifest=True,
              standard_audit_fresh_batches=audit['fresh_batches'], standard_audit_reused_batches=audit['reused_batches'],
              standard_audit_source_equivalent_batches=audit.get('source_equivalent_batches', 0),
              unresolved_findings=len(audit['unresolved']), actual_human_participants=0)
(root / 'site-verification-c19.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
focused = root / 'c19-focused'
focused.mkdir(exist_ok=True)
shutil.copytree(first, focused / 'site-trial', dirs_exist_ok=True)
shutil.copyfile(root / 'reader_browser.cjs', focused / 'reader_browser.cjs')
shutil.copytree(root / 'participant-inputs', focused / 'participant-inputs', dirs_exist_ok=True)
lock = dict(build_id=manifest['build_id'], manifest_sha256=report['manifest_sha256'],
            source_commit=report['source_commit'], start_url='https://frozen-sdd.test/index.html',
            parent_protocol_sha256=hashlib.sha256((root / 'protocol.json').read_bytes()).hexdigest(),
            browser_helper_sha256=hashlib.sha256((focused / 'reader_browser.cjs').read_bytes()).hexdigest(),
            frozen_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            scope='One fresh automatic role performs only the original S and R on this final candidate. '
                  'Same fixed minimums; no authoring history, first trial or rubric provided. R waits at least 300 seconds.',
            source_kind='agent', actual_human_participants=0)
(focused / 'reader-lock.json').write_text(json.dumps(lock, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, ensure_ascii=False), flush=True)
