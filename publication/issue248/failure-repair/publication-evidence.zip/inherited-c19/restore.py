import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tarfile

import yaml

root = Path(__file__).resolve().parent
project = root.parents[3]
repository = root.parents[1] / 'public-evaluation-release'
release_commit = '76a4640c0b91c9b340c807c40f1bf6bc378385c3'
source_commit = 'c19d05128f3ae1f0ebe63acb4deaca9fbb1dde78'
runtime_commit = '02159b94968b29970de7a6f79a6d6e08feb107a9'
source = root / 'source-c19'
original = root / 'original' / 'release'
workspace = root / 'workspace' / 'release'
workspace.mkdir(parents=True, exist_ok=True)
shutil.copytree(original, workspace, dirs_exist_ok=True)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    return digest(path.read_bytes())


def git_blob(commit, path, repo=repository):
    return subprocess.check_output(['git', 'show', f'{commit}:{path}'], cwd=repo)


def git_paths(commit, path, repo):
    data = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', '-z', commit, '--', path], cwd=repo)
    return [p.decode('utf-8') for p in data.split(b'\0') if p]


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, path
    else:
        path.write_bytes(data)


release = json.loads((root / 'public-release.json').read_bytes())
archive_index = json.loads((root / 'public-release-index.json').read_bytes())
assert sha(root / 'public-release-evidence.tar.gz') == release['archive_sha256']
assert sha(root / 'public-release-index.json') == release['archive_index_sha256']
assert len(archive_index) == release['archive_files']
for name, expected in archive_index.items():
    data = (root / 'original' / name).read_bytes()
    assert len(data) == expected['bytes'] and digest(data) == expected['sha256'], name

manifest_raw = git_blob(release_commit, 'docs/site-manifest.json')
manifest = json.loads(manifest_raw)
assert digest(manifest_raw) == release['manifest_sha256']
assert manifest['build_id'] == release['build_id']
write(root / 'public-site-manifest.json', manifest_raw)
inputs = manifest['inputs']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == source_commit
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source, text=True)

pr98 = root / 'pr98-package'
baseline_index = json.loads((pr98 / 'archive-index.json').read_bytes())
baseline_package = json.loads((pr98 / 'package.json').read_bytes())
baseline_archive = pr98 / 'native-and-public-evidence.tar.gz'
assert sha(baseline_archive) == baseline_package['archive_sha256']
assert len(baseline_index) == baseline_package['entries']
baseline_member = 'base/config/sections.yaml'
baseline_target = workspace / 'prior98' / baseline_member
seen = set()
with tarfile.open(baseline_archive) as archive:
    for member in archive:
        assert member.isfile() and member.name not in seen and member.name in baseline_index
        raw = archive.extractfile(member).read()
        assert digest(raw) == baseline_index[member.name], member.name
        if member.name == baseline_member:
            write(baseline_target, raw)
        seen.add(member.name)
assert seen == set(baseline_index) and baseline_target.is_file()

old = root.parent / 'inherited' / 'original'
old_style_index = json.loads((old / 'resolved-inputs/index.json').read_bytes())
intro = (old / 'run-05/site-intro.md').read_bytes()
assert digest(intro) == inputs['intro']
write(workspace / 'site-intro.md', intro)
runtime_assets = root / 'workspace' / 'runtime-assets'
for item in ('style', 'templates', 'examples/libcamera/prompts'):
    paths = git_paths(runtime_commit, item, project)
    assert paths, item
    for rel in paths:
        write(runtime_assets / rel, git_blob(runtime_commit, rel, project))

mermaid = root / 'workspace' / 'mermaid'
for rel in git_paths(release_commit, 'docs/assets/mermaid', repository):
    raw = git_blob(release_commit, rel)
    assert digest(raw) == manifest['outputs'][rel.removeprefix('docs/')]
    write(mermaid / rel.removeprefix('docs/assets/mermaid/'), raw)
assert (mermaid / 'mermaid.esm.min.mjs').is_file()

products_path = workspace / 'config/products.yaml'
products = yaml.safe_load(products_path.read_bytes())
assert sha(products_path) == inputs['products/0']
product_evidence = {}
for n, row in enumerate(products['evidence'], 1):
    rel = PurePosixPath(row['file'])
    assert not rel.is_absolute() and '..' not in rel.parts
    raw = (old / 'run-05/config' / rel).read_bytes()
    assert digest(raw) == row['sha256'] == inputs[f'products/{n}'], str(rel)
    write(products_path.parent / rel, raw)
    product_evidence[str(rel)] = digest(raw)

historical_cfg = yaml.safe_load((original / 'publication.yaml').read_bytes())
historic_root = str(historical_cfg['output']['sdd_dir']).rsplit('\\', 1)[0]


def normalized(path):
    return str(path).replace('\\', '/').casefold()


substitutions = {}
for key, path in {'prompts': runtime_assets / 'examples/libcamera/prompts',
                  'templates': runtime_assets / 'templates', 'style': runtime_assets / 'style'}.items():
    substitutions[normalized(historical_cfg['paths'][key])] = path
substitutions[normalized(historical_cfg['site']['mermaid_dir'])] = mermaid
substitutions[normalized(historical_cfg['source']['root'])] = source
compdb = root / 'original/source/clang/compile_commands.json'
assert compdb.is_file()
substitutions[normalized(historical_cfg['source']['compile_commands'])] = compdb
regression = next(row for row in historical_cfg['publication']['reports'] if row['producer'] == 'generator-ci')
raw = git_blob(release_commit, 'publication/issue253-contract-reuse/regression.json')
assert digest(raw) == regression['sha256']
regression_path = workspace / 'restored-regression.json'
write(regression_path, raw)
substitutions[normalized(regression['path'])] = regression_path

profile_styles = {}
unavailable_unused = {}
profile_dir = original / 'profiles'
active_profile_paths = historical_cfg['site']['manuscript_profiles']
for profile_file in sorted(profile_dir.glob('*.yaml')):
    profile = yaml.safe_load(profile_file.read_bytes())
    original_style = profile['paths']['style']
    target = root / 'workspace' / 'profile-styles' / profile_file.stem
    expected = {path.rsplit('/', 1)[-1]: expected_sha for path, expected_sha in inputs.items()
                if path.startswith('editorial/style/') and path.rsplit('/', 1)[0].removeprefix('editorial/style/')
                in {page for page, owner in active_profile_paths.items() if Path(owner).name == profile_file.name}}
    matched = [row for row in old_style_index
               if normalized(row['original_path']).rsplit('/', 1)[0] == normalized(original_style)]
    copied = {}
    if matched:
        for row in matched:
            raw = (old / row['snapshot']).read_bytes()
            assert digest(raw) == row['sha256']
            name = PurePosixPath(row['snapshot']).name
            write(target / name, raw)
            copied[name] = digest(raw)
    elif not expected:
        unavailable_unused[profile_file.name] = original_style
        continue
    else:
        raise AssertionError(f'Active style source missing for {profile_file.name}')
    assert all(copied.get(name) == value for name, value in expected.items()), profile_file.name
    substitutions[normalized(original_style)] = target
    profile_styles[profile_file.name] = copied

for name, expected in inputs.items():
    if name.startswith('editorial/style/default/'):
        assert sha(runtime_assets / 'style' / name.rsplit('/', 1)[-1]) == expected

def remap(item):
    if isinstance(item, dict):
        return {key: remap(value) for key, value in item.items()}
    if isinstance(item, list):
        return [remap(value) for value in item]
    if isinstance(item, str) and re.match(r'^[A-Za-z]:[\\/]', item):
        key = normalized(item)
        if key in substitutions:
            return str(substitutions[key])
        prefix = normalized(historic_root) + '/'
        if key.startswith(prefix):
            return str(workspace / item.replace('\\', '/')[len(prefix):])
    return item

def config_copy(name):
    raw = yaml.safe_load((original / name).read_bytes())
    relocated = remap(raw)
    (workspace / name).write_text(yaml.safe_dump(relocated, allow_unicode=True, sort_keys=False), encoding='utf-8', newline='\n')

for name in ('publication.yaml', 'review.yaml', 'baseline98.yaml', 'generation.yaml', 'publication-pending.yaml',
             'translation.yaml', *(str(path.relative_to(original)) for path in profile_dir.glob('*.yaml'))):
    config_copy(name)

manuscripts = {}
for name, expected in manifest['outputs'].items():
    if name.endswith('.md'):
        original_input = workspace / 'manuscripts' / name
        assert sha(original_input) == inputs['markdown/' + name] == expected == digest(git_blob(release_commit, 'docs/' + name)), name
        manuscripts[name] = expected
assert len(manuscripts) == 29
for key, rel in {'facts': 'facts/facts.json', 'english_catalog': 'english.json', 'sections': 'config/sections.yaml',
                 'visuals': 'config/visuals.yaml', 'reader_paths': 'reader-paths.yaml', 'intro': 'site-intro.md',
                 'consistency_configuration': 'config/contracts.yaml', 'consistency_review': 'build/consistency-review.json'}.items():
    assert sha(workspace / rel) == inputs[key], key
assert json.loads((workspace / 'facts/facts.json').read_bytes())['meta']['source_commit'] == source_commit
for page, path in active_profile_paths.items():
    assert sha(profile_dir / Path(path).name) == inputs['editorial/profile/' + page], page

native = {}
for rel in ('build/cli-checkpoints', 'build/prompts', 'build/translation-prompts'):
    archive_files = {p.relative_to(original).as_posix(): sha(p) for p in (original / rel).rglob('*') if p.is_file()}
    assert archive_files
    for name, expected in archive_files.items():
        assert sha(workspace / name) == expected
    native[rel] = {'files': len(archive_files), 'receipt_count': sum(name.endswith('.receipt.json') for name in archive_files),
                   'path': str(workspace / rel), 'all_original_sha256_verified': True}

sys.path.insert(0, str(project / 'src'))
from sdd.config import load
from sdd.publication_plan import check_baseline, check_catalog, check_reports
from sdd.validation_execution import staged

cfg = load(workspace / 'publication.yaml')
assert cfg.agent.kind == 'cli' and cfg.agent.runner == 'codex' and cfg.agent.model == 'gpt-6.1-terra'
assert cfg.agent.args == ['-c', 'model_reasoning_effort="high"']

@staged
def preflight(config):
    check_baseline(config)
    check_catalog(config)
    check_reports(config, 'before-export')
    return len(config.sections())

missing = {key: str(path) for key, path in cfg.paths.items() if not path.exists()}
assert not missing, missing
sections_count = preflight(cfg)
profile_hashes = {p.name: {'archive': sha(p), 'relocated_yaml': sha(workspace / 'profiles' / p.name)}
                  for p in profile_dir.glob('*.yaml')}
report = dict(status='restored-loadable-config', public_commit=release_commit, source_commit=source_commit,
              published_build_id=manifest['build_id'], manifest_sha256=digest(manifest_raw), archive_entries_verified=len(archive_index),
              configuration=str(workspace / 'publication.yaml'), review_configuration=str(workspace / 'review.yaml'),
              source_checkout=str(source), clean_source_checkout=True, compile_commands=str(compdb),
              compile_commands_scope='Preserved original WSL extraction paths. New extraction requires a local compdb.',
              current_manuscripts_count=len(manuscripts), current_manuscript_sha256=manuscripts, current_facts_sha256=inputs['facts'],
              current_catalog_sha256=inputs['english_catalog'], source_profiles=profile_hashes, profile_styles=profile_styles,
              historical_unused_profile_style_paths_unresolved=unavailable_unused, manifest_pinned_runtime_assets=runtime_commit,
              supplemental_baseline=dict(public_pr=98, archive_entries_verified=len(seen), sections_sha256=sha(baseline_target)),
              product_evidence_sha256=product_evidence, native_cache=native, missing_required_paths=missing,
              baseline_catalog_report_preflight='passed', sections_count=sections_count,
              changes_from_public_original='Only operating YAML absolute paths relocated. Archive YAML and all inputs remain intact.',
              initial_failure='First relocation found site-intro.md omitted by the c19 archive. Restored earlier archived bytes matching the c19 published input SHA256.',
              next_checks='Run current runtime manuscript, contract identity and receipt gates, translation coverage, and normal export.',
              fresh_cli_calls=0, generated=False, exported=False)
(root / 'restoration.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: report[k] for k in ('status', 'archive_entries_verified', 'configuration', 'source_checkout',
                                       'current_manuscripts_count', 'baseline_catalog_report_preflight', 'native_cache')}, indent=2))
