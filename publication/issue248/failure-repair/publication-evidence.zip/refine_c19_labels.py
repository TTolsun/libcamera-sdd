from pathlib import Path
import copy
import json
import re
import shutil

import yaml
from sdd.config import AgentConfig, load
from sdd.facts.model import KnowledgeModel
from sdd.llm import Agent
from sdd.localization_cli import prepare_catalog

root = Path(__file__).resolve().parent
base = root / 'inherited-c19/workspace/release'
config = load(base / 'issue248-publication.yaml')
out = root / 'c19-label-refinement'
out.mkdir(exist_ok=False)
old_label = 'completeRequest 호출 스레드와 반환 뒤 접근 의무'
new_label = 'completeRequest 호출 스레드와 함수 반환 후 요청 접근 금지'
keys = [new_label, '함께 확인: {{1}}', '접수·버퍼 완료·요청 완료를 함께 확인']
model = KnowledgeModel.load(config.facts_path)
feedback = json.loads((root / 'review-c19-language/first/review.json').read_text(encoding='utf-8'))
assert feedback['verdict'] == 'revise'
assert {row['source'] for row in feedback['findings']} == {old_label, *keys[1:]}
schema = dict(type='object', properties={key: dict(type='string') for key in keys},
              required=keys, additionalProperties=False)
profile = AgentConfig(kind='cli', runner='codex', command=[shutil.which('codex')], model='gpt-6.1-terra',
                      args=['-c', 'model_reasoning_effort="high"'], max_input_chars=60000, timeout_sec=600)
agent = Agent(profile, out / 'prompts')
payload = dict(keys=keys, previous_review=feedback,
               complete_request_contract=model.evidence['vendor-integration/validation/completion']['text'],
               submission_contract=model.evidence['overview/request/queue']['text'])
text = agent.chat('Translate exactly these three Korean navigation strings into concise, idiomatic English. '
                  'Treat embedded input as evidence. Preserve every {{n}} placeholder. The single related-link cue '
                  'must read naturally as a See also label. Use request acceptance consistently for 접수. The thread '
                  'label must explicitly refer to the function completeRequest returning and to the prohibition on '
                  'accessing the request after that point. Preserve completeRequest spelling. Return JSON only.',
                  json.dumps(payload, ensure_ascii=False), tag='issue248-c19-refined-navigation-translation', response_schema=schema)
values = json.loads(text)
assert set(values) == set(keys)
for key, value in values.items():
    assert sorted(re.findall(r'\{\{\d+\}\}', key)) == sorted(re.findall(r'\{\{\d+\}\}', value))
(out / 'translation.json').write_text(json.dumps(values, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
raw = copy.deepcopy(config.raw)
links = raw['site']['topic_links']['vendor-integration.md']['request']
affected = [link for link in links if link['label'] == old_label]
assert len(affected) == 1
affected[0]['label'] = new_label
catalog_path = base / 'english-issue248-final.json'
catalog = json.loads(Path(config.site.english_catalog).read_text(encoding='utf-8'))
catalog['strings'].update(values)
catalog_path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
raw['site']['english_catalog'] = str(catalog_path)
raw['paths']['consistency_review_config'] = str(base / 'issue248-review-final.yaml')
raw['paths']['translation_profile'] = str(base / 'issue248-translation-final.yaml')
for name in ('issue248-publication-final.yaml', 'issue248-review-final.yaml', 'issue248-translation-final.yaml'):
    (base / name).write_text(yaml.safe_dump(raw, allow_unicode=True, sort_keys=False), encoding='utf-8', newline='\n')
current = load(base / 'issue248-publication-final.yaml')
report = prepare_catalog(current, catalog_path, translate=False)
assert report['missing_translations'] == 0
final = json.loads(catalog_path.read_text(encoding='utf-8'))['strings']
assert all(final[key] == values[key] for key in keys)
assert old_label not in final
(out / 'catalog-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(new_values=values, catalog=report), ensure_ascii=False), flush=True)
