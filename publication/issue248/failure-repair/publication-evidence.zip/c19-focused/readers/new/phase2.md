# R 재개 기록

빌드 `d7de4e291f0e8b920d07d71d92481b22a1d523b0c4411dbd59cdf742f576d433`의 자동 첫 독자 기록이다. 중단 전 메모 SHA-256은 `e8f11d746b9bcec9835130b8148152e0d9628712cf96cefd16cc3ed95970a702`이며 저장 시점의 해시와 같다.

## 재개 후 원답

메모에서 이어갈 상태는 완료 누락 제보를 받은 뒤 문서에서 조사 지점을 찾아 둔 단계다. 제보에는 제출 성공과 완료 알림을 보지 못했다는 내용이 있다. 내게 실제 실행 관측값은 없다. 정확한 반환값과 호출 파일, 대상 제출 회차, 버퍼 수, 관측 시간, 큐 상태, 장치 제출·완료, 앱 콜백 연결과 실행 여부는 미확인이다.

가장 먼저 기존 Camera::queueRequest 호출의 파일과 반환값을 같은 제출 회차로 기록한다. 0이면 비동기 처리 접수로 해석하고 다음 단계로 간다. 음수이면 제출 오류 쪽을 조사한다. 값을 확인하기 위해 요청을 다시 제출하지 않는다.

접수됐다면 doQueueRequests에서 waitingRequests_의 대기 여부와 queuedRequests_.size()가 maxQueuedRequestsDevice_에 도달했는지 확인한다. 한도에 이르면 장치 전달이 대기한다. 한도에 이르지 않았다면 선두의 prepared_ 값을 확인하고, 거짓이면 펜스 신호와 준비 만료·취소를 확인한다. doQueueRequest까지 갔다면 cancelled_와 장치 반환값을 기록한다. 이미 취소된 요청은 장치 제출을 건너뛰어 completeRequest로 가고, 기존 queueRequestDevice의 결과가 0이 아니면 cancelRequest 경로를 본다.

장치 제출에 성공했다면 같은 회차의 bufferCompleted 알림과 기존 completeBuffer 반환값을 따로 관찰한다. false면 아직 남은 버퍼를 찾고, true면 핸들러의 명시적 completeRequest 호출을 확인한다. 이 함수에 진입했다면 queuedRequests_ 선두가 RequestPending인지 확인한다. 선두가 대기 중이면 뒤 요청의 내부 처리가 끝났어도 앱 반환이 기다린다. camera->requestComplete 통지 호출까지 확인된 뒤에도 앱에서 requestCompleted를 보지 못했다면 연결 위치·방식과 콜백 진입·복귀 시각, 실행 스레드를 기록한다. 주소나 cookie만으로 묶지 않고 요청이 유효할 때 기록한 제출 회차를 사용한다.

## 확인한 근거

- 원래 제출 반환값으로 첫 분기를 고른다. 대기 큐와 선두 준비 상태, 장치 제출과 취소, 버퍼 완료와 요청 완료, 선두의 반환 대기를 단계마다 확인한다. [구성과 요청 오류 조사 / 실패 위치별 확인 순서](https://frozen-sdd.test/request-diagnosis.html#%EC%8B%A4%ED%8C%A8-%EC%9C%84%EC%B9%98%EB%B3%84-%ED%99%95%EC%9D%B8-%EC%88%9C%EC%84%9C)
- 획득 펜스의 대기와 준비 만료에 따른 취소를 확인한다. 장치 큐 한도와 선두 준비 상태가 장치 제출을 막는 조건을 설명한다. [Pipeline 요청 제출과 완료 / 요청 준비와 장치 큐](https://frozen-sdd.test/pipeline-requests.html#%EC%9A%94%EC%B2%AD-%EC%A4%80%EB%B9%84%EC%99%80-%EC%9E%A5%EC%B9%98-%ED%81%90)
- 같은 제출 회차의 completeRequest 진입과 requestComplete 통지를 따로 기록하고, 앱의 연결 방식과 콜백 진입·복귀 시각 및 스레드를 관찰한다. [요청 처리와 문제 진단 / 정지와 연결 해제를 구분하기](https://frozen-sdd.test/request-lifecycle.html#%EC%A0%95%EC%A7%80%EC%99%80-%EC%97%B0%EA%B2%B0-%ED%95%B4%EC%A0%9C%EB%A5%BC-%EA%B5%AC%EB%B6%84%ED%95%98%EA%B8%B0)

## 방문 경로와 시간

- 중단 UTC 2026-11-11T19:00:21.3636005Z
- 재개 및 메모 해시 확인 시작 UTC 2026-11-11T19:05:55.6815002Z. 중단 경과 334.318초.
- 진단 절 도착 UTC 2026-11-11T19:06:18.649Z. 재개 뒤 22.967초.
- 마지막 근거 읽기 완료 UTC 2026-11-11T19:06:36.643Z
- 원답 정리 완료 UTC 2026-11-11T19:08:38.8685459Z. 재개 뒤 163.187초.

- 2026-11-11T19:06:02.123Z → 2026-11-11T19:06:04.159Z [index.html](https://frozen-sdd.test/index.html)
- 2026-11-11T19:06:08.076Z → 2026-11-11T19:06:09.866Z [request-lifecycle.html](https://frozen-sdd.test/request-lifecycle.html)
- 2026-11-11T19:06:16.876Z → 2026-11-11T19:06:18.649Z [request-diagnosis.html#실패-위치별-확인-순서](https://frozen-sdd.test/request-diagnosis.html#%EC%8B%A4%ED%8C%A8-%EC%9C%84%EC%B9%98%EB%B3%84-%ED%99%95%EC%9D%B8-%EC%88%9C%EC%84%9C)
- 2026-11-11T19:06:29.122Z → 2026-11-11T19:06:30.887Z [pipeline-requests.html#요청-준비와-장치-큐](https://frozen-sdd.test/pipeline-requests.html#%EC%9A%94%EC%B2%AD-%EC%A4%80%EB%B9%84%EC%99%80-%EC%9E%A5%EC%B9%98-%ED%81%90)
- 2026-11-11T19:06:34.838Z → 2026-11-11T19:06:36.643Z [request-lifecycle.html#정지와-연결-해제를-구분하기](https://frozen-sdd.test/request-lifecycle.html#%EC%A0%95%EC%A7%80%EC%99%80-%EC%97%B0%EA%B2%B0-%ED%95%B4%EC%A0%9C%EB%A5%BC-%EA%B5%AC%EB%B6%84%ED%95%98%EA%B8%B0)

진단 절에서 준비 대기와 앱 콜백 링크를 확인했다. 준비 대기 절을 읽은 뒤 앱 콜백 링크로 앞서 본 요청 처리 문서에 돌아왔다. 링크는 ‘정지와 연결 해제를 구분하기’로 연결됐다. 그 절 아래에서 콜백 관찰 문단을 찾았다. 원래 실행 로그와 기기가 없어 관측값을 확인할 수 없었다. 도움을 요청하거나 받지 않았다.

## 읽은 뒤 평가

- 읽기 쉬움 4/5. 시작 화면과 조사 메모 링크를 따라 첫 관측 지점을 빠르게 찾았다. 콜백 링크는 정지 절 첫머리로 연결되어 본문에서 관찰 계획을 찾아야 했다.
- 흥미 4/5. 장치 제출을 건너뛰는 취소와 제출 순서 때문에 앱 통지가 지연되는 경우가 서로 다른 확인 지점으로 이어졌다.
- 문장의 자연스러움 4/5. 분기 조건과 변수 이름은 읽기 편했다. 조사 항목을 설명하는 문장에서 ‘관찰’과 ‘확인’이 반복되어 긴 절은 다시 훑었다.
