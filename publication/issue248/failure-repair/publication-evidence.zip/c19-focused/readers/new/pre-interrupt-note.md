제보는 “제출 성공을 반환했는데 완료 알림이 없다”이다. 지금까지는 문서에서 정상 경로와 분기 위치를 찾았다. 원래 호출의 로그나 기기에는 접근하지 못했다. 호출 파일, 정확한 반환값과 제출 회차, 버퍼 수, 관측 시간, 실제 콜백 연결 상태는 모두 미확인이다.

돌아오면 원래 Camera::queueRequest 호출 위치와 반환값부터 기록하자. 0이면 비동기 처리 접수로 분류하고, 음수라면 제출 자체의 오류를 조사한다. 요청을 다시 큐에 넣어 확인하지 말고 기존 실행 기록이나 관측점을 사용한다. 동일한 제출 회차를 따라가며 먼저 doQueueRequests에서 waitingRequests_에 대기가 있는지, queuedRequests_.size()가 한도와 같은지, 선두 prepared_가 거짓인지 살펴본다. 선두가 준비되지 않았다면 fence 신호와 준비 만료·취소를 확인한다. 전달 단계에 도달했다면 cancelled_와 기존 queueRequestDevice의 반환값을 기록한다. 이미 취소됐으면 장치에 보내기 전에 completeRequest로 가고, 장치 반환이 0이 아니면 cancelRequest로 간다.

장치가 접수했다면 해당 요청·버퍼의 bufferCompleted와 기존 completeBuffer 반환값을 따로 확인한다. false면 남은 버퍼를 찾고, true면 completeRequest 호출 여부를 확인한다. 이 호출까지 확인되면 queuedRequests_의 선두가 RequestPending인지 확인한다. 선두가 대기 중이면 뒤의 완료된 요청도 앱에 반환되지 않는다. 해당 요청이 camera->requestComplete를 통해 반환됐는데 앱에서 신호를 못 봤다면 앱의 requestCompleted 연결 위치·방식과 콜백 진입 시각·스레드를 확인한다. 같은 주소나 cookie가 재사용될 수 있으므로 유효할 때 확보한 제출 회차를 기준으로 로그를 대조한다. 현재는 이 중 어느 분기가 실제로 일어났는지 모른다.

시작 화면의 ‘요청 처리와 문제 진단’ → ‘제보와 관측을 구분해 조사 메모 남기기’로 다시 들어갈 수 있다. 내가 확인한 근거는 https://frozen-sdd.test/request-diagnosis.html#실패-위치별-확인-순서 (원 호출 기록, 큐 조건, 장치 반환값, 버퍼와 전체 완료), https://frozen-sdd.test/pipeline-requests.html#요청-준비와-장치-큐 (펜스 준비와 취소), https://frozen-sdd.test/request-lifecycle.html#정지와-연결-해제를-구분하기 (앱 연결·콜백 관찰, 제출 회차 대조)다.
