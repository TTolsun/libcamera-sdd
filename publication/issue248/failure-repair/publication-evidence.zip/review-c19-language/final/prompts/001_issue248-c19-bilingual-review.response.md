{"verdict":"faithful","findings":[],"human_review":"pending"}
