const { chromium } = require('C:/Users/baboe/.codex/worktrees/cb18/camera-hal-sdd-generator/build/pan-20261105/pw/node_modules/playwright');
const fs = require('node:fs/promises');
const path = require('node:path');
const assert = require('node:assert/strict');

const [mode, destination, site] = process.argv.slice(2);
const local = mode === 'local';
const base = local ? 'https://frozen-sdd.test/' : 'https://ttolsun.github.io/libcamera-sdd/';
const paths = ['overview.html', 'vendor-integration.html', 'request-lifecycle.html', 'request-diagnosis.html'];
const type = {'.mjs': 'application/javascript', '.js': 'application/javascript', '.css': 'text/css', '.html': 'text/html', '.json': 'application/json'};

async function follow(page, link, pathname) {
  const href = await link.getAttribute('href');
  assert(href && href.includes('#'));
  await link.click();
  assert(new URL(page.url()).pathname.endsWith(pathname));
  const target = decodeURIComponent(new URL(page.url()).hash.slice(1));
  assert(target && await page.evaluate(id => document.getElementById(id)?.tagName === 'H2', target));
  return target;
}

async function main() {
  await fs.mkdir(destination, {recursive: true});
  const manifest = local ? JSON.parse(await fs.readFile(path.join(site, 'site-manifest.json'), 'utf8')) : null;
  const browser = await chromium.launch({channel: 'chrome', headless: true});
  const report = {base, mode, engine: browser.version(), results: []};
  try {
    for (const mobile of [false, true]) {
      for (const lang of ['ko', 'en']) {
        for (const file of paths) {
          const viewport = mobile ? {width: 390, height: 844} : {width: 1280, height: 900};
          const context = await browser.newContext({viewport, isMobile: mobile, hasTouch: mobile});
          if (local) {
            await context.route('**/*', async route => {
              const url = new URL(route.request().url());
              const relative = decodeURIComponent(url.pathname.slice(1));
              if (url.origin !== new URL(base).origin || !manifest.outputs[relative]) return route.abort();
              return route.fulfill({path: path.join(site, relative), contentType: type[path.extname(relative)]});
            });
          }
          const page = await context.newPage();
          const errors = [];
          page.on('pageerror', error => errors.push(String(error)));
          const prefix = lang === 'en' ? 'en/' : '';
          const response = await page.goto(base + prefix + file, {waitUntil: 'networkidle'});
          assert(response.ok());
          const row = {file, lang, mobile};
          const screenshot = `${file.replace('.html', '')}-${lang}-${mobile ? 'mobile' : 'desktop'}.png`;
          if (file === 'overview.html') {
            const diagram = page.locator('article h3[id="요청-접수와-버퍼-완료-요청-완료"] + pre.mermaid[data-ready="true"]');
            await diagram.waitFor({state: 'visible'});
            assert.match(await diagram.textContent(), /completeBuffer/);
            assert.match(await diagram.textContent(), /completeRequest/);
            await diagram.click();
            await page.locator('#diagram-dialog[open]').waitFor({state: 'visible'});
            await page.locator('#node-search').fill('completeBuffer');
            assert.equal(await page.locator('#diagram-canvas .node.is-match').count(), 1);
            await page.screenshot({path: path.join(destination, screenshot)});
            await page.keyboard.press('Escape');
            assert(await diagram.evaluate(element => document.activeElement === element));
            row.diagramSearchAndFocus = true;
          } else if (file === 'vendor-integration.html') {
            const link = page.locator('article .reading-links a').filter({hasText: /completeRequest/});
            await link.scrollIntoViewIfNeeded();
            await page.screenshot({path: path.join(destination, screenshot)});
            row.target = await follow(page, link, 'vendor-integration.html');
            assert.match(await page.locator('article').innerText(), /completeRequest[\s\S]*CameraManager/);
          } else if (file === 'request-lifecycle.html') {
            const guide = page.locator('article .reading-links a[href^="overview.html#"]');
            const memo = page.locator('article .reading-links a[href^="request-diagnosis.html#"]');
            assert.equal(await guide.count(), 1);
            await memo.scrollIntoViewIfNeeded();
            await page.screenshot({path: path.join(destination, screenshot)});
            row.target = await follow(page, memo, 'request-diagnosis.html');
            await page.locator('article aside.reading-checkpoint').waitFor({state: 'visible'});
          } else {
            const note = page.locator('article aside.reading-checkpoint');
            await note.scrollIntoViewIfNeeded();
            assert.equal(await note.locator('li').count(), 6);
            assert.equal(await note.locator('input,form,textarea').count(), 0);
            const label = await note.getAttribute('aria-label');
            assert.equal(/[가-힣]/.test(label), lang === 'ko');
            const text = await note.innerText();
            for (const pattern of (lang === 'ko' ? [/제보/, /관측/, /임시 가정/, /미확인/, /분기/, /근거/]
                                                : [/report/i, /observ/i, /assum/i, /unconfirm|verif/i, /branch/i, /support|evidence/i])) {
              assert.match(text, pattern);
            }
            await page.screenshot({path: path.join(destination, screenshot)});
            row.memoFields = 6;
          }
          const width = await page.evaluate(() => ({viewport: innerWidth, page: document.documentElement.scrollWidth}));
          assert(width.page <= width.viewport + 1);
          assert.deepEqual(errors, []);
          report.results.push({...row, width, errors});
          await context.close();
        }
      }
    }
  } finally {
    await browser.close();
  }
  await fs.writeFile(path.join(destination, 'report.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(`Verified ${report.results.length} Chrome contexts`);
}

main().catch(error => { console.error(error); process.exitCode = 1; });
