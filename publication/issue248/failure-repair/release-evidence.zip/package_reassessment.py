from pathlib import Path
import argparse
import hashlib
import json
import zipfile

from sdd.call_records import load_record
from sdd.cli_provenance import verify_cli_receipt
from sdd.config import AgentConfig

parser = argparse.ArgumentParser()
parser.add_argument('scope', choices=['study', 'publication', 'release'])
args = parser.parse_args()
root = Path(__file__).resolve().parent
scope = args.scope
files = set()

def add(path):
    path = path.resolve()
    path.relative_to(root)
    if not path.is_file():
        raise FileNotFoundError(path)
    files.add(path)

def add_tree(path, *, exclude=()):
    for item in path.rglob('*'):
        if item.is_file() and not any(part in exclude for part in item.relative_to(path).parts):
            add(item)

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def new_translation_records(working, original):
    archived = {digest(path) for path in original.rglob('*.receipt.json')}
    for path in working.rglob('*.receipt.json'):
        if digest(path) not in archived:
            add(path)

if scope == 'study':
    for name in ('protocol.json', 'reader-lock.json', 'reader-lock-before-browser-smoke.json', 'reader_browser.cjs',
                 'grade.py', 'summarize_trial.py', 'trial-summary.json', 'baseline/live-manifest.json',
                 'site-trial/site-manifest.json', 'site-verification.json', 'candidate.json',
                 'draft_visual.py', 'prepare_candidate.py', 'translate_candidate.py', 'translation.json',
                 'translation-delta.json', 'review_change.py', 'first-contract-attempt-outcome.json',
                 'second-contract-attempt-outcome.json', 'receipt-recovery.json', 'parallel_contracts.py',
                 'recover_current_receipts.py', 'recover_staged.py', 'regression-02.log',
                 'aria-regression.log', 'docs-links.log', 'regression-current-c19.log'):
        add(root / name)
    for pattern in ('visual-draft*.log', 'prepare-candidate*.log', 'change-review*.log', 'parallel-contracts*.log',
                    'receipt-recovery*.log', 'standard-consistency.log', 'export-candidate.log'):
        for path in root.glob(pattern):
            add(path)
    for directory in ('readers', 'participant-inputs', 'independent-grading', 'visual-repair',
                      'independent-change-review', 'current-policy-contracts'):
        add_tree(root / directory)
    report = root / 'current-policy-contracts-attempt02/results.json'
    add(report)
    for unit in read(report)['units']:
        for name in unit.get('receipts', []):
            add(root / name)
    working = root / 'inherited/workspace/run-05'
    add(working / 'build/consistency-review.json')
    new_translation_records(working / 'build/translation-prompts', root / 'inherited/original/run-05')
    add(root / 'inherited/restoration.json')
    add(root / 'inherited/baseline-export-conclusion.json')
elif scope == 'publication':
    for name in ('candidate-c19.json', 'visual-revalidation-c19.json', 'translation-c19.json',
                 'c19-resume-route-catalog.json', 'native-contracts-c19.json', 'site-verification-c19.json',
                 'site-release/site-manifest.json', 'inherited-c19/restoration.json', 'inherited-c19/restore.py',
                 'inherited-c19/public-release.json', 'inherited-c19/public-site-manifest.json',
                 'prepare_c19.py', 'revalidate_c19_visuals.py', 'translate_c19.py', 'review_c19_language.py',
                 'refine_c19_labels.py', 'add_c19_resume_route.py', 'review_current_contracts.py', 'export_c19.py',
                 'focused-summary.json', 'verify_c19_browser.cjs'):
        add(root / name)
    for pattern in ('*c19*.log', 'c19-resume-route.log'):
        for path in root.glob(pattern):
            add(path)
    for directory in ('review-c19-language', 'c19-label-refinement', 'c19-focused', 'ui-c19-local'):
        add_tree(root / directory, exclude=('site-trial',))
    working = root / 'inherited-c19/workspace/release'
    for unit in read(root / 'native-contracts-c19.json')['units']:
        for name in unit.get('receipts', []):
            path = Path(name)
            add(path if path.is_absolute() else working / 'build/prompts/calls' / path)
        add(working / 'build/cli-checkpoints' / unit['checkpoint'])
    for name in ('issue248-publication-final.yaml', 'issue248-review-final.yaml', 'issue248-translation-final.yaml',
                 'visuals-issue248.yaml', 'english-issue248-final.json', 'build/consistency-review.json'):
        add(working / name)
    for name in read(root / 'site-verification-c19.json')['manuscript_bytes_changed']:
        add(working / 'manuscripts-issue248' / name)
    for path in (working / 'build/generation-runs').glob('*.json'):
        if read(path).get('operation_id') == 'issue248-failed-task-repair-c19':
            add(path)
    new_translation_records(working / 'build/translation-prompts', root / 'inherited-c19/original/release')
else:
    for name in ('candidate-102.json', 'visual-revalidation-102.json', 'translation-102.json',
                 'native-contracts-102.json', 'site-verification-102.json', 'site-publish/site-manifest.json',
                 'inherited-102/pr102-site-manifest.json', 'inherited-102/restoration.json',
                 'reader-section-equivalence.json', 'focused-summary.json', 'trial-summary.json',
                 'publication-evidence-index.json', 'study-evidence-index.json', 'generator-merge.json',
                 'prepare_102.py', 'revalidate_102_visuals.py', 'translate_102.py', 'review_current_contracts.py',
                 'export_102.py', 'compare_reader_sections.py', 'verify_c19_browser.cjs', 'package_reassessment.py',
                 'regression-merged-base-102.log'):
        add(root / name)
    for path in root.glob('*102*.log'):
        add(path)
    for path in (root / 'inherited-102').glob('*.py'):
        add(path)
    add_tree(root / 'ui-102-local')
    working = root / 'inherited-102/workspace/release'
    for unit in read(root / 'native-contracts-102.json')['units']:
        for name in unit.get('receipts', []):
            path = Path(name)
            add(path if path.is_absolute() else working / 'build/prompts/calls' / path)
        add(working / 'build/cli-checkpoints' / unit['checkpoint'])
    for name in ('issue248-publication.yaml', 'issue248-review.yaml', 'issue248-translation.yaml',
                 'visuals-issue248.yaml', 'english-issue248.json', 'build/consistency-review.json'):
        add(working / name)
    for name in read(root / 'site-verification-102.json')['manuscript_bytes_changed']:
        add(working / 'manuscripts-issue248' / name)
    for path in (working / 'build/generation-runs').glob('*.json'):
        if read(path).get('operation_id') == 'issue248-failed-task-repair-102':
            add(path)

expected = AgentConfig(kind='cli', runner='codex', model='gpt-6.1-terra',
                       args=['-c', 'model_reasoning_effort="high"'])
verified = {}
for receipt in sorted(path for path in files if path.name.endswith('.receipt.json')):
    calls = receipt.parent.parent
    record = load_record(receipt, root=calls)
    result = verify_cli_receipt(record.request, record.raw, record.receipt, calls, expected)
    add(record.request_path)
    add(record.response_path)
    stdout = calls.parent / record.receipt['provider']['stdout_path']
    add(stdout)
    stderr = stdout.with_name(stdout.name.replace('.stdout.txt', '.stderr.txt'))
    if stderr.is_file():
        add(stderr)
    key = digest(receipt)
    verified.setdefault(key, dict(receipt=str(receipt.relative_to(root)), receipt_sha256=key,
                                 completed_at=record.receipt['completed_at'], **result))
archive = root / f'{scope}-evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as stream:
    for path in sorted(files):
        stream.write(path, path.relative_to(root).as_posix())
index = {path.relative_to(root).as_posix(): digest(path) for path in sorted(files)}
with zipfile.ZipFile(archive) as stream:
    assert set(stream.namelist()) == set(index)
    assert all(hashlib.sha256(stream.read(name)).hexdigest() == sha for name, sha in index.items())
manifest = dict(schema=1, scope=scope, archive=archive.name, archive_sha256=digest(archive),
                files=index, native_completed_receipts=len(verified), native_receipts=list(verified.values()),
                actual_human_participants=0)
(root / f'{scope}-evidence-index.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(scope=scope, files=len(index), native_completed_receipts=len(verified),
                      archive_sha256=manifest['archive_sha256']), ensure_ascii=False), flush=True)
