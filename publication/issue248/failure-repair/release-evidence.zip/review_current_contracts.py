"""Prepare and run independent native audit requests, then run the standard audit separately."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, replace
from pathlib import Path
import argparse
import json
import threading
import time

from sdd.cli_checkpoint import Capture
from sdd.config import load
from sdd.consistency import SYSTEM, batches, groups, policy_hash, request, review_store, validate
from sdd.facts.model import KnowledgeModel
from sdd.llm import Agent
from sdd.validation_stage import staged


@staged
def prepare(config, model):
    units = []
    for group in groups(config):
        payload = request(config, model, group)
        for index, batch in enumerate(batches(payload, max_input_chars=config.agent.max_input_chars)):
            store, envelope = review_store(config, batch)
            if len(SYSTEM) + len(envelope['user']) > config.agent.max_input_chars:
                raise ValueError(f'Input budget exceeded for {group["id"]} batch {index}')
            units.append((group['id'], index, batch, store, envelope))
    if len({store.path for _, _, _, store, _ in units}) != len(units):
        raise ValueError('Native audit requests must have distinct checkpoints')
    return units


def execute(config, model, units, destination, concurrency):
    if config.publication.get('budget') or config.publication.get('operation_file'):
        raise ValueError('Use the standard operation runner for an explicit publication operation or budget')
    limits = {name: getattr(config.review, name) for name in (
        'max_calls', 'max_seconds', 'document_max_calls', 'document_max_seconds')}
    report = dict(status='running', units=[], planned_units=len(units), concurrency=concurrency,
                  source_commit=model.meta['source_commit'], policy_sha256=policy_hash(),
                  profile=asdict(config.agent), limits=limits, new_calls_reserved=0,
                  human_review='pending')
    lock = threading.RLock()
    started = time.monotonic()

    def save():
        temp = destination.with_suffix('.tmp')
        temp.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        temp.replace(destination)

    def timeout():
        elapsed = time.monotonic() - started
        ceilings = [limit - elapsed for name, limit in limits.items() if name.endswith('seconds') and limit]
        if ceilings and min(ceilings) <= 0:
            raise RuntimeError('Configured audit time limit exhausted')
        return min([config.agent.timeout_sec, *ceilings])

    def check(unit):
        group, index, batch, store, envelope = unit
        began = time.monotonic()
        result = dict(group=group, index=index, checkpoint=store.path.name)
        try:
            timeout()
            saved = store.read()
            if saved is None:
                with lock:
                    limit = timeout()
                    used = report['new_calls_reserved']
                    if any(limits[name] and used >= limits[name] for name in ('max_calls', 'document_max_calls')):
                        raise RuntimeError('Configured audit call limit exhausted')
                    report['new_calls_reserved'] += 1
                    save()
                agent = Agent(replace(config.agent, timeout_sec=limit), config.build_dir / 'prompts')
                capture = Capture(agent)
                raw = capture.chat(SYSTEM, envelope['user'], tag=f'issue248_c19_{group}_{index}',
                                   response_schema=envelope['response_schema'])
                verdicts = validate(batch, raw)
                store.write(raw, verdicts, capture)
                if not capture.receipts or store.read() is None:
                    raise ValueError('Completed native response lacks a validated checkpoint')
                result.update(status='new-cli-completed', receipts=[str(p) for p in capture.receipts])
            else:
                payload, _ = saved
                verdicts = validate(batch, payload['raw'])
                if verdicts != payload['statements']:
                    raise ValueError('Validated response and checkpoint verdicts differ')
                result.update(status='checkpoint-revalidated', receipts=payload['receipts'])
            timeout()
            result['verdicts'] = {kind: sum(v['status'] == kind for v in verdicts) for kind in (
                'compatible', 'contradiction', 'ambiguous', 'insufficient-evidence')}
        except Exception as error:
            result.update(status='failed', error=str(error))
        result['elapsed_seconds'] = round(time.monotonic() - began, 3)
        return result

    save()
    with ThreadPoolExecutor(max_workers=concurrency) as pool:
        for future in as_completed([pool.submit(check, unit) for unit in units]):
            with lock:
                report['units'].append(future.result())
                save()
            print(f'Completed {len(report["units"])}/{len(units)} native audit units', flush=True)
    report['status'] = 'failed' if any(unit['status'] == 'failed' for unit in report['units']) else 'completed'
    report['elapsed_seconds'] = round(time.monotonic() - started, 3)
    save()
    if report['status'] != 'completed':
        raise RuntimeError('One or more native audit units failed. See the original records.')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('config', type=Path)
    parser.add_argument('destination', type=Path)
    parser.add_argument('--concurrency', type=int, default=4)
    args = parser.parse_args()
    config = load(args.config)
    if (config.agent.kind, config.agent.runner, config.agent.model) != ('cli', 'codex', 'gpt-6.1-terra'):
        raise ValueError('Expected the independent Codex CLI / Terra review profile')
    if config.agent.args != ['-c', 'model_reasoning_effort="high"']:
        raise ValueError('Expected high reasoning effort')
    model = KnowledgeModel.load(config.facts_path)
    units = prepare(config, model)
    execute(config, model, units, args.destination, args.concurrency)


if __name__ == '__main__':
    main()
