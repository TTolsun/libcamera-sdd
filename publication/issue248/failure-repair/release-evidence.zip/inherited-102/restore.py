import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tarfile

import yaml


root = Path(__file__).resolve().parent
project = root.parents[3]
repository = root.parents[1] / 'public-evaluation-release'
prior = root.parent / 'inherited-c19'
prior_original = prior / 'original/release'
prior_workspace = prior / 'workspace/release'
original = root / 'original/release'
workspace = root / 'workspace/release'
source = prior / 'source-c19'
public_commit = '3d75b5cce724aea0d88350d9410df74ff4cb514d'
source_commit = 'c19d05128f3ae1f0ebe63acb4deaca9fbb1dde78'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    return digest(path.read_bytes())


def read_json(path):
    return json.loads(path.read_bytes())


def git_blob(commit, path):
    return subprocess.check_output(['git', 'show', f'{commit}:{path}'], cwd=repository)


def local_path(path):
    rel = PurePosixPath(path)
    assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in path and ':' not in path
    return rel


package = read_json(root / 'package.json')
overlay_index = read_json(root / 'archive-index.json')
archive_path = root / 'native-and-operation-evidence.tar.xz'
assert sha(archive_path) == package['archive_sha256']
assert sha(root / 'archive-index.json') == package['index_sha256']
assert sha(prior / 'public-release-evidence.tar.gz') == package['inherited_archive_sha256']
assert package['files'] == len(overlay_index)
seen = set()
with tarfile.open(archive_path) as archive:
    for member in archive:
        rel = local_path(member.name)
        assert member.isfile() and member.name in overlay_index and member.name not in seen
        raw = archive.extractfile(member).read()
        assert digest(raw) == overlay_index[member.name] == sha(root / 'original' / rel), member.name
        seen.add(member.name)
assert seen == set(overlay_index)

base_index = read_json(prior / 'public-release-index.json')
for name, expected in base_index.items():
    assert sha(prior / 'original' / name) == expected['sha256'], name

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == source_commit
assert not subprocess.check_output(['git', '--no-optional-locks', 'status', '--porcelain'], cwd=source, text=True)

manifest_bytes = git_blob(public_commit, 'docs/site-manifest.json')
assert manifest_bytes == (root / 'pr102-site-manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
before = read_json(root / 'pr99-site-manifest.json')
retirement = read_json(root / 'pr100-site-manifest.json')
inputs = manifest['inputs']
removed = sorted(set(before['outputs']) - set(manifest['outputs']))
assert removed == ['en/reader-decision.html', 'en/reader-work.html', 'reader-decision.html', 'reader-work.html']
assert set(retirement['outputs']) == set(manifest['outputs'])
git_outputs = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', '-z', public_commit, '--', 'docs'], cwd=repository)
git_paths = {p.decode('utf-8').removeprefix('docs/') for p in git_outputs.split(b'\0') if p}
assert set(manifest['outputs']) <= git_paths and not git_paths.intersection(removed)

workspace.mkdir(parents=True, exist_ok=True)
shutil.copytree(prior_original, workspace, dirs_exist_ok=True)
shutil.copytree(original, workspace, dirs_exist_ok=True)
archived = workspace.parent / 'pr99-gate-reports'
archived.mkdir(exist_ok=True)

cfg_original = yaml.safe_load((original / 'publication.yaml').read_bytes())
review_original = yaml.safe_load((original / 'review.yaml').read_bytes())
prefix = cfg_original['output']['sdd_dir'].rsplit('\\', 1)[0]
assert 'reader_paths' not in cfg_original['site'] and 'reader_paths' not in review_original['site']

for folder in ('runtime-assets', 'profile-styles', 'mermaid'):
    shutil.copytree(prior / 'workspace' / folder, workspace.parent / folder, dirs_exist_ok=True)
for p in (workspace.parent / 'mermaid').rglob('*'):
    if p.is_file():
        path = p.relative_to(workspace.parent / 'mermaid').as_posix()
        assert sha(p) == manifest['outputs']['assets/mermaid/' + path], path

baseline_path = 'prior98/base/config/sections.yaml'
baseline = prior_workspace / baseline_path
baseline_expected = read_json(prior / 'pr98-package/archive-index.json')['base/config/sections.yaml']
assert sha(baseline) == baseline_expected
(workspace / baseline_path).parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(baseline, workspace / baseline_path)

product_path = workspace / 'config/products.yaml'
assert sha(product_path) == inputs['products/0']
product_evidence = {}
for n, row in enumerate(yaml.safe_load(product_path.read_bytes())['evidence'], 1):
    rel = local_path(row['file'])
    dependency = prior_workspace / 'config' / rel
    expected = row['sha256']
    assert sha(dependency) == expected == inputs[f'products/{n}'], rel
    target = product_path.parent / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(dependency, target)
    product_evidence[str(rel)] = expected


def normalized(path):
    return str(path).replace('\\', '/').casefold()


runtime = workspace.parent / 'runtime-assets'
substitutions = {normalized(cfg_original['paths'][k]): v for k, v in
                 {'prompts': runtime / 'examples/libcamera/prompts', 'templates': runtime / 'templates',
                  'style': runtime / 'style'}.items()}
substitutions[normalized(cfg_original['site']['mermaid_dir'])] = workspace.parent / 'mermaid'
substitutions[normalized(cfg_original['source']['root'])] = source
compdb = prior / 'original/source/clang/compile_commands.json'
assert sha(compdb) == base_index['source/clang/compile_commands.json']['sha256']
substitutions[normalized(cfg_original['source']['compile_commands'])] = compdb

report_provenance = []
for number, row in enumerate(cfg_original['publication']['reports']):
    location = normalized(row['path'])
    if row['producer'] == 'generator-ci':
        data = git_blob(public_commit, 'publication/issue253-contract-reuse/regression.json')
    else:
        suffix = location.split('/c19-original/release/', 1)[1]
        data = (prior_original / suffix).read_bytes()
    assert digest(data) == row['sha256'], row['producer']
    report_path = archived / f'{number}-{Path(row["path"]).name}'
    report_path.write_bytes(data)
    substitutions[location] = report_path
    report_provenance.append(dict(path=str(report_path), original_path=row['path'], sha256=row['sha256'],
                                  producer=row['producer'], source='prior published PR99 proof'))

profile_dir = prior_original / 'profiles'
active_profiles = set(Path(p).name for p in cfg_original['site']['manuscript_profiles'].values())
missing_unused_profile_styles = {}
for path in profile_dir.glob('*.yaml'):
    original_style = yaml.safe_load(path.read_bytes())['paths']['style']
    relocated = workspace.parent / 'profile-styles' / path.stem
    if relocated.is_dir():
        substitutions[normalized(original_style)] = relocated
    else:
        assert path.name not in active_profiles
        missing_unused_profile_styles[path.name] = original_style

for name, expected in inputs.items():
    if name.startswith('editorial/style/'):
        page, filename = name.removeprefix('editorial/style/').rsplit('/', 1)
        directory = runtime / 'style' if page == 'default' else (
            workspace.parent / 'profile-styles' / Path(cfg_original['site']['manuscript_profiles'][page]).stem)
        assert sha(directory / filename) == expected, name
    if name.startswith('editorial/profile/'):
        page = name.removeprefix('editorial/profile/')
        assert sha(profile_dir / Path(cfg_original['site']['manuscript_profiles'][page]).name) == expected, name


def remap(item):
    if isinstance(item, dict):
        return {key: remap(value) for key, value in item.items()}
    if isinstance(item, list):
        return [remap(value) for value in item]
    if isinstance(item, str) and re.match(r'^[A-Za-z]:[\\/]', item):
        key = normalized(item)
        if key in substitutions:
            return str(substitutions[key])
        start = normalized(prefix) + '/'
        if key.startswith(start):
            return str(workspace / item.replace('\\', '/')[len(start):])
    return item


for name in ('publication.yaml', 'review.yaml', 'baseline98.yaml'):
    data = remap(yaml.safe_load((original / name).read_bytes()))
    (workspace / name).write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding='utf-8', newline='\n')
for path in profile_dir.glob('*.yaml'):
    data = remap(yaml.safe_load(path.read_bytes()))
    (workspace / 'profiles' / path.name).write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding='utf-8', newline='\n')

manuscripts = {}
for name, expected in manifest['outputs'].items():
    if name.endswith('.md'):
        assert sha(workspace / 'manuscripts' / name) == inputs['markdown/' + name] == expected == digest(git_blob(public_commit, 'docs/' + name)), name
        manuscripts[name] = expected
assert len(manuscripts) == 29

for key, name in {'facts': 'facts/facts.json', 'english_catalog': 'english.json', 'sections': 'config/sections.yaml',
                  'visuals': 'config/visuals.yaml', 'intro': 'site-intro.md', 'consistency_configuration': 'config/contracts.yaml',
                  'consistency_review': 'build/consistency-review.json'}.items():
    assert sha(workspace / name) == inputs[key], key
assert read_json(workspace / 'facts/facts.json')['meta']['source_commit'] == source_commit

native = {}
collisions = []
for part in ('build/cli-checkpoints', 'build/prompts', 'build/translation-prompts'):
    files = {key.removeprefix('release/'): item['sha256'] for key, item in base_index.items()
             if key.startswith('release/' + part + '/')}
    fresh = {key.removeprefix('release/'): item for key, item in overlay_index.items()
             if key.startswith('release/' + part + '/')}
    collisions.extend(dict(path=key, prior=files[key], overlay=fresh[key]) for key in sorted(files.keys() & fresh.keys())
                      if files[key] != fresh[key])
    files.update(fresh)
    actual = {p.relative_to(workspace).as_posix(): sha(p) for p in (workspace / part).rglob('*') if p.is_file()}
    assert actual == files, part
    native[part] = dict(path=str(workspace / part), files=len(files), overlay_files=len(fresh),
                        original_receipts=sum(name.endswith('.receipt.json') for name in files), all_sha256_verified=True)

sys.path.insert(0, str(project / 'src'))
from sdd.config import load
from sdd.publication_plan import check_baseline, check_catalog, check_reports
from sdd.validation_execution import staged

cfg = load(workspace / 'publication.yaml')
review = load(workspace / 'review.yaml')
for profile in (cfg, review):
    assert profile.agent.kind == 'cli' and profile.agent.runner == 'codex' and profile.agent.model == 'gpt-6.1-terra'
    assert profile.agent.args == ['-c', 'model_reasoning_effort="high"']
    assert 'reader_paths' not in profile.raw['site']
    assert profile.source_root == source and profile.build_dir == workspace / 'build'
    assert not {key: str(path) for key, path in profile.paths.items() if not path.exists()}


@staged
def preflight(config):
    check_baseline(config)
    check_catalog(config)
    check_reports(config, 'before-export')
    return len(config.sections())


sections = preflight(cfg)
fact_prior = read_json(prior_original / 'facts/facts.json')
fact_current = read_json(workspace / 'facts/facts.json')
old_evidence = fact_prior['evidence']
new_evidence = fact_current['evidence']
fact_delta = sorted(key for key in old_evidence.keys() | new_evidence.keys() if old_evidence.get(key) != new_evidence.get(key))
audit = read_json(workspace / 'build/consistency-review.json')
report = dict(status='restored-loadable-config', public_commit=public_commit, source_commit=source_commit,
              published_build_id=manifest['build_id'], manifest_sha256=digest(manifest_bytes), output_owned_files=len(manifest['outputs']),
              html_files=sum(name.endswith('.html') for name in manifest['outputs']), role_outputs_removed=removed,
              removal_verified_in_public_git=True, publication_yaml=str(workspace / 'publication.yaml'), review_yaml=str(workspace / 'review.yaml'),
              source_checkout=str(source), source_checkout_scope='Existing pinned checkout referenced read-only.',
              overlay_archive_sha256=package['archive_sha256'], overlay_index_sha256=package['index_sha256'], overlay_entries_verified=len(seen),
              base_archive_sha256=package['inherited_archive_sha256'], base_entries_verified=len(base_index),
              markdown_verified=manuscripts, facts_sha256=inputs['facts'], catalog_sha256=inputs['english_catalog'],
              prior_pr99_changed_facts_evidence= fact_delta, baseline_pr98_sections_sha256=baseline_expected,
              inherited_product_evidence_sha256=product_evidence, archived_report_provenance=report_provenance,
              missing_unused_profile_styles=missing_unused_profile_styles, native_cache=native, native_overlay_replacements=collisions,
              historical_audit_status=audit['status'], historical_audit_fresh_batches=audit.get('fresh_batches'),
              historical_audit_reused_batches=audit.get('reused_batches'), historical_audit_unresolved=len(audit.get('unresolved', [])),
              baseline_catalog_report_preflight='passed', sections_count=sections, missing_required_paths={},
              next_checks='Revalidate current manuscript and contract/receipt identities. Recheck modified bilingual catalog and complete normal export.',
              compile_commands_scope='Historical WSL paths retained. New extraction needs a local compile database.',
              first_validation_attempt='Current SiteConfig no longer defines reader_paths. The retry checked the raw YAML key and verified the role outputs stayed absent.',
              new_cli_calls=0, generated=False, exported=False)
(root / 'restoration.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: report[key] for key in ('status', 'published_build_id', 'output_owned_files', 'role_outputs_removed',
                                              'publication_yaml', 'review_yaml', 'native_cache', 'baseline_catalog_report_preflight')}, indent=2))
