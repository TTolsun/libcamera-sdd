from pathlib import Path
import copy
import hashlib
import json
import shutil

import yaml
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.visual_refresh import refresh

root = Path(__file__).resolve().parent
repo = root.parents[2]
current = root / 'inherited-102/workspace/release'
original_path = current / 'publication.yaml'
original = load(original_path)
before = load(root / 'inherited/workspace/run-05/sdd.yaml')
model = KnowledgeModel.load(original.facts_path)
old_model = KnowledgeModel.load(before.facts_path)
source_commit = 'c19d05128f3ae1f0ebe63acb4deaca9fbb1dde78'
assert model.meta['source_commit'] == source_commit
definition = json.loads((root / 'visual-repair/attempt02/definition.json').read_text(encoding='utf-8'))
keys = {ref['source'] for item in definition['nodes'] + definition['edges'] for ref in item['evidence']}
source_windows = []
for key in sorted(keys):
    name = 'overview/' + key
    old, new = old_model.evidence[name], model.evidence[name]
    assert new['commit'] == source_commit and new['status'] == 'available'
    fields = ('file', 'start_line', 'end_line', 'text', 'sha256', 'selector')
    assert all(old.get(field) == new.get(field) for field in fields), name
    assert hashlib.sha256(new['text'].encode()).hexdigest() == new['sha256']
    source_windows.append(dict(key=name, sha256=new['sha256'], same_source_window=True))

raw = copy.deepcopy(original.raw)
manuscripts = current / 'manuscripts-issue248'
shutil.copytree(original.sdd_dir, manuscripts, dirs_exist_ok=True)
raw['output']['sdd_dir'] = str(manuscripts)
catalog = current / 'english-issue248.json'
shutil.copyfile(Path(original.site.english_catalog), catalog)
raw['site']['english_catalog'] = str(catalog)
raw['site'].pop('reader_paths', None)
example = yaml.safe_load((repo / 'examples/libcamera/sdd.yaml').read_text(encoding='utf-8'))
for name in ('overview.md', 'vendor-integration.md', 'request-lifecycle.md'):
    configured = raw['site'].setdefault('topic_links', {}).setdefault(name, {})
    for topic, targets in example['site']['topic_links'][name].items():
        existing = configured.setdefault(topic, [])
        for target in targets:
            if target not in existing:
                existing.append(target)
raw['site']['reading_checkpoints'] = example['site']['reading_checkpoints']
specs = yaml.safe_load((original.root / original.visuals.file).read_text(encoding='utf-8'))
matches = [i for i, spec in enumerate(specs['sections']['overview']) if spec['id'] == definition['id']]
assert len(matches) == 1
old_spec = specs['sections']['overview'][matches[0]]
assert definition['nodes'][:len(old_spec['nodes'])] == old_spec['nodes']
assert definition['edges'][:len(old_spec['edges'])] == old_spec['edges']
specs['sections']['overview'][matches[0]] = definition
visuals = current / 'visuals-issue248.yaml'
visuals.write_text(yaml.safe_dump(specs, allow_unicode=True, sort_keys=False), encoding='utf-8', newline='\n')
raw['visuals']['file'] = str(visuals)
raw['publication']['baseline_config'] = str(original_path)
raw['publication']['operation_id'] = 'issue248-failed-task-repair-102'
raw['publication']['allowed_contract_changes'] = {}
raw['paths']['consistency_review_config'] = str(current / 'issue248-review.yaml')
raw['paths']['translation_profile'] = str(current / 'issue248-translation.yaml')
raw['agent']['command'] = [shutil.which('codex')]
assert raw['agent']['command'][0] and raw['agent']['model'] == 'gpt-6.1-terra'
for name in ('issue248-publication.yaml', 'issue248-review.yaml', 'issue248-translation.yaml'):
    (current / name).write_text(yaml.safe_dump(raw, allow_unicode=True, sort_keys=False), encoding='utf-8', newline='\n')
config_path = current / 'issue248-publication.yaml'
config = load(config_path)
original_manuscript = (original.sdd_dir / 'overview.md').read_bytes()
manifest = json.loads((root / 'inherited-102/pr102-site-manifest.json').read_text(encoding='utf-8'))
expected = manifest['outputs']['overview.md']
derived = refresh(config, model, 'overview', original_manuscript, expected_sha256=expected)
(manuscripts / 'overview.md').write_bytes(derived)
untouched = [path.relative_to(original.sdd_dir).as_posix() for path in original.sdd_dir.rglob('*.md')
             if path.name != 'overview.md' and path.read_bytes() == (manuscripts / path.relative_to(original.sdd_dir)).read_bytes()]
assert len(untouched) == 28
result = dict(status='prepared', configuration=str(config_path), source_commit=source_commit,
              previous_public_build=manifest['build_id'], source_windows=source_windows,
              unchanged_manuscripts=untouched, original_overview_sha256=expected,
              overview_sha256=hashlib.sha256(derived).hexdigest(),
              source_review_lineage='Same complete excerpts verified at c19. Original be7 native diagram creation and review retained.',
              human_review='pending')
(root / 'candidate-102.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False), flush=True)
