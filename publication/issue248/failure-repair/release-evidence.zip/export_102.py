from pathlib import Path
import hashlib
import json
import subprocess

from sdd.config import load
from sdd.document_metadata import split_frontmatter
from sdd.export_site import export_site
from sdd.site_build import verify_site
from sdd.trial_workspace import write_snapshot

root = Path(__file__).resolve().parent
base = root / 'inherited-102/workspace/release'
path = base / 'issue248-publication.yaml'
config = load(path)
audit_file = config.build_dir / 'consistency-review.json'
audit = json.loads(audit_file.read_text(encoding='utf-8'))
assert audit['status'] == 'passed' and audit['human_review'] == 'pending'
for row in config.raw['publication']['reports']:
    if (config.root / row['path']).resolve() == audit_file:
        row['sha256'] = hashlib.sha256(audit_file.read_bytes()).hexdigest()
translation = json.loads((root / 'translation-102.json').read_text(encoding='utf-8'))
assert not translation['pairs_changed_after_prepare'] and not translation['report']['missing_translations']
for name, key, value, producer in (
    ('translation-102.json', 'status', 'verified', 'verified-retention-of-independently-reviewed-bilingual-labels'),
    ('review-c19-language/final/review.json', 'verdict', 'faithful', 'independent-bilingual-review-c19'),
    ('visual-revalidation-102.json', 'status', 'passed', 'current-citation-policy-revalidation'),
    ('candidate-102.json', 'status', 'prepared', 'source-window-equivalence-and-managed-visual-refresh'),
):
    file = root / name
    data = json.loads(file.read_text(encoding='utf-8'))
    assert data[key] == value
    row = dict(path=str(file), sha256=hashlib.sha256(file.read_bytes()).hexdigest(), gate='before-export',
               producer=producer, bindings={key: value})
    if row not in config.raw['publication']['reports']:
        config.raw['publication']['reports'].append(row)
write_snapshot(config, path)
config = load(path)
first = export_site(config, root / 'site-publish')
second = export_site(config, root / 'site-publish-repeat')
raw = (first / 'site-manifest.json').read_bytes()
assert raw == (second / 'site-manifest.json').read_bytes()
manifest = json.loads(raw)
prior = json.loads((root / 'inherited-102/pr102-site-manifest.json').read_text(encoding='utf-8'))
assert manifest['outputs'].keys() == prior['outputs'].keys()
retired = {'reader-work.html', 'reader-decision.html', 'en/reader-work.html', 'en/reader-decision.html'}
assert not retired & manifest['outputs'].keys()
changed = [name for name, sha in manifest['outputs'].items() if prior['outputs'][name] != sha]
expected = {'overview.md'} | {row['page'] for row in json.loads((root / 'visual-revalidation-102.json').read_text(encoding='utf-8'))['pages']}
assert {name for name in changed if name.endswith('.md')} == expected
original = load(base / 'publication.yaml')
for name in expected - {'overview.md'}:
    old = split_frontmatter((original.sdd_dir / name).read_text(encoding='utf-8'))[1]
    new = split_frontmatter((first / name).read_text(encoding='utf-8'))[1]
    assert old == new, name
for name in ('pipeline-requests.md', 'request-lifecycle.md', 'ipa-algorithms.md'):
    assert manifest['outputs'][name] == prior['outputs'][name]
generator = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root.parents[2], text=True).strip()
report = dict(status='verified', build_id=manifest['build_id'], manifest_sha256=hashlib.sha256(raw).hexdigest(),
              generator=generator, source_commit=audit['source_commit'], public_base='3d75b5cce724aea0d88350d9410df74ff4cb514d',
              owned_outputs=len(manifest['outputs']), changed_outputs=changed, manuscripts_with_new_body=['overview.md'],
              manuscript_bytes_changed=sorted(expected), retired_pages_still_absent=sorted(retired),
              quality=verify_site(first), repeat_quality=verify_site(second), identical_repeat_manifest=True,
              standard_audit_fresh_batches=audit['fresh_batches'], standard_audit_reused_batches=audit['reused_batches'],
              unresolved_findings=len(audit['unresolved']), actual_human_participants=0)
(root / 'site-verification-102.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, ensure_ascii=False), flush=True)
