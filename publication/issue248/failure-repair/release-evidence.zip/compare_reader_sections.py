from pathlib import Path
import hashlib
import json
import re
from urllib.parse import unquote

import html5lib

root = Path(__file__).resolve().parent
focused = json.loads((root / 'focused-summary.json').read_text(encoding='utf-8'))
sections = {item for row in focused['assessments'] for item in row['evidence']}
sections.update({'request-lifecycle.html#제출에서-완료까지',
                 'vendor-integration.html#요청을-장치에-전달하고-반환하기',
                 'vendor-integration.html#구현-뒤-확인할-계약과-실행-한계'})

def normalize(value):
    return re.sub(r'\s+', ' ', value or '').strip()

def visible(element):
    if element.tag in ('details', 'script', 'style') or not isinstance(element.tag, str):
        return []
    values = [(element.tag, element.get('href', ''), element.get('aria-label', ''), normalize(element.text))]
    for child in element:
        values.extend(visible(child))
        if normalize(child.tail):
            values.append(('text', normalize(child.tail)))
    return values

def scope(directory, page, anchor):
    document = html5lib.parse((directory / page).read_text(encoding='utf-8'), namespaceHTMLElements=False)
    article, = document.iter('article')
    children = list(article)
    begin, = [index for index, element in enumerate(children) if element.get('id') == anchor]
    heading = children[begin]
    level = int(heading.tag[1])
    selected = []
    for index, element in enumerate(children[begin:], start=begin):
        if index != begin and isinstance(element.tag, str) and re.fullmatch(r'h[1-6]', element.tag) and int(element.tag[1]) <= level:
            break
        selected.extend(visible(element))
    return selected

def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False).encode()).hexdigest()

report = []
for reference in sorted(sections):
    page, anchor = reference.split('#', 1)
    old = scope(root / 'site-release', page, unquote(anchor))
    new = scope(root / 'site-publish', page, unquote(anchor))
    report.append(dict(reference=reference, evaluated_scope_sha256=digest(old), publication_scope_sha256=digest(new),
                       visible_text_markup_links_equal=old == new))
result = dict(status='matched' if all(row['visible_text_markup_links_equal'] for row in report) else 'different',
              scope='Cited heading sections and changed entry links. Closed details are excluded. Separate browser and publication checks cover the final build.',
              automatic_reader_build=focused['build_id'], rows=report, actual_human_participants=0)
(root / 'reader-section-equivalence.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(result['status'], len(report))
