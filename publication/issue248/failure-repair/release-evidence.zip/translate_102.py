from pathlib import Path
import hashlib
import json

from sdd.config import load
from sdd.localization_cli import prepare_catalog

root = Path(__file__).resolve().parent
base = root / 'inherited-102/workspace/release'
previous = root / 'inherited-c19/workspace/release'
config = load(base / 'issue248-publication.yaml')
prior_config = load(previous / 'publication.yaml')
prior_path = previous / 'english-issue248-final.json'
approved = json.loads(prior_path.read_text(encoding='utf-8'))
old = json.loads(Path(prior_config.site.english_catalog).read_text(encoding='utf-8'))
target = Path(config.site.english_catalog)
current = json.loads(target.read_text(encoding='utf-8'))
assert current['source_commit'] == approved['source_commit'] == 'c19d05128f3ae1f0ebe63acb4deaca9fbb1dde78'
delta = {key: value for key, value in approved['strings'].items() if old['strings'].get(key) != value}
seeded = []
for key, value in delta.items():
    if key in current['strings']:
        assert current['strings'][key] == value, key
        continue
    current['strings'][key] = value
    contexts = approved['translation_contexts'].get(key, [])
    if contexts:
        current.setdefault('translation_contexts', {})[key] = contexts
    for context in contexts:
        for source in context.get('source_ids', []):
            proof = approved['source_contexts'][source]
            historical = current.setdefault('source_contexts', {}).setdefault(source, proof)
            assert historical == proof
    seeded.append(key)
target.write_text(json.dumps(current, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
report = prepare_catalog(config, target, translate=True)
final = json.loads(target.read_text(encoding='utf-8'))
assert report['missing_translations'] == 0
changes = {key: (approved['strings'][key], final['strings'].get(key)) for key in delta
           if approved['strings'][key] != final['strings'].get(key)}
result = dict(status='verified', approved_catalog_sha256=hashlib.sha256(prior_path.read_bytes()).hexdigest(),
              approved_pair_count=len(delta), seeded_pair_count=len(seeded), pairs_changed_after_prepare=changes,
              current_catalog_sha256=hashlib.sha256(target.read_bytes()).hexdigest(), report=report,
              human_review='pending')
(root / 'translation-102.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False), flush=True)
