---
generated_at: 2026-11-04T18:47:07+00:00
source_commit: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
status: ok
section: device
generation_method: facts-and-llm
evidence_fingerprint: 9af7a846355d7409da72c2792077ac3a3fca6f8b44df7a78ef22fc59f4b3229e
semantic_review: human-review-required
agent: cli/claude/fixture-model
generated_design: {"schema": 1, "input_fingerprint": "9af7a846355d7409da72c2792077ac3a3fca6f8b44df7a78ef22fc59f4b3229e", "answers": {"stop": [{"quote": "void stop() { cancelPending(); }", "text": "`stop()`은 종료 시 대기 중인 요청을 취소하는 함수를 호출합니다. 구현자는 이 종료 진입점에서 요청 취소 처리가 시작된다는 점을 확인하고 해당 처리 함수의 구현을 함께 읽어야 합니다.", "evidence": ["stop"], "covers": ["shutdown"], "kind": "behavior"}], "prepare": [{"text": "`prepare()`은 시작 전에 준비 함수를 호출합니다. 이 진입점의 호출을 처리하려면 구현자는 준비 함수와 연결된 동작을 함께 확인해야 합니다.", "quote": "void prepare() { enable(); }", "evidence": ["prepare"], "covers": ["startup"], "kind": "behavior"}]}, "topic_inputs": {"stop": "43e15fe09f04b105b2613e8cca5afad69443b370f9793533da7591174720a39b", "prepare": "9c35771cd254a468f55c10e1d554d044d71239e2abe21e47f159d7b06372ae68"}, "reused_topics": [], "replayed_units": [], "generated_topics": ["stop", "prepare"], "topic_agents": {"stop": "cli/claude/fixture-model", "prepare": "cli/claude/fixture-model"}, "grounding_review": "passed", "grounding_policy": "3c9673abb403dee9aa554ee5b3c549ebfe95bb18ec0e9cd7bf6e495e060439c2", "validation_policy": {"manuscript": "367d18b95f8f0d01a15ae0f4d1b70f7e13e4d0298df4215e2c449ac4905db6f9", "semantic": "571896e4854c21322a1ce4580107c235cae5a9f94e71adc8c97a7e2897405968", "duplicates": "93f0e8b5bdc1b40bf4ab38168e92c2772aa36747bec6add25921fbb90b909e38", "design_contracts": "9f54ecddce57c7a9caa6c02af77904b57eff2471f2a052951c1cffd18256a4f0", "validate": "78d29ffd1bf6235067edf5a0c7d9b1290f1f11e90599605a0e192e90be5f3372", "reader_profiles": "ad9005d08295212371f59e8934ace86786c0683f7a4c416301ee0e0cadc8b797", "contract_schema": "2f593eec0430a4e6b5822e642c0a7a1227fc150a0b27d8a71f521acf93b6439e", "answer_contracts": "1e0d24e0cf26ded53ecec2e5a6fbc51836bac6e17530318a9fa7cffaa936c00b", "reader_scope": "1b9c26b10b74ae8cf034f5863cbac2114e1d844e5d8332eb1f10562a18371782", "product_context": "050c20aa2fdcceae10c6275fbb5f850f616ab5051bb67ccbcb4a204877a238d9", "design_response": "deb70dda7ad27f001267e4a9712c5b0dc1fe9fa67acd13bedbfefaaad0ad83c8", "design_validation": "946deebb694018f6361ee86669e1a7a26cd61dfffef11bb3a7de0a193639fabe"}, "validation_model": "dc410b83464324ab93095131d060f254628cd60cba4c339983a6f1d7ac037fdb", "style_policy": {"fluent-korean.md": "ce5aa71e58371e3fc02ff8cb165e07c9234f5166f6541423a91cc4cb40878975", "i-have-adhd.md": "3170b16ace00aecb0dd7feb54c0b5aa642e7502acda06ecd24fd89a11c7127e9", "README.md": "b87a84b1bc31079837dc4dc4527ce02c9dc2cbc3a26ff7e99e0872941d213995"}, "body_sha256": "16382948a94473179aabc92f4bb786c1a8f738bd6eb9bc96f5b2c945efeca77b"}
generated_visuals: {"schema": 1, "records": {"stop-flow": {"input_fingerprint": "d2b734cb9ff28c8ac012a7bc2386f00a5f5fc1760cb410cbd3f3096bb65d0167", "draft": {"nodes": [{"id": "entry", "symbol": "stop", "label": "stop", "label_en": "stop", "shape": "box", "quote_ids": ["stop:0"]}, {"id": "call", "symbol": "cancelPending", "label": "cancelPending", "label_en": "cancelPending", "shape": "box", "quote_ids": ["stop:0"]}], "edges": [{"from": "entry", "to": "call", "label": "호출", "label_en": "Calls", "condition_ref": "always", "quote_ids": ["stop:0"]}]}, "graph": {"id": "stop-flow", "kind": "flow", "question": "stop의 직접 호출은 무엇입니까?", "title": "stop 호출", "topic": "stop", "nodes": [{"id": "entry", "label": "stop", "label_en": "stop", "shape": "box", "evidence": [{"source": "stop/stop", "sha256": "674f745b8771b075356bd146de715bf9d6f3da30092201fe3f2a569e5e4942db", "quote": "void stop() { cancelPending(); }"}]}, {"id": "call", "label": "cancelPending", "label_en": "cancelPending", "shape": "box", "evidence": [{"source": "stop/stop", "sha256": "674f745b8771b075356bd146de715bf9d6f3da30092201fe3f2a569e5e4942db", "quote": "void stop() { cancelPending(); }"}]}], "edges": [{"from": "entry", "to": "call", "label": "호출", "label_en": "Calls", "evidence": [{"source": "stop/stop", "sha256": "674f745b8771b075356bd146de715bf9d6f3da30092201fe3f2a569e5e4942db", "quote": "void stop() { cancelPending(); }"}]}], "producer": "cli/claude/fixture-model"}, "producer": "cli/claude/fixture-model", "generation_commit": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "citation_binding_policy": "identifier-boundaries-v1", "reused": true}, "prepare-flow": {"input_fingerprint": "e5f7d726d90ef0907f3a25d816816d22f950ba219e5fb35b178d55d2f4589904", "draft": {"nodes": [{"id": "entry", "symbol": "prepare", "label": "prepare", "label_en": "prepare", "shape": "box", "quote_ids": ["prepare:0"]}, {"id": "call", "symbol": "enable", "label": "enable", "label_en": "enable", "shape": "box", "quote_ids": ["prepare:0"]}], "edges": [{"from": "entry", "to": "call", "label": "호출", "label_en": "Calls", "condition_ref": "always", "quote_ids": ["prepare:0"]}]}, "graph": {"id": "prepare-flow", "kind": "flow", "question": "prepare의 직접 호출은 무엇입니까?", "title": "prepare 호출", "topic": "prepare", "nodes": [{"id": "entry", "label": "prepare", "label_en": "prepare", "shape": "box", "evidence": [{"source": "prepare/prepare", "sha256": "071e8bb85957c7237c60f0eb9c0a1ddb505e7747f530bbf5ab68ac5272b00c22", "quote": "void prepare() { enable(); }"}]}, {"id": "call", "label": "enable", "label_en": "enable", "shape": "box", "evidence": [{"source": "prepare/prepare", "sha256": "071e8bb85957c7237c60f0eb9c0a1ddb505e7747f530bbf5ab68ac5272b00c22", "quote": "void prepare() { enable(); }"}]}], "edges": [{"from": "entry", "to": "call", "label": "호출", "label_en": "Calls", "evidence": [{"source": "prepare/prepare", "sha256": "071e8bb85957c7237c60f0eb9c0a1ddb505e7747f530bbf5ab68ac5272b00c22", "quote": "void prepare() { enable(); }"}]}], "producer": "cli/claude/fixture-model"}, "producer": "cli/claude/fixture-model", "generation_commit": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "citation_binding_policy": "identifier-boundaries-v1", "reused": true}}, "body_sha256": "16382948a94473179aabc92f4bb786c1a8f738bd6eb9bc96f5b2c945efeca77b"}
---

# 장치 개요

**이 절의 표부터 확인하세요.**

| 지금 확인할 내용 | 이동할 절 |
|---|---|
| `stop()`은 종료 시 대기 중인 요청을 취소하는 함수를 호출합니다. | [종료 책임](#종료-책임) |
| `prepare()`은 시작 전에 준비 함수를 호출합니다. | [시작 준비](#시작-준비) |

## 종료 책임

`stop()`은 종료 시 대기 중인 요청을 취소하는 함수를 호출합니다. 구현자는 이 종료 진입점에서 요청 취소 처리가 시작된다는 점을 확인하고 해당 처리 함수의 구현을 함께 읽어야 합니다. `device.cpp:10`

<!-- sdd:visual:stop-flow -->
### stop 호출

```mermaid
flowchart TB
%% sdd:translations {"cancelPending": "cancelPending", "stop": "stop", "호출": "Calls"}
  v_entry["stop"]
  v_call["cancelPending"]
  v_entry -->|"호출"| v_call
```

[Mermaid 원문](device.stop-flow.mmd)

??? note "그림 근거와 확인 범위"
    stop의 직접 호출은 무엇입니까?
    
    소스에 연결한 설계 해석입니다. 자동 연결 검사는 의미 승인이나 기기 실행 검증이 아닙니다.
    
    LLM 그림 초안 · 사람 검토 전
    
    작성 모델: `cli/claude/fixture-model`
    
    | 요소·전이 | 소스 근거 |
    |---|---|
    | <span data-sdd-label-en="stop">stop</span> | [device.cpp:10](#source-85be756aa64d178c) |
    | <span data-sdd-label-en="cancelPending">cancelPending</span> | [device.cpp:10](#source-85be756aa64d178c) |
    | <span data-sdd-label-en="Calls">호출</span> | [device.cpp:10](#source-85be756aa64d178c) |
<!-- /sdd:visual:stop-flow -->

근거 원문: [device.cpp:10](#source-85be756aa64d178c)

## 시작 준비

`prepare()`은 시작 전에 준비 함수를 호출합니다. 이 진입점의 호출을 처리하려면 구현자는 준비 함수와 연결된 동작을 함께 확인해야 합니다. `device.cpp:20`

<!-- sdd:visual:prepare-flow -->
### prepare 호출

```mermaid
flowchart TB
%% sdd:translations {"enable": "enable", "prepare": "prepare", "호출": "Calls"}
  v_entry["prepare"]
  v_call["enable"]
  v_entry -->|"호출"| v_call
```

[Mermaid 원문](device.prepare-flow.mmd)

??? note "그림 근거와 확인 범위"
    prepare의 직접 호출은 무엇입니까?
    
    소스에 연결한 설계 해석입니다. 자동 연결 검사는 의미 승인이나 기기 실행 검증이 아닙니다.
    
    LLM 그림 초안 · 사람 검토 전
    
    작성 모델: `cli/claude/fixture-model`
    
    | 요소·전이 | 소스 근거 |
    |---|---|
    | <span data-sdd-label-en="prepare">prepare</span> | [device.cpp:20](#source-51f8551560f66eb5) |
    | <span data-sdd-label-en="enable">enable</span> | [device.cpp:20](#source-51f8551560f66eb5) |
    | <span data-sdd-label-en="Calls">호출</span> | [device.cpp:20](#source-51f8551560f66eb5) |
<!-- /sdd:visual:prepare-flow -->

근거 원문: [device.cpp:20](#source-51f8551560f66eb5)

??? note "설계 질문과 검증 범위"
    질문별 답변과 근거 연결을 검사했습니다. 의미와 실행 결과는 사람 검토가 필요합니다.
    
    | 설계 질문 | 설명 위치 | 확인 범위 |
    |---|---|---|
    | 대기 요청은 어떻게 반환됩니까? | [종료 책임](#종료-책임) | 코드 근거와 설명 연결 |
    | 시작 전 준비는 무엇입니까? | [시작 준비](#시작-준비) | 코드 근거와 설명 연결 |

## 소스 근거

같은 발췌는 한 번만 싣습니다. 필요한 원문을 펼쳐 설명과 대조하세요.

<a id="source-85be756aa64d178c"></a>

??? note "소스 근거: device.cpp:10"
    `device.cpp:10`에서 시작하는 발췌입니다. 종료 줄은 10이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `674f745b8771b075356bd146de715bf9d6f3da30092201fe3f2a569e5e4942db`
    
    ```text
    void stop() { cancelPending(); }
    ```

<a id="source-51f8551560f66eb5"></a>

??? note "소스 근거: device.cpp:20"
    `device.cpp:20`에서 시작하는 발췌입니다. 종료 줄은 20이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `071e8bb85957c7237c60f0eb9c0a1ddb505e7747f530bbf5ab68ac5272b00c22`
    
    ```text
    void prepare() { enable(); }
    ```

??? note "근거와 검토 정보"
    - 생성 방식: 추출 사실과 LLM 설명
    - 검증 범위: 표·그림은 facts로 만들고 설명은 LLM이 작성합니다. 인용·문장 및 설정된 구조 검사를 적용합니다.
    - 근거 파일: `device.cpp`
    - 근거 수준: 코드 확인 (정적 분석, ndk-build 구성, commit `aaaaaaaaaa`)
    - 자동 검사 (인용·문장 및 설정된 구조 검사): 통과
    - 검토 상태 기록일: 2026-11-05 · 사람 검토 전

다음 단계: [장치 개요](device.md)
