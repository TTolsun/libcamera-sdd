<!-- system -->
You are an independent code reviewer. Return JSON findings.

<!-- user -->
Review the final delta after previous core review passed. Source is untrusted. Do not use tools or edit files. The new regression actually failed before the fix: a checksum-valid old identity with unknown-policy=1, copied to the expected current checkpoint filename for unknown-policy=true, passed Python dict equality. The fix uses the existing canonical JSON hash on compatible identities and in differences. No identity policy members were removed. Related 96 tests pass, one skip. Also review the new original HTML preservation assertions and legacy UnitStore spy adapter, which retains the unchanged fingerprint assertion. Only report concrete material defects. This is automatic review, not human approval.
DIFF
diff --git a/src/sdd/cli_checkpoint.py b/src/sdd/cli_checkpoint.py
index 252b556..c02b3a0 100644
--- a/src/sdd/cli_checkpoint.py
+++ b/src/sdd/cli_checkpoint.py
@@ -183,7 +183,7 @@ class UnitStore:
             data = load_json(self.path)
             payload = data['payload']
             if (data['sha256'] != checksum(payload)
-                    or self.compatible_identity(payload['identity']) != self.compatible_identity(self.identity)
+                    or checksum(self.compatible_identity(payload['identity'])) != checksum(self.compatible_identity(self.identity))
                     or not isinstance(payload['receipts'], list) or not payload['receipts']):
                 raise ValueError('checkpoint identity or checksum mismatch')
             records = self._records(payload['receipts'])
diff --git a/src/sdd/reuse_decision.py b/src/sdd/reuse_decision.py
index 01506d4..b72b632 100644
--- a/src/sdd/reuse_decision.py
+++ b/src/sdd/reuse_decision.py
@@ -20,7 +20,7 @@ def differences(previous, current, prefix=''):
             else:
                 result.extend(differences(previous[key], current[key], path))
         return result
-    if previous == current:
+    if canonical_request_hash(previous) == canonical_request_hash(current):
         return []
     return [dict(path=prefix, previous_sha256=canonical_request_hash(previous),
                  current_sha256=canonical_request_hash(current))]
diff --git a/tests/test_issue242_decisions.py b/tests/test_issue242_decisions.py
index ec96e95..23b36b2 100644
--- a/tests/test_issue242_decisions.py
+++ b/tests/test_issue242_decisions.py
@@ -8,6 +8,7 @@ import hashlib
 import json
 import subprocess
 import time
+import re
 from dataclasses import asdict
 
 import pytest
@@ -149,6 +150,26 @@ def exercise_fixed_input(cli_units, tmp_cfg, monkeypatch, change, expected):
               sum(c[0] == 'visual' for c in extra), sum(c[0] == 'translation' for c in extra))
     assert actual == expected
     assert all(path.read_bytes() == raw for path, raw in archives.items())
+    outputs = {p.relative_to(site).as_posix(): p.read_bytes() for p in site.rglob('*') if p.is_file()}
+    assert outputs.keys() == original_outputs.keys()  # No unaffected page/asset disappears.
+    for name in ('assets/reading.css','assets/site.js'):
+        assert outputs[name] == original_outputs[name]
+    def article(raw):
+        values = re.findall(r'<article>(.*?)</article>',raw.decode('utf-8'),re.S)
+        assert len(values) == 1
+        return values[0]
+    old_article,new_article = article(original_outputs['device.html']),article(outputs['device.html'])
+    prepare_marker = '<h2 id="시작-준비">'
+    assert old_article.count(prepare_marker) == new_article.count(prepare_marker) == 1
+    def prepare_html(value):
+        return value.split(prepare_marker,1)[1].split('<h2 ',1)[0]
+    assert prepare_html(new_article) == prepare_html(old_article)
+    if change not in ('question','evidence','visual'):
+        # DESIGN.md places mutable generation/checkpoint metadata outside the
+        # article. Compare the complete original visible article and sources.
+        assert new_article == old_article
+    else:
+        assert new_article != old_article
     meta,body = split_frontmatter((tmp_cfg.sdd_dir/'device.md').read_text(encoding='utf-8'))
     old_design,new_design = original_meta['generated_design'],meta['generated_design']
     assert new_design['answers']['prepare'] == old_design['answers']['prepare']
@@ -364,3 +385,26 @@ def test_decision_journal_serializes_concurrent_updates(tmp_cfg):
     saved = json.loads(execution.path.read_bytes())
     assert {row['unit'] for row in saved['decisions']} == {str(i) for i in range(32)}
     assert len(saved['decisions']) == len(execution.report['decisions']) == 32
+
+
+def test_relabelled_checkpoint_cannot_hide_an_unknown_dependency_type_change(cli_units, tmp_cfg):
+    from sdd.cli_checkpoint import UnitStore, checksum
+    _, model, _, _, state, factory = cli_units
+    state['interrupt'] = False
+    Generator(tmp_cfg, model, factory()).run()
+    original = next((tmp_cfg.build_dir/'cli-checkpoints').glob('*.json'))
+    saved = json.loads(original.read_bytes())
+    old = copy.deepcopy(saved['payload']['identity'])
+    old['unknown-policy'] = 1
+    current = copy.deepcopy(old)
+    current['unknown-policy'] = True  # Python equality hides this JSON type change.
+    saved['payload']['identity'] = old
+    saved['sha256'] = checksum(saved['payload'])
+    store = UnitStore(tmp_cfg,current)
+    # A checksum-valid archive cannot become current by moving it to the new
+    # expected filename. The receipt is valid, but its policy input is stale.
+    store.path.write_text(json.dumps(saved),encoding='utf-8')
+    with pytest.raises(ValueError,match='identity'):
+        store.read()
+    from sdd.reuse_decision import differences
+    assert differences({'unknown-policy':1},{'unknown-policy':True})[0]['path'] == 'unknown-policy'
diff --git a/tests/test_structure_contract.py b/tests/test_structure_contract.py
index ed49ba0..ae67ebe 100644
--- a/tests/test_structure_contract.py
+++ b/tests/test_structure_contract.py
@@ -139,7 +139,9 @@ def test_checkpoint_execution_identity_keeps_legacy_fingerprint(generated, tmp_c
     class CapturedIdentity(Exception):
         pass
 
-    def capture(cfg, identity):
+    def capture(cfg, identity, *, comparison_scope=None):
+        assert comparison_scope == ('design','device','stop',None,None)
+        assert 'comparison_scope' not in identity  # Diagnostic metadata must not change the legacy key.
         captured.append(identity['execution'])
         raise CapturedIdentity
 

CONTEXT
FILE src/sdd/cli_checkpoint.py
"""Atomic, receipt-bound checkpoints for completed CLI design units.

Only fully validated answers enter this store. Loading verifies original CLI
archives and reruns current deterministic checks and exact grounding verdicts.
It never turns an imported response into a new call or a human approval.
"""
from __future__ import annotations

import hashlib
import ast
import json
from pathlib import Path

from .call_records import canonical_request_hash, load_record
from .cli_provenance import verify_cli_receipt
from .state_io import save
from .trial_workspace import contained_path, reject_symlinks
from .llm import AgentError
from .validation_stage import current, load_json, InputChanged


def checksum(value):
    return canonical_request_hash(value)


def execution_identity(agent_config, schema):
    """Keep invocation details at the receipt/checkpoint boundary, byte-exact."""
    from .cli_agent import arguments
    return dict(runner=agent_config.runner, model=agent_config.model,
                command=agent_config.command, args=agent_config.args,
                arguments=arguments(agent_config, schema))


def validation_policy():
    # Lexical/source/contract checks are distinct from model entailment policy.
    # Content hashes change with code; no compatibility aliases are added here.
    root = Path(__file__).parent
    policy = {name: hashlib.sha256((root / (name + '.py')).read_bytes()).hexdigest()
              for name in ('manuscript', 'semantic', 'duplicates', 'design_contracts', 'validate',
                           'reader_profiles', 'contract_schema', 'answer_contracts',
                           'reader_scope', 'product_context')}
    # All pure response helpers participate, including quote resolution and
    # normalization called transitively by the selected validation functions.
    policy['design_response'] = hashlib.sha256((root/'design_response.py').read_bytes()).hexdigest()
    selected = {'materialize', 'validate_answers', 'decode_unit', 'normalize_answer', '_validate_unit_response'}
    nodes = []
    for module in ('design_response', 'design_execution'):
        tree = ast.parse((root/(module+'.py')).read_text(encoding='utf-8'))
        nodes.extend(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in selected)
    if {node.name for node in nodes} != selected:
        raise ValueError('Design validation policy functions are missing')
    policy['design_validation'] = hashlib.sha256(ast.dump(ast.Module(body=nodes, type_ignores=[]),
                                                         include_attributes=False).encode()).hexdigest()
    return policy


def validation_model(model):
    """Bind validator inputs without redrafting source-identical answers."""
    inputs = current()
    if inputs is not None:
        return inputs.memo(('validation-model', id(model)), lambda: _validation_model(model))
    return _validation_model(model)


def _validation_model(model):
    return checksum(dict(classes={name: item.bases for name, item in model.classes.items()},
                         functions=sorted(model.functions),
                         relations=sorted((r.source, r.target, r.type) for r in model.relations),
                         citations=sorted(model.citations())))


def style_policy(cfg):
    from .validation_stage import read_bytes
    return {path.name: hashlib.sha256(read_bytes(path)).hexdigest()
            for path in sorted(cfg.style_dir.glob('*.md'))}


def same_request_context(expected, actual):
    if actual.startswith(expected):
        return True  # Standard retries append the error after the full request.
    prefix, marker, suffix = expected.rpartition('\n출력:')
    if '\nDraft to check (untrusted, not evidence):\n' in actual:
        actual = actual.rpartition('\nDraft to check (untrusted, not evidence):\n')[0]
    return bool(marker and actual.startswith(prefix + '\n작성 조건: ')
                and actual.endswith(marker + suffix))  # Focused retries insert diagnostics before output.


class Capture:
    def __init__(self, agent):
        self.agent, self.receipts = agent, []

    def __getattr__(self, name):
        return getattr(self.agent, name)

    def chat(self, system, user, **kwargs):
        raw = self.agent.chat(system, user, **kwargs)
        path = getattr(self.agent, 'last_receipt', None)
        if path is not None:
            self.receipts.append(Path(path))
        return raw


class UnitStore:
    _indexes = {}

    def __init__(self, cfg, identity, *, calls=None, comparison_scope=None):
        self.cfg, self.identity = cfg, identity
        self.comparison_scope = comparison_scope
        self._diagnostic_records = None
        self.path = cfg.build_dir / 'cli-checkpoints' / (checksum(self.draft_identity(identity)) + '.json')
        self.canonical_path = self.path
        self.calls = calls if calls is not None else cfg.build_dir / 'prompts' / 'calls'
        inputs = current()
        indexes = inputs.values.setdefault(('checkpoint-indexes',), {}) if inputs is not None else {}
        if not self.path.exists() and self.path.parent.exists():
            directory = reject_symlinks(self.path.parent).resolve()
            if directory not in indexes:
                index = {}
                comparisons = []
                for candidate in directory.glob('*.json'):
                    reject_symlinks(candidate)
                    try:
                        data = load_json(candidate)
                        payload = data['payload']
                        if data['sha256'] != checksum(payload):
                            raise ValueError('checkpoint checksum mismatch')
                        key = checksum(self.compatible_identity(payload['identity']))
                        index.setdefault(key, candidate)
                        comparisons.append((candidate, dict(identity=payload['identity'],
                            receipts=payload.get('receipts'), comparison_scope=payload.get('comparison_scope'))))
                    except (ValueError, KeyError, TypeError, OSError) as exc:
                        raise ValueError(f'CLI checkpoint is damaged: {candidate}: {exc}') from exc
                indexes[directory] = index
                self._diagnostic_records = comparisons
                if inputs is not None:
                    inputs.values[('checkpoint-diagnostic-inputs', directory)] = comparisons
            compatible = indexes[directory].get(checksum(self.compatible_identity(identity)))
            if compatible is not None:
                self.path = compatible

    @staticmethod
    def draft_identity(identity):
        return {key: value for key, value in identity.items()
                if key not in ('validation_policy', 'validation_model', 'validation_answers', 'grounding_policy')}

    @classmethod
    def compatible_identity(cls, identity):
        result = cls.draft_identity(identity)
        if isinstance(result.get('topic'), dict):
            result['topic'] = {key: value for key, value in result['topic'].items() if key != 'title'}
            if isinstance(result['topic'].get('answer_contract'), dict):
                result['topic']['answer_contract'] = {key: value for key, value in result['topic']['answer_contract'].items()
                                                       if key != 'reject_patterns'}
        # Actual system/user/schema, source revision and execution identity must
        # STILL match. Only a layout title and checks absent from the model's
        # input can use this path, always under current deterministic validation.
        return result

    def _records(self, paths):
        rows = []
        for name in paths:
            path = contained_path(self.calls, name)
            record = load_record(path, root=self.calls)
            verify_cli_receipt(record.request, record.raw, record.receipt, self.calls, self.cfg.agent)
            arguments = record.receipt['provider'].get('arguments')
            # A historical receipt without actual CLI arguments is insufficient
            # for this optimization; ordinary manuscript provenance is separate.
            from .cli_agent import arguments as invocation_arguments
            # Validating an archived call does not execute its historical binary.
            # Keep the exact configured prefix arguments without resolving PATH.
            expected = self.cfg.agent.command[1:] + invocation_arguments(self.cfg.agent, record.request['response_schema'])
            if arguments != expected:
                raise ValueError('CLI checkpoint arguments mismatch')
            rows.append(record)
        return rows

    def read(self):
        if not self.path.exists():
            self._observe_read(None)
            return None
        try:
            reject_symlinks(self.path)
            data = load_json(self.path)
            payload = data['payload']
            if (data['sha256'] != checksum(payload)
                    or checksum(self.compatible_identity(payload['identity'])) != checksum(self.compatible_identity(self.identity))
                    or not isinstance(payload['receipts'], list) or not payload['receipts']):
                raise ValueError('checkpoint identity or checksum mismatch')
            records = self._records(payload['receipts'])
            request = self.identity['request']
            if not any(row.raw == payload['raw'] and row.request['system'] == request['system']
                       and same_request_context(request['user'], row.request['user'])
                       and row.request.get('response_schema') == request['response_schema'] for row in records):
                raise ValueError('validated response has no completed CLI receipt')
            cached = payload, Reviewer(records)
            self._observe_read(cached)
            return cached
        except (ValueError, OSError, KeyError, TypeError) as exc:
            raise ValueError(f'CLI checkpoint is damaged; previous output preserved: {self.path}: {exc}') from exc

    def explain(self, cached=None):
        """Describe a verified hit or comparable misses, without changing read()."""
        from .reuse_decision import explain
        if cached is not None:
            return explain(self.identity, [(self.path, cached[0])], verified=True)
        try:
            return self._explain_comparisons()
        except InputChanged:
            raise  # Input mutation is a real integrity failure, not a diagnostic.
        except (ValueError, TypeError, KeyError, AttributeError, OSError) as exc:
            result = explain(self.identity)
            result['reason_codes'].append('diagnostic-unavailable-current-gates-required')
            result['diagnostic_error'] = type(exc).__name__
            return result

    def _explain_comparisons(self):
        from .reuse_decision import explain, scope
        unit = self.comparison_scope or scope(self.identity)
        if unit is None or not self.path.parent.exists():
            return explain(self.identity)
        directory = reject_symlinks(self.path.parent).resolve()
        inputs = current()
        unavailable = []
        # Reuse ONLY inputs that the existing compatibility lookup already read.
        # Diagnostics must not enlist an unrelated archive in stage validation.
        rows = (inputs.values.get(('checkpoint-diagnostic-inputs', directory), [])
                if inputs is not None else self._diagnostic_records)
        if rows is None:
            rows = []
            for path in sorted(directory.glob('*.json')):
                try:
                    reject_symlinks(path)
                    # Standalone, non-authorizing comparison snapshot. Never
                    # use the staged loader or feed this into read()/reuse.
                    data = json.loads(path.read_bytes())
                    payload = data['payload']
                    if data['sha256'] != checksum(payload):
                        raise ValueError('checksum mismatch')
                    rows.append((path,payload))
                except (ValueError, TypeError, KeyError, AttributeError, OSError):
                    unavailable.append(path.name)
        candidates = []
        for path, payload in rows:
            try:
                if (not isinstance(payload.get('identity'), dict)
                        or not isinstance(payload.get('receipts'), list)
                        or any(not isinstance(name,str) for name in payload['receipts'])):
                    raise ValueError('comparison metadata unavailable')
                candidate_scope = payload.get('comparison_scope') or scope(payload['identity'])
                if candidate_scope is not None and tuple(candidate_scope) == tuple(unit):
                    candidates.append((path,payload))
            except (ValueError, TypeError, KeyError, AttributeError):
                unavailable.append(path.name)
        result = explain(self.identity, candidates)
        if unavailable:
            result['unavailable_comparisons'] = unavailable
        return result

    def _observe_read(self, cached):
        # Observe the receipt boundary without changing consistency's semantic
        # policy or wire payload. Its existing validator/status still decides
        # success. This hook neither authorizes a hit nor catches read failures.
        if self.identity.get('purpose') != 'cross-document-consistency':
            return
        from .generation_run import observed
        execution = observed()
        if execution is not None and execution.current is not None:
            key = execution.report.get('current_task')
            if key:
                self._observed_explanation = self.explain(cached)
                execution.decision(key, dict(action='revalidate-review' if cached else 'review-new',
                    stage='before-work', resolve_on_status=True, **self._observed_explanation,
                    receipts=cached[0]['receipts'] if cached else []))

    def write(self, raw, statements, capture):
        if not capture.receipts:
            # A custom ChatPort without an archive is allowed, but cannot certify
            # a durable checkpoint as a real CLI call.
            return
        try:
            paths = [path.resolve().relative_to(self.calls.resolve()).as_posix() for path in capture.receipts]
            self._records(paths)
            payload = dict(identity=self.identity, raw=raw, statements=statements, receipts=paths)
            if self.comparison_scope is not None:
                payload['comparison_scope'] = list(self.comparison_scope)
            data = dict(schema=1, payload=payload, sha256=checksum(payload))
            if current() is not None:
                current().verify()
            save(self.canonical_path, data, newline='\n')
            if current() is not None:
                current().produced(self.canonical_path, (json.dumps(data, ensure_ascii=False, indent=2)+'\n').encode())
            self.path = self.canonical_path
            directory = self.path.parent.resolve()
            indexes = current().values.get(('checkpoint-indexes',), {}) if current() is not None else {}
            if directory in indexes:
                indexes[directory][checksum(self.compatible_identity(self.identity))] = self.path
            if self.identity.get('purpose') == 'cross-document-consistency':
                from .generation_run import observed
                execution = observed()
                key = execution.report.get('current_task') if execution is not None else None
                if key:
                    execution.decision(key, dict(action='review-new', stage='validated',
                        **getattr(self, '_observed_explanation', self.explain((payload, None))),
                        receipts=paths, current_receipts_verified=True))
        except (ValueError, OSError) as exc:
            raise AgentError(f'CLI checkpoint persistence failed; previous output preserved: {exc}') from exc


class Reviewer:
    def __init__(self, records):
        self.records = {canonical_request_hash(row.request): row.raw for row in records}

    def chat(self, system, user, **kwargs):
        key = canonical_request_hash(dict(system=system, user=user, response_schema=kwargs.get('response_schema')))
        if key not in self.records:
            raise ValueError('CLI checkpoint lacks the exact current grounding review receipt')
        return self.records[key]

FILE src/sdd/reuse_decision.py
"""Explain existing reuse gates; diagnostics never authorize compatibility.

Only identity paths and hashes are logged. Original requests and receipts stay
in their archives. A nearby checkpoint is a comparison, never a reuse fallback.
"""
import json

from .call_records import canonical_request_hash


def differences(previous, current, prefix=''):
    if isinstance(previous, dict) and isinstance(current, dict):
        result = []
        for key in sorted(previous.keys() | current.keys()):
            path = f'{prefix}.{key}' if prefix else key
            if key not in previous or key not in current:
                result.append(dict(path=path,
                    previous_sha256=canonical_request_hash(previous[key]) if key in previous else None,
                    current_sha256=canonical_request_hash(current[key]) if key in current else None))
            else:
                result.extend(differences(previous[key], current[key], path))
        return result
    if canonical_request_hash(previous) == canonical_request_hash(current):
        return []
    return [dict(path=prefix, previous_sha256=canonical_request_hash(previous),
                 current_sha256=canonical_request_hash(current))]


def reason(path):
    root = path.split('.')[0]
    if root == 'topic':
        if path == 'topic.question':
            return 'question-changed'
        if path.startswith('topic.sources'):
            return 'evidence-selection-changed'
        if path == 'topic.title':
            return 'heading-changed-current-checks-required'
        return 'answer-contract-or-unit-changed'
    return dict(source_commit='source-commit-changed', execution='cli-profile-changed',
        request='request-or-schema-changed', style_policy='global-style-changed',
        prompt_policy='writing-prompt-changed', revision='revision-policy-changed',
        validation_policy='deterministic-policy-changed', validation_model='validator-facts-changed',
        validation_answers='prior-answers-changed', grounding_policy='grounding-policy-changed',
        policy='review-or-translation-policy-changed', receipt_directory='receipt-archive-changed'
        ).get(root, 'unregistered-dependency-changed')


def scope(identity):
    """Restrict diagnostic comparisons to the same logical design unit.

    Translation text has no stable cross-edit unit ID in historical checkpoints.
    Compare the same source text only, never invent an ID across text edits.
    """
    if isinstance(identity.get('topic'), dict):
        # Historical identities have no section ID. Never attribute another
        # section's same-named topic to this one. New stores provide an explicit
        # comparison_scope outside the reuse identity, bound by the payload SHA.
        return None
    try:
        payload = json.loads(identity['request']['user'])
        if identity.get('purpose') == 'translation':
            source = payload.get('source', payload.get('texts'))
            return ('translation', canonical_request_hash(source)) if source is not None else None
        if identity.get('purpose') == 'cross-document-consistency':
            return ('consistency', payload['contract']['id'], tuple(sorted(payload['claims'])))
    except (KeyError, TypeError, ValueError):
        pass  # Legacy/retry records without a comparable scope remain explicit.
    return None


def explain(identity, candidates=(), *, verified=False):
    comparisons = []
    for path, payload in candidates:
        changes = differences(payload['identity'], identity)
        comparisons.append(dict(checkpoint=path.name,
            identity_sha256=canonical_request_hash(payload['identity']),
            receipts=list(payload.get('receipts', [])), receipts_verified=verified,
            changed_dependencies=changes,
            reason_codes=sorted({reason(change['path']) for change in changes})))
    # Several archived versions may describe the same unit. Keep every nearest
    # comparison rather than falsely calling one of them the previous run.
    if comparisons:
        minimum = min(len(row['changed_dependencies']) for row in comparisons)
        comparisons = [row for row in comparisons if len(row['changed_dependencies']) == minimum]
    codes = sorted({code for row in comparisons for code in row['reason_codes']})
    if not comparisons:
        codes = ['no-comparable-provenance']
    elif not codes:
        codes = ['identical-inputs-current-checks-required']
    return dict(current_identity_sha256=canonical_request_hash(identity),
                reason_codes=codes, comparisons=comparisons,
                comparison_only=not verified, human_review='pending')


def record(agent, key, action, explanation, *, stage='before-work', **details):
    update = getattr(agent, 'decision', None)
    if update is not None:
        update(key, dict(action=action, stage=stage, **explanation, **details))

