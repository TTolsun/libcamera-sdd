---
generated_at: 2026-11-04T18:36:15+00:00
source_commit: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
status: ok
section: device
generation_method: facts-and-llm
evidence_fingerprint: 9af7a846355d7409da72c2792077ac3a3fca6f8b44df7a78ef22fc59f4b3229e
semantic_review: human-review-required
agent: cli/claude/fixture-model
generated_design: {"schema": 1, "input_fingerprint": "9af7a846355d7409da72c2792077ac3a3fca6f8b44df7a78ef22fc59f4b3229e", "answers": {"stop": [{"quote": "void stop() { cancelPending(); }", "text": "`stop()`은 종료 시 대기 중인 요청을 취소하는 함수를 호출합니다. 구현자는 이 종료 진입점에서 요청 취소 처리가 시작된다는 점을 확인하고 해당 처리 함수의 구현을 함께 읽어야 합니다.", "evidence": ["stop"], "covers": ["shutdown"], "kind": "behavior"}], "prepare": [{"text": "`prepare()`은 시작 전에 준비 함수를 호출합니다. 이 진입점의 호출을 처리하려면 구현자는 준비 함수와 연결된 동작을 함께 확인해야 합니다.", "quote": "void prepare() { enable(); }", "evidence": ["prepare"], "covers": ["startup"], "kind": "behavior"}]}, "topic_inputs": {"stop": "7481e6eec3497e2ae6ac86d1ab2e26b7c4235f9704d82ebcb1ef1c1e03879f9a", "prepare": "a204d9ce2497887408e8653a99e92f4de45c6978a3e1d2b62145436b017b323d"}, "reused_topics": [], "replayed_units": [], "generated_topics": ["stop", "prepare"], "topic_agents": {"stop": "cli/claude/fixture-model", "prepare": "cli/claude/fixture-model"}, "grounding_review": "not-run", "grounding_policy": null, "validation_policy": {"manuscript": "367d18b95f8f0d01a15ae0f4d1b70f7e13e4d0298df4215e2c449ac4905db6f9", "semantic": "571896e4854c21322a1ce4580107c235cae5a9f94e71adc8c97a7e2897405968", "duplicates": "93f0e8b5bdc1b40bf4ab38168e92c2772aa36747bec6add25921fbb90b909e38", "design_contracts": "9f54ecddce57c7a9caa6c02af77904b57eff2471f2a052951c1cffd18256a4f0", "validate": "78d29ffd1bf6235067edf5a0c7d9b1290f1f11e90599605a0e192e90be5f3372", "reader_profiles": "ad9005d08295212371f59e8934ace86786c0683f7a4c416301ee0e0cadc8b797", "contract_schema": "2f593eec0430a4e6b5822e642c0a7a1227fc150a0b27d8a71f521acf93b6439e", "answer_contracts": "1e0d24e0cf26ded53ecec2e5a6fbc51836bac6e17530318a9fa7cffaa936c00b", "reader_scope": "1b9c26b10b74ae8cf034f5863cbac2114e1d844e5d8332eb1f10562a18371782", "product_context": "050c20aa2fdcceae10c6275fbb5f850f616ab5051bb67ccbcb4a204877a238d9", "design_response": "deb70dda7ad27f001267e4a9712c5b0dc1fe9fa67acd13bedbfefaaad0ad83c8", "design_validation": "946deebb694018f6361ee86669e1a7a26cd61dfffef11bb3a7de0a193639fabe"}, "validation_model": "dc410b83464324ab93095131d060f254628cd60cba4c339983a6f1d7ac037fdb", "style_policy": {"fluent-korean.md": "ce5aa71e58371e3fc02ff8cb165e07c9234f5166f6541423a91cc4cb40878975", "i-have-adhd.md": "3170b16ace00aecb0dd7feb54c0b5aa642e7502acda06ecd24fd89a11c7127e9", "README.md": "b87a84b1bc31079837dc4dc4527ce02c9dc2cbc3a26ff7e99e0872941d213995"}, "body_sha256": "ba085055b00d462543c8c771daa877bb3d502f1683ccca3e6f41d3fc03553f09"}
---

# 장치 개요

**이 절의 표부터 확인하세요.**

| 지금 확인할 내용 | 이동할 절 |
|---|---|
| `stop()`은 종료 시 대기 중인 요청을 취소하는 함수를 호출합니다. | [종료 책임](#종료-책임) |
| `prepare()`은 시작 전에 준비 함수를 호출합니다. | [시작 준비](#시작-준비) |

## 종료 책임

`stop()`은 종료 시 대기 중인 요청을 취소하는 함수를 호출합니다. 구현자는 이 종료 진입점에서 요청 취소 처리가 시작된다는 점을 확인하고 해당 처리 함수의 구현을 함께 읽어야 합니다. `device.cpp:10`

근거 원문: [device.cpp:10](#source-85be756aa64d178c)

## 시작 준비

`prepare()`은 시작 전에 준비 함수를 호출합니다. 이 진입점의 호출을 처리하려면 구현자는 준비 함수와 연결된 동작을 함께 확인해야 합니다. `device.cpp:20`

근거 원문: [device.cpp:20](#source-51f8551560f66eb5)

??? note "설계 질문과 검증 범위"
    질문별 답변과 근거 연결을 검사했습니다. 의미와 실행 결과는 사람 검토가 필요합니다.
    
    | 설계 질문 | 설명 위치 | 확인 범위 |
    |---|---|---|
    | 대기 요청은 어떻게 반환됩니까? | [종료 책임](#종료-책임) | 코드 근거와 설명 연결 |
    | 시작 전 준비는 무엇입니까? | [시작 준비](#시작-준비) | 코드 근거와 설명 연결 |

## 소스 근거

같은 발췌는 한 번만 싣습니다. 필요한 원문을 펼쳐 설명과 대조하세요.

<a id="source-85be756aa64d178c"></a>

??? note "소스 근거: device.cpp:10"
    `device.cpp:10`에서 시작하는 발췌입니다. 종료 줄은 10이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `674f745b8771b075356bd146de715bf9d6f3da30092201fe3f2a569e5e4942db`
    
    ```text
    void stop() { cancelPending(); }
    ```

<a id="source-51f8551560f66eb5"></a>

??? note "소스 근거: device.cpp:20"
    `device.cpp:20`에서 시작하는 발췌입니다. 종료 줄은 20이며, 아래 원문을 설명과 대조할 수 있습니다.
    
    SHA-256: `071e8bb85957c7237c60f0eb9c0a1ddb505e7747f530bbf5ab68ac5272b00c22`
    
    ```text
    void prepare() { enable(); }
    ```

??? note "근거와 검토 정보"
    - 생성 방식: 추출 사실과 LLM 설명
    - 검증 범위: 표·그림은 facts로 만들고 설명은 LLM이 작성합니다. 인용·문장 및 설정된 구조 검사를 적용합니다.
    - 근거 파일: `device.cpp`
    - 근거 수준: 코드 확인 (정적 분석, ndk-build 구성, commit `aaaaaaaaaa`)
    - 자동 검사 (인용·문장 및 설정된 구조 검사): 통과
    - 검토 상태 기록일: 2026-11-05 · 사람 검토 전

다음 단계: [장치 개요](device.md)
