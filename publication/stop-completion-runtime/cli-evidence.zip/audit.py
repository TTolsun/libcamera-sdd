from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.consistency import groups, request, batches, review_store, validate, SYSTEM, schema, audit, enforce
from sdd.cli_checkpoint import Capture
from sdd.llm import Agent

root=Path(__file__).resolve().parent
cfg=load(root/'workspace/sdd.review.yaml')
model=KnowledgeModel.load(cfg.facts_path)
jobs=[]
for group in groups(cfg):
    for index,batch in enumerate(batches(request(cfg,model,group),max_input_chars=cfg.agent.max_input_chars)):
        jobs.append((group['id'],index,batch))
print('Independent source-bound batches: '+str(len(jobs)),flush=True)
def run(job):
    gid,index,batch=job
    store,data=review_store(cfg,batch)
    if store.read() is not None:
        return f'{gid}/{index}: exact completed review reused'
    capture=Capture(Agent(cfg.agent,dump_dir=cfg.build_dir/'prompts'))
    raw=capture.chat(SYSTEM,data['user'],tag=f'consistency_{gid}_{index}',response_schema=schema(batch))
    checked=validate(batch,raw)
    store.write(raw,checked,capture)
    assert capture.receipts
    return f'{gid}/{index}: fresh Codex Terra/high review completed'
with ThreadPoolExecutor(max_workers=4) as pool:
    futures=[pool.submit(run,job) for job in jobs]
    for future in as_completed(futures):
        print(future.result(),flush=True)
# No ordinary auditor runs until every independent writer has finished. This
# final native audit assembles and verifies exact completed cache/receipt sets.
result=audit(cfg,model,Agent(cfg.agent,dump_dir=cfg.build_dir/'prompts'))
enforce(cfg,model)
print(json.dumps(dict(status=result['status'],batches=len(jobs),unresolved=len(result['unresolved']),
                     assembly_fresh_batches=result['fresh_batches'],assembly_reused_batches=result['reused_batches'])),flush=True)
