from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent;repo=r.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
material=repo/'examples/libcamera/config/product-evidence/callback-observation.json'
m=json.loads(material.read_bytes());obs=json.loads((r/'runtime/observation.json').read_bytes());cpp=(repo/'examples/libcamera/runtime/callback_probe.cpp').read_text(encoding='utf-8')
assert m['source_commit']==obs['source_commit']=='293d751a814e0d4c34e85ad457ccd9d5eefd1a61'
assert m['probe_sha256']==obs['probe_sha256']==sha(repo/'examples/libcamera/runtime/callback_probe.cpp')
assert m['raw_observation_sha256']==sha(r/'runtime/observation.json')
assert m['operating_system']['os_release_sha256']==sha(r/'runtime/os-release.txt')
assert m['operating_system']['os_release']==(r/'runtime/os-release.txt').read_text(encoding='utf-8')
assert 'ID=ubuntu' in m['operating_system']['os_release']
for field in ('connection_code','callback_instrumentation_in_source_order','stop_instrumentation_in_source_order'):
 positions=[cpp.index(line) for line in m[field]];assert positions==sorted(positions)
assert 'manager.get("Virtual2")' in cpp and m['test_configuration']['simulation'] is True
rows=[]
for i,record in enumerate(obs['results'],1):
 out=r/f'runtime/run-{i}.stdout';err=r/f'runtime/run-{i}.stderr'
 assert sha(out)==record['raw_stdout_sha256'] and sha(err)==record['raw_stderr_sha256']
 events=[json.loads(x) for x in out.read_text().splitlines()]
 assert [e['index'] for e in events]==list(range(len(events)))
 outcomes=[e for e in events if e['event']=='request-outcome']
 assert sum(e['status']==1 for e in outcomes)==m['per_run']['requests_reported_RequestComplete']==4
 assert sum(e['status']==2 for e in outcomes)==m['per_run']['requests_reported_RequestCancelled']==4
 entries=[e for e in events if e['event']=='callback-enter'];near=[e for e in events if e['event']=='callback-return']
 assert len(entries)==len(near)==m['per_run']['callbacks']==24
 start=next(e['index'] for e in events if e['event']=='stop-enter' and e['phase']==1)
 end=next(e['index'] for e in events if e['event']=='stop-return' and e['phase']==1)
 for c in m['connections']:
  selected=[e for e in entries if e['connection']==c['connection']];assert len(selected)==c['callbacks_per_run']==8
  assert all((e['tid']==e['receiver_tid'])==(c['connection']!='direct') for e in selected)
  for e in selected:
   returned=next(x for x in near if (x['connection'],x['cookie'])==(e['connection'],e['cookie']))
   assert e['index']<returned['index'] and e['tid']==returned['tid']
   if e['cookie']>=200:
    assert start<e['index']<returned['index']<end if c['connection']=='direct' else end<e['index']<returned['index']
 errors=[line for line in err.read_text().splitlines() if 'ERROR' in line]
 assert sum('Unable to sync dma fd' in line for line in errors)==m['retained_dma_sync_errors_per_run'][i-1]==8
 assert sum('Could not open any dma-buf provider' in line for line in errors)==m['retained_dma_provider_errors_per_run'][i-1]==2
 rows.append(dict(run=i,callbacks=len(entries),first_request_connection_order=[e['connection'] for e in entries if e['cookie']==100],retained_error_lines=len(errors)))
assert m['runs']==obs['run_count']==len(rows)==3 and m['total_callbacks']==obs['total_callbacks']==sum(x['callbacks'] for x in rows)==72
report=dict(schema=1,status='passed',new_runtime_execution=False,purpose='Recheck the final native records and exact source/material derivation; not a new execution or human approval.',material_sha256=sha(material),observation_sha256=sha(r/'runtime/observation.json'),probe_sha256=m['probe_sha256'],results=rows,human_review='pending',dma_validation='unvalidated-errors-retained',physical_camera_validation='not-run',internal_hal_validation='not-run')
(r/'runtime-material-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,ensure_ascii=False))
