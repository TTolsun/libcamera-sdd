from pathlib import Path
import json,yaml
from sdd.config import load
from sdd.llm import Agent
r=Path(__file__).resolve().parent;cfg=load(r/'workspace/sdd.yaml');agent=Agent(cfg.agent,dump_dir=r/'glossary-generation')
system='Write a concise Korean developer glossary definition from the supplied official source. Use complete Korean sentences. Do not claim this test achieved working DMA. Return only JSON.'
payload=dict(term='DMA',full='Direct Memory Access',source_url='https://docs.kernel.org/core-api/dma-api-howto.html',source_scope='CPU and DMA addresses, paragraphs about devices reading/writing system memory and DMA bus addresses; observed 2026-10-31',source_excerpt='I/O devices use a third kind of address: a “bus address”.',source_facts='The official guide describes a device performing DMA to read or write system memory. DMA bus addresses can differ from CPU physical addresses. The current callback probe uses CPU memfd buffers and retains DMA sync errors; it does not qualify DMA.',task='한 문장으로 DMA의 뜻만 설명하세요. 정의 외에 실험 결과나 성능·지원 보장을 추가하지 마세요.')
schema=dict(type='object',additionalProperties=False,required=['definition'],properties=dict(definition=dict(type='string')))
raw=agent.chat(system,json.dumps(payload,ensure_ascii=False),tag='callback_dma_glossary',response_schema=schema);d=json.loads(raw);assert d['definition'];entry=dict(term='DMA',full='Direct Memory Access',definition=d['definition'],aliases=[])
for p in (Path('examples/libcamera/config/glossary.yaml'),r/'workspace/config/glossary.yaml'):
 text=p.read_text(encoding='utf-8');assert not any(x['term']=='DMA' for x in yaml.safe_load(text)['terms']);start=text.index('terms:')+len('terms:');text=text[:start]+'\n# https://docs.kernel.org/core-api/dma-api-howto.html ; native Haiku/high receipt retained.\n'+yaml.safe_dump([entry],allow_unicode=True,sort_keys=False).rstrip()+text[start:];p.write_text(text,encoding='utf-8',newline='\n')
(r/'glossary-generation.json').write_text(json.dumps(dict(entry=entry,source=payload,receipt=str(agent.last_receipt.relative_to(r))),ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Native Haiku/high glossary definition generated.',flush=True)
