from pathlib import Path
import json
from sdd.config import load
from sdd.localization_cli import prepare_catalog
from sdd.translation import translate_missing

root=Path(__file__).resolve().parent
render=load(root/'workspace/sdd.render.yaml')
author=load(root/'workspace/sdd.yaml')
catalog=root/'workspace/english.json'
print(prepare_catalog(render,catalog),flush=True)
data=translate_missing(author,json.loads(catalog.read_bytes()))
assert all(data['strings'].values())
catalog.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Actual Haiku/high translation finished; global defaults unchanged.',flush=True)
