from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
from sdd.config import load
from sdd import approvals
from sdd.site_build import verify_site

r=Path(__file__).resolve().parent;repo=r.parents[1];w=r/'workspace';old=repo/'build/navigation-audit-scope/workspace';public=repo/'build/issue194/publication';pkg=public/'publication/stop-completion-runtime'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def copy(p,q):q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)

manifest=public/'docs/site-manifest.json';m=json.loads(manifest.read_bytes());assert manifest.read_bytes()==(r/'first-manifest.json').read_bytes();checks=verify_site(public/'docs')
audit=json.loads((w/'build/consistency-review.json').read_bytes());assert audit['status']=='passed';assert not any(f['status']=='contradiction' for c in audit['contracts'] for f in c['findings'])
ground=json.loads((r/'independent-grounding.json').read_bytes());assert not any(x['status']=='failed' for x in ground['results'])
runtime_review=json.loads((r/'runtime-review-final.json').read_bytes());assert all(x['assessment']['bounded_scope_supported'] and not x['assessment']['problems'] for x in runtime_review['results'])
obs=json.loads((r/'runtime/observation.json').read_bytes());assert obs['run_count']==3 and obs['total_callbacks']==72
assert sha(repo/'examples/libcamera/runtime/callback_probe.cpp')==obs['probe_sha256']
pins=json.loads((r/'baseline/manuscript-hashes.json').read_bytes());changed=[n for n,h in pins.items() if sha(w/'manuscripts'/n)!=h];assert sorted(changed)==['pipeline-handler.md','request-lifecycle.md']
baseline=json.loads((r/'baseline/facts.json').read_bytes());facts=json.loads((w/'facts/facts.json').read_bytes());assert all(baseline[k]==facts[k] for k in baseline if k!='evidence')
before=load(old/'sdd.yaml');after=load(w/'sdd.yaml');state=dict(schema=1,before_ledger_exists=approvals.ledger_path(before).exists(),after_ledger_exists=approvals.ledger_path(after).exists(),effective_before=approvals.load(before),effective_after=approvals.load(after),accept_executed=False);assert state['effective_before']==state['effective_after'];state['preserved']=True;write(r/'approval-state.json',state)
pkg.mkdir(parents=True,exist_ok=True)
if not (pkg/'previous-run.json').exists():copy(public/'run.json',pkg/'previous-run.json')
for n in ('preflight.json','approval-state.json','browser-validation.json','independent-grounding.json','runtime-review-final.json','runtime-material-verification.json','glossary-generation.json','upstream-check.json'):
 copy(r/n,pkg/n)
copy(r/'baseline/consistency-review.json',pkg/'previous-consistency-review.json')
for n in ('pipeline-handler.md','request-lifecycle.md'):copy(r/'baseline'/n,pkg/'previous-manuscripts'/n)
shutil.copytree(w/'config',pkg/'config',dirs_exist_ok=True);shutil.copytree(w/'manuscripts',pkg/'manuscripts',dirs_exist_ok=True)
for n in ('sdd.yaml','sdd.review.yaml','sdd.runtime-review.yaml','sdd.render.yaml'):copy(w/n,pkg/'profiles'/n)
copy(w/'english.json',pkg/'english.json');copy(w/'site-intro.md',pkg/'site-intro.md')
for p in (r/'runtime').glob('*'):
 if p.is_file() and p.name!='callback-probe':copy(p,pkg/'runtime'/p.name)
for p in (repo/'examples/libcamera/runtime').glob('*'):
 if p.is_file():copy(p,pkg/'runtime-source'/p.name)
with zipfile.ZipFile(pkg/'facts.zip','w',zipfile.ZIP_DEFLATED) as z:z.write(w/'facts/facts.json','facts.json')
write(pkg/'facts-reference.json',dict(schema=1,source_commit=facts['meta']['source_commit'],facts_sha256=sha(w/'facts/facts.json'),archive_sha256=sha(pkg/'facts.zip'),original_structural_archive='../callback-observation/structural-facts.zip',new_structural_extraction_performed=False,structural_fields_retained=True,changed_top_level=['evidence'],reason='Official upstream unchanged; source excerpts and authenticated runtime measurement were recollected through the existing evidence pipeline. Full facts bytes changed.'))
write(pkg/'input-preservation.json',dict(schema=1,changed_manuscripts=changed,prior_manuscript_hashes=pins,current_manuscript_hashes={n:sha(w/'manuscripts'/n) for n in pins},historical_records_preserved=True,human_approval=state,english_catalog_sha256=sha(w/'english.json')))
files=[p for p in (w/'build').rglob('*') if p.is_file()]
for folder in ('preflight','document-review','runtime-review','runtime-review-final','runtime-review-third','runtime-review-complete','glossary-generation','first-run','runtime-original-review','runtime-before-size-assert','validator-buffer-count-failure','preliminary-generation'):
 files += [p for p in (r/folder).rglob('*') if p.is_file() and p.name not in ('callback-probe',)]
files += [p for p in r.glob('*.log') if not p.name.startswith(('server','package','export','verify'))]+list(r.glob('*.py'))+list(r.glob('*.json'))+[r/'claude-help.txt']
index={};fresh=[];historical=0
with zipfile.ZipFile(pkg/'cli-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(files)):
  n=p.relative_to(r).as_posix();assert not any(s in p.name.lower() for s in ('credentials','auth.json','.env'));z.write(p,n);index[n]=dict(sha256=sha(p),bytes=p.stat().st_size)
  if p.name.endswith('.receipt.json'):
   d=json.loads(p.read_bytes());assert d['model'] in ('claude-haiku-5-5','gpt-6.1-terra');args=d['provider']['arguments']
   if d['model']=='claude-haiku-5-5':assert args[args.index('--effort')+1]=='high' and set(d['provider']['provider']['modelUsage'])=={'claude-haiku-5-5'}
   else:assert 'model_reasoning_effort="high"' in args
   prior=old/p.relative_to(w) if p.is_relative_to(w) else None
   if prior and prior.exists() and sha(prior)==sha(p):historical+=1
   else:fresh.append(dict(path=n,sha256=sha(p),tag=d['tag'],runner=d['provider']['runner'],model=d['model']))
write(pkg/'cli-evidence-index.json',dict(schema=1,archive_sha256=sha(pkg/'cli-evidence.zip'),files=index));write(pkg/'new-receipts.json',dict(schema=1,new_receipts=fresh,retained_historical_receipts=historical,human_review='pending',note='Includes completed native attempts and reviews; rejected drafts/verdicts and interrupted audit preparation remain history, not successful final assessments. Exact original completed units remain identified by their own receipts.'))
generator=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();original=json.loads((pkg/'previous-run.json').read_bytes())
run=dict(schema=1,source_repository=original['source_repository'],source_commit=facts['meta']['source_commit'],generator_repository=original['generator_repository'],generator_behavior_commit=generator,generator_pr=209,build_id=m['build_id'],manifest_sha256=sha(manifest),manifest_outputs=len(m['outputs']),facts_sha256=sha(w/'facts/facts.json'),english_catalog_sha256=sha(w/'english.json'),author_profile=dict(kind='cli',runner='claude',model='claude-haiku-5-5',args=['--effort','high','--setting-sources','project,local']),independent_review_profile=dict(kind='cli',runner='codex',model='gpt-6.1-terra',args=['-c','model_reasoning_effort="high"'],max_input_chars=100000),manuscript_generation_performed=True,translation_performed=True,facts_extraction_performed=False,structural_facts_retained=True,evidence_recollected=True,validation=checks,repeat_build_identical=True,automatic_unresolved=len(audit['unresolved']),human_review='pending',callback_runtime_validation='executed-public-virtual-CPU-only',runtime_runs=3,runtime_request_callbacks=72,dma_validation='unvalidated-errors-retained',physical_camera_validation='not-run',production_application_validation='not-run',internal_hal_validation='not-run',evidence='publication/stop-completion-runtime/README.md',post_deployment='Actual Pages and public output hash verification recorded in the release PR after merge.')
write(public/'run.json',run);write(pkg/'build-validation.json',dict(build_id=m['build_id'],manifest_sha256=sha(manifest),repeat_identical=True,**checks));(pkg/'.gitattributes').write_text('** -text whitespace=cr-at-eol\nmanuscripts/** -whitespace\nprevious-manuscripts/** -whitespace\n',encoding='utf-8')
(pkg/'README.md').write_text(f'''# Normal completion, stop conditions and actual virtual callbacks

Generator [PR209](https://github.com/TTolsun/camera-hal-sdd-generator/pull/209), commit `{generator}`, clarifies normal waiting dispatch versus stop detachment and separates the measured callback observation from the remaining production-application investigation. Only pipeline-handler and request-lifecycle manuscripts changed. The original automatic English-condition finding and previous manuscripts remain preserved. Read the current [Korean lifecycle guide](https://ttolsun.github.io/libcamera-sdd/request-lifecycle.html) and [English guide](https://ttolsun.github.io/libcamera-sdd/en/request-lifecycle.html).

Three final native processes executed the real public libcamera virtual pipeline and application callbacks: 24 request callbacks per run, 72 total. Each process observed four RequestComplete and four RequestCancelled requests through Auto, Direct and Queued connections. Stop-cancelled Direct entry/near-return markers occur between the application stop-enter/stop-return markers; Auto/Queued markers occur after stop-return. Those markers bracket camera->stop() and are not instruction-level function boundaries. Near-return markers precede the counter increment and local destruction and do not prove the actual return instruction. The [complete native records](runtime/) and [executed source](runtime-source/) retain exact source/library/binary hashes and all raw errors. Independent [complete runtime review](runtime-review-final.json) and [full manuscript grounding](independent-grounding.json) state their actual reviewed windows and limits.

This is CPU memfd / eventfd test input on WSL2 Virtual2. Each run retains two missing DMA-provider errors and eight unsupported DMA-sync errors. RequestComplete/FrameSuccess does not qualify DMA or physical capture. Physical cameras, production applications, other configurations and internal Camera HAL remain unvalidated. Prior not-run records are historical and remain unchanged; current execution is bounded, not human approval.

Generation and translation use independent Claude Code 2.1.314, exact claude-haiku-5-5 with --effort high --setting-sources project,local. Source/bilingual reviews use independent Codex gpt-6.1-terra with -c model_reasoning_effort="high". Full context input limits are explicit per-run settings; global defaults are unchanged. [Preflight](preflight.json), [profiles](profiles/), [native receipt index](new-receipts.json), [complete archive](cli-evidence.zip) and its [hash index](cli-evidence-index.json) distinguish current native calls, rejected attempts and retained completed history. No alternate CLI/model, direct API, manual manuscript or saved response substituted for new generation or review. The DMA glossary definition was generated by the same Haiku CLI from the [official Linux DMA guide](https://docs.kernel.org/core-api/dma-api-howto.html).

Official libcamera remains `{facts['meta']['source_commit']}`. The original Meson/Ninja/libclang structural fields are retained; authenticated measurement/source evidence was recollected, so full facts bytes changed. [Facts provenance](facts-reference.json), [current archive](facts.zip), [preservation](input-preservation.json) and [effective human approval](approval-state.json) record that distinction. No approval ledger or accepted entries were added. [Current contract audit](../../docs/contract-consistency.json) has {len(audit['unresolved'])} automatic unresolved findings in its configured scope; automatic checks are not exhaustive all-pairs proof or human review.

[Build validation](build-validation.json) and [browser checks](browser-validation.json) record the repeated site build and Korean/English rendering. Generated HTML was not edited directly. Post-merge Pages and public manifest/all-output verification are recorded in the release PR.
''',encoding='utf-8',newline='\n')
p=public/'README.md';lines=p.read_text(encoding='utf-8').splitlines();lines[2]=f'Current release: [normal/stop conditions and bounded actual callbacks](publication/stop-completion-runtime/README.md), generator [PR209](https://github.com/TTolsun/camera-hal-sdd-generator/pull/209), build `{m["build_id"]}`. [Korean and English site](https://ttolsun.github.io/libcamera-sdd/). Human review remains pending; physical camera/DMA/production/internal HAL validation remains incomplete.';p.write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n');print(json.dumps(dict(build_id=m['build_id'],outputs=len(m['outputs']),new_receipts=len(fresh),historical_receipts=historical,archive_files=len(index),unresolved=len(audit['unresolved'])),ensure_ascii=False))
