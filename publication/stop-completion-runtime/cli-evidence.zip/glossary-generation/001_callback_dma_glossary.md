<!-- system -->
Write a concise Korean developer glossary definition from the supplied official source. Use complete Korean sentences. Do not claim this test achieved working DMA. Return only JSON.

<!-- user -->
{"term": "DMA", "full": "Direct Memory Access", "source_url": "https://docs.kernel.org/core-api/dma-api-howto.html", "source_scope": "CPU and DMA addresses, paragraphs about devices reading/writing system memory and DMA bus addresses; observed 2026-10-31", "source_excerpt": "I/O devices use a third kind of address: a “bus address”.", "source_facts": "The official guide describes a device performing DMA to read or write system memory. DMA bus addresses can differ from CPU physical addresses. The current callback probe uses CPU memfd buffers and retains DMA sync errors; it does not qualify DMA.", "task": "한 문장으로 DMA의 뜻만 설명하세요. 정의 외에 실험 결과나 성능·지원 보장을 추가하지 마세요."}
