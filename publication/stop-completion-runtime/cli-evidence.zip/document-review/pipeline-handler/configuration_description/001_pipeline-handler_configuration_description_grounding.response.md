{"reviews":[{"index":0,"supported":true,"reason":"호출자의 roles 입력 의무, 두 함수의 호출 문맥과 반환값, configure()의 검증 전제 및 setStream() 연결 책임이 원문과 일치하며 may와 shall의 강도도 보존합니다."}]}
