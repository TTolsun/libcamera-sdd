{"reviews":[{"index":0,"supported":true,"reason":"생성·참조 계수, match()의 성공과 실패 조건, 장치 자동 해제 및 acquire()/release()의 잠금과 호출 짝이 제시된 소스에 명시되어 있습니다."}]}
