{"reviews":[{"index":0,"supported":true,"reason":"두 최솟값의 std::max 인자와 큰 값을 선택한다는 설명이 코드와 일치합니다."},{"index":1,"supported":true,"reason":"반복 순서와 감소, 두 값의 재초기화, 반복문 안의 코드 및 높이 자르기 주석이 소스와 일치합니다."}]}
