{"reviews":[{"index":0,"supported":true,"reason":"근거는 CameraManager 스레드에서의 호출 의무, 완료된 요청의 순서 제약 없는 호출, 제출 순서 반환 보장 및 함수 반환 후 요청 접근 금지를 명시합니다."}]}
