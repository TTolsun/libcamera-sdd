{"reviews":[{"index":0,"supported":true,"reason":"근거는 버퍼 완료 통지 시 CameraManager 스레드에서 completeBuffer를 호출해야 하며, 마지막 버퍼 완료 후에도 completeRequest()를 명시적으로 호출해야 한다고 규정합니다."}]}
