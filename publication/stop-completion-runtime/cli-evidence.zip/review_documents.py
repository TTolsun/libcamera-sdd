from pathlib import Path
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from types import SimpleNamespace
import hashlib,json
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.llm import Agent
from sdd.document_metadata import split_frontmatter
from sdd.design_request import _design_units
from sdd.grounding import review
r=Path(__file__).resolve().parent;cfg=load(r/'workspace/sdd.review.yaml');model=KnowledgeModel.load(cfg.facts_path)
assert cfg.agent.model=='gpt-6.1-terra' and cfg.agent.args==['-c','model_reasoning_effort="high"']
jobs=[];hashes={};counts={}
for section in cfg.sections():
 if section['id'] not in ('pipeline-handler','request-lifecycle'):continue
 sid=section['id'];raw=(cfg.sdd_dir/(sid+'.md')).read_bytes();meta,_=split_frontmatter(raw.decode('utf-8'));assert meta['source_commit']==model.meta['source_commit'];answers=meta['generated_design']['answers'];hashes[sid]=hashlib.sha256(raw).hexdigest();counts[sid]=sum(map(len,answers.values()));groups=defaultdict(list)
 for unit in _design_units(section,{}):
  basis=unit.get('answer_contract',{}).get('basis','execution-check' if unit.get('_statement_kind') else 'description');groups[unit['id'],basis].append(unit)
 for (tid,basis),units in groups.items():
  parts={u.get('_part_id') for u in units};statements=[s for s in answers[tid] if s.get('part_id') in parts];assert statements
  ids=list(dict.fromkeys(s['id'] for u in units for s in u['sources']));records={x:model.evidence[f"{sid}/{tid}/{x}"] for x in ids};jobs.append((sid,tid,basis,units,statements,records))
def check(job):
 sid,tid,basis,units,statements,records=job;agent=Agent(cfg.agent,dump_dir=r/'document-review'/sid/(tid+'_'+basis));topic=dict(question='\n'.join(u['question'] for u in units),answer_contract=dict(basis='investigation' if basis=='execution-check' else basis));status='supported';finding=None
 try:
  review(SimpleNamespace(cfg=cfg,agent=agent),topic,statements,{x:v['text'] for x,v in records.items()},sid+'_'+tid+'_'+basis,source_files={x:v['file'] for x,v in records.items()},source_scopes={x:v['selector']['scope'] for x,v in records.items() if v['selector'].get('scope')},context_records=records)
 except ValueError as exc:
  if basis=='execution-check' and str(exc).startswith('모델 근거 대조 실패'):
   assert len(statements)==1 and statements[0]['kind']=='limitation';status='insufficient-evidence-target-application-plan';finding=str(exc)
  else:status='failed';finding=str(exc)
 result=dict(section=sid,topic=tid,basis=basis,statements=len(statements),status=status,finding=finding,receipt=str(agent.last_receipt.relative_to(r)));print(sid+'/'+tid+'/'+basis+': '+status,flush=True);return result
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(check,jobs))
assert all(sum(x['statements'] for x in results if x['section']==sid)==n for sid,n in counts.items())
report=dict(schema=1,source_commit=model.meta['source_commit'],manuscript_hashes=hashes,profile=dict(kind=cfg.agent.kind,runner=cfg.agent.runner,model=cfg.agent.model,args=cfg.agent.args),scope='All generated statements in both changed documents, original topics/bases and complete associated contexts.',results=results,statement_counts=counts,human_review='pending',callback_runtime_validation='executed-public-virtual-CPU-only',physical_camera_validation='not-run',internal_hal_validation='not-run');(r/'independent-grounding.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');assert not any(x['status']=='failed' for x in results), 'Unresolved grounding findings retained in report.'
