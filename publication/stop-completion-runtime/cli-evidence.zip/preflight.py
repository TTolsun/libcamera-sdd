from pathlib import Path
import json, subprocess
from sdd.config import load
from sdd.llm import Agent

root=Path(__file__).resolve().parent
cfg=load(root/'workspace/sdd.yaml')
cmd=cfg.agent.command
help_text=subprocess.check_output([*cmd,'--help'],text=True,encoding='utf-8')
assert '--effort' in help_text and 'high' in help_text
version=subprocess.check_output([*cmd,'--version'],text=True).strip()
(root/'claude-help.txt').write_text(help_text,encoding='utf-8')
agent=Agent(cfg.agent,dump_dir=root/'preflight')
result=agent.chat('Return exactly OK. No tools.','Confirm this selected model and effort can complete this call.',tag='callback_preflight')
receipt=json.loads(agent.last_receipt.read_bytes())
assert receipt['model']=='claude-haiku-5-5'
assert receipt['provider']['arguments'][receipt['provider']['arguments'].index('--effort')+1]=='high'
assert set(receipt['provider']['provider']['modelUsage'])=={'claude-haiku-5-5'}
record=dict(cli_version=version,kind=cfg.agent.kind,runner=cfg.agent.runner,model=cfg.agent.model,
            args=cfg.agent.args,command=cmd,help_supports_high=True,actual_model_usage=receipt['provider']['provider']['modelUsage'],
            receipt=str(agent.last_receipt.relative_to(root)),global_defaults_changed=False,
            review_cli_version=subprocess.check_output(['codex','--version'],text=True,shell=True).strip())
(root/'preflight.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record,ensure_ascii=False))
