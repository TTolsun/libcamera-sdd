"""Record bounded per-item visualization checks of the regenerated pages."""
from pathlib import Path
import re

import yaml

from prepare_public_incremental import HEAD, OLD, OUT
from public_incremental_stage import now, read, sha, write
from sdd.document_metadata import split_frontmatter


sections=yaml.safe_load((OUT/'config/sections.yaml').read_bytes())['sections']
configured=yaml.safe_load((OUT/'config/visuals.yaml').read_bytes())['sections']
decisions={
    'responsibility':('figure', ['handler-device-ownership','acquire-release-locks'], '장치 선택·수명과 잠금 경계를 기존 두 그림에서 확인했습니다.'),
    'configuration':('figure', ['configuration-contracts'], '구성 입력과 검증의 책임을 기존 그림에서 확인했습니다.'),
    'shutdown':('figure', ['normal-dispatch-and-stop'], '정상 전달·정지 분기와 구현 주체를 기존 그림에서 확인했습니다.'),
    'input-search-boundary':('figure', ['input-search-loops'], 'IPU3 탐색 반복과 경계 조건을 기존 그림에서 확인했습니다.'),
    'queue':('figure', ['queue-gates'], '준비 상태·한도·취소·장치 전달의 분기를 기존 그림에서 확인했습니다.'),
    'completion':('figure', ['buffer-request-completion'], '버퍼 완료와 요청 완료·반환의 차이를 기존 그림에서 확인했습니다.'),
    'queue-limit':('adjacent-figure', ['queue-gates'], '세 문장이 기본 한도와 대기 의미를 설명합니다. 같은 페이지의 요청 준비 절 그림에서 한도와 대기 분기를 확인할 수 있습니다.'),
    'tuning':('figure', ['ipa-tuning-file-fallback'], '새 그림은 원래 이름과 대체 이름 검색의 분기를 설명합니다. 두 YAML의 다섯 항목과 빌드 목록은 짧은 설명으로 비교합니다.'),
    'dma-import':('figure', ['softisp-dmabuf-import-paths'], '새 그림은 미지원 형식·EGL 실패와 출력 텍스처 연결을 구분합니다. GL과 DRM 형식 대응은 본문을 대조했습니다.'),
    'softisp-lsc':('figure', ['softisp-lsc-shader-order'], '새 그림은 블랙 레벨 정규화부터 조건부 보정·색 조정의 순서를 보여 줍니다. 인터페이스 선언의 범위는 본문에서 확인합니다.'),
}

rows=[]
changed=[]
reference=OUT/'prior98/base' if (OUT/'prior98').is_dir() else OLD
for section in sections:
    filename=section.get('output',section['id']+'.md')
    if filename not in {'component-index.md','ipa-algorithms.md','pipeline-handler.md','pipeline-requests.md'}:
        continue
    document=OUT/'manuscripts'/filename
    meta,body=split_frontmatter(document.read_text(encoding='utf-8'))
    _,old=split_frontmatter((reference/'manuscripts'/filename).read_text(encoding='utf-8'))
    assert meta['source_commit']==HEAD
    if body==old:
        continue
    changed.append(filename)
    headings=list(re.finditer(r'^## ([^\n]+)\n',body,re.M))
    if section['id']=='component-index':
        for heading in headings:
            rows.append(dict(page=filename,item=heading[1],decision='omit-with-reason',figure_ids=[],
                reason='패키지별 선언과 정의를 찾는 색인입니다. 각 행이 코드 위치로 이어져 구조나 순서를 중복해 그릴 필요가 없습니다.'))
        continue
    figures={entry['id']:entry for entry in configured[section['id']]}
    for topic in section['design_topics']:
        kind,ids,reason=decisions[topic['id']]
        i=next(i for i,h in enumerate(headings) if h[1]==topic['title'])
        start=headings[i].start()
        end=headings[i+1].start() if i+1<len(headings) else len(body)
        rendered=body[start:end]
        for figure in ids:
            scope=rendered if kind=='figure' else body
            block=re.search(r'<!-- sdd:visual:'+figure+r' -->(.*?)<!-- /sdd:visual:'+figure+r' -->',scope,re.S)
            assert figure in figures and block and '```mermaid\n' in block[1], (filename,figure)
        answers=meta['generated_design']['answers'][topic['id']]
        rows.append(dict(page=filename,item=topic['id'],question=topic['question'],decision=kind,figure_ids=ids,
            answer_characters=sum(len(a['text']) for a in answers),reason=reason,document_sha256=sha(document),
            source_windows=[s['file'] for s in topic.get('sources',[])]))

review=OUT/'ipa-current-source-review-02/result.json'
assert read(review)['result']['verdict']=='pass'
write(OUT/'visual-items-assessment.json',dict(status='completed',stage='per-item-visualization-assessment',
    source_commit=HEAD,recorded_at=now(),changed_pages=sorted(changed),figure_id='ipa-tuning-file-fallback',
    ipa_source_review_sha256=sha(review),scope='Regenerated IPA, pipeline documents and index. The remaining pages were carried with their existing evidence. Full #215 inventory, device behavior and human assessment are outside this proof.',
    rows=rows,human_review='pending'))
