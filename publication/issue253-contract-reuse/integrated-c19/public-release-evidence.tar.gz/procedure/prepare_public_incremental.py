"""Keep the published corpus and select changes against the new extracted facts."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

import yaml

from sdd.carryover import carry_forward
from sdd.config import load
from sdd.document_metadata import split_frontmatter
from sdd.evidence import collect
from sdd.facts.model import KnowledgeModel


ROOT = Path(__file__).resolve().parents[2]
OLD = ROOT/'build/issue253/reader-current249/run-05'
OUT = Path(os.environ.get('SDD_ISSUE253_PUBLIC_WORK',ROOT/'build/q253pub')).resolve()
RUNTIME = ROOT/'build/q253rt2'
SOURCE = ROOT/'build/issue253/upstream-c19'
EXTRACT = ROOT/'build/issue253/consistency-cost-optimization/public-extract-v2'
SHARED = ROOT/'build/issue253/current-public-followups/issue243-followup/operation/workspace'
BASE = 'be7e83e91348250c015aad6d6f59f1468555bae8'
HEAD = 'c19d05128f3ae1f0ebe63acb4deaca9fbb1dde78'
SID = 'contract-evidence/access-default/declarations'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relocate(value):
    if isinstance(value, list):
        return [relocate(item) for item in value]
    if isinstance(value, dict):
        return {key: relocate(item) for key, item in value.items()}
    if isinstance(value, str) and value.startswith(str(OLD)+'\\'):
        return str(OUT)+value[len(str(OLD)):]
    return value


def dump(name, data):
    (OUT/name).write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding='utf-8')


def restore_declaration(cfg, model):
    original = KnowledgeModel.load(OLD/'facts/facts.json').evidence[SID]
    copy = deepcopy(cfg)
    copy.paths['sections_file'] = OUT/'audit-source-selection.yaml'
    copy.raw['documentation'] = {'enabled':False}
    selected = deepcopy(model)
    collect(copy,selected)
    record = selected.evidence[SID]
    assert set(selected.evidence) == {SID}
    assert record['commit']==HEAD and original['commit']==BASE
    assert {k:v for k,v in record.items() if k!='commit'} == {k:v for k,v in original.items() if k!='commit'}
    model.evidence[SID] = record


def main():
    manifest = json.loads((OLD/'site/site-manifest.json').read_bytes())
    assert manifest['inputs']['facts']==sha(OLD/'facts/facts.json')
    assert manifest['inputs']['english_catalog']==sha(OLD/'english-v11.json')
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()==HEAD
    OUT.mkdir(exist_ok=False)
    for name in ('manuscripts','config','profiles','historical-prerequisites'):
        shutil.copytree(OLD/name,OUT/name)
    for name in ('reader-paths.yaml','site-intro.md','translation.yaml'):
        shutil.copyfile(OLD/name,OUT/name)
    shutil.copyfile(OLD/'english-v11.json',OUT/'english.json')
    shutil.copyfile(SHARED/'audit-source-selection.yaml',OUT/'audit-source-selection.yaml')
    (OUT/'facts').mkdir()
    shutil.copyfile(EXTRACT/'facts.json',OUT/'facts/facts.json')
    config = relocate(yaml.safe_load((OLD/'publication-v12.yaml').read_bytes()))
    config['source'].update(root=str(SOURCE),compile_commands=str(EXTRACT/'compile_commands.json'))
    config['site']['english_catalog'] = str(OUT/'english.json')
    config['paths']['consistency_review_config'] = str(OUT/'review.yaml')
    config['paths'].update(prompts=str(RUNTIME/'examples/libcamera/prompts'),templates=str(RUNTIME/'templates'),style=str(RUNTIME/'style'))
    config['publication']['operation_id']='issue253-incremental-contract-public-c19'
    # Preserve all original prerequisite kinds; the final publication profile
    # will point to the corresponding current proof files.
    dump('publication-pending.yaml',config)
    review = deepcopy(config)
    review['site']['enabled']=False
    dump('review.yaml',review)
    dump('generation.yaml',review)
    cfg=load(OUT/'generation.yaml')
    m=KnowledgeModel.load(cfg.facts_path)
    assert m.meta['source_commit']==HEAD
    begin=time.perf_counter()
    collect(cfg,m)
    restore_declaration(cfg,m)
    m.save(cfg.facts_path)
    collection=time.perf_counter()-begin
    begin=time.perf_counter()
    promoted,stale=carry_forward(cfg,m,[])
    carry=time.perf_counter()-begin
    result=dict(status='completed',old_public_commit='019c8d068f140764bf9f7ed34699ddc67f7b2478',
        old_build=manifest['build_id'],source_base=BASE,source_head=HEAD,collection_seconds=collection,
        carry_seconds=carry,source_facts_sha256=sha(cfg.facts_path),source_extraction_sha256=sha(EXTRACT/'facts.json'),
        promoted=[p.relative_to(cfg.sdd_dir).as_posix() for p in promoted],stale=[dict(
            page=p.relative_to(cfg.sdd_dir).as_posix(),section=split_frontmatter(p.read_text(encoding='utf8'))[0].get('section'),
            findings=issues) for p,issues in stale],human_review='pending',human_active_review_seconds=None,
        model_calls=0,recorded_at=datetime.now(timezone.utc).isoformat())
    (OUT/'carry-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    for item in result['stale']:
        config['site']['manuscript_profiles'].pop(item['page'],None)
        review['site']['manuscript_profiles'].pop(item['page'],None)
    dump('publication-pending.yaml',config)
    dump('review.yaml',review)
    dump('generation.yaml',review)
    print('Promoted',len(promoted),'and held',len(stale),'manuscripts. Held pages:',[row['page'] for row in result['stale']])


if __name__=='__main__':
    main()
