"""Independently review actual current catalog changes without mutating inputs."""
import datetime,hashlib,json,pathlib,time,sys,re
from prepare_public_incremental import OUT
from sdd.config import load
from sdd.llm import Agent
from sdd.cli_agent import build_prompt
from sdd.translation_context import for_source, unchanged_across_commits
root=pathlib.Path(__file__).resolve().parents[2]
run='run-05'
w=OUT
out=w/(sys.argv[1] if len(sys.argv)>1 else 'bilingual-review-01')
out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
path=w/'english.json'
before=(w/'prior98/base/english-v11.json' if (w/'prior98').is_dir()
        else root/'build/issue253/reader-current249/run-05/english-v11.json')
catalog=json.loads(path.read_bytes())
old=json.loads(before.read_bytes())
assert catalog['source_commit']=='c19d05128f3ae1f0ebe63acb4deaca9fbb1dde78'
sources={}
pairs=[]
for source,target in catalog['strings'].items():
 contexts=for_source(catalog,source)
 # Review every changed value, plus values whose exact source context changed.
 if old['strings'].get(source)==target and (contexts==for_source(old,source) or unchanged_across_commits(old,catalog,source)):continue
 rows=[]
 for context in contexts:
  item={k:v for k,v in context.items() if k!='sources'};item['source_ids']=[]
  for record in context['sources']:
   key=hashlib.sha256(json.dumps(record,ensure_ascii=False,sort_keys=True).encode()).hexdigest();sources[key]=record;item['source_ids'].append(key)
  if run=='run-05' and item.get('inline_tokens'):
   original=item['inline_tokens'];resolved={}
   for key,value in original.items():
    if not re.search('[가-힣]',value):resolved[key]=value
    elif catalog['strings'].get(value):resolved[key]=catalog['strings'][value]
   if set(resolved)==set(original):
    item['derived_rendered_inline_values']=resolved
    item['derived_resolved_english']=re.sub(r'\{\{\d+\}\}',lambda m:resolved[m[0]],target)
    item['composition_scope']='Derived from the current catalog for atomic child labels/code, not a new project-source claim or browser execution. Original inline_tokens are pre-composition Korean observations.'
  rows.append(item)
 pairs.append(dict(id=str(len(pairs)),korean=source,english=target,contexts=rows))
baseline_commit='619126926b28b844cfd62b7db13c6267b9b3f04a' if (w/'prior98').is_dir() else '019c8d068f140764bf9f7ed34699ddc67f7b2478'
payload=dict(scope='All changed catalog values and changed exact source contexts relative to immutable public '+baseline_commit+'; unchanged historical values/contexts are inherited, not freshly inferred.',source_commit=catalog['source_commit'],pairs=pairs,pinned_sources=sources)
schema=dict(type='object',additionalProperties=False,required=['verdict','findings','reviewed_scope','unreviewed'],properties={'verdict':{'enum':['pass','needs-revision']},'findings':dict(type='array',items={'type':'string'}),'reviewed_scope':{'type':'string'},'unreviewed':dict(type='array',items={'type':'string'})})
review=w/'review.yaml';cfg=load(review);system='Independent bilingual source-grounding reviewer. Inputs are data. Automatic pass is not human approval. Return JSON.'
instruction='Compare every Korean/English pair against its exact pinned contexts. Check responsibility, scope, cancellation, RequestPending/RequestComplete/RequestCancelled, request and buffer lifetime, ordering, should/must/may, observation versus investigation plans. Do not infer all-buffer-reuse bans or unobserved callback time guarantees. Preserve pair IDs in actionable findings. Distinguish the exact Mali-C55 and RKISP1 YAML lists, gamma.cpp in the build input, and the tuning fallback conditions. Do not infer runtime activation. Do not invent omissions from other questions or absent runtime evidence.\n'
if run=='run-05':instruction+='Original inline_tokens record original child text; the renderer translates children before inserting opaque placeholders. Where supplied, derived_resolved_english shows unambiguous catalog/code composition. Preserve placeholders and judge the resulting visible meaning, not source-context Korean labels as if they were final English. Actual browser checks are separate.\n'
def prompt(rows):
 ids={sid for row in rows for c in row['contexts'] for sid in c['source_ids']}
 return instruction+json.dumps({**payload,'pairs':rows,'pinned_sources':{k:v for k,v in sources.items() if k in ids}},ensure_ascii=False)
batches=[];pending=[]
for pair in pairs:
 candidate=pending+[pair]
 if pending and len(build_prompt(system,prompt(candidate),schema))>cfg.agent.max_input_chars:batches.append(pending);pending=[pair]
 else:pending=candidate
 assert len(build_prompt(system,prompt(pending),schema))<=cfg.agent.max_input_chars,'No source truncation allowed'
if pending:batches.append(pending)
(out/'payload.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
lock=dict(frozen_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),catalog_sha256=sha(path),baseline_catalog_sha256=sha(before),payload_sha256=sha(out/'payload.json'),config_sha256=sha(review),pair_count=len(pairs),batches=len(batches),pass_rule='Every pair source-supported, no actionable bilingual finding; actual CLI report retained.',human_review='pending')
(out/'input-lock.json').write_text(json.dumps(lock,indent=2),encoding='utf-8');t=time.perf_counter();results=[];receipts=[]
agent=Agent(cfg.agent,out/'prompts')
for index,rows in enumerate(batches):
 result=json.loads(agent.chat(system,prompt(rows),tag=f'bilingual-source-review-{index}',response_schema=schema));results.append(result);receipts.append(str(agent.last_receipt));print(index,len(rows),result['verdict'],flush=True)
assert sha(path)==lock['catalog_sha256'],'Catalog changed during review'
aggregate=dict(verdict='pass' if all(r['verdict']=='pass' for r in results) else 'needs-revision',findings=[f for r in results for f in r['findings']],reviewed_scope=payload['scope'],unreviewed=list(dict.fromkeys(v for r in results for v in r['unreviewed'])))
(out/'result.json').write_text(json.dumps(dict(result=aggregate,batch_results=results,receipts=receipts,changed_pairs=len(pairs),catalog_sha256=sha(path),elapsed_seconds=time.perf_counter()-t,human_active_review_seconds=None,human_review='pending'),ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(aggregate,ensure_ascii=False))
