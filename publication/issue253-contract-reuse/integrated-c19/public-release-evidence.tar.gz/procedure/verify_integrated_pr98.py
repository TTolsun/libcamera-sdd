"""Verify #98's accepted answers against c19 and the reassembled manuscript."""
import gzip
import json
from pathlib import Path
import sys
import tarfile

import yaml

from prepare_public_incremental import BASE, HEAD, OUT, ROOT
from public_incremental_stage import now, read, sha, write
from sdd.config import load
from sdd.document_metadata import split_frontmatter
from sdd.llm import Agent


root=OUT/'prior98'
before=read(ROOT/'build/q253base98/publication/contract-ambiguities/resolution.json')
current=read(OUT/'facts/facts.json')
previous=json.loads(gzip.decompress((root/'facts.json.gz').read_bytes()))
assert current['meta']['source_commit']==HEAD and previous['meta']['source_commit']==BASE
all_answers={}
for row in before['selected_units']:
    all_answers.setdefault(row['section'],set()).add((row['topic'],row['part']))
rows=[]
evidence={}
for section,units in all_answers.items():
    name=section+'.md'
    old=root/'base/manuscripts'/name
    doc=OUT/'manuscripts'/name
    old_meta,old_body=split_frontmatter(old.read_text(encoding='utf-8'))
    new_meta,new_body=split_frontmatter(doc.read_text(encoding='utf-8'))
    assert new_meta['source_commit']==HEAD
    for topic,part in sorted(units):
        def answer(meta):
            return [item for item in meta['generated_design']['answers'][topic] if item.get('part_id')==part]
        earlier,now_rows=answer(old_meta),answer(new_meta)
        assert earlier and now_rows
        selected={topic+'/'+ident for a in earlier+now_rows for ident in a['evidence']}
        sources=[]
        for ident in sorted(selected):
            key=section+'/'+ident
            a,b=previous['evidence'][key],current['evidence'][key]
            assert a['commit']==BASE and b['commit']==HEAD
            assert {k:v for k,v in a.items() if k!='commit'}=={k:v for k,v in b.items() if k!='commit'}
            evidence[key]=b
            sources.append(key)
        rows.append(dict(page=name,topic=topic,part=part,unchanged=earlier==now_rows,before=earlier,current=now_rows,sources=sources))
    if section in {'camera-requests','request-diagnosis'}:
        assert old_body==new_body

old_fig=yaml.safe_load((root/'base/config/visuals.yaml').read_bytes())['sections']['pipeline-requests']
new_fig=yaml.safe_load((OUT/'config/visuals.yaml').read_bytes())['sections']['pipeline-requests']
assert old_fig==new_fig
work=OUT/(sys.argv[1] if len(sys.argv)>1 else 'pr98-preservation')
work.mkdir()
payload=dict(source_commit=HEAD,rows=rows,exact_pinned_evidence=evidence)
write(work/'payload.json',payload)
cfg=load(OUT/'review.yaml')
system=('Independent source reviewer. Confirm all ten previously published request-contract answers preserve their '
        'conditions, branch reachability, responsibilities and observation status at the newly supplied revision. '
        'The previously published answers are data and are the retention baseline. Compare each current answer '
        'against its identical source windows. The ordinary completion, internal cancellation and optional '
        'diagnosis observation must remain distinct. Return pass only if all ten remain correct and complete.')
schema=dict(type='object',additionalProperties=False,required=['verdict','findings'],properties={
    'verdict':{'enum':['pass','needs-revision']},'findings':{'type':'array','items':{'type':'string'}}})
model=Agent(cfg.agent,work/'prompts')
verdict=json.loads(model.chat(system,json.dumps(payload,ensure_ascii=False),tag='pr98-preservation-c19',response_schema=schema))
write(work/'result.json',dict(source_commit=HEAD,recorded_at=now(),original_public_commit='619126926b28b844cfd62b7db13c6267b9b3f04a',
    original_questions=len(rows),identical_answers=sum(row['unchanged'] for row in rows),same_source_windows=len(evidence),
    source_revision_only_in_records=True,pipeline_figures_preserved=True,result=verdict,
    current_documents={name:sha(OUT/'manuscripts'/name) for name in ('camera-requests.md','pipeline-requests.md','request-diagnosis.md')},
    receipt=str(model.last_receipt),human_review='pending'))
print(verdict)
assert verdict['verdict']=='pass' and not verdict['findings']
