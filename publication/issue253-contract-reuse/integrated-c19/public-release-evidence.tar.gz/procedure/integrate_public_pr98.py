"""Preserve the published #98 contracts in the independently extracted c19 corpus."""
from copy import deepcopy
import gzip
import json
from pathlib import Path, PurePosixPath
import shutil
import tarfile

import yaml

from prepare_public_incremental import BASE, HEAD, OUT, ROOT, OLD, RUNTIME, restore_declaration
from public_incremental_stage import now, read, sha, write
from sdd.carryover import carry_forward
from sdd.config import load
from sdd.document_metadata import split_frontmatter
from sdd.evidence import collect
from sdd.facts.model import KnowledgeModel


candidate=ROOT/'build/q253pub'
baseline=ROOT/'build/q253base98'
assert OUT==ROOT/'build/q253pub98'
published=baseline/'publication/contract-ambiguities'
archive=published/'native-and-public-evidence.tar.gz'
package=read(published/'package.json')
assert sha(archive)==package['archive_sha256']
manifest=read(baseline/'docs/site-manifest.json')
assert manifest['build_id']==package['build_id']
OUT.mkdir(exist_ok=False)
for name in ('config','profiles','historical-prerequisites','facts','manuscripts'):
    shutil.copytree(candidate/name,OUT/name)
for name in ('reader-paths.yaml','site-intro.md','translation.yaml','audit-source-selection.yaml','source-scope-binding-v2.json',
             'retention249-body-and-source-equivalence.json','contract-archive-transfer.json'):
    shutil.copyfile(candidate/name,OUT/name)
for name in ('generation.yaml','review.yaml','publication-pending.yaml'):
    path=OUT/name
    path.write_text((candidate/name).read_text(encoding='utf-8').replace(str(candidate),str(OUT)),encoding='utf-8')

reference=OUT/'prior98'
reference.mkdir()
with tarfile.open(archive) as tar:
    for member in tar:
        name=member.name
        if not (name.startswith(('base/','merged-audit-groups/')) or name=='facts.json.gz'):
            continue
        rel=PurePosixPath(name)
        assert member.isfile() and not rel.is_absolute() and '..' not in rel.parts and ':' not in name and '\\' not in name
        target=reference.joinpath(*rel.parts)
        assert target.resolve().is_relative_to(reference)
        target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as stream:
            shutil.copyfileobj(tar.extractfile(member),stream)

prior=reference/'base'
assert sha(prior/'english-v11.json')==manifest['inputs']['english_catalog']
assert sha(prior/'build/consistency-review.json')==manifest['inputs']['consistency_review']
assert read(prior/'build/consistency-review.json')['status']=='passed'
old98_model=KnowledgeModel.from_dict(json.loads(gzip.decompress((reference/'facts.json.gz').read_bytes())))
assert old98_model.meta['source_commit']==BASE

selected={'camera-requests','pipeline-requests','request-diagnosis'}
for ident in selected:
    name=ident+'.md'
    path=prior/'manuscripts'/name
    assert sha(path)==manifest['inputs']['markdown/'+name]
    shutil.copyfile(path,OUT/'manuscripts'/name)
shutil.copyfile(prior/'english-v11.json',OUT/'english.json')
for path in ('sections.yaml','visuals.yaml'):
    current=OUT/'config'/path
    data=yaml.safe_load(current.read_bytes())
    earlier=yaml.safe_load((prior/'config'/path).read_bytes())
    if path=='sections.yaml':
        overrides={s['id']:s for s in earlier['sections'] if s['id'] in selected}
        assert set(overrides)==selected
        data['sections']=[overrides.get(section['id'],section) for section in data['sections']]
    else:
        for ident in selected:
            if ident in earlier['sections']:
                data['sections'][ident]=earlier['sections'][ident]
    current.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')

# Candidate input files and canonical receipts stay intact; the independent
# #98 receipts are a second cache population and are never substituted for
# same-key current-source records. Both original archives remain available.
build=OUT/'build'
build.mkdir()
for part in ('prompts','translation-prompts','cli-checkpoints'):
    shutil.copytree(candidate/'build'/part,build/part)
imports={}
for part in ('prompts','translation-prompts','cli-checkpoints'):
    root=prior/'build'/part
    counts=dict(imported=0,identical=0,kept_current=0)
    for path in root.rglob('*'):
        if not path.is_file():
            continue
        destination=build/part/path.relative_to(root)
        destination.parent.mkdir(parents=True,exist_ok=True)
        if destination.exists():
            if sha(path)==sha(destination):
                counts['identical']+=1
            else:
                assert part=='cli-checkpoints', str(destination)
                counts['kept_current']+=1
        else:
            shutil.copyfile(path,destination)
            counts['imported']+=1
    imports[part]=counts

for filename in ('impact.json','impact-review.md','change_impact.md'):
    shutil.copyfile(candidate/'build'/filename,build/filename)

cfg=load(OUT/'generation.yaml')
model=KnowledgeModel.load(cfg.facts_path)
collect(cfg,model)
restore_declaration(cfg,model)
model.save(cfg.facts_path)

def evidence_values(model, selected):
    return {k:{name:value for name,value in v.items() if name!='commit'} for k,v in model.evidence.items()
            if k.split('/')[0] in selected}


assert evidence_values(old98_model,selected)==evidence_values(model,selected)
promoted,stale=carry_forward(cfg,model,[])
records=[]
for page,issues in stale:
    meta,_=split_frontmatter(page.read_text(encoding='utf-8'))
    records.append(dict(page=page.relative_to(cfg.sdd_dir).as_posix(),section=meta['section'],findings=issues))
assert set(r['section'] for r in records)<=selected
write(OUT/'carry-result.json',dict(status='completed',source_head=HEAD,source_base=BASE,
    original_candidate=str(candidate),public_base='619126926b28b844cfd62b7db13c6267b9b3f04a',
    promoted=[p.relative_to(cfg.sdd_dir).as_posix() for p in promoted],stale=records,
    imported_native_archive=imports,source_windows=len(evidence_values(model,selected)),recorded_at=now(),human_review='pending'))
print('Promoted:',[p.name for p in promoted], 'needs assembly:', [r['section'] for r in records], 'archives:', imports)
