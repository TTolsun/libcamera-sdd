"""Bind verification profiles and the latest published contract baseline."""
from copy import deepcopy
from pathlib import Path

import yaml

from prepare_public_incremental import HEAD, OUT
from public_incremental_stage import now, read, sha, write
from sdd.carryover import carry_forward
from sdd.config import load
from sdd.document_metadata import split_frontmatter
from sdd.facts.model import KnowledgeModel


prior=OUT/'prior98/base'
base_profile=OUT/'baseline98.yaml'
for name in ('generation.yaml','review.yaml','publication-pending.yaml'):
    path=OUT/name
    cfg=yaml.safe_load(path.read_bytes())
    for filename in ('camera-requests.md','pipeline-requests.md','request-diagnosis.md'):
        cfg['site']['manuscript_profiles'].pop(filename,None)
    cfg['publication']['baseline_config']=str(base_profile)
    cfg['publication']['operation_id']='issue253-integrated-pr98-libcamera-c19'
    path.write_text(yaml.safe_dump(cfg,allow_unicode=True,sort_keys=False),encoding='utf-8')
    if name=='generation.yaml':
        baseline=deepcopy(cfg)
        baseline['paths']['sections_file']=str(prior/'config/sections.yaml')
        baseline['publication']={}
        base_profile.write_text(yaml.safe_dump(baseline,allow_unicode=True,sort_keys=False),encoding='utf-8')

cfg=load(OUT/'generation.yaml')
model=KnowledgeModel.load(cfg.facts_path)
assert model.meta['source_commit']==HEAD
before=read(OUT/'carry-result.json')
promoted,stale=carry_forward(cfg,model,[])
rows=[]
for path,issues in stale:
    meta,_=split_frontmatter(path.read_text(encoding='utf-8'))
    rows.append(dict(page=path.relative_to(cfg.sdd_dir).as_posix(),section=meta['section'],findings=issues))
assert {row['section'] for row in rows}=={'pipeline-requests'}, rows
prior_record=OUT/'carry-before-profile-binding.json'
(OUT/'carry-result.json').rename(prior_record)
write(OUT/'carry-result.json',{**before,'previous_sha256':sha(prior_record),'profile_binding_at':now(),
    'promoted':before['promoted']+[p.relative_to(cfg.sdd_dir).as_posix() for p in promoted], 'stale':rows})
print('Assemble',rows,flush=True)
