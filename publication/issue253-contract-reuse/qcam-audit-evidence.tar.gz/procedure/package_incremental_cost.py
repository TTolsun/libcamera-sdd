"""Package and check the measured qcam audit and its original call evidence."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile


ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT/'build/issue253/consistency-cost-optimization'
RUN = WORK/'benchmark-v2'
OUT = ROOT/'build/q253record'
OUT.mkdir(exist_ok=False)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


files = {}
for path in RUN.rglob('*'):
    if not path.is_file():
        continue
    relative = path.relative_to(RUN)
    if relative.parts[:3] in (('head','build','prompts'),('head','build','cli-checkpoints')):
        continue
    files['benchmark/'+relative.as_posix()] = path
files['original-comparison/original-input-analysis.json'] = WORK/'original-input-analysis.json'
files['original-comparison/benchmark-v1-input-lock.json'] = WORK/'benchmark-v1/input-lock.json'
files['original-comparison/earlier-prototype-analysis.json'] = WORK/'new-policy-input-analysis.json'
for path in sorted(WORK.glob('code-review-*')):
    for member in path.rglob('*'):
        if member.is_file():
            files['review/'+member.relative_to(WORK).as_posix()] = member
for name in ('analyze_consistency_cost.py','prepare_incremental_benchmark_v2.py',
             'seed_contract_reviews.py','measure_incremental_audit.py','package_incremental_cost.py'):
    files['procedure/'+name] = ROOT/'build/issue253'/name

archive = OUT/'qcam-audit-evidence.tar.gz'
index = {}
with archive.open('wb') as raw, gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
    with tarfile.open(fileobj=compressed,mode='w') as tar:
        for name,path in sorted(files.items()):
            content = path.read_bytes()
            item = tarfile.TarInfo(name)
            item.size = len(content)
            item.mode = 0o644
            tar.addfile(item,io.BytesIO(content))
            index[name] = dict(bytes=len(content),sha256=digest(content),recorded_path=str(path))
with tarfile.open(archive,'r:gz') as tar:
    checked = set()
    for item in tar:
        assert item.isfile() and item.name not in checked and item.name in index
        assert digest(tar.extractfile(item).read())==index[item.name]['sha256']
        checked.add(item.name)
    assert checked==set(index)

summary = json.loads((RUN/'measured-audit.json').read_bytes())
assert summary['warm_head_fresh_calls']==0 and len(summary['verified_original_receipts'])==88
(OUT/'archive-index.json').write_text(json.dumps(index,indent=2),encoding='utf8')
(OUT/'measured-audit.json').write_bytes((RUN/'measured-audit.json').read_bytes())
package = dict(status='verified',archive=archive.name,archive_sha256=digest(archive.read_bytes()),
    archive_index_sha256=digest((OUT/'archive-index.json').read_bytes()),files=len(index),
    native_receipts=88,source='Public libcamera qcam parent/head',runtime=summary['runtime'],
    reproduction='Use the pinned runtime and the original maintenance-cost-v2 package for unchanged external profiles and assets. Relocate recorded input paths. The head uses the identical original parent prompt/checkpoint archive as measured. Archive entries are evidence from actual runs. Any new cold run must use the selected CLI.',
    limitations='The controlled old translation remains blocked on both revisions. Human review pending. Earlier prototype metadata-only preflight and rejected code reviews are preserved as history.')
(OUT/'package.json').write_text(json.dumps(package,indent=2),encoding='utf8')
print('Verified archive',len(index),'files',archive.stat().st_size,'bytes',flush=True)
