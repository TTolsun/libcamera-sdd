"""Measure warm qcam update through the normal CLI and publication verifier."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

from sdd.call_records import load_record
from sdd.cli_provenance import verify_cli_receipt
from sdd.config import load
from sdd.consistency import enforce, policy_hash
from sdd.facts.model import KnowledgeModel


ROOT = Path(__file__).resolve().parents[2]
RUNTIME = ROOT/'build/q253rt2'
OUT = ROOT/'build/issue253/consistency-cost-optimization/benchmark-v2'
LOCK = json.loads((OUT/'input-lock.json').read_bytes())
assert policy_hash() == LOCK['policy']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=RUNTIME,text=True).strip()==LOCK['runtime']
SEED = json.loads((OUT/'base/native-seed-01/result.json').read_bytes())
assert SEED['status'] == 'completed-awaiting-normal-audit' and SEED['new_original_calls'] == 88
LEDGER = OUT/'measured-audit.json'
assert not LEDGER.exists()
rows = []


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def archive(side):
    cfg = load(OUT/side/'review.yaml')
    calls = cfg.build_dir/'prompts/calls'
    result = {}
    for p in sorted(calls.rglob('*.receipt.json')):
        record = load_record(p, root=calls)
        verified = verify_cli_receipt(record.request, record.raw, record.receipt, calls, cfg.agent)
        result[p.relative_to(calls).as_posix()] = dict(sha256=digest(p),
            source_commit=json.loads(record.request['user'])['source_commit'], **verified)
    return result


def normal(side):
    folder = OUT/side
    for rel, expected in LOCK['conditions'][side]['files'].items():
        assert digest(folder/rel)==expected
    row = dict(stage='normal-audit-'+side, started_at=datetime.now(timezone.utc).isoformat(),
        human_active_review_seconds=None)
    argv = [sys.executable,str(RUNTIME/'tools/run_sdd.py'),'--config',str(folder/'review.yaml'),'audit-consistency']
    t = time.perf_counter()
    with (folder/'normal-audit.log').open('w', encoding='utf-8') as stream:
        p = subprocess.run(argv,cwd=RUNTIME,stdout=stream,stderr=subprocess.STDOUT,timeout=1200)
    row.update(elapsed_seconds=time.perf_counter()-t,returncode=p.returncode,argv=argv)
    rows.append(row)
    print(row,flush=True)
    result = json.loads((folder/'build/consistency-review.json').read_bytes())
    assert result['status'] in ('passed','failed')
    assert p.returncode == (0 if result['status']=='passed' else 1)
    assert result['fresh_batches']==0 and result['reused_batches']==88
    cfg = load(folder/'review.yaml')
    model = KnowledgeModel.load(cfg.facts_path)
    t = time.perf_counter()
    try:
        enforce(cfg,model)
    except ValueError as exc:
        assert result['status']=='failed' and 'failed or is incomplete' in str(exc)
        status='blocked-by-contract-contradiction'
    else:
        assert result['status']=='passed'
        status='passed'
    rows.append(dict(stage='publication-contract-enforcement-'+side,status=status,
                     elapsed_seconds=time.perf_counter()-t,human_active_review_seconds=None))
    return result


base_before = archive('base')
assert len(base_before)==88
base = normal('base')
assert archive('base')==base_before and base['source_equivalent_batches']==0
t = time.perf_counter()
for name in ('cli-checkpoints','prompts'):
    shutil.copytree(OUT/'base/build'/name,OUT/'head/build'/name)
rows.append(dict(stage='copy-original-checkpoints-and-receipts',elapsed_seconds=time.perf_counter()-t))
head_before = archive('head')
assert head_before==base_before
head = normal('head')
assert archive('head')==head_before and head['source_equivalent_batches']==88
assert base['status']==head['status']
assert base['unresolved']==head['unresolved']
for parent, updated in zip(base['contracts'], head['contracts']):
    assert parent['id']==updated['id'] and parent['findings']==updated['findings']
    for origin in updated['review_units']:
        assert origin['reviewed_source_commit']==base['source_commit']
        assert origin['current_source_commit']==head['source_commit']
        assert origin['review_request_sha256']!=origin['request_sha256']

result = dict(status='verified',runtime=LOCK['runtime'],policy=LOCK['policy'],
    original_head_fresh_calls=88,original_head_sequential_audit_seconds=2989.341531,
    current_policy_first_seed_calls=88,seed_workers=SEED['concurrency'],seed_seconds=SEED['elapsed_seconds'],
    warm_head_fresh_calls=0,warm_head_original_receipts_revalidated=88,
    source_equivalent_batches=88,findings_and_unresolved_identical=True,
    unresolved_count=len(head['unresolved']),head_contract_status=head['status'],
    stages=rows,verified_original_receipts=base_before,
    human_review='pending',human_active_review_seconds=None,
    scope='Audit stage of original qcam source pair. Same complete target/primary/source coverage. Original sequential cold run, current parallel cold seed and current warm normal audit are separate measurements. No extraction, generation, translation, total labor or production saving rate measured here.')
LEDGER.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print({k:v for k,v in result.items() if k!='verified_original_receipts'},flush=True)
