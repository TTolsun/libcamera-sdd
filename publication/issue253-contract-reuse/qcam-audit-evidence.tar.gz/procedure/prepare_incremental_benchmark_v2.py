"""Freeze the original qcam pair before current-policy CLI cost measurement."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

import yaml

from sdd.config import load
from sdd.consistency import batches, groups, policy_hash, request, review_store
from sdd.facts.model import KnowledgeModel
from sdd.validation_stage import stage


ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT/'build/issue253/consistency-cost-optimization'
RUNTIME = ROOT/'build/q253rt2'
ORIGINAL = ROOT/'build/issue253/cost-followup/manuscript-run-02'
OUT = WORK/'benchmark-v2'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare(side):
    base = ORIGINAL/side
    folder = OUT/side
    folder.mkdir(parents=True)
    shutil.copytree(base/'facts', folder/'facts')
    shutil.copytree(base/'manuscripts', folder/'manuscripts')
    shutil.copyfile(base/'english.json', folder/'english.json')
    config = yaml.safe_load((base/'review-v2.yaml').read_bytes())
    config['output'].update(facts_dir=str(folder/'facts'), sdd_dir=str(folder/'manuscripts'),
                            diagrams_dir=str(folder/'manuscripts/diagrams'))
    config['site']['english_catalog'] = str(folder/'english.json')
    config['paths']['consistency_review_config'] = str(folder/'review.yaml')
    config['publication']['operation_id'] = 'issue253-incremental-contract-'+side
    profile = folder/'review.yaml'
    profile.write_text(yaml.safe_dump(config, allow_unicode=True, sort_keys=False), encoding='utf-8')
    files = {}
    for item in sorted(folder.rglob('*')):
        if not item.is_file():
            continue
        rel = item.relative_to(folder).as_posix()
        files[rel] = digest(item)
        if item != profile:
            assert files[rel] == digest(base/rel)
    cfg = load(profile)
    model = KnowledgeModel.load(cfg.facts_path)
    assert cfg.agent.runner == 'codex' and cfg.agent.model == 'gpt-6.1-terra'
    assert cfg.agent.args == ['-c', 'model_reasoning_effort="high"']
    rows = []
    with stage() as observed:
        observed.pin(cfg, model)
        for group in groups(cfg):
            payload = request(cfg, model, group)
            for index, batch in enumerate(batches(payload, max_input_chars=cfg.agent.max_input_chars)):
                store, wire = review_store(cfg, batch)
                assert store.read() is None
                rows.append(dict(group=group['id'], index=index, key=store.path.name,
                    target_ids=list(batch['claims']), primary_peer_ids=list(batch['peer_claims']),
                    source_ids=list(batch['sources']), literal_request_sha256=hashlib.sha256(wire['user'].encode()).hexdigest()))
        observed.verify()
    return dict(source_commit=model.meta['source_commit'], files=files, units=rows)


assert not OUT.exists()
rows = {side: prepare(side) for side in ('base', 'head')}
assert len(rows['base']['units']) == len(rows['head']['units']) == 88
for base, head in zip(rows['base']['units'], rows['head']['units']):
    assert base['literal_request_sha256'] != head['literal_request_sha256']
    assert {k:v for k,v in base.items() if k!='literal_request_sha256'} == {
        k:v for k,v in head.items() if k!='literal_request_sha256'}
data = dict(frozen_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    runtime=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=RUNTIME, text=True).strip(),
    policy=policy_hash(), conditions=rows, original_input_analysis_sha256=digest(WORK/'original-input-analysis.json'),
    criteria='Retain88 target batches, all primary comparison claims and exact current sources. Fresh seed88 original native receipts. Head must use normal audit and publication enforcement. Reuse only identical lookup keys with full archived native request verification. Contradictions and unresolved findings unchanged by reuse.',
    scope='Audit-only cost experiment. Original actual qcam parent/head facts, manuscripts and English catalogs copied byte-for-byte. No extraction, generation or translation cost repeated. Different initial policy and warm versus cold state accounted for.',
    human_review='pending', human_active_review_seconds=None)
(OUT/'input-lock.json').write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
print('Locked88 identical lookup keys, different full native request hashes and all original target/peer/source IDs.')
