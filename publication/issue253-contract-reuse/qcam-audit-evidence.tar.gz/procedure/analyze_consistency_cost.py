import pathlib,json,datetime,hashlib,collections,sys
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.consistency import groups,request,batches,wire_payload,policy_hash,review_store
r=pathlib.Path(__file__).resolve().parents[2];out=r/'build/issue253/consistency-cost-optimization';out.mkdir(exist_ok=True);old=r/'build/issue253/cost-followup/manuscript-run-02';data={};sha=lambda a:hashlib.sha256(json.dumps(a,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
for side in ['base','head']:
 cfg=load(old/side/'review-v2.yaml');model=KnowledgeModel.load(cfg.facts_path);units=[]
 for g in groups(cfg):
  p=request(cfg,model,g)
  for i,b in enumerate(batches(p,max_input_chars=cfg.agent.max_input_chars)):
   w=wire_payload(b);n={k:v for k,v in w.items() if k!='source_commit'};units.append(dict(group=g['id'],index=i,wire=w,request_sha256=sha(w),without_revision_sha256=sha(n),claim_count=len(b['claims']),primary_peers=len(b.get('peer_claims',{}))))
 data[side]=dict(source_commit=model.meta['source_commit'],build_dir=str(cfg.build_dir),existing_checkpoint_files=len(list((cfg.build_dir/'cli-checkpoints').glob('*.json'))),units=units)
assert len(data['base']['units'])==len(data['head']['units']);same=0;diff=[];topchanges=collections.Counter()
for a,b in zip(data['base']['units'],data['head']['units']):
 assert (a['group'],a['index'])==(b['group'],b['index'])
 if a['without_revision_sha256']==b['without_revision_sha256']:same+=1
 changes=[k for k in a['wire'].keys()|b['wire'].keys() if a['wire'].get(k)!=b['wire'].get(k)];topchanges.update(changes)
 if changes!=['source_commit']:diff.append(dict(group=a['group'],index=a['index'],changed_fields=changes))
report=dict(measured_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),runtime=sys.path[0],review_policy=policy_hash(),scope='Original controlled qcam parent/head inputs, no model calls, original runs unchanged',conditions={k:{f:v for f,v in d.items() if f!='units'} for k,d in data.items()},units_per_condition=len(data['base']['units']),identical_except_source_commit=same,top_field_change_counts=dict(topchanges),other_differences=diff,inputs=data,human_review='pending')
p=out/'original-input-analysis.json';assert not p.exists();p.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps({k:report[k] for k in ['conditions','units_per_condition','identical_except_source_commit','top_field_change_counts','other_differences']},ensure_ascii=False))
