"""Add source-bound figures to regenerated complex IPA items."""
from pathlib import Path
import shutil
import sys

import yaml

from prepare_public_incremental import HEAD, OUT
from public_incremental_stage import now, read, sha, write


path=OUT/'config/visuals.yaml'
archive=OUT/'before-ipa-figures'
fix=len(sys.argv)>1 and sys.argv[1]=='--fix-quotes'
if fix:
    archive=OUT/'before-ipa-figure-quote-fix'
archive.mkdir(exist_ok=False)
for item in (path,OUT/'manuscripts/ipa-algorithms.md',OUT/'english.json'):
    shutil.copyfile(item,archive/item.name)
facts=read(OUT/'facts/facts.json')
assert facts['meta']['source_commit']==HEAD


def evidence(source,*literals):
    record=facts['evidence']['ipa-algorithms/'+source]
    assert record['status']=='available' and record['commit']==HEAD
    assert all(literal in record['text'] for literal in literals)
    return [dict(source=source,sha256=record['sha256'],quote=literal) for literal in literals]


def node(ident,ko,en,proof,decision=False):
    value=dict(id=ident,label=ko,label_en=en,evidence=proof)
    if decision:
        value['shape']='decision'
    return value


def edge(left,right,ko,en,proof):
    return {'from':left,'to':right,'label':ko,'label_en':en,'evidence':proof}


def dma(*literals):
    return evidence('dma-import/import',*literals)


format_check=dma('switch (eglImage.format_)')
unknown=dma('default:\n\t\tLOG(eGL, Error) << "unhandled GL format";\n\t\treturn -ENODEV;')
image_check=dma('if (image == EGL_NO_IMAGE_KHR)')
failure=dma('eglImage.dmabuf_import_failed_ = true;\n\t\treturn -ENODEV;')
output=dma('if (output)')
attach=dma('ret = attachTextureToFBO(eglImage);')
end=dma('int ret = 0;', 'return ret;')
dma_figure=dict(id='softisp-dmabuf-import-paths',topic='dma-import',kind='flow',title='DMA-BUF 가져오기 분기',
    question='GL 형식과 EGL 이미지 검사에서 각각 어떻게 실패하며, 언제 프레임버퍼를 연결하나요?',
    nodes=[node('format','GL 형식을 지원하는가?','Is the GL format supported?',format_check,True),
           node('unknown','-ENODEV 반환','Return -ENODEV',unknown),
           node('image','EGL 이미지 생성에 실패했는가?','Did EGL image creation fail?',image_check,True),
           node('failed','실패 플래그 설정 후 -ENODEV 반환','Set the failure flag and return -ENODEV',failure),
           node('output','출력 텍스처인가?','Is this an output texture?',output,True),
           node('attach','프레임버퍼 연결 결과 반환','Return the framebuffer attachment result',attach),
           node('success','0 반환','Return 0',end)],
    edges=[edge('format','unknown','아니요','No',unknown),edge('format','image','예, DRM 형식 선택','Yes, select the DRM format',
           dma('drm_format = DRM_FORMAT_R8;', 'vtable_.eglCreateImageKHR')),
           edge('image','failed','예','Yes',failure),edge('image','output','아니요','No',output),
           edge('output','attach','예','Yes',attach),edge('output','success','아니요','No',end)])


def shaders(*literals):
    return evidence('softisp-lsc/packed-shader',*literals)+evidence('softisp-lsc/unpacked-shader',*literals)


black=shaders('rgb = (rgb - blacklevel) / (1.0 - blacklevel);')
condition=shaders('#if defined(APPLY_LSC)')
apply=evidence('softisp-lsc/packed-shader','texture2D(lsc_tex, textureOut).rgb * 4.0')+evidence('softisp-lsc/unpacked-shader','texture2D(lsc_tex, center.xy).rgb * 4.0')
awb=shaders('rgb = clamp(rgb * awb, vec3(0.0), vec3(1.0));')
color=shaders('rgb = ccm * rgb;', 'rgb = clamp(rgb, 0.0, 1.0);', 'rgb.r = apply_contrast(rgb.r);', 'rgb = pow(rgb, vec3(gamma));')
lsc_figure=dict(id='softisp-lsc-shader-order',topic='softisp-lsc',kind='flow',title='셰이더의 렌즈 음영 보정 위치',
    question='두 셰이더에서 어떤 조건일 때 렌즈 음영을 보정하며, 전후에는 무엇을 처리하나요?',
    nodes=[node('black','블랙 레벨 정규화','Normalize the black level',black),
           node('condition','APPLY_LSC가 정의됐는가?','Is APPLY_LSC defined?',condition,True),
           node('lsc','lsc_tex의 RGB에 4.0을 곱해 적용','Apply lsc_tex RGB scaled by 4.0',apply),
           node('awb','AWB 이득 곱셈과 범위 제한','Apply AWB gains and clamp',awb),
           node('color','CCM, 범위 제한, 대비, 감마 순서','CCM, clamp, contrast, then gamma',color)],
    edges=[edge('black','condition','블랙 레벨 처리 후','After black-level correction',black+condition),
           edge('condition','lsc','예','Yes',condition+apply),edge('condition','awb','아니요','No',condition+awb),
           edge('lsc','awb','음영 보정 후','After lens shading correction',apply+awb),
           edge('awb','color','AWB 적용 후','After AWB',awb+color)])


figures=yaml.safe_load(path.read_bytes())
if fix:
    figures['sections']['ipa-algorithms']=figures['sections']['ipa-algorithms'][:1]
figures['sections']['ipa-algorithms'].extend((dma_figure,lsc_figure))
path.write_text(yaml.safe_dump(figures,allow_unicode=True,sort_keys=False),encoding='utf-8')
write(OUT/('ipa-visual-inputs-v2.json' if fix else 'ipa-visual-inputs.json'),dict(source_commit=HEAD,figure_ids=[dma_figure['id'],lsc_figure['id']],
    config_sha256=sha(path),frozen_at=now(),human_review='pending'))
