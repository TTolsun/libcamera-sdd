"""Run preserved reader interactions and the new IPA figure in Chrome."""
import json
import os
from pathlib import Path
import subprocess
import sys

from prepare_public_incremental import OUT, ROOT, RUNTIME
from public_incremental_stage import now, read, sha, write


prefix='preflight-' if len(sys.argv)>1 and sys.argv[1]=='--preflight' else ''
server=read(OUT/(prefix+'preview-server.json'))
modules=ROOT/'build/issue253/browser-qa/node_modules'
source=RUNTIME/'examples/libcamera/validation/issue253/reader-clarity/browser_test.cjs'
script=OUT/(prefix+'browser-core-and-tuning.cjs')
before="  {page:'vendor-overview',id:'hardware-boundary',nodes:4,search:'Camera'},"
original=source.read_text(encoding='utf-8')
before=before.removeprefix(' ')
assert original.count(before)==1
targets="\n".join((" {page:'ipa-algorithms',id:'ipa-tuning-file-fallback',nodes:6,search:{en:'fallback',ko:'대체'}},",
                    " {page:'ipa-algorithms',id:'softisp-dmabuf-import-paths',nodes:7,search:{en:'failure',ko:'실패'}},",
                    " {page:'ipa-algorithms',id:'softisp-lsc-shader-order',nodes:5,search:'APPLY_LSC'},"))
text=original.replace(before,before+'\n'+targets)
text=text.replace('await search.fill(spec.search);', "await search.fill(typeof spec.search==='string'?spec.search:spec.search[lang]);")
with script.open('x',encoding='utf-8') as stream:
    stream.write(text)
checks=[(prefix+'browser-core',['node',str(script),server['url'],str(OUT/(prefix+'browser-core')),server['directory']],dict(NODE_PATH=str(modules))),
        (prefix+'browser-retention249',['node',str(ROOT/'build/issue253/current-public249/operation/browser.cjs')],
         dict(ISSUE249_URL=server['url'],ISSUE249_BROWSER_OUT=str(OUT/(prefix+'browser-retention249')),ISSUE249_PLAYWRIGHT=str(modules/'playwright')))]
results=[]
for name,argv,extra in checks:
    started=now()
    with (OUT/(name+'.log')).open('xb') as log:
        result=subprocess.run(argv,cwd=ROOT,env={**os.environ,**extra},stdout=log,stderr=subprocess.STDOUT,timeout=1200)
    row=dict(name=name,argv=argv,script_sha256=sha(Path(argv[1])),started_at=started,
             ended_at=now(),returncode=result.returncode)
    results.append(row)
    print(name,result.returncode,flush=True)
write(OUT/(prefix+'browser-results.json'),dict(status='passed' if all(row['returncode']==0 for row in results) else 'failed',
    results=results,human_review='pending'))
assert all(row['returncode']==0 for row in results)
