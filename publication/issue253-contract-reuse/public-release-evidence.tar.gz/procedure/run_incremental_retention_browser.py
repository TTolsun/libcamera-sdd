"""Retest the preserved #249 browser contract at the current source revision."""
import os
from pathlib import Path
import subprocess

from prepare_public_incremental import BASE, HEAD, OUT, ROOT
from public_incremental_stage import now, read, sha, write


previous=read(OUT/'preflight-browser-results.json')
assert previous['status']=='failed'
core=next(row for row in previous['results'] if row['name']=='preflight-browser-core')
assert core['returncode']==0 and read(OUT/'preflight-browser-core/report.json')['status']=='passed'
source=ROOT/'build/issue253/current-public249/operation/browser.cjs'
script=OUT/'preflight-browser-retention249-current-source.cjs'
original=source.read_text(encoding='utf-8')
assert original.count(BASE)==1
with script.open('x',encoding='utf-8') as stream:
    stream.write(original.replace(BASE,HEAD))
server=read(OUT/'preflight-preview-server.json')
env={**os.environ,'ISSUE249_URL':server['url'],
     'ISSUE249_BROWSER_OUT':str(OUT/'preflight-browser-retention249-v2'),
     'ISSUE249_PLAYWRIGHT':str(ROOT/'build/issue253/browser-qa/node_modules/playwright')}
argv=['node',str(script)]
started=now()
with (OUT/'preflight-browser-retention249-v2.log').open('xb') as log:
    result=subprocess.run(argv,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
record=dict(status='passed' if result.returncode==0 else 'failed',source_commit=HEAD,
    results=[core,dict(name='preflight-browser-retention249-v2',argv=argv,script_sha256=sha(script),
                       old_script_sha256=sha(source),started_at=started,ended_at=now(),returncode=result.returncode)],
    change='The exact pinned source-link revision was updated to the candidate. All original assertions still run.',
    human_review='pending')
write(OUT/'preflight-browser-results-v2.json',record)
print(record['status'],flush=True)
assert result.returncode==0
