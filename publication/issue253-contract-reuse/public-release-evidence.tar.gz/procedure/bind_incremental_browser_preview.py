"""Bind the verified preview behavior to the byte-identical final export."""
from prepare_public_incremental import HEAD, OUT
from public_incremental_stage import now, read, sha, write


site=OUT/'site'
preview=OUT/'browser-preflight-site'
manifest=read(site/'site-manifest.json')
browser_path=OUT/'preflight-browser-results-v2.json'
browser=read(browser_path)
assert browser['status']=='passed'
assert read(OUT/'preflight-browser-core/report.json')['status']=='passed'
report_name='contract-consistency.json'
assert read(preview/report_name)['status']=='pending'
assert read(site/report_name)['status']=='passed' and sha(site/report_name)==manifest['outputs'][report_name]
diff=[name for name,digest in manifest['outputs'].items()
      if name!=report_name and (not (preview/name).is_file() or sha(preview/name)!=digest)]
assert not diff, diff
assert {p.relative_to(preview).as_posix() for p in preview.rglob('*') if p.is_file()}==set(manifest['outputs'])
write(OUT/'browser-results.json',dict(status='passed',source_commit=HEAD,build_id=manifest['build_id'],
    manifest_sha256=sha(site/'site-manifest.json'),byte_identical_preview_outputs=len(manifest['outputs'])-1,
    final_contract_report_sha256=sha(site/report_name),
    browser_preview_report_sha256=sha(browser_path),
    core_report_sha256=sha(OUT/'preflight-browser-core/report.json'),verified_at=now(),
    scope='Chrome desktop/mobile Korean and English interactions ran on the private preview. All UI assets and pages are byte-identical to the final export. The contract-report JSON alone changed from pending preview data to the verified final report. Human review remains pending.',
    human_review='pending'))
