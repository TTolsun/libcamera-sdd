"""Bind actual c19 receipts and the seven existing publication prerequisites."""
from collections import Counter
import json
from pathlib import Path
import shutil

import yaml

from prepare_public_incremental import HEAD, OLD, OUT, ROOT
from public_incremental_stage import now, read, sha, write
from sdd.call_records import load_record
from sdd.cli_provenance import verify_cli_receipt
from sdd.config import load
from sdd.consistency import enforce
from sdd.document_metadata import split_frontmatter
from sdd.facts.model import KnowledgeModel


cfg=load(OUT/'review.yaml')
audit_path=cfg.build_dir/'consistency-review.json'
facts=KnowledgeModel.load(cfg.facts_path)
assert enforce(cfg,facts)==None  # Normal publication gate authenticates the current report and its run.
audit=read(audit_path)
assert audit['status']=='passed' and audit['source_commit']==HEAD
seed=read(OUT/'public-native-audit-seed-final/result.json')
assert seed['status']=='completed-awaiting-normal-audit'
assert seed['planned_units']==audit['fresh_batches']+audit['reused_batches']
assert seed['planned_new_calls']==seed['new_original_calls']

tuning_path=OUT/'ipa-current-source-review-02/result.json'
tuning=read(tuning_path)
bilingual_path=OUT/'bilingual-review-02/result.json'
bilingual=read(bilingual_path)
catalog=OUT/'english.json'
ipa_page=OUT/'manuscripts/ipa-algorithms.md'
assert tuning['result']['verdict']==bilingual['result']['verdict']=='pass'
assert tuning['document_sha256']==sha(ipa_page) and bilingual['catalog_sha256']==sha(catalog)
assert not tuning['result']['findings'] and not bilingual['result']['findings']

boundary=read(OUT/'carry-result.json')['recorded_at']
rows=[]
historic=[]
failed=[]
seen=set()
for path in sorted(OUT.rglob('*.receipt.json')):
    checksum=sha(path)
    if checksum in seen:
        continue
    seen.add(checksum)
    receipt=read(path)
    row=dict(path=path.relative_to(OUT).as_posix(),sha256=checksum,tag=receipt['tag'])
    if receipt.get('completed_at','')<boundary:
        historic.append(row)
        continue
    if receipt.get('provider',{}).get('exit_code')!=0:
        failed.append(row)
        continue
    record=load_record(path,root=path.parent)
    call_dir=next(parent for parent in path.parents if parent.name=='calls')
    rows.append({**row,**verify_cli_receipt(record.request,record.raw,receipt,call_dir,cfg.agent)})
assert rows
native=OUT/'native-call-verification.json'
write(native,dict(status='verified',stage='after-independent-review',source_commit=HEAD,boundary_at=boundary,
    completed_new_original_receipts=len(rows),new_tag_counts=dict(Counter(row['tag'] for row in rows)),
    records=rows, historical_receipts=historic,failed_receipts=failed,human_review='pending',human_active_review_seconds=None))

retention=read(OUT/'retention249-body-and-source-equivalence.json')
assert retention['status']=='verified' and retention['new_reader_trials']==0
request=OUT/'manuscripts/request-lifecycle.md'
assert retention['manuscript_sha256']==sha(request)
acceptance=OUT/'acceptance.json'
write(acceptance,dict(status='passed',stage='issue249-representative-automatic-review',source_commit=HEAD,
    manuscript_sha256=sha(request),catalog_sha256=sha(catalog),historical_original_automatic_passed=5,
    current_equivalence_proof_sha256=sha(OUT/'retention249-body-and-source-equivalence.json'),
    bilingual_result_sha256=sha(bilingual_path),ipa_tuning_review_sha256=sha(tuning_path),
    normal_audit_sha256=sha(audit_path),automatic_unresolved_count=len(audit['unresolved']),
    new_reader_trials=0,human_participants=0,human_review='pending',human_active_review_seconds=None))

rows=[]
for page in sorted((OUT/'manuscripts').rglob('*.md')):
    name=page.relative_to(OUT/'manuscripts').as_posix()
    original=OLD/'manuscripts'/name
    new_meta,new_body=split_frontmatter(page.read_text(encoding='utf-8'))
    _,old_body=split_frontmatter(original.read_text(encoding='utf-8'))
    assert new_meta['source_commit']==HEAD
    artifact=new_meta.get('generated_design',{})
    rows.append(dict(page=name,previous_sha256=sha(original),current_sha256=sha(page),
        body_changed=old_body!=new_body,reused_topics=artifact.get('reused_topics',[]),
        generated_topics=artifact.get('generated_topics',[])))
changed={row['page'] for row in rows if row['body_changed']}
assert len(rows)==29 and changed<={'component-index.md','ipa-algorithms.md','pipeline-handler.md','pipeline-requests.md'}
assert {'component-index.md','ipa-algorithms.md'}<=changed
write(OUT/'manuscript-retention.json',dict(source_commit=HEAD,rows=rows,changed=sorted(changed),human_review='pending'))

visuals=OUT/'per-item-visualization.json'
visual_assessment=OUT/'visual-items-assessment.json'
assessed=read(visual_assessment)
assert assessed['status']=='completed' and assessed['source_commit']==HEAD
assert assessed['figure_id']=='ipa-tuning-file-fallback' and assessed['ipa_source_review_sha256']==sha(tuning_path)
assert set(assessed['changed_pages'])==changed
shutil.copyfile(visual_assessment,visuals)

regression=ROOT/'build/q253record/regression.json'
assert read(regression)['status']=='passed'
profile=yaml.safe_load((OUT/'publication-pending.yaml').read_bytes())
reports=profile['publication']['reports']
assert len(reports)==7
current=[regression,visuals,native,audit_path,acceptance]
for row,path in zip(reports[2:],current,strict=True):
    data=read(path)
    row.update(path=str(path),sha256=sha(path),bindings={key:data[key] for key in row['bindings']})
for row in reports[:2]:
    assert sha(Path(row['path']))==row['sha256']
destination=OUT/'publication.yaml'
with destination.open('x',encoding='utf-8') as stream:
    yaml.safe_dump(profile,stream,allow_unicode=True,sort_keys=False)
write(OUT/'publication-report-lock.json',dict(frozen_at=now(),source_commit=HEAD,
    configuration_sha256=sha(destination),reports=reports,human_review='pending'))
