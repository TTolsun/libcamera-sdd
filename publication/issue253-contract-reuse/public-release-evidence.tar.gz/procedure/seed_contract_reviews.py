"""Execute standard native review units concurrently, then require normal audit."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import sys
import time

from sdd.cli_checkpoint import Capture
from sdd.config import load
from sdd.consistency import batches, groups, policy_hash, request, review_store, validate
from sdd.facts.model import KnowledgeModel
from sdd.llm import Agent
from sdd.state_io import save
from sdd.validation_stage import stage


profile = Path(sys.argv[1]).resolve(strict=True)
out = profile.parent/sys.argv[2]
out.mkdir(exist_ok=False)
cfg = load(profile)
assert cfg.agent.kind == 'cli' and cfg.agent.runner == 'codex' and cfg.agent.model == 'gpt-6.1-terra'
assert cfg.agent.args == ['-c', 'model_reasoning_effort="high"']
model = KnowledgeModel.load(cfg.facts_path)
policy = policy_hash()
started = time.perf_counter()
now = lambda: datetime.now(timezone.utc).isoformat()
units = []
with stage() as inputs:
    inputs.pin(cfg, model)
    for group in groups(cfg):
        payload = request(cfg, model, group)
        for index, batch in enumerate(batches(payload, max_input_chars=cfg.agent.max_input_chars)):
            store, wire = review_store(cfg, batch)
            cached = store.read()
            if cached is not None:
                assert validate(batch, cached[0]['raw']) == cached[0]['statements']
            units.append((group['id'], index, batch, cached is not None))
    inputs.verify()

pending = sum(not unit[3] for unit in units)
for budget in (cfg.review.max_calls, cfg.review.document_max_calls):
    assert not budget or pending <= budget
report = dict(status='running', source_commit=model.meta['source_commit'], started_at=now(),
    policy=policy, concurrency=4, planned_units=len(units), planned_new_calls=pending,
    human_review='pending', human_active_review_seconds=None, units=[])
save(out/'result.json', report, newline='\n')


def review(unit):
    group, index, batch, cached = unit
    if cached:
        return dict(group=group, index=index, status='verified-original-checkpoint')
    with stage() as inputs:
        inputs.pin(cfg, model)
        assert policy_hash() == policy
        store, wire = review_store(cfg, batch)
        assert store.read() is None
        settings = deepcopy(cfg.agent)
        elapsed = time.perf_counter()-started
        for budget in (cfg.review.max_seconds, cfg.review.document_max_seconds):
            if budget:
                settings.timeout_sec = min(settings.timeout_sec, int(budget-elapsed))
        if settings.timeout_sec < 1:
            raise ValueError('Native seed time budget exhausted')
        capture = Capture(Agent(settings, cfg.build_dir/'prompts'))
        raw = capture.chat(wire['system'], wire['user'], tag=f'seed-{group}-{index}',
                           response_schema=wire['response_schema'])
        verdicts = validate(batch, raw)
        store.write(raw, verdicts, capture)
        assert len(capture.receipts) == 1
        assert store.read()[0]['statements'] == verdicts
        inputs.verify()
        return dict(group=group, index=index, status='new-original-cli-completed',
                    receipt=str(capture.receipts[0]))


with ThreadPoolExecutor(max_workers=4) as workers:
    running = {workers.submit(review, unit): unit for unit in units}
    for future in as_completed(running):
        group, index, _, _ = running[future]
        try:
            result = future.result()
        except Exception as exc:
            result = dict(group=group, index=index, status='failed', error=repr(exc))
        report['units'].append(result)
        save(out/'result.json', report, newline='\n')
        print(group, index, result['status'], flush=True)
report.update(ended_at=now(), elapsed_seconds=time.perf_counter()-started,
    new_original_calls=sum(row['status']=='new-original-cli-completed' for row in report['units']))
report['status'] = ('failed' if any(row['status']=='failed' for row in report['units'])
                    else 'completed-awaiting-normal-audit')
save(out/'result.json', report, newline='\n')
assert report['status'] != 'failed'
