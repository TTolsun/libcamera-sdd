"""Bind the two changed non-C++ source files and the tuning lookup figure."""
from datetime import datetime, timezone
import hashlib
from pathlib import Path
import shutil
import subprocess

import yaml

from prepare_public_incremental import HEAD, OLD, OUT, SOURCE
from public_incremental_stage import restore, write
from sdd.config import load
from sdd.evidence import collect, select_span
from sdd.facts.model import KnowledgeModel


def source(file):
    return subprocess.check_output(['git','show',f'{HEAD}:{file}'],cwd=SOURCE,encoding='utf-8')


def pin(file, ident, start, end):
    selected = {'id':ident,'file':file,'start':start,'end':end}
    text = source(file)
    left,right = select_span(text,selected)
    assert not text[:left].strip() and not text[right:].strip()
    selected['sha256'] = hashlib.sha256(text[left:right].encode()).hexdigest()
    return selected


def dump(path, value):
    path.write_text(yaml.safe_dump(value,allow_unicode=True,sort_keys=False),encoding='utf-8')


paths = OUT/'config'
snapshot = OUT/'before-source-binding'
if not snapshot.exists():
    snapshot.mkdir()
    for path in (paths/'sections.yaml',paths/'visuals.yaml',OUT/'build/impact.json',OUT/'build/impact-review.md'):
        shutil.copyfile(path,snapshot/path.name)

sections = yaml.safe_load((snapshot/'sections.yaml').read_bytes())
ipa = next(section for section in sections['sections'] if section['id']=='ipa-algorithms')
tuning = next(topic for topic in ipa['design_topics'] if topic['id']=='tuning')
data_file = 'src/ipa/mali-c55/data/uncalibrated.yaml'
meson_file = 'src/ipa/mali-c55/algorithms/meson.build'
yaml_evidence = pin(data_file,'mali-c55-uncalibrated','# SPDX-License-Identifier: CC0-1.0','...')
meson_evidence = pin(meson_file,'mali-c55-algorithm-build','# SPDX-License-Identifier: CC0-1.0','])')
old = next(row for row in tuning['sources'] if row['id']==yaml_evidence['id'])
assert old=={key:value for key,value in yaml_evidence.items() if key!='sha256'}
tuning['sources'].append({key:value for key,value in meson_evidence.items() if key!='sha256'})
tuning['question'] += ' Mali-C55에서 gamma.cpp가 알고리즘 빌드 목록에 포함되는 근거와 YAML의 Gamma 항목을 구분하세요.'
dump(paths/'sections.yaml',sections)

for profile in ('generation.yaml','review.yaml','publication-pending.yaml'):
    path=OUT/profile
    config=yaml.safe_load(path.read_bytes())
    config['publication']['baseline_config']=str(OLD/'publication-v12.yaml')
    dump(path,config)

cfg=load(OUT/'generation.yaml')
model=KnowledgeModel.load(cfg.facts_path)
collect(cfg,model)
fallback=model.evidence['ipa-algorithms/tuning/fallback']


def quote(literal):
    assert literal in fallback['text']
    return {'source':'tuning/fallback','sha256':fallback['sha256'],'quote':literal}


def node(ident, ko, en, literal, decision=False, extra=None):
    value=dict(id=ident,label=ko,label_en=en,evidence=[quote(text) for text in (literal,extra) if text])
    if decision:
        value['shape']='decision'
    return value


def edge(begin,end,literal,ko=None,en=None):
    value={'from':begin,'to':end,'evidence':[quote(literal)]}
    if ko:
        value.update(label=ko,label_en=en)
    return value


lookup='ipaConfigurationFile(ipaName, name, configPaths_)'
found='if (!confPath.empty())'
empty='if (fallbackName.empty())'
search_fallback='confPath = ipaConfigurationFile(ipaName, fallbackName, configPaths_);'
figures=yaml.safe_load((snapshot/'visuals.yaml').read_bytes())
assert 'ipa-algorithms' not in figures['sections']
figures['sections']['ipa-algorithms']=[dict(id='ipa-tuning-file-fallback',topic='tuning',kind='flow',
    title='IPA 튜닝 파일 검색 순서',question='요청한 튜닝 파일을 찾지 못하면 어떤 조건에서 대체 이름을 검색하나요?',
    nodes=[node('lookup','요청한 이름으로 검색','Look up the requested name',lookup),
           node('found','요청 경로가 있는가?','Requested path found?',found,True),
           node('requested','요청 경로 반환','Return the requested path','return confPath;'),
           node('fallback','대체 이름이 비었는가?','Is the fallback name empty?',empty,True),
           node('missing','오류 기록 후 빈 경로 반환','Log an error and return an empty path','return std::string();',extra='LOG(IPAProxy, Error)'),
           node('alternative','대체 이름으로 검색하고 경고 기록','Look up the fallback name and log a warning',search_fallback,extra='LOG(IPAProxy, Warning)')],
    edges=[edge('lookup','found',found,'검색 결과 확인','Check the result'),edge('found','requested','return confPath;','예','Yes'),
           edge('found','fallback',empty,'아니요','No'),edge('fallback','missing','return std::string();','예','Yes'),
           edge('fallback','alternative',search_fallback,'아니요','No')])]
dump(paths/'visuals.yaml',figures)
model.save(cfg.facts_path)
restore()
write(OUT/'source-scope-binding-v2.json',dict(source_commit=HEAD,recorded_at=datetime.now(timezone.utc).isoformat(),
    files=[yaml_evidence,meson_evidence],visual='ipa-tuning-file-fallback',human_review='pending',
    scope='Current Git blobs authenticated in full. LLM design selectors derive checksums at collection and do not have static hashes. The impact classifier still lists both findings. Generated prose and independent source review must cover both files. YAML configuration and Meson compilation are distinct. The diagram covers lookup branches.'))
