"""Verify the exact deployed manifest and every public artifact hash."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import sys
import time
from urllib.parse import quote, urljoin
from urllib.request import Request, urlopen

from prepare_public_incremental import HEAD, OUT
from public_incremental_stage import now, read, write


base='https://ttolsun.github.io/libcamera-sdd/'
local=OUT/'site/site-manifest.json'
expected=read(local)
deployed_commit=sys.argv[1]
deployment_url=sys.argv[2]
result=OUT/'live-verification.json'


def fetch(rel):
    request=Request(urljoin(base,quote(rel,safe='/')),headers={
        'Cache-Control':'no-cache','User-Agent':'libcamera-sdd-contract-update-verification'})
    with urlopen(request,timeout=35) as response:
        assert response.status==200
        return response.read()


def check(pair):
    relative,sha=pair
    try:
        data=fetch(relative)
        actual=hashlib.sha256(data).hexdigest()
        return dict(path=relative,expected=sha,actual=actual,bytes=len(data),ok=actual==sha)
    except Exception as exc:
        return dict(path=relative,expected=sha,ok=False,error=repr(exc))


begin=now()
start=time.perf_counter()
manifest=fetch('site-manifest.json')
assert manifest==local.read_bytes(),'Live manifest differs from the verified export'
with ThreadPoolExecutor(max_workers=8) as pool:
    files=list(pool.map(check,expected['outputs'].items()))
good=sum(row['ok'] for row in files)
record=dict(status='passed' if good==len(files) else 'failed',started_at=begin,ended_at=now(),
    elapsed_seconds=time.perf_counter()-start,deployed_commit=deployed_commit,deployment_url=deployment_url,
    url=base,source_commit=HEAD,build_id=expected['build_id'],manifest_sha256=hashlib.sha256(manifest).hexdigest(),
    expected_outputs=len(files),passed_outputs=good,files=files,human_review='pending',human_participants=0)
write(result,record)
print({key:value for key,value in record.items() if key!='files'})
assert record['status']=='passed'
