"""Build and extract the pinned official libcamera revision under WSL."""
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
import subprocess
import time

import yaml


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT/'build/issue253/consistency-cost-optimization/public-extract-v2'
NATIVE = Path.home()/'.cache/camera-hal-sdd-issue253-incremental-c19-clang'
RUNTIME = ROOT/'build/q253rt2'
SRC = NATIVE/'source'
COMMIT = 'c19d05128f3ae1f0ebe63acb4deaca9fbb1dde78'
PY = Path.home()/'work/camera-hal-sdd-generator/.venv/bin/python'
OUT.mkdir(exist_ok=False)
NATIVE.mkdir(exist_ok=False)
rows = []


def run(name, argv, cwd=NATIVE):
    row = dict(stage=name, command=[str(x) for x in argv], cwd=str(cwd),
               started_at=datetime.now(timezone.utc).isoformat(), status='running')
    rows.append(row)
    t = time.perf_counter()
    try:
        with (OUT/(name+'.log')).open('wb') as stream:
            p = subprocess.run(argv, cwd=cwd, stdout=stream, stderr=subprocess.STDOUT, timeout=3600)
        row.update(status='completed' if p.returncode==0 else 'failed', returncode=p.returncode)
        p.check_returncode()
    finally:
        row.update(ended_at=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.perf_counter()-t)
        (OUT/'execution.json').write_text(json.dumps(dict(source_commit=COMMIT, stages=rows),indent=2),encoding='utf-8')
        print(name, row['status'], round(row['elapsed_seconds'], 2), flush=True)


run('source-clone', ['git','clone','--no-hardlinks','--branch','codex/issue253-upstream-c19',
    ROOT/'build/issue253/latest-source',SRC])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SRC,text=True).strip()==COMMIT
run('libpisp-clone', ['git','clone','--no-hardlinks',Path.home()/'.cache/camera-hal-sdd-issue253-cost-v2/source/subprojects/libpisp',SRC/'subprojects/libpisp'])
run('libpisp-pin', ['git','checkout','--detach','86d71c805c3f96ca6b304a404a753b3fff44c85b'], SRC/'subprojects/libpisp')
run('meson', ['meson','setup','build','-Dpipelines=all','-Dipas=ipu3,mali-c55,rkisp1,rpi/pisp,rpi/vc4,softisp,vimc',
    '-Dcam=enabled','-Dgstreamer=enabled','-Dqcam=disabled','-Dlc-compliance=disabled',
    '-Ddocumentation=disabled','-Dtest=false'], SRC)
run('build', ['ninja','-C','build','-j','3'], SRC)
run('compdb', [PY,RUNTIME/'examples/libcamera/prepare_compdb.py','--build-dir',SRC/'build',
    '--out',NATIVE/'compile_commands.json'])
original = yaml.safe_load((ROOT/'build/issue253/cost-followup/linux-run-02/head-sdd.yaml').read_bytes())
original['source'].update(root=str(SRC),compile_commands=str(NATIVE/'compile_commands.json'))
original['output'].update(facts_dir=str(NATIVE/'facts'),sdd_dir=str(NATIVE/'sdd'),diagrams_dir=str(NATIVE/'diagrams'))
original['paths'].update(sections_file=str(RUNTIME/'examples/libcamera/config/sections.yaml'),
    consistency_file=str(RUNTIME/'examples/libcamera/config/contracts.yaml'),
    scenarios_file=str(RUNTIME/'examples/libcamera/config/scenarios.yaml'),
    products_file=str(RUNTIME/'examples/libcamera/config/products.yaml'),
    prompts=str(RUNTIME/'examples/libcamera/prompts'),templates=str(RUNTIME/'templates'),style=str(RUNTIME/'style'))
original['products']['file'] = original['paths']['products_file']
config = NATIVE/'sdd.yaml'
config.write_text(yaml.safe_dump(original,allow_unicode=True,sort_keys=False),encoding='utf-8')
shutil.copyfile(config,OUT/'extract-config.yaml')
run('extract', [PY,RUNTIME/'tools/run_sdd.py','--config',config,'extract'])
for src,dest in [(NATIVE/'facts/facts.json',OUT/'facts.json'),(NATIVE/'compile_commands.json',OUT/'compile_commands.json')]:
    shutil.copyfile(src,dest)
facts = json.loads((OUT/'facts.json').read_bytes())
assert facts['meta']['source_commit']==COMMIT
print('Facts extracted',facts['meta'].get('translation_units'),len(facts['classes']),flush=True)
