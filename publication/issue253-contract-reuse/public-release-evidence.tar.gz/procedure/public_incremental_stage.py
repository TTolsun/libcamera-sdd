"""Record regular generator commands and source-bound prerequisites for c19."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

from prepare_public_incremental import BASE, HEAD, OLD, OUT, ROOT, RUNTIME, restore_declaration


def write(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def sdd(profile, *arguments):
    return [str(RUNTIME/'tools/run_sdd.py'), '--config', str(OUT/profile), *arguments]


def run(name, argv):
    record = OUT/(name+'-execution.json')
    argv = [sys.executable,*map(str,argv)]
    data = dict(source_commit=HEAD, argv=argv, started_at=now(), status='running',
                human_review='pending', human_active_review_seconds=None)
    write(record,data)
    start = time.perf_counter()
    try:
        with (OUT/(name+'.log')).open('xb') as log:
            result = subprocess.run(argv, cwd=RUNTIME, stdout=log, stderr=subprocess.STDOUT,timeout=14400)
        data.update(status='completed' if result.returncode==0 else 'failed', returncode=result.returncode)
    except Exception as exc:
        data.update(status='failed', error=repr(exc))
    finally:
        data.update(ended_at=now(), elapsed_seconds=time.perf_counter()-start)
        record.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(name, data['status'], round(data['elapsed_seconds'],2),flush=True)
    return data.get('returncode',1)


def restore():
    from sdd.config import load
    from sdd.facts.model import KnowledgeModel

    cfg = load(OUT/'generation.yaml')
    model = KnowledgeModel.load(cfg.facts_path)
    restore_declaration(cfg, model)
    model.save(cfg.facts_path)


def archives():
    baseline = ROOT/'build/issue253/consistency-cost-optimization/benchmark-v2/base/build'
    destination = OUT/'build'
    counts = {}
    for group in ('cli-checkpoints','prompts'):
        counts[group] = 0
        for source in (baseline/group).rglob('*'):
            if not source.is_file():
                continue
            target = destination/source.relative_to(baseline)
            target.parent.mkdir(parents=True,exist_ok=True)
            if target.exists():
                assert sha(source)==sha(target), str(target)
            else:
                shutil.copyfile(source,target)
            counts[group] += 1
    assert all(counts.values())
    write(OUT/'contract-archive-transfer.json',dict(archived_at=now(),source=str(baseline),counts=counts))


def retention():
    from sdd.document_metadata import split_frontmatter

    document = OUT/'manuscripts/request-lifecycle.md'
    prior_document = OLD/'manuscripts/request-lifecycle.md'
    source_prefix = 'request-lifecycle/resources/'
    old_facts = read(OLD/'facts/facts.json')
    new_facts = read(OUT/'facts/facts.json')
    assert old_facts['meta']['source_commit']==BASE and new_facts['meta']['source_commit']==HEAD

    def source_inputs(facts, commit):
        selected = {name: record for name,record in facts['evidence'].items() if name.startswith(source_prefix)}
        assert selected and all(record['commit']==commit for record in selected.values())
        return {name: {key:value for key,value in record.items() if key!='commit'} for name,record in selected.items()}

    prior = read(OLD/'acceptance-v12.json')
    evaluator = RUNTIME/'examples/libcamera/validation/issue249'
    assert prior['status']=='passed' and prior['candidate_known_case_regression_passed']==5
    assert prior['manuscript_sha256']==sha(prior_document)
    assert prior['fixed_questions_sha256']==sha(evaluator/'questions.json')
    assert prior['rubric_sha256']==sha(evaluator/'rubric.json')
    old_body = split_frontmatter(prior_document.read_text(encoding='utf-8'))[1]
    new_body = split_frontmatter(document.read_text(encoding='utf-8'))[1]
    assert old_body==new_body
    assert source_inputs(old_facts,BASE)==source_inputs(new_facts,HEAD)
    prior_result = OLD/'retention249-grading/result.json'
    prior_grounding = OLD/'retention249-grounding/result.json'
    assert sha(prior_result)==prior['grader_result_sha256']
    assert sha(prior_grounding)==prior['source_review_sha256']
    assert read(prior_result)['result']['verdict']==read(prior_grounding)['result']['verdict']=='pass'
    write(OUT/'retention249-body-and-source-equivalence.json',dict(
        status='verified', stage='issue249-known-case-input-equivalence', source_commit=HEAD,
        old_source_commit=BASE, verified_at=now(), baseline_acceptance_sha256=sha(OLD/'acceptance-v12.json'),
        manuscript_sha256=sha(document), baseline_manuscript_sha256=sha(prior_document),
        identical_evaluator_body_sha256=hashlib.sha256(new_body.encode()).hexdigest(),
        fixed_questions_sha256=prior['fixed_questions_sha256'], rubric_sha256=prior['rubric_sha256'],
        original_grading_sha256=sha(prior_result), original_grounding_sha256=sha(prior_grounding),
        source_windows_verified=len(source_inputs(new_facts,HEAD)), original_automatic_passed=5,
        new_reader_trials=0, human_review='pending', human_participants=0,
        scope='The document-only reader and grader used the identical body. Resource source windows were compared against newly collected facts, excluding the checked commit label. The old five outcomes remain historical.'))


if __name__=='__main__':
    mode = sys.argv[1]
    if mode=='impact':
        sys.exit(run(mode,sdd('generation.yaml','impact','--base',BASE,'--head',HEAD,'--base-facts',OLD/'facts/facts.json','--fail-on-coverage-gap')))
    if mode=='generate':
        pages = read(OUT/'carry-result.json')['stale']
        assert all(item['section'] for item in pages)
        sections = sys.argv[3] if len(sys.argv)>3 else ','.join(item['section'] for item in pages)
        sys.exit(run(sys.argv[2] if len(sys.argv)>2 else mode,
                     sdd('generation.yaml','generate','--from-impact','--sections',sections)))
    if mode=='restore':
        restore()
    if mode=='translate':
        sys.exit(run(sys.argv[2] if len(sys.argv)>2 else mode,
                     ['-m','sdd.site_localization','--config',OUT/'publication-pending.yaml','--out',OUT/'english.json','--translate']))
    if mode=='seed-audit':
        if not (OUT/'contract-archive-transfer.json').exists():
            archives()
        name=sys.argv[2] if len(sys.argv)>2 else mode
        attempt='public-native-audit-seed-final' if name=='seed-audit-final' else 'public-native-audit-seed'
        sys.exit(run(name,[ROOT/'build/issue253/seed_contract_reviews.py',OUT/'review.yaml',attempt]))
    if mode=='audit':
        sys.exit(run(mode,sdd('review.yaml','audit-consistency')))
    if mode=='retention':
        retention()
