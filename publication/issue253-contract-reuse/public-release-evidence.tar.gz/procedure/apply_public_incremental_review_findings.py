"""Strengthen only the three question contracts flagged by source review."""
import shutil
import yaml

from prepare_public_incremental import HEAD, OUT
from public_incremental_stage import now, read, sha, write


archive=OUT/'before-source-review-corrections'
archive.mkdir(exist_ok=False)
path=OUT/'config/sections.yaml'
for item in (path,OUT/'english.json',OUT/'manuscripts/ipa-algorithms.md',OUT/'manuscripts/pipeline-requests.md'):
    shutil.copyfile(item,archive/item.name)
bilingual=read(OUT/'bilingual-review-01/result.json')
ipa=read(OUT/'ipa-current-source-review/result.json')
assert bilingual['result']['verdict']==ipa['result']['verdict']=='needs-revision'
assert len(bilingual['result']['findings'])==3 and len(ipa['result']['findings'])==1
data=yaml.safe_load(path.read_bytes())
sections={s['id']:s for s in data['sections']}
queue=next(t for t in sections['pipeline-requests']['design_topics'] if t['id']=='queue')
parts={p['id']:p for p in queue['parts']}
parts['cancelled']['question']+=' 최종 문장에도 조건 이름 cancelled_와 이미 취소된 요청이라는 뜻을 직접 쓰세요. 앞 문장의 조건을 가리키는 대명사를 쓰지 마세요.'
parts['fences']['question']+=' 타이머 생성 조건과 prepared 신호 발생 조건을 별도 문장으로 쓰세요. 타이머를 지정하지 않은 경우에도 모든 펜스가 신호되면 준비 완료 신호를 발생시킵니다. 타임아웃 만료 시 취소와 완료 신호를 구분하세요.'
shader=next(t for t in sections['ipa-algorithms']['design_topics'] if t['id']=='softisp-lsc')
shader['question']+=' 이미 구성한 rgb를 처리하는 구간으로 범위를 한정하세요. main의 첫 단계라고 표현하지 마세요. AWB 다음과 CCM 다음의 두 범위 제한을 구분하고, fdStats·fdParams·lscEnabled 선언이 lsc_tex와의 연결을 명시하는지 그 선언 범위에서 설명하세요.'
path.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
write(OUT/'source-review-corrections.json',dict(status='questions-strengthened',source_commit=HEAD,recorded_at=now(),
    current_sections_sha256=sha(path),original_sections_sha256=sha(archive/'sections.yaml'),
    original_bilingual_findings=bilingual['result']['findings'],original_ipa_findings=ipa['result']['findings'],
    corrected_questions=['pipeline-requests/queue/cancelled','pipeline-requests/queue/fences','ipa-algorithms/softisp-lsc'],
    provisional_seed_interrupted=True,human_review='pending'))
