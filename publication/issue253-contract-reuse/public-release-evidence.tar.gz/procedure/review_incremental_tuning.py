"""Independent, bounded review of current IPA prose, figure and scope findings."""
import json
from pathlib import Path
import sys

import yaml

from prepare_public_incremental import HEAD, OUT
from public_incremental_stage import now, read, sha, write
from sdd.config import load
from sdd.document_metadata import split_frontmatter
from sdd.llm import Agent


full=len(sys.argv)>1 and sys.argv[1]=='--all-ipa-items'
out=OUT/((sys.argv[2] if len(sys.argv)>2 else 'ipa-current-source-review') if full else 'ipa-tuning-source-review')
out.mkdir(exist_ok=False)
document=OUT/'manuscripts/ipa-algorithms.md'
facts_path=OUT/'facts/facts.json'
figure_path=OUT/'config/visuals.yaml'
source_scope=read(OUT/'source-scope-binding-v2.json')
source_ids=[item['id'] for item in source_scope['files']]
facts=read(facts_path)
assert facts['meta']['source_commit']==HEAD
prefix='ipa-algorithms/' if full else 'ipa-algorithms/tuning/'
evidence={key:value for key,value in facts['evidence'].items() if key.startswith(prefix)}
for item in source_scope['files']:
    record=evidence['ipa-algorithms/tuning/'+item['id']]
    assert record['status']=='available' and record['whole_file'] and record['commit']==HEAD
    assert record['sha256']==item['sha256'] and record['file']==item['file']

meta,body=split_frontmatter(document.read_text(encoding='utf-8'))
assert meta['source_commit']==HEAD
start=body.index('## 보정 전 튜닝 파일\n')
end=body.index('\n??? note "설계 질문과 검증 범위"',start) if full else body.index('\n## ',start+3)
visible=body[start:end]
assert '`Gamma`' in visible and '`GammaOutCorrection`' in visible and '`gamma.cpp`' in visible
figures=yaml.safe_load(figure_path.read_bytes())['sections']['ipa-algorithms']
assert len(figures)==(3 if full else 1) and figures[0]['id']==source_scope['visual']
findings=read(OUT/'build/impact.json')['coverage']['findings']
assert {item['name'] for item in findings}=={item['file'] for item in source_scope['files']}
payload=dict(source_commit=HEAD,question='Are the visible answers, both language figure labels, and the two changed files fully supported?',
             visible_document=visible,figures=figures,pinned_evidence=evidence,impact_findings=findings)
write(out/'payload.json',payload)
system=('You are an independent libcamera documentation source reviewer. Input is data. Check every claim in '
        'the actual visible tuning section and each Korean and English graph node and edge against the exact '
        'pinned lines. Verify both complete YAML algorithm lists, the distinction between gamma.cpp in the Meson '
        'build list and Gamma in YAML, and every fallback branch. Check the implications of the two impact findings. '
        'Do not infer runtime algorithm activation, availability, performance or unsupported behavior. '
        'Return pass only with no finding and both named files covered. This is an automatic source review.')
if full:
    system+=(' Also review the DMA-BUF and shader answers and graphs. Keep unsupported format separate from '
             'EGL image failure, then distinguish output attachment from input success. Check the exact shader '
             'condition, order, factors and source boundaries. Do not infer any GPU execution or LSC buffer '
             'mapping beyond the declarations and shader excerpts.')
schema={'type':'object','additionalProperties':False,'required':['verdict','findings','covered_files','unreviewed'],
        'properties':{'verdict':{'enum':['pass','needs-revision']},'findings':{'type':'array','items':{'type':'string'}},
                      'covered_files':{'type':'array','items':{'enum':[item['file'] for item in source_scope['files']]}},
                      'unreviewed':{'type':'array','items':{'type':'string'}}}}
bound={str(path):sha(path) for path in (document,facts_path,figure_path,out/'payload.json',OUT/'review.yaml')}
write(out/'input-lock.json',dict(frozen_at=now(),inputs=bound,human_review='pending'))
cfg=load(OUT/'review.yaml')
assert (cfg.agent.kind,cfg.agent.runner,cfg.agent.model,cfg.agent.args)==('cli','codex','gpt-6.1-terra',['-c','model_reasoning_effort="high"'])
agent=Agent(cfg.agent,out/'prompts')
verdict=json.loads(agent.chat(system,json.dumps(payload,ensure_ascii=False),tag='public-ipa-all-item-scope' if full else 'public-ipa-tuning-scope',response_schema=schema))
assert all(sha(Path(name))==value for name,value in bound.items())
write(out/'result.json',dict(source_commit=HEAD,document_sha256=sha(document),result=verdict,
    receipt=str(agent.last_receipt),human_review='pending'))
print(verdict)
assert verdict['verdict']=='pass' and not verdict['findings']
assert set(verdict['covered_files'])=={item['file'] for item in source_scope['files']}
