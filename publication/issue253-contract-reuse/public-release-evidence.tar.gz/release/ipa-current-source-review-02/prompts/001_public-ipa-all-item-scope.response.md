{"verdict":"pass","findings":[],"covered_files":["src/ipa/mali-c55/data/uncalibrated.yaml","src/ipa/mali-c55/algorithms/meson.build"],"unreviewed":[]}
