from pathlib import Path
import json,zipfile,hashlib
w=Path(__file__).resolve().parent;prior=w.parent/'comment-followup';dest=w.parent/'queue-native-evidence.zip';assert not dest.exists();rows=[]
excluded={'site','repeat-site','final-site','final-repeat','impact-manuscripts','failed-audit-output','__pycache__'}
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as out:
 for base,prefix in ((w,''),(prior,'previous-comment-stage/')):
  for p in sorted(base.rglob('*')):
   if not p.is_file():continue
   rel=p.relative_to(base)
   if rel.parts[0] in excluded or '__pycache__' in rel.parts or p.suffix=='.pyc':continue
   frozen=rel.parts[0] in {'run','config','before','independent-rounds','bilingual-rounds','consistency-rounds','caption-repair'} or rel.as_posix().startswith(('build/prompts/','build/translation-prompts/','build/cli-checkpoints/','build/generation-runs/')) or p.suffix=='.yaml'
   if not frozen:continue
   data=p.read_bytes();name=prefix+rel.as_posix();out.writestr(name,data);rows.append(dict(path=name,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
(w.parent/'queue-native-evidence-index.json').write_text(json.dumps(dict(schema=1,files=rows,scope='Frozen completed native records and source/profile inputs prepared in parallel with normal site rendering. Final packaging rechecks every byte before retaining these entries.'),indent=2)+'\n',encoding='utf-8');print('Prepared frozen evidence',len(rows),'files',dest.stat().st_size,'bytes',flush=True)
