from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import urllib.request,urllib.parse,json,hashlib,time,datetime
w=Path(__file__).resolve().parent;base='https://ttolsun.github.io/libcamera-sdd/'
expected=(w/'final-site/site-manifest.json').read_bytes();manifest=json.loads(expected);rows=[]
def fetch(rel):
 url=base+urllib.parse.quote(rel,safe='/')
 for attempt in range(3):
  try:
   with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'camera-hal-sdd-issue193-verification','Cache-Control':'no-cache'}),timeout=60) as r:return r.status,r.read(),r.geturl()
  except Exception:
   if attempt==2:raise
   time.sleep(1)
status,raw,url=fetch('site-manifest.json')
assert raw==expected,'Live manifest is not the reviewed published build yet'
with ThreadPoolExecutor(max_workers=8) as pool:
 jobs={pool.submit(fetch,rel):(rel,sha) for rel,sha in manifest['outputs'].items()}
 for future in as_completed(jobs):
  rel,sha=jobs[future];status,body,url=future.result();actual=hashlib.sha256(body).hexdigest()
  assert status==200 and actual==sha,rel+' live digest mismatch'
  rows.append(dict(path=rel,status=status,sha256=actual,bytes=len(body)))
report=dict(schema=1,status='passed',verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),base_url=base,build_id=manifest['build_id'],manifest_sha256=hashlib.sha256(raw).hexdigest(),outputs=len(rows),rows=sorted(rows,key=lambda x:x['path']),scope='Live HTTPS bytes at ordinary public URLs without query parameters for every manifest-owned artifact, including both languages, raw Markdown/Mermaid, search, local assets and consistency review.',human_review='pending',internal_hal_validation='not-run')
(w/'live-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Live manifest and',len(rows),'artifacts match the exact reviewed build',manifest['build_id'],flush=True)
