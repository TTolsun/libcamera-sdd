"""Fresh source-bound Claude audit batches; standard audit validates and assembles receipts."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib,json,uuid,shutil
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.consistency import groups,request,batches,review_store,validate,audit,SYSTEM,policy_hash
from sdd.cli_checkpoint import Capture
from sdd.generation_run import Execution
from sdd.llm import Agent
work=Path(__file__).resolve().parent;cfg=load(work/'independent-review.yaml')
model=KnowledgeModel.load(cfg.facts_path)
catalog_file=cfg.root/cfg.site.english_catalog
assert json.loads(catalog_file.read_bytes())['source_commit']==model.meta['source_commit']
run=work/'consistency-rounds'/uuid.uuid4().hex;run.mkdir(parents=True)
shutil.copyfile(work/'independent-review.yaml',run/'profile.yaml')
policy=policy_hash();pending=[];rows=[]
for group in groups(cfg):
 for index,batch in enumerate(batches(request(cfg,model,group),max_input_chars=cfg.agent.max_input_chars)):
  store,data=review_store(cfg,batch)
  pending.append((group['id'],index,batch,store,data))
def check(item):
 group,index,batch,store,data=item
 assert policy_hash()==policy,'Review policy changed during execution'
 saved=store.read()
 if saved is not None:
  record,_=saved;checked=validate(batch,record['raw'])
  assert checked==record['statements']
  return dict(group=group,batch=index,status='verified-existing-receipt',claims=len(checked))
 agent=Execution(cfg,Agent(cfg.agent,cfg.build_dir/'prompts'))
 capture=Capture(agent)
 raw=capture.chat(SYSTEM,data['user'],tag='consistency_'+group+'_'+str(index),response_schema=data['response_schema'])
 checked=validate(batch,raw);store.write(raw,checked,capture)
 assert capture.receipts
 return dict(group=group,batch=index,status='fresh-claude-cli',claims=len(checked),receipts=[str(p.relative_to(work)) for p in capture.receipts])
report=dict(schema=1,status='incomplete',policy_sha256=policy,catalog_sha256=hashlib.sha256(catalog_file.read_bytes()).hexdigest(),source_commit=model.meta['source_commit'],rows=rows,human_review='pending')
def save(): (run/'execution.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
save()
print('planned-batches',len(pending),'policy',policy,flush=True)
try:
 with ThreadPoolExecutor(max_workers=8) as executor:
  for future in as_completed([executor.submit(check,x) for x in pending]):
   row=future.result();rows.append(row);save();print(row['group'],row['batch'],row['status'],flush=True)
 assert policy_hash()==policy
 result=audit(cfg,model,Agent(cfg.agent,run/'assembly-prompts'))
 report['status']=result['status'];report['assembly']='Standard audit validates exact source/claim receipts; no new model call during assembly.'
 shutil.copyfile(cfg.build_dir/'consistency-review.json',run/'review.json')
 print('final',result['status'],'unresolved',len(result['unresolved']),flush=True)
except BaseException as exc:
 report['error']=str(exc);raise
finally:save()
