Camera request prose could describe `0` as confirmation that capture queueing succeeded. The implementation returns after posting the queued `invokeMethod` call, and completion arrives separately through `requestCompleted`.

Bind the `completion-signal` answer to the implementation excerpt and require that distinction. Reject the observed capture-queue success wording even when every required identifier is present.

Validation: 51 answer-contract, design-contract and reader-scope tests passed. The actual selected-Claude generation, translation and separate grounding review remain recorded under issue #193 and will precede the public SDD follow-up.
