from pathlib import Path
from collections import Counter
import json,hashlib,shutil,zipfile
from sdd.config import load
from sdd.cli_provenance import verify_cli_receipt
w=Path(__file__).resolve().parent;prior_stage=w.parent/'comment-followup';public=w.parent/'public';dest=public/'publication/issue193-comment-followup';
if dest.exists():
 assert not (dest/'README.md').exists(),'Completed package must not be overwritten'
 for name in ('run.json','generation-receipts.json','README.md'):assert (dest/('previous-'+name)).read_bytes()==(public/name).read_bytes(),'Public root changed during partial packaging'
report=json.loads((w/'build-validation.json').read_bytes());assert report['status']=='passed';dest.mkdir(parents=True,exist_ok=True);cfg=load(w/'independent-review.yaml')
for p in ('run.json','generation-receipts.json','README.md'):shutil.copyfile(public/p,dest/('previous-'+p))
prior=json.loads((public/'generation-receipts.json').read_bytes());seen={r['receipt_sha256'] for r in prior['rows']};new=[];all_hashes=set()
for base,p,prefix in [(base,p,prefix) for base,prefix in ((w,''),(prior_stage,'previous-comment-stage/')) for p in sorted(base.rglob('*.receipt.json'))]:
 if any(part in ('site','repeat-site','final-site','final-repeat','impact-manuscripts','failed-audit-output') for part in p.relative_to(base).parts):continue
 checksum=hashlib.sha256(p.read_bytes()).hexdigest()
 if checksum in all_hashes:continue
 all_hashes.add(checksum)
 if checksum in seen:continue
 r=json.loads(p.read_bytes());stem=p.name.removesuffix('.receipt.json');request=json.loads(p.with_name(stem+'.request.json').read_bytes());raw=p.with_name(stem+'.response.txt').read_text(encoding='utf-8');verify_cli_receipt(request,raw,r,p.parent.parent,cfg.agent);provider=r['provider'];assert r['model']=='claude-haiku-5-5' and provider['runner']=='claude' and provider['exit_code']==0;assert provider['arguments'][-4:]==['--model','claude-haiku-5-5','--effort','high'];runtime=list(provider['provider']['modelUsage']);assert runtime==['claude-haiku-5-5']
 rel=prefix+p.relative_to(base).as_posix();phase='independent-review' if 'independent-rounds' in rel or 'bilingual-rounds' in rel or 'caption-repair/independent-prompts/' in rel or r['tag'].startswith('consistency_') else 'translation' if 'translation-prompts' in rel else 'generation-or-preflight'
 new.append(dict(path=rel,archive='publication/issue193-comment-followup/cli-evidence.zip',receipt_sha256=checksum,tag=r['tag'],model=r['model'],runner=provider['runner'],request_sha256=r['request_sha256'],response_sha256=r['response_sha256'],stdout_sha256=provider['stdout_sha256'],runtime_models=runtime,phase=phase))
assert new
index=dict(schema=1,scope='Actual completed selected-Claude calls added by the four-unit Claude-comment follow-up. Copied historical cache records are excluded from the new-call count. Source generation, translation and independent reviews have separate profiles and raw receipts.',rows=new,model_counts=dict(Counter(r['model'] for r in new)),phase_counts=dict(Counter(r['phase'] for r in new)),human_review='pending');(dest/'generation-receipts.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ('scope.json','generation-correction.json','source-review.json','translation-summary.json','bilingual-review.json','build-validation.json','render-only-profile-note.json','effective-comment-contracts.json','generator-merge.json','failed-output-preservation.json','generator-ci212.json','shared-bilingual-review.json','caption-repair.json','caption-rebinding.json'):shutil.copyfile(w/name,dest/name)
shutil.copyfile(w/'build/consistency-review.json',dest/'consistency-review.json');shutil.copyfile(prior_stage/'build/impact.json',dest/'previous-comment-impact.json')
files=[]
pre=json.loads((w.parent/'queue-native-evidence-index.json').read_bytes());existing={r['path']:r for r in pre['files']};shutil.copyfile(w.parent/'queue-native-evidence.zip',dest/'cli-evidence.zip')
with zipfile.ZipFile(dest/'cli-evidence.zip','a',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for base,prefix in ((w,''),(prior_stage,'previous-comment-stage/')):
  for p in sorted(base.rglob('*')):
   if not p.is_file():continue
   rel=p.relative_to(base)
   if rel.parts[0] in ('site','repeat-site','final-site','final-repeat','impact-manuscripts','failed-audit-output') or p.suffix=='.pyc' or '__pycache__' in rel.parts:continue
   data=p.read_bytes();name=prefix+rel.as_posix();sha=hashlib.sha256(data).hexdigest()
   if name in existing:assert existing[name]['sha256']==sha,(name,'frozen evidence changed')
   else:archive.writestr(name,data)
   files.append(dict(path=name,sha256=sha,bytes=len(data)))
assert set(existing)<={r['path'] for r in files},'Frozen evidence lost from final index'
assert (dest/'cli-evidence.zip').stat().st_size<100*1024*1024
(dest/'evidence-index.json').write_text(json.dumps(dict(schema=1,archive_sha256=hashlib.sha256((dest/'cli-evidence.zip').read_bytes()).hexdigest(),files=files),indent=2)+'\n',encoding='utf-8')
readme='''# Claude comment follow-up for issue193

PR68 retained an ordinary request-lifecycle profile without the three summaries requested in issue193 comment6533480897. Actual Claude generated three summaries and narrowed submission. The separate cross-document review then rejected an existing camera-requests statement equating return0 with successful capture queueing. Generator PR212 binds that one question to the queued invokeMethod implementation and rejects the observed success wording; selected Claude regenerated that one unit. Global defaults remain unchanged.

All five changed answer units were generated by actual Claude Code CLI claude-haiku-5-5 with --effort high. New translations use a separate profile. Separate fresh selected-Claude source entailment, required-question coverage and rendered bilingual review passed. Normal cross-document audit authenticates exact native receipts. Current full source review remains automatic, bounded to changed units; earlier broad editorial findings for ordinary documents remain open. No human approval, internal HAL or physical-device validation is claimed.

Official public source293 is unchanged; the generator is pinned to the actual reviewed PR212 merge recorded in generator-merge.json. The new queued-connection excerpts match immutable Git source. All non-evidence facts, six scenario manuscripts, their fourteen Korean/English HTML pages including index, existing calls and full trace records are byte-identical to PR68. Historical publication and runtime records remain unchanged. The preceding four-unit source and bilingual passes, failed79-batch audit with its two contradictions, profiles and native records remain unchanged under previous-comment-stage/ in the ZIP. Current one-unit source and bilingual passes plus the final successful normal audit are separate reports. New profiles, raw requests/responses/native stdout, exact source snapshots and reproducible scripts are in cli-evidence.zip; every file has a SHA-256 index. Copied historical cache/native files are counted separately from new actual calls. The original static renderer agent identity is retained only for existing visual fingerprints; it executes no generation or review CLI. All new inference uses the three explicit selected-Claude profiles.

Two normal exports have identical manifests; local links, document health and route-table removal pass. Actual post-merge Pages and live HTTPS proofs will be recorded in generator issue193. Previous root run, README and receipt index are preserved here. This follow-up does not erase or promote previous negative assessments.
''';(dest/'README.md').write_text(readme,encoding='utf-8')
combined={**prior,'rows':prior['rows']+new};combined['model_counts']=dict(Counter(r['model'] for r in combined['rows']));combined['phase_counts']=dict(Counter(r['phase'] for r in combined['rows']));combined['supplement']='publication/issue193-comment-followup/README.md';(public/'generation-receipts.json').write_text(json.dumps(combined,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
run=json.loads((public/'run.json').read_bytes());run.update(generator_behavior_commit=report['generator_commit'],build_id=report['build_id'],facts_sha256=hashlib.sha256((w/'run/facts/facts.json').read_bytes()).hexdigest(),english_catalog_sha256=hashlib.sha256((w/'run/english.json').read_bytes()).hexdigest(),manifest_sha256=report['manifest_sha256'],manifest_outputs=report['outputs']);run['comment_followup']='publication/issue193-comment-followup/README.md';run['historical_reuse']['ordinary_documents']+='; four request-lifecycle summary/submission units and one camera-requests completion-signal unit were subsequently generated through selected Claude CLI and separately reviewed';(public/'run.json').write_text(json.dumps(run,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
root_readme=(public/'README.md').read_text(encoding='utf-8');root_readme=root_readme.replace('build 1940468f0421836a6532951a6dfc0b09bc58102a1ccc163af32f03251f965e7f','build '+report['build_id']);root_readme+='\nClaude comment follow-up: [three opening summaries and source-bound queue return explanations](publication/issue193-comment-followup/README.md). All six scenario outputs and previous publication archives remain unchanged.\n';(public/'README.md').write_text(root_readme,encoding='utf-8');print('Packaged',len(new),'new actual selected-Claude calls;',len(files),'files;', (dest/'cli-evidence.zip').stat().st_size,'ZIP bytes',flush=True)
