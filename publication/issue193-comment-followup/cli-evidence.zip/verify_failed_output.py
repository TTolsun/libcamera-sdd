from pathlib import Path
import shutil,json,hashlib
from sdd.config import load
from sdd.export_site import export_site
w=Path(__file__).resolve().parent;prior=w.parent/'comment-followup';cfg=load(prior/'publication.yaml');failed=json.loads((prior/'build/consistency-review.json').read_bytes());assert failed['status']=='failed';sink=w/'failed-audit-output';assert not sink.exists();shutil.copytree(w.parent/'public/docs',sink)
def tree():return {p.relative_to(sink).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sink.rglob('*') if p.is_file()}
before=tree();error=None
try:export_site(cfg,sink)
except ValueError as e:error=str(e)
assert error and ('contract review failed' in error or 'contradiction' in error),error
assert before==tree(),'Failed source review changed a prior good output'
(w/'failed-output-preservation.json').write_text(json.dumps(dict(schema=1,status='passed',error=error,prior_good_files=len(before),all_previous_output_bytes_identical=True,failed_review_status=failed['status'],scope='Real normal export rejected the independently confirmed source contradiction before replacing an isolated copy of the previously published complete output. Live/public docs were never mutated.',human_review='pending'),indent=2)+'\n',encoding='utf-8');print('Actual rejected review preserved',len(before),'prior output files',flush=True)
