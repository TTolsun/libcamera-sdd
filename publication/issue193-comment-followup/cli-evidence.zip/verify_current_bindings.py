from pathlib import Path
import json,yaml,hashlib
from sdd.document_metadata import split_frontmatter
w=Path(__file__).resolve().parent;prior=w.parent/'comment-followup';root=w.parents[2];data=yaml.safe_load((w/'config/sections.yaml').read_text(encoding='utf-8'));main=yaml.safe_load((root/'examples/libcamera/config/sections.yaml').read_text(encoding='utf-8'));sections={s['id']:s for s in data['sections']};up={s['id']:s for s in main['sections']}
rows=[]
for sid,tid,pid in [('request-lifecycle','journey','summary'),('request-lifecycle','resources','summary'),('request-lifecycle','stopping','summary'),('request-lifecycle','journey','submission'),('camera-requests','request','completion-signal')]:
 part=next(p for t in sections[sid]['design_topics'] if t['id']==tid for p in t['parts'] if p['id']==pid);expected=next(p for t in up[sid]['design_topics'] if t['id']==tid for p in t['parts'] if p['id']==pid);assert part==expected,(sid,tid,pid);rows.append(dict(section=sid,topic=tid,part=pid,exact_current_main_definition=True))
assert (w/'run/manuscripts/request-lifecycle.md').read_bytes()==(prior/'run/manuscripts/request-lifecycle.md').read_bytes()
for name in ('source-review.json','bilingual-review.json'):
 before=json.loads((prior/name).read_bytes());current=json.loads((w/name).read_bytes());assert before['status']==current['status']=='passed'
 for report,folder,page in [(before,prior,'request-lifecycle.md'),(current,w,'camera-requests.md')]:
  expected=report.get('manuscript_sha256') or report['pages'][0]['manuscript_sha256'];assert hashlib.sha256((folder/'run/manuscripts'/page).read_bytes()).hexdigest()==expected
catalog=json.loads((w/'run/english.json').read_bytes());bi=json.loads((prior/'bilingual-review.json').read_bytes());pairs=json.loads((prior/bi['run']/'request-lifecycle/pairs.json').read_bytes());assert len(pairs)==4
from sdd.site_localization import display_pairs
current_bi=json.loads((w/'bilingual-review.json').read_bytes());rendered=(w/current_bi['run']/'rendered/request-lifecycle.html').read_text(encoding='utf-8');actual={(x['key'],x['source']):x['translated'] for x in display_pairs(rendered,catalog['strings'])};changes=[]
for p in pairs:
 value=actual[(p['catalog_key'],p['korean'])]
 if value!=p['english']:
  shared=json.loads((w/'shared-bilingual-review.json').read_bytes());assert shared['status']=='passed';shared_pairs=json.loads((w/shared['run']/'request-lifecycle/pairs.json').read_bytes());assert any(x['korean']==p['korean'] and x['english']==value for x in shared_pairs);changes.append(p['id'])
meta,_=split_frontmatter((w/'run/manuscripts/camera-requests.md').read_text(encoding='utf-8'));old,_=split_frontmatter((w/'before/camera-requests.md').read_text(encoding='utf-8'))
for tid,answers in old['generated_design']['answers'].items():
 for a in answers:
  if (tid,a.get('part_id'))==('request','completion-signal'):continue
  assert a in meta['generated_design']['answers'][tid]
for n in ('generation.yaml','translation.yaml','independent-review.yaml'):
 d=yaml.safe_load((w/n).read_text(encoding='utf-8'));assert d['agent']['runner']=='claude' and d['agent']['model']=='claude-haiku-5-5' and d['agent']['args']==['--effort','high'] and d['agent']['max_input_chars']>=48000;assert Path(d['site']['mermaid_dir']).is_dir()
(w/'effective-comment-contracts.json').write_text(json.dumps(dict(schema=1,status='passed',rows=rows,prior_four_unit_reports_retained='previous-comment-stage/source-review.json and bilingual-review.json in cli-evidence.zip',four_unit_manuscript_byte_identical=True,four_rendered_translation_values_identical=not changes,new_shared_reviewed_pair_ids=changes,unchanged_camera_request_structured_answers_preserved=True,scope='Five changed units bound to exact generator main definitions, actual separately reviewed manuscript hashes and native bilingual values. Original failed cross-document verdict is preserved, not promoted to pass.',human_review='pending'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Five current question definitions and separate source/translation review bindings passed',flush=True)
