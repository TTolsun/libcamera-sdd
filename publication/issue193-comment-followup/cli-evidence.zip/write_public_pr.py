from pathlib import Path
import json
w=Path(__file__).resolve().parent;d=json.loads((w/'build-validation.json').read_bytes());assert d['status']=='passed';assert json.loads((w/'public-output-copy-verification.json').read_bytes())['status']=='passed'
body=f'''PR68 retained an older request-lifecycle question configuration. Apply the three opening conclusions requested in generator issue193, distinguish the request creator from the buffer-adding caller, and bind submission to the queued invocation and separate completion signal.

The separate selected-Claude contract audit then rejected an existing camera-requests statement that equated return0 with successful capture queueing. Generator PR212 now binds that question to the implementation and rejects the observed wording. One answer unit was regenerated through the selected CLI. A shared evidence caption has a separate actual translation and independent language review.

All new inference uses actual Claude Code CLI claude-haiku-5-5 with --effort high. Generation, translation and independent source/bilingual reviews have separate profiles and native records. The preceding failed audit, unaccepted caption, raw stdout and original assessments remain preserved in the evidence package. Exact unchanged native receipts are authenticated before reuse; they are not described as new inference.

Validation: 60 Korean/English HTML pages, zero broken links, two identical normal-export manifests, {d['outputs']} outputs. The fourteen Korean/English scenario/index HTML files, six manuscripts, all non-evidence Clang facts, calls and full trace records remain byte-identical to PR68. Actual current source windows match immutable libcamera commit293d751a814e0d4c34e85ad457ccd9d5eefd1a61. Merged generator: {d['generator_commit']}. Build: {d['build_id']}. Manifest SHA256: {d['manifest_sha256']}.

The current standard contract audit has zero confirmed contradictions and five unresolved ordinary-document comparisons. Those classifications and earlier supplementary whole-page editorial findings remain open; this is not whole-repository completeness, human approval, internal HAL or physical-device qualification. All earlier publication archives are preserved.

Pages deployment and ordinary public HTTPS artifact checks are performed after this PR merges and tracked in TTolsun/camera-hal-sdd-generator#193. No public recurring schedule is installed.
'''
(w/'public-pr.md').write_text(body,encoding='utf-8');(w/'public-commit.txt').write_text('Apply checked request summaries and queued-return correction\n',encoding='utf-8')
