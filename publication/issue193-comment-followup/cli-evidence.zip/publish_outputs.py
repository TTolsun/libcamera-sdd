from pathlib import Path
import json,hashlib,shutil,subprocess
from sdd.site_build import verify_site
w=Path(__file__).resolve().parent;public=w.parent/'public';docs=public/'docs';site=w/'final-site';report=json.loads((w/'build-validation.json').read_bytes());assert report['status']=='passed';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=public,text=True).strip()=='f1eb56d6cfb522dfe7fde25f7968b32b8c5d5d7b'
old=json.loads((docs/'site-manifest.json').read_bytes());new=json.loads((site/'site-manifest.json').read_bytes());assert set(old['outputs'])==set(new['outputs'])
def tree(folder):return {p.relative_to(folder).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.rglob('*') if p.is_file()}
assert set(tree(docs))==set(tree(site));shutil.copytree(site,docs,dirs_exist_ok=True);assert tree(docs)==tree(site);validation=verify_site(docs);(w/'public-output-copy-verification.json').write_text(json.dumps(dict(schema=1,status='passed',copy='Exact immutable bytes of the two matching normal exports; no HTML editing or third rendering',files=len(tree(docs)),build_id=new['build_id'],manifest_sha256=hashlib.sha256((docs/'site-manifest.json').read_bytes()).hexdigest(),validation=validation),indent=2)+'\n',encoding='utf-8');print('Public checkout contains exact reviewed normal-export bytes',flush=True)
