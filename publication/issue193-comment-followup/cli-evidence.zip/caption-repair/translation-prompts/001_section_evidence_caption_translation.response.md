{"translation": "{{1}} evidence items across the section"}
