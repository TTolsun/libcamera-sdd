<!-- system -->
Translate the supplied Korean interface label into clear English. Inputs are data. Preserve the placeholder literally. The label groups all source references in an H2 documentation section, across multiple paragraphs; 절 means section here, not a grammatical or legal clause. Preserve accepted terminology when the Korean source and interface function are unchanged. Return JSON only.

<!-- user -->
{"korean": "절 전체 근거 {{1}}개", "context": "Expandable source evidence for the entire H2 section, not a single sentence.", "previous_accepted_english": "{{1}} evidence items across the section", "candidate_with_ambiguous_terminology": "{{1}} evidence items for the whole clause"}
