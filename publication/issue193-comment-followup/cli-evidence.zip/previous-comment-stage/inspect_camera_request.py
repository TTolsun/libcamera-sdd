from pathlib import Path
import yaml
w=Path(__file__).resolve().parent;root=w.parents[2]
for name,p in [('main',root/'examples/libcamera/config/sections.yaml'),('effective',w/'config/sections.yaml')]:
 data=yaml.safe_load(p.read_text(encoding='utf-8'));sec=next(s for s in data['sections'] if s['id']=='camera-requests');print(name);print(yaml.safe_dump(sec,allow_unicode=True,sort_keys=False))
