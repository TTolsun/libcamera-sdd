from pathlib import Path
import json,hashlib,subprocess,copy
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.generated_design import verify
from sdd.export_site import export_site
from sdd.site_build import verify_site
from sdd.document_health import enforce as health_enforce
from sdd.consistency import enforce as consistency_enforce
w=Path(__file__).resolve().parent;old=w.parent/'latest293';cfg=load(w/'publication.yaml');m=KnowledgeModel.load(cfg.facts_path)
for name in ('generation-correction.json','source-review.json','translation-summary.json','bilingual-review.json'):
 assert json.loads((w/name).read_bytes())['status']=='passed',name
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w.parents[2],text=True).strip()=='54e7e3e592a182e1704707cabd1f3f1de7db8e0b'
source=m.meta['source_commit'];assert source=='293d751a814e0d4c34e85ad457ccd9d5eefd1a61';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=cfg.source_root,text=True).strip()==source
subprocess.run(['git','diff','--exit-code',source,'--','src','include'],cwd=cfg.source_root,check=True,capture_output=True)
prior=json.loads((old/'run/facts/facts.json').read_bytes());now=m.to_dict();assert {k:v for k,v in prior.items() if k!='evidence'}=={k:v for k,v in now.items() if k!='evidence'}
source_checks=[]
for key,r in now['evidence'].items():
 if prior['evidence'].get(key)==r:continue
 text=r['text'];assert hashlib.sha256(text.encode()).hexdigest()==r['sha256'];blob=subprocess.check_output(['git','show',source+':'+r['file']],cwd=cfg.source_root).decode('utf-8').replace('\r\n','\n');assert text in blob,key
 ctx=r.get('context')
 if ctx:assert hashlib.sha256(ctx['text'].encode()).hexdigest()==ctx['sha256'] and ctx['text'] in blob,key
 source_checks.append(dict(id=key,file=r['file'],sha256=r['sha256'],immutable_git_match=True))
for p in (old/'run/manuscripts/scenarios').glob('*.md'):assert p.read_bytes()==(cfg.sdd_dir/'scenarios'/p.name).read_bytes(),p.name
verified=[]
for sec in cfg.sections():
 p=cfg.sdd_dir/sec['output']
 if p.exists() and sec.get('design_topics'):verify(m,sec,p.read_text(encoding='utf-8'),cfg=cfg);verified.append(sec['output'])
consistency_enforce(cfg,m);health=health_enforce(cfg,m);assert not health['findings'],health['findings']
first=export_site(cfg,w/'site');manifest=(first/'site-manifest.json').read_bytes();validation=verify_site(first);second=export_site(cfg,w/'repeat-site');assert manifest==(second/'site-manifest.json').read_bytes()
bodyproof=[]
for rel,entry in json.loads(manifest)['outputs'].items():
 if not rel.endswith('.html'):continue
 import re
 text=(first/rel).read_text(encoding='utf-8')
 for table in re.findall(r'<table\b[^>]*>.*?</table>',text,re.S):
  headers=[' '.join(re.sub('<[^>]+>','',h).split()) for h in re.findall(r'<th\b[^>]*>(.*?)</th>',table,re.S)]
  assert not (len(headers)==2 and headers[0] in ('지금 확인할 내용','What to check','What you should check now')), (rel,headers)
 if rel.startswith(('scenarios/','en/scenarios/')):
  old_text=(w.parent/'public/docs'/rel).read_bytes();assert (first/rel).read_bytes()==old_text,rel
  bodyproof.append(rel)
report=dict(schema=1,status='passed',source_commit=source,generator_commit='54e7e3e592a182e1704707cabd1f3f1de7db8e0b',build_id=json.loads(manifest)['build_id'],manifest_sha256=hashlib.sha256(manifest).hexdigest(),outputs=len(json.loads(manifest)['outputs']),validation=validation,repeat_build_identical=True,verified_manuscripts=verified,new_source_windows=source_checks,structural_facts_unchanged=True,scenario_ko_en_html_byte_identical=bodyproof,health_findings=health['findings'],human_review='pending',internal_hal_validation='not-run')
(w/'build-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
