from pathlib import Path
import copy,json,shutil,yaml,hashlib
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.evidence import collect
w=Path(__file__).resolve().parent;old=w.parent/'latest293';root=w.parents[2]
assert not (w/'generation.yaml').exists(),'Already prepared; inspect existing run'
shutil.copytree(old/'config',w/'config');shutil.copytree(old/'run',w/'run');(w/'before').mkdir()
for n in ('generation.yaml','translation.yaml','independent-review.yaml','publication.yaml'):
 d=yaml.safe_load((old/n).read_text(encoding='utf-8'));d['output']['facts_dir']=str(w/'run/facts');d['output']['sdd_dir']=str(w/'run/manuscripts');d['output']['diagrams_dir']=str(w/'run/manuscripts/diagrams')
 for k,v in list(d['paths'].items()):
  if isinstance(v,str) and str(old/'config') in v:d['paths'][k]=v.replace(str(old/'config'),str(w/'config'))
 d['paths']['consistency_review_config']=str(w/'independent-review.yaml');d['site']['english_catalog']=str(w/'run/english.json')
 d['agent'].update(kind='cli',runner='claude',model='claude-haiku-5-5',args=['--effort','high'],max_input_chars=160000 if n=='independent-review.yaml' else 64000,timeout_sec=600,full_style_guides=True);d['agent'].pop('command',None)
 (w/n).write_text(yaml.safe_dump(d,allow_unicode=True,sort_keys=False),encoding='utf-8')
p=w/'config/sections.yaml';data=yaml.safe_load(p.read_text(encoding='utf-8'));main=yaml.safe_load((root/'examples/libcamera/config/sections.yaml').read_text(encoding='utf-8'));sec=next(s for s in data['sections'] if s['id']=='request-lifecycle');current=next(s for s in main['sections'] if s['id']=='request-lifecycle');shutil.copyfile(p,w/'before/sections.yaml');shutil.copyfile(w/'run/manuscripts/request-lifecycle.md',w/'before/request-lifecycle.md');shutil.copyfile(w/'run/english.json',w/'before/english.json')
for tid in ('journey','resources','stopping'):
 t=next(t for t in sec['design_topics'] if t['id']==tid);latest=next(t for t in current['design_topics'] if t['id']==tid);summary=copy.deepcopy(next(p for p in latest['parts'] if p['id']=='summary'));t['parts'].insert(0,summary)
 if tid=='journey':t['parts']=[copy.deepcopy(next(p for p in latest['parts'] if p['id']=='submission')) if p['id']=='submission' else p for p in t['parts']]
 refs={ref for p in t['parts'] for ref in p['sources']};present={s['id'] for s in t['sources']}
 for src in latest['sources']:
  if src['id'] in refs-present:t['sources'].append(copy.deepcopy(src))
p.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
cfg=load(w/'generation.yaml');m=KnowledgeModel.load(cfg.facts_path);raw=m.to_dict();collect(cfg,m);m.save(cfg.facts_path);assert {k:v for k,v in raw.items() if k!='evidence'}=={k:v for k,v in m.to_dict().items() if k!='evidence'}
(w/'scope.json').write_text(json.dumps(dict(schema=1,source_commit=m.meta['source_commit'],generator_commit='54e7e3e592a182e1704707cabd1f3f1de7db8e0b',reason='Final effective-config check found Claude issue193 comment summary requirements absent from retained ordinary manuscript. Generate only three summary units and narrowed submission through real selected Claude CLI; preserve all other current source-reviewed structured statements and immutable publication68 records.',selected=[['journey','summary'],['resources','summary'],['stopping','summary'],['journey','submission']],structural_facts_unchanged=True,human_review='pending'),indent=2)+chr(10),encoding='utf-8')
print('Prepared isolated four-unit Claude comment correction; no public output changed',flush=True)
