from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import copy,json,hashlib,sys,shutil
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.document_metadata import split_frontmatter
from sdd.generated_design import _prepare_generation,_assemble_generation,verify
from sdd.design_request import _design_units,_unit_tag
from sdd.design_execution import _request_unit
from sdd.generation_run import Execution
from sdd.llm import Agent
from sdd.generate import Generator
from sdd.generated_visuals import from_manuscript
w=Path(__file__).resolve().parent;stage=w;cfg=load(w/'generation.yaml');m=KnowledgeModel.load(cfg.facts_path)
selected={'request-lifecycle':{('journey','summary'),('resources','summary'),('stopping','summary'),('journey','submission')}}
def run(sid):
 sec=next(s for s in cfg.sections() if s['id']==sid);p=cfg.sdd_dir/sec['output'];previous=p.read_text(encoding='utf-8');meta,_=split_frontmatter(previous)
 baseline=w/'before'/sec['output'];assert p.read_bytes()==baseline.read_bytes()
 # Old files remain immutable; retain exact structured answers, never feed saved responses as new inference.
 answers=copy.deepcopy(meta['generated_design']['answers']);plan,_,_=_prepare_generation(cfg,m,sec,previous)
 targets=selected[sid];changed={t for t,_ in targets};inputs=copy.deepcopy(meta['generated_design']['topic_inputs']);inputs.update({t:plan.inputs[t] for t in changed})
 origins=copy.deepcopy(meta['generated_design']['topic_agents']);execution=Execution(cfg,Agent(cfg.agent,cfg.build_dir/'prompts'));lineage=[]
 try:
  with execution.document(sid,[_unit_tag(sec,u) for u in _design_units(sec,{}) if (u['id'],u.get('_part_id')) in targets]):
   for unit in _design_units(sec,{}):
    pair=(unit['id'],unit.get('_part_id'))
    if pair not in targets:continue
    prior=[r for r in answers[unit['id']] if unit.get('_part_id') and r.get('part_id')!=unit['_part_id']]
    before=copy.deepcopy(answers[unit['id']]);answers[unit['id']]=prior
    new,record=_request_unit(cfg,m,execution,sec,unit,plan.prompts[unit['id']],plan.policy['design_grounding'],None,answers)
    if unit.get('_part_id'):
     oldparts=[p['id'] for t in sec['design_topics'] if t['id']==unit['id'] for p in t['parts']];answers[unit['id']]=sorted(prior+new,key=lambda r:oldparts.index(r['part_id']))
    else:answers[unit['id']]=new
    origins[unit['id']]=cfg.agent.label;execution.unit(_unit_tag(sec,unit),'newly-generated' if record is None else 'checkpoint-revalidated')
    lineage.append(dict(topic=unit['id'],part=unit.get('_part_id'),original_statement_sha256=hashlib.sha256(json.dumps(before,ensure_ascii=False,sort_keys=True).encode()).hexdigest(),checkpoint=record))
  reused=[t['id'] for t in sec['design_topics'] if t['id'] not in changed]
  result=_assemble_generation(cfg,m,sec,answers,inputs,reused,[],origins,plan.policy)
  result[3]['partial_topic_revisions']=dict(original_manuscript_sha256=hashlib.sha256(baseline.read_bytes()).hexdigest(),revised_units=lineage,unchanged_units='Exact historical structured statements retained and revalidated; no new drafting claimed for these parts.',original_profile='publication/issue193/profiles/generation.yaml')
  gen=Generator(cfg,m,execution);gen.generated_designs[sid]=result
  visual=from_manuscript(cfg,m,sec,previous)
  if visual:gen.generated_visuals[sid]=visual
  gen._prose(sec);verify(m,sec,p.read_text(encoding='utf-8'),cfg=cfg)
  return dict(page=sec['output'],status='passed',revised_units=lineage,manuscript_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 finally:execution.persist()
rows=[]
with ThreadPoolExecutor(max_workers=2) as pool:
 for row in pool.map(run,selected):rows.append(row);print(row['page'],row['status'],flush=True)
(stage/'generation-correction.json').write_text(json.dumps(dict(schema=1,status='passed',pages=rows,manual_prose_edit=False,scope='Four normal selected-Claude requests for three required opening summaries and narrowed submission; standard grounding/decode/assembly/rendering; other exact source-reviewed statements retained.',human_review='pending'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
