from pathlib import Path
import json,yaml,hashlib,subprocess
from sdd.document_metadata import split_frontmatter
w=Path(__file__).resolve().parent;root=w.parents[2];data=yaml.safe_load((w/'config/sections.yaml').read_text(encoding='utf-8'));main=yaml.safe_load((root/'examples/libcamera/config/sections.yaml').read_text(encoding='utf-8'));sec=next(s for s in data['sections'] if s['id']=='request-lifecycle');up=next(s for s in main['sections'] if s['id']=='request-lifecycle');meta,_=split_frontmatter((w/'run/manuscripts/request-lifecycle.md').read_text(encoding='utf-8'));old,_=split_frontmatter((w/'before/request-lifecycle.md').read_text(encoding='utf-8'));selected={tuple(x) for x in json.loads((w/'scope.json').read_bytes())['selected']};rows=[]
for tid,pid in sorted(selected):
 topic=next(t for t in sec['design_topics'] if t['id']==tid);expected=next(t for t in up['design_topics'] if t['id']==tid);part=next(p for p in topic['parts'] if p['id']==pid);assert part==next(p for p in expected['parts'] if p['id']==pid);assert any(a.get('part_id')==pid for a in meta['generated_design']['answers'][tid]);rows.append(dict(topic=tid,part=pid,exact_current_main_part=True,role=part.get('role')))
for tid,answers in old['generated_design']['answers'].items():
 for a in answers:
  if (tid,a.get('part_id')) in selected:continue
  assert a in meta['generated_design']['answers'][tid],(tid,a.get('part_id'))
for name in ('generation.yaml','translation.yaml','independent-review.yaml'):
 d=yaml.safe_load((w/name).read_text(encoding='utf-8'));assert d['agent']['runner']=='claude' and d['agent']['model']=='claude-haiku-5-5' and d['agent']['args']==['--effort','high'];assert d['agent']['max_input_chars']>=48000;assert Path(d['site']['mermaid_dir']).is_dir()
example=yaml.safe_load((root/'examples/libcamera/sdd.yaml').read_text(encoding='utf-8'));assert example['agent']['max_input_chars']>=48000
assert 'unique_ptr' in str(next(p for t in sec['design_topics'] if t['id']=='journey' for p in t['parts'] if p['id']=='create'))
subprocess.run(['git','merge-base','--is-ancestor','e44905f','HEAD'],cwd=root,check=True)
impact=json.loads((w/'build/impact.json').read_bytes());assert 'request-lifecycle' in impact['sections'] and not impact['changed_files']
(w/'effective-comment-contracts.json').write_text(json.dumps(dict(schema=1,status='passed',source_commit=meta['source_commit'],rows=rows,unchanged_structured_answers_preserved=True,impact_selected_request_lifecycle=True,impact_other_sections=impact['sections'],main_includes_pr199=True,selected_inference_profiles_minimum_input_chars=48000,local_mermaid_preserved=True,scope='Bounded four requested prose corrections, exact current-main part definitions. All other current published ordinary statements and runtime evidence remain historical. Root current generator CI already covers transient executable-path identity. Static renderer preserves historical visual identity and executes no model call.',human_review='pending'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Effective four-unit comment contracts and prior-answer preservation passed',flush=True)
