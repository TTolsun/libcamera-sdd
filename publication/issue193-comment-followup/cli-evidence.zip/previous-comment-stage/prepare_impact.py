from pathlib import Path
import yaml,shutil
w=Path(__file__).resolve().parent;shutil.copytree(w/'run/manuscripts',w/'impact-manuscripts');shutil.copyfile(w/'before/request-lifecycle.md',w/'impact-manuscripts/request-lifecycle.md');d=yaml.safe_load((w/'generation.yaml').read_text(encoding='utf-8'));d['output']['sdd_dir']=str(w/'impact-manuscripts');d['output']['diagrams_dir']=str(w/'impact-manuscripts/diagrams');(w/'impact.yaml').write_text(yaml.safe_dump(d,allow_unicode=True,sort_keys=False),encoding='utf-8')
