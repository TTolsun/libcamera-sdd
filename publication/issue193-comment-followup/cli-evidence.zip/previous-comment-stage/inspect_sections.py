from pathlib import Path
import yaml,json
w=Path(__file__).resolve().parent; root=w.parents[2]; old=yaml.safe_load((w.parent/'latest293/config/sections.yaml').read_text(encoding='utf-8')); new=yaml.safe_load((root/'examples/libcamera/config/sections.yaml').read_text(encoding='utf-8'))
a=next(s for s in old['sections'] if s['id']=='request-lifecycle');b=next(s for s in new['sections'] if s['id']=='request-lifecycle')
for t in b['design_topics']:
 o=next(x for x in a['design_topics'] if x['id']==t['id']);print(t['id'],'OLD',[x['id'] for x in o['parts']],'NEW',[x['id'] for x in t['parts']]); print('SOURCES old/new',[x['id'] for x in o['sources']],[x['id'] for x in t['sources']])
print('TOPIC IDS',[x['id'] for x in a['design_topics']],[x['id'] for x in b['design_topics']])
