from pathlib import Path
import copy,hashlib,json,yaml
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.document_metadata import split_frontmatter
from sdd.render_profiles import for_page
from sdd.generated_visuals import generate
from sdd.visual_refresh import refresh
from sdd.llm import Agent
from sdd.generation_run import Execution
from sdd.validation_stage import stage
r=Path(__file__).resolve().parent;b=r/'base';raw=yaml.safe_load((b/'publication.yaml').read_text(encoding='utf-8'))
origin=copy.deepcopy(raw);origin['visuals']['file']=str(r/'before-visuals.yaml');(b/'origin-visuals-profile.yaml').write_text(yaml.safe_dump(origin,allow_unicode=True,sort_keys=False),encoding='utf-8');original_cfg=load(b/'origin-visuals-profile.yaml')
p=b/'visuals.yaml';data=yaml.safe_load(p.read_text(encoding='utf-8'));current=yaml.safe_load((Path.cwd()/'examples/libcamera/config/visuals.yaml').read_text(encoding='utf-8'));new=next(x for x in current['sections']['pipeline-handler'] if x['id']=='input-search-loops');i=next(i for i,x in enumerate(data['sections']['pipeline-handler']) if x['id']==new['id']);data['sections']['pipeline-handler'][i]=new;p.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
cfg=load(b/'publication.yaml');model=KnowledgeModel.load(cfg.facts_path);section=next(s for s in cfg.sections() if s['id']=='pipeline-handler');selected=for_page(cfg,'pipeline-handler.md')
assert selected.agent.runner=='codex' and selected.agent.model=='gpt-6.1-terra' and 'model_reasoning_effort="high"' in selected.agent.args
single=copy.deepcopy(selected);subset=r/'single-visual.yaml';subset.write_text(yaml.safe_dump({'schema':1,'sections':{'pipeline-handler':[new]}},allow_unicode=True,sort_keys=False),encoding='utf-8');single.raw['visuals']['file']=str(subset)
old=(r/'pipeline-handler-before.md').read_bytes();assert old==(cfg.sdd_dir/'pipeline-handler.md').read_bytes();meta,_=split_frontmatter(old.decode('utf-8').replace('\r\n','\n').replace('\r','\n'))
artifact_path=r/'new-native-artifact.json'
if artifact_path.exists():
 artifact=json.loads(artifact_path.read_bytes())
 print('Resume assembly from the already completed native artifact; no new CLI generation claimed',flush=True)
else:
 agent=Execution(single,Agent(single.agent,r/'native-figure'),model=model)
 with stage() as inputs:
  inputs.pin(single,model)
  with agent.track('generation'),agent.document('pipeline-handler.md',['visual_pipeline-handler_input-search-loops']):
   artifact=generate(single,model,section,agent)
 artifact_path.write_text(json.dumps(artifact,ensure_ascii=False,indent=2),encoding='utf-8')
combined=copy.deepcopy(meta['generated_visuals']);combined={'schema':1,'records':combined['records']};combined['records']['input-search-loops']=artifact['records']['input-search-loops']
updated=refresh(cfg,model,'pipeline-handler',old,expected_sha256=hashlib.sha256(old).hexdigest(),original_cfg=original_cfg,visual_artifact=combined)
after,_=split_frontmatter(updated.decode('utf-8').replace('\r\n','\n').replace('\r','\n'));old_design=copy.deepcopy(meta['generated_design']);new_design=copy.deepcopy(after['generated_design']);new_design['body_sha256']=old_design['body_sha256'];assert new_design==old_design
unchanged=[key for key in combined['records'] if key!='input-search-loops'];assert all(after['generated_visuals']['records'][key]==meta['generated_visuals']['records'][key] for key in unchanged)
(cfg.sdd_dir/'pipeline-handler.md').write_bytes(updated)
(r/'figure-refresh.json').write_text(json.dumps({'original_manuscript_sha256':hashlib.sha256(old).hexdigest(),'updated_manuscript_sha256':hashlib.sha256(updated).hexdigest(),'changed_native_graphs':['input-search-loops'],'unchanged_original_graphs':unchanged,'prose_and_prose_authorship_preserved':True,'human_approval':'not granted','actual_human_or_executive_evaluation':'not performed'},indent=2),encoding='utf-8')
(r/'new-graph.json').write_text(json.dumps(after['generated_visuals']['records']['input-search-loops'],ensure_ascii=False,indent=2),encoding='utf-8');print('PASS one native graph refreshed, original prose and four historical graph records preserved',flush=True)
