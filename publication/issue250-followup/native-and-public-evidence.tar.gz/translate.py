from pathlib import Path
import json,shutil
from sdd.config import load
from sdd.localization_cli import prepare_catalog
r=Path(__file__).resolve().parent;cfg=load(r/'base/publication.yaml');profile=load(cfg.paths['translation_profile'])
assert profile.agent.kind=='cli' and profile.agent.runner=='codex' and profile.agent.model=='gpt-6.1-terra' and 'model_reasoning_effort="high"' in profile.agent.args
print('Actual translation profile',profile.agent.runner,profile.agent.command,profile.agent.model,profile.agent.args,flush=True)
path=Path(cfg.site.english_catalog)
if not (r/'english-before-followup.json').exists():shutil.copyfile(path,r/'english-before-followup.json')
result=prepare_catalog(cfg,path,translate=True)
(r/'translation-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(result,flush=True)
