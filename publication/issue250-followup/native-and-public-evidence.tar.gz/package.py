from pathlib import Path
import json,hashlib,gzip,shutil,tarfile,datetime,re
from html.parser import HTMLParser
from urllib.parse import unquote
from sdd.config import load
r=Path(__file__).resolve().parent;repo=Path.cwd();proof=r/'release-evidence';proof.mkdir(exist_ok=True);cfg=load(r/'base/publication.yaml')
manifest=json.loads((r/'site/site-manifest.json').read_bytes());checks={}
for role in ['work','decision']:
 data=json.loads((r/f'evaluation-final-{role}.json').read_bytes());assert data['actual_human'] is False and data['actual_executive'] is False
 identity=data.get('build_identity',data.get('build_verification'));before=identity.get('before',identity.get('before_build_id'));after=identity.get('after',identity.get('after_build_id'));assert before==after==manifest['build_id'];checks[role]={'same_build_before_after':True,'evaluator_type':data['evaluator_type']}
class IDs(HTMLParser):
 def __init__(self):super().__init__();self.ids=set()
 def handle_starttag(self,tag,attrs):
  for k,v in attrs:
   if k=='id':self.ids.add(v)
seen={}
def check_url(value):
 file,fragment=value.split('#',1);p=r/'site'/file;assert p.is_file(),value
 if file not in seen:
  parser=IDs();parser.feed(p.read_text(encoding='utf-8'));seen[file]=parser.ids
 assert unquote(fragment) in seen[file],value
urls=set()
def walk(value):
 if isinstance(value,str) and re.fullmatch(r'[a-z0-9_./-]+\.html#[^\s]+',value):urls.add(value)
 elif isinstance(value,list):
  for item in value:walk(item)
 elif isinstance(value,dict):
  for item in value.values():walk(item)
for role in ['work','decision']:
 data=json.loads((r/f'evaluation-final-{role}.json').read_bytes());walk(data)
 if role=='decision':
  for nav in data.get('navigation',[]):
   if isinstance(nav,dict) and 'path' in nav:
    path=Path(nav['path']);assert path.is_file()
    if path.suffix=='.html':
     for anchor in nav.get('anchors',[]):urls.add(path.relative_to(r/'site').as_posix()+'#'+anchor)
for url in urls:check_url(url)
(r/'evaluation-trace-verification.json').write_text(json.dumps({'status':'passed','role_build_checks':checks,'reported_HTML_anchors_checked':len(urls)},indent=2),encoding='utf-8')
records=json.loads((r/'native-verification.json').read_bytes())['records'];files=set()
for row in records:
 for relative in [row['receipt'],*row.get('aliases',[])]:
  receipt=r/relative;prefix=receipt.name.removesuffix('.receipt.json')
  files.update(p for p in receipt.parent.glob(prefix+'.*') if p.is_file())
  metadata=json.loads(receipt.read_bytes());stdout=receipt.parent.parent.parent/metadata['provider']['stdout_path'];prefix=stdout.name.split('.stdout')[0]
  files.update(p for p in stdout.parent.glob(prefix+'*') if p.is_file())
for pattern in ['*.json','*.py','*.cjs','*.log','*.yaml','*.md']:files.update(p for p in r.glob(pattern) if p.is_file())
for pattern in ['*.yaml','*.md','*.json']:
 for p in (r/'base').glob(pattern):files.add(p)
files.update(p for p in cfg.sdd_dir.rglob('*') if p.is_file())
files.update(p for p in (r/'base/bound-prerequisites').rglob('*') if p.is_file())
files.update(p for p in (r/'browser-final').rglob('*') if p.is_file())
files.update(p for p in (r/'evaluation-before-main243').rglob('*') if p.is_file())
# Keep the exact current facts, not a new extraction claim.
with gzip.open(r/'facts.json.gz','wb') as f:f.write(cfg.facts_path.read_bytes())
files.add(r/'facts.json.gz')
archive=proof/'native-and-public-evidence.tar.gz';index={}
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(files):
  name=p.relative_to(r).as_posix();tar.add(p,arcname=name,recursive=False);index[name]=hashlib.sha256(p.read_bytes()).hexdigest()
(proof/'archive-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding='utf-8')
for name in ['evaluation-final-work.json','evaluation-final-decision.json','evaluation-final-plan.json','evaluation-trace-verification.json','figure-refresh.json','native-verification.json','site-verification.json','bilingual-review.json','bilingual-integrated-review.json','main243-integration.json']:
 shutil.copyfile(r/name,proof/name)
shutil.copyfile(repo/'examples/libcamera/reader-paths.yaml',proof/'reader-paths.yaml');shutil.copyfile(r/'browser-final/summary.json',proof/'browser-verification.json')
(proof/'package.json').write_text(json.dumps({'schema':1,'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'entries':len(index),'public_source_only':True,'actual_human_evaluation':'unverified','actual_executive_evaluation':'unverified'},indent=2),encoding='utf-8')
shutil.copytree(proof,repo/'build/issue250/public/publication/issue250-followup',dirs_exist_ok=True)
print('PASS report trace, public evidence package',len(index),'files;',archive.stat().st_size,'bytes')
