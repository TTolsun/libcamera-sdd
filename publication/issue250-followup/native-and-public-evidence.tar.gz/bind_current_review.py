from pathlib import Path
import json,yaml,hashlib
r=Path(__file__).resolve().parent;p=r/'base/publication.yaml';d=yaml.safe_load(p.read_text(encoding='utf-8'));report=r/'base/build/consistency-review.json'
a=json.loads(report.read_bytes());assert a['status']=='passed'
for x in d['publication']['reports']:
 if x['producer']=='independent-codex-cli-audit':x['sha256']=hashlib.sha256(report.read_bytes()).hexdigest()
p.write_text(yaml.safe_dump(d,allow_unicode=True,sort_keys=False),encoding='utf-8')
print('Bound current actual review',a['fresh_batches'],a['reused_batches'],'unresolved',len(a['unresolved']))
