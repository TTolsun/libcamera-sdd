from pathlib import Path
import json,hashlib,subprocess,shutil
from sdd.config import load
from sdd.export_site import export_site
r=Path(__file__).resolve().parent;public=r.parent/'issue250/public';cfg=load(r/'base/publication.yaml')
assert (public/'docs/site-manifest.json').read_bytes()==(r/'baseline-site-manifest.json').read_bytes(),'Integrate changed public main before staging'
# Save every non-owned existing validation page and asset before export.
before={p.relative_to(public/'docs').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (public/'docs/validation').rglob('*') if p.is_file()}
export_site(cfg,public/'docs')
assert (public/'docs/site-manifest.json').read_bytes()==(r/'site/site-manifest.json').read_bytes()
after={p.relative_to(public/'docs').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (public/'docs/validation').rglob('*') if p.is_file()};assert before==after
(public/'.gitattributes').open('a',encoding='utf-8').write('\npublication/issue250-followup/** -text -whitespace\n')
(public/'README.md').open('a',encoding='utf-8').write('\n- [Issue250 follow-up: conditions, direct navigation and ordered search — agent proxy evaluation; human evaluation unverified](publication/issue250-followup/README.md)\n')
shutil.copytree(r/'release-evidence',public/'publication/issue250-followup',dirs_exist_ok=True)
subprocess.run(['git','-C',str(public),'add','.gitattributes','README.md','docs','publication/issue250-followup'],check=True)
(r/'staging-preservation.json').write_text(json.dumps({'status':'passed','existing_validation_files_identical':len(before),'manifest_matches_evaluated_build':True},indent=2),encoding='utf-8')
print('PASS exact release staged; preserved',len(before),'existing validation files')
