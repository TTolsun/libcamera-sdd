from pathlib import Path
import json,hashlib
from sdd.config import load
from sdd.export_site import export_site
from sdd.site_build import verify_site
r=Path(__file__).resolve().parent;cfg=load(r/'base/publication.yaml')
baseline=(r/'baseline-site-manifest.json').read_bytes()
assert Path('build/issue250/public/docs/site-manifest.json').read_bytes()==baseline,'Public baseline changed; integrate before staging'
report=json.loads((cfg.build_dir/'consistency-review.json').read_bytes());assert report['status']=='passed'
site=export_site(cfg,r/'site');before=(site/'site-manifest.json').read_bytes()
export_site(cfg,site);assert (site/'site-manifest.json').read_bytes()==before
result={'site':verify_site(site),'repeat_manifest_identical':True,'build_id':json.loads(before)['build_id'],'actual_human_evaluation':'not performed','actual_executive_evaluation':'not performed','internal_HAL':'not validated'}
(r/'site-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS repeated gated export',result,flush=True)
