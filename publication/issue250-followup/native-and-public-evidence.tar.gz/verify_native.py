from pathlib import Path
import json,hashlib,datetime
from sdd.config import load
from sdd.cli_provenance import verify_cli_receipt
r=Path(__file__).resolve().parent;expected=load(r/'review.yaml').agent
started=datetime.datetime.fromtimestamp((r/'baseline-profile.json').stat().st_mtime,datetime.timezone.utc)
imported={hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'latest-main-243').rglob('*.receipt.json')};seen={};matches=[];artifact=json.loads((r/'new-native-artifact.json').read_bytes())['records']['input-search-loops']['draft']
for directory in [r/'condition-generation',r/'native-figure',r/'review-code',r/'review-content',r/'bilingual-review',r/'bilingual-integrated-review',r/'base/build/translation-prompts',r/'base/build/prompts']:
 if not directory.exists():continue
 for p in directory.rglob('*.receipt.json'):
  receipt=json.loads(p.read_bytes());stamp=datetime.datetime.fromisoformat(receipt['completed_at'].replace('Z','+00:00'))
  if stamp<started:continue
  prefix=p.with_name(p.name.removesuffix('.receipt.json'));request=json.loads(prefix.with_suffix('.request.json').read_bytes());response=prefix.with_suffix('.response.txt').read_text(encoding='utf-8');result=verify_cli_receipt(request,response,receipt,p.parent.parent,expected)
  digest=hashlib.sha256(p.read_bytes()).hexdigest();relative=p.relative_to(r).as_posix()
  if digest in seen:seen[digest]['aliases'].append(relative)
  else:seen[digest]={'receipt':relative,'aliases':[],'receipt_sha256':digest,'origin':('imported-main243-completed-native' if digest in imported else 'followup-execution'),'tag':receipt['tag'],'completed_at':receipt['completed_at'],'verification':result}
  if receipt['tag'].startswith('visual_pipeline-handler_input-search-loops') and json.loads(response)==artifact:matches.append(relative)
assert seen and matches,'Final draft is not tied to an actual completed CLI response'
report={'status':'verified','unique_completed_receipts':len(seen),'followup_completed_receipts':sum(x['origin']=='followup-execution' for x in seen.values()),'imported_completed_receipts_not_new_calls':sum(x['origin']!='followup-execution' for x in seen.values()),'copied_aliases_not_new_calls':sum(len(x['aliases']) for x in seen.values()),'records':list(seen.values()),'final_native_draft_matching_receipts':matches,'scope':'CLI request/response/native stdout/model/arguments integrity. Includes rejected/intermediate proposals; not semantic acceptance, human approval or device execution.'}
(r/'native-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print('PASS original native receipts',len(seen),'and selected draft bound to completed native response')
