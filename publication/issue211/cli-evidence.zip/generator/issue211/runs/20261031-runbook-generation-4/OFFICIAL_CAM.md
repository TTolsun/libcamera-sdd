공식 libcamera `cam`의 WSL 실행 결과는 가상 카메라(`Virtual2`, 400x300 NV12/SMPTE170M)에서만 관찰되었습니다. 물리 DMA, 물리 카메라, 제품 앱, 사내 HAL은 검증되지 않았습니다.

**준비 조건**

지원 대상은 udmabuf가 내장된 테스트 커널 `6.18.33.2-microsoft-standard-WSL2-issue211`입니다. `/dev/udmabuf`는 root만 접근할 수 있으며 권한은 바꾸지 않습니다. 커널, `.wslconfig`, WSL 종료는 공유 설정이므로 별도 호스트 승인이 필요합니다.

1. 호스트 승인을 받습니다. 요청에는 백업 대상과 정확한 롤백 절차를 포함하고, Docker를 먼저 중지합니다. 모듈은 설치하지 않으며 `kernel_trial.py`는 자동으로 실행하지 않습니다.
2. 소스를 `293d751a814e0d4c34e85ad457ccd9d5eefd1a61`로 고정하고 추적 파일이 깨끗한지 확인합니다. 수정하지 않은 소스를 디버그 Meson 빌드로 빌드합니다.
3. 프로브를 컴파일합니다. `gcc -std=c11 -Wall -Wextra -Werror -O0 -g dmabuf_probe.c -o <compiled-dmabuf-probe>`
4. 새 증거 디렉터리 경로를 정합니다. 기존 출력 디렉터리는 덮어쓸 수 없습니다.
5. WSL에서 root 권한 자식 프로세스로 아래 명령을 실행합니다. `--tools`에는 `usr/bin/gdb`와 `usr/share/gdb`가 들어 있는 디렉터리를 지정합니다.

```
PYTHONPATH=<generator>/src python3 <generator>/examples/libcamera/runtime/run_cam.py --source <unmodified-source-at-293d751a> --build <its-debug-meson-build> --tools <private-extracted-tools-prefix> --probe <compiled-dmabuf-probe> --out <new-evidence-directory>
```

**결과**

세 독립 프로세스(PID 434, 449, 464)는 각각 요청 3개를 완료했고 할당은 4회였습니다. 취소된 콜백은 0개였지만, 취소 분기를 실행해 얻은 값이 아닙니다. 각 프로세스의 sequence 0, 1, 2는 PID, `request`, `sequence`로 조인했고, 관찰 지점의 `status`는 모두 1, buffer-metadata의 `buffer_status`는 0이었습니다. TID는 동등 조인 키가 아닙니다. 콜백 TID(437, 452, 467)와 처리 TID(PID와 동일)가 다르므로 차이를 기록만 합니다. 프로브는 `/dev/udmabuf` 열기, 4096바이트 DMA-BUF 할당, mmap, sync 시작·종료, CPU 읽기·쓰기 접근과 체크섬을 기록했고 오류 errno는 모두 0이었습니다. 0.5초 시간 제한 프로브는 timed_out이 true이고 exit code 1로 실패 상태를 유지했습니다. 시간 초과와 실패는 성공으로 바꾸지 않습니다. 일반 사용자 실행은 관찰된 테스트 커널 실행에서만 errno 13으로 실패했습니다.

시험 후 커널은 `6.18.33.2-microsoft-standard-WSL2`로 복원되었고 `.wslconfig`는 없습니다. 복원된 기본 커널은 allocator를 노출하지 않습니다. 이번 성공 기록은 기본 커널이 udmabuf를 지원한다는 뜻이 아닙니다.

**범위**

물리 DMA, 물리 카메라, 제품 앱, 사내 HAL, 사람 검토(`human_review: pending`)는 검증되지 않았습니다. GDB 중단점은 타이밍을 바꾸므로 타이밍이나 콜백 반환의 증거가 아닙니다.

CPU 전용 과거 프로브 기록은 [README.md](README.md)를, 원본 관찰값은 [observation.json](../validation/issue211/runs/20261031-wsl-cam-3/observation.json)을 참고합니다.
