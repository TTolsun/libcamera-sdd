# official cam WSL 가상 카메라 검증

**결과:** 소스 `293d751a814e0d4c34e85ad457ccd9d5eefd1a61`을 수정하지 않은 디버그 빌드의 공식 cam이 WSL의 `Virtual2` 카메라(400x300 NV12)에서 프레임 3개를 처리하는 것을 관측했습니다. 이 결과는 WSL 가상 카메라 범위에만 해당합니다.

## 실행 전 준비

1. 할당기를 지원하는 커널을 확인합니다. 태그는 `linux-msft-wsl-6.18.33.2`, sha256은 `cf23bf492a00a5c7517e221b0d8f742ea3cffa9351823191a5ba5c476ba15460`입니다. udmabuf은 커널에 내장되어 있으며, 일치하는 모듈은 설치하지 않습니다.
2. 공유 커널, `.wslconfig`, WSL 종료를 포함한 호스트 변경 계획을 작성합니다. 정확한 백업 경로와 복구 절차를 담고 Docker를 중지한 뒤, PR 병합·Pages 배포 승인과 별개인 호스트 승인을 받습니다.
3. 승인된 계획을 한 단계씩 수행해 커널을 준비하고 부팅합니다. `kernel_trial.py`는 자동으로 실행하지 않습니다.
4. 실행 중인 커널이 `6.18.33.2-microsoft-standard-WSL2-issue211`인지, root가 `/dev/udmabuf`을 열 수 있는지 확인합니다. 하나라도 다르면 캡처하지 않습니다.
5. WSL root 자식 컨텍스트에서 아래 명령을 실행합니다. `<new-evidence-directory>`는 새 빈 디렉터리여야 합니다. `<private-extracted-tools-prefix>`는 `usr/bin/gdb`와 `usr/share/gdb`를 포함하는 디렉터리입니다. `<compiled-dmabuf-probe>`는 `dmabuf_probe.c`를 `gcc -std=c11 -Wall -Wextra -Werror -O0 -g`로 컴파일한 결과입니다.

```
PYTHONPATH=<generator>/src python3 <generator>/examples/libcamera/runtime/run_cam.py --source <unmodified-source-at-293d751a> --build <its-debug-meson-build> --tools <private-extracted-tools-prefix> --probe <compiled-dmabuf-probe> --out <new-evidence-directory>
```

**관측:** PID 434, 449, 464 세 프로세스 각각에서 요청(request)과 sequence 0~2, status 1, 성공 buffer metadata(buffer_status 0)가 기록되었습니다. 세 기록은 PID, request, sequence로 묶어 비교합니다. TID는 같아야 하는 키가 아닙니다. 콜백 TID(437, 452, 467)와 처리 TID(434, 449, 464)가 달랐으므로 그대로 기록합니다. DMA 프로브는 `/dev/udmabuf` 열기, 4096바이트 할당, mmap, CPU 읽기/쓰기 동기화, 해제를 모두 errno 0으로 마쳤습니다.

**범위:** 복구된 기본 커널(`6.18.33.2-microsoft-standard-WSL2`)은 allocator를 노출하지 않습니다. 이번 시험 커널에서 성공했다고 기본 커널이 지원한다는 뜻은 아닙니다. udmabuf 권한은 root 전용 그대로 바꾸지 않았고, 권한 없는 실행의 errno 13은 이 시험 커널 실행에만 해당합니다. 시간 초과와 실패는 실패로 남기며, 이전 출력 디렉터리는 덮어쓰지 않습니다. GDB 중단점은 타이밍에 영향을 주므로 콜백 반환의 증거가 아닙니다. 물리 DMA, 물리 카메라, 제품 앱, 사내 HAL, 사람 검토는 검증되지 않았으며, 사람 검토는 아직 pending 상태입니다.

CPU 전용 과거 프로브는 [README.md](README.md)를, 원본 관측 기록은 [observation.json](../validation/issue211/runs/20261031-wsl-cam-3/observation.json)을 참고합니다.
