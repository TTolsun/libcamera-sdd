<!-- system -->
Independently ground publication notes in supplied public data. No tools. Return JSON; automatic review is not human approval.

<!-- user -->
Check both corrected notes. This includes COMPLETE compact record index from the completed selected calls already machine-verified, not just representative receipts. Every row binds a completed native stdout to the exact profile and request/response/prompt hashes; this asserts call provenance, not semantic passage of all historical attempts. Original full verification is retained. Previous release source plus official+mirror ls-remote establish unchanged SHA. Public PR69 readme, actual profile, passed audit metadata and byte equality establish historical context. Root run and receipt files also have exact package copies.
NOTES
{"root-README.md": "# libcamera-sdd publication: issue211\n\n## Current release\n\n- Release notes: [publication/issue211/README.md](publication/issue211/README.md)\n- Run record: [run.json](publication/issue211/run.json)\n- Generation receipts: [generation-receipts.json](publication/issue211/generation-receipts.json)\n- Korean: https://ttolsun.github.io/libcamera-sdd/official-cam-validation.html\n- English: https://ttolsun.github.io/libcamera-sdd/en/official-cam-validation.html\n\nStatus: this package was prepared before deployment. The Pages deployment and the live output-hash proof are not yet recorded. They will be added to issue211 after the merge.\n\n- Source commit: 293d751a814e0d4c34e85ad457ccd9d5eefd1a61\n- Generator issue: https://github.com/TTolsun/camera-hal-sdd-generator/issues/211\n\nScope: observed on a WSL virtual camera (Virtual2) only. Hardware DMA, physical camera, production application, and internal HAL are not validated. Human review is pending.\n\n## Historical publications\n\n- [publication/issue193](publication/issue193/)\n- [publication/issue193-comment-followup](publication/issue193-comment-followup/)\n- [publication/source-excerpts](publication/source-excerpts/)\n- [publication/reader-ux](publication/reader-ux/)\n- [publication/reader-cleanup](publication/reader-cleanup/)\n- [publication/goal-162-163](publication/goal-162-163/)\n- [cli-runners](cli-runners/)\n", "README.md": "## Result\n\n- Status: `observed-wsl-virtual-only`. Camera: Virtual2, applied configuration `(0) 400x300-NV12/SMPTE170M`.\n- Trial kernel: `6.18.33.2-microsoft-standard-WSL2-issue211`.\n- Three independent final processes (pids 434, 449, 464) each completed 3 frames (buffer sequences 0, 1, 2), made 4 udmabuf allocations, had zero observed cancelled callbacks, and exited with code 0.\n- Observed TIDs: [434, 437], [449, 452], [464, 467]. These are the observed main-processing and callback roles in each process; other process threads may exist.\n\n## Callback and processing threads\n\n- Callback entry (`CameraSession::requestComplete`) ran on callback TIDs 437, 452, and 467.\n- Frame processing (`CameraSession::processRequest`, immediately before `captureCount_++`, `camera_session.cpp:535`) ran on main TIDs 434, 449, and 464. At this measured processing point, it was not observed on the callback thread.\n- Buffer metadata was read after `FrameMetadata` at `camera_session.cpp:503`.\n\n## udmabuf lifecycle (CPU read/write, not hardware DMA)\n\n1. Open `/dev/udmabuf`.\n2. Allocate a 4096-byte dmabuf (backing_fd 4, dmabuf_fd 5).\n3. `mmap`.\n4. `sync-start` (flags 3).\n5. CPU access: 4096 bytes, checksum 522240.\n6. `sync-end` (flags 7).\n7. `munmap`, then close dmabuf, backing, and provider. All return 0.\n\n## Environment during the trial\n\n- The default kernel `6.18.33.2-microsoft-standard-WSL2` is restored, and `.wslconfig` is absent after restore.\n- Kernel tag `linux-msft-wsl-6.18.33.2` (commit `c21a03b2943d147c280bdf32530d4fe6badfd6bd`). The compiler and config diff is preserved in full: GCC 13.2 to Ubuntu GCC 15.2, binutils 2.41 to 2.46, pahole 1.25 to 1.31.\n- Matching modules are not installed. Docker was stopped during the trial. The user authorized the kernel trial.\n- `/dev/udmabuf` is root-only. Permissions are unchanged. The unprivileged run failed with errno 13.\n\n## Limits\n\n- GDB breakpoints affect timing. The run does not prove callback return or performance.\n- No callback-return instruction was observed.\n- The cancellation branch was not exercised dynamically. The observed count of 0 was not forced.\n- Timeout probe (0.5 s) timed out with exit code 1. Cleanup returned 0 for `sync-end`, `munmap`, and all closes, and the process group was absent.\n- Negative probes: absent provider errno 2, unsupported ioctl errno 25, exit code 1.\n- Not validated: hardware DMA (`not-validated`), physical camera (`not-run`), production application (`not-run`), internal HAL (`not-run`). Human review is `pending`.\n\n## Generation\n\n- Writer and translation: native CLI `claude-haiku-5-5` with `--effort high --setting-sources project,local`.\n- New-document review: a separate Codex run, `gpt-6.1-terra` with `-c 'model_reasoning_effort=\"high\"'`.\n- The historical issue193/PR69 selected-Claude contract audit keeps its actual historical identity. It is not relabeled as Terra.\n- The renderer's original Codex visual identity is used for authentication only and invokes no model.\n- PR69 latest corrected source-identical request documents are preserved.\n- The official upstream is unchanged, so this is not a trivial rebuild. A new reader task closes the missing evidence for actual WSL allocator and callback behavior.\n\n## Evidence and files\n\n- Raw runs: https://github.com/TTolsun/camera-hal-sdd-generator/tree/main/examples/libcamera/validation/issue211/runs/20261031-wsl-cam-3\n- Runbook: https://github.com/TTolsun/camera-hal-sdd-generator/blob/main/examples/libcamera/runtime/OFFICIAL_CAM.md\n- Reproduction script: https://github.com/TTolsun/camera-hal-sdd-generator/blob/main/examples/libcamera/runtime/run_cam.py\n- Source commit `293d751a814e0d4c34e85ad457ccd9d5eefd1a61` is tracked clean and unmodified.\n- Package contents: `config/`, `manuscripts/`, `facts293.json.gz`, `english.json`, `profiles/`, `reviews/`, `build-validation.json`, `consistency-review.json`, `cli-evidence.zip`, `evidence-index.json`, `previous-release/`.\n- Pending: the postmerge Pages check and live output-hash proof, to be recorded in issue211.\n"}
MEASUREMENT
{
  "source_commit": "293d751a814e0d4c34e85ad457ccd9d5eefd1a61",
  "kernel": "6.18.33.2-microsoft-standard-WSL2-issue211",
  "results": [
    {
      "completed_frames": 3,
      "cancelled_callbacks": 0,
      "observed_tids": [
        434,
        437
      ],
      "successful_buffer_sequences": [
        0,
        1,
        2
      ],
      "pid": 434,
      "allocations": 4
    },
    {
      "completed_frames": 3,
      "cancelled_callbacks": 0,
      "observed_tids": [
        449,
        452
      ],
      "successful_buffer_sequences": [
        0,
        1,
        2
      ],
      "pid": 449,
      "allocations": 4
    },
    {
      "completed_frames": 3,
      "cancelled_callbacks": 0,
      "observed_tids": [
        464,
        467
      ],
      "successful_buffer_sequences": [
        0,
        1,
        2
      ],
      "pid": 464,
      "allocations": 4
    }
  ],
  "uid": 0,
  "gid": 0,
  "binaries": {
    "/home/baboess/.cache/issue211-runtime-D6sfkcnF/build/src/apps/cam/cam": "1ceed18da065a383e2f573ba49e9caea77033abd6830a7ec051e3681dabc79d2",
    "/home/baboess/.cache/issue211-runtime-D6sfkcnF/build/src/libcamera/libcamera.so": "2423e936a6ffde0fa533c76a4738f748f77b4535c881c12a616dfeec50a940eb",
    "/home/baboess/.cache/issue211-runtime-D6sfkcnF/build/src/libcamera/base/libcamera-base.so": "441f04294e61632d080f4bb55fb38ce787bb8af173a4b6d55d7c05f0f04fd18c",
    "/home/baboess/.cache/issue211-runtime-D6sfkcnF/dmabuf-probe-2": "531e499f094cca32f03e354afe2aa5a8d48b425916cbd7be2ad7e02306c58512"
  },
  "human_review": "pending",
  "physical_dma": "not-validated",
  "physical_camera": "not-run",
  "production_application": "not-run",
  "internal_hal": "not-run",
  "status": "observed-wsl-virtual-only",
  "schema": 1,
  "camera": "Virtual2",
  "applied_configuration": "(0) 400x300-NV12/SMPTE170M",
  "official_source_tracked_clean": true,
  "kernel_tag": "linux-msft-wsl-6.18.33.2",
  "kernel_tag_commit": "c21a03b2943d147c280bdf32530d4fe6badfd6bd",
  "kernel_sha256": "cf23bf492a00a5c7517e221b0d8f742ea3cffa9351823191a5ba5c476ba15460",
  "compiler_config_diff": "GCC 13.2 to Ubuntu GCC 15.2 capability changes, binutils 2.41 to 2.46, pahole 1.25 to 1.31; full diff preserved",
  "matching_modules_installed": false,
  "docker_during_trial": "stopped",
  "allocator": "udmabuf built-in, /dev/udmabuf root-only; permissions unchanged",
  "unprivileged_run": {
    "status": "failed",
    "errno": 13
  },
  "dma_probe_events": [
    {
      "event": "provider-open",
      "provider": "/dev/udmabuf",
      "result": 3,
      "errno": 0
    },
    {
      "event": "allocate",
      "result": 5,
      "errno": 0,
      "backing_fd": 4,
      "dmabuf_fd": 5,
      "size": 4096
    },
    {
      "event": "mmap",
      "result": 0,
      "errno": 0
    },
    {
      "event": "sync-start",
      "result": 0,
      "errno": 0,
      "flags": 3,
      "retry": false
    },
    {
      "event": "cpu-access",
      "result": 0,
      "errno": 0,
      "bytes": 4096,
      "checksum": 522240
    },
    {
      "event": "sync-end",
      "result": 0,
      "errno": 0,
      "flags": 7,
      "retry": false
    },
    {
      "event": "munmap",
      "result": 0,
      "errno": 0
    },
    {
      "event": "close-dmabuf",
      "result": 0,
      "errno": 0
    },
    {
      "event": "close-backing",
      "result": 0,
      "errno": 0
    },
    {
      "event": "close-provider",
      "result": 0,
      "errno": 0
    }
  ],
  "run_threads": [
    {
      "pid": 434,
      "callbacks": [
        437
      ],
      "processed": [
        434
      ]
    },
    {
      "pid": 449,
      "callbacks": [
        452
      ],
      "processed": [
        449
      ]
    },
    {
      "pid": 464,
      "callbacks": [
        467
      ],
      "processed": [
        464
      ]
    }
  ],
  "inferior_exit_codes": [
    0,
    0,
    0
  ],
  "processed_sequences": [
    [
      0,
      1,
      2
    ],
    [
      0,
      1,
      2
    ],
    [
      0,
      1,
      2
    ]
  ],
  "timeout_probe": {
    "seconds": 0.5,
    "timed_out": true,
    "exit_code": 1,
    "sync_end_return_code": 0,
    "munmap_return_code": 0,
    "close_return_codes": [
      0,
      0,
      0
    ],
    "process_group_absent": true
  },
  "negative_probes": {
    "absent_provider_errno": 2,
    "unsupported_ioctl_errno": 25,
    "exit_codes": [
      1,
      1
    ]
  },
  "supplemental_official_cam_strace": {
    "exit_code": 0,
    "callback_observation": false
  },
  "restored_kernel": "6.18.33.2-microsoft-standard-WSL2",
  "restored_wslconfig_exists": false,
  "old_cpu_probe": {
    "callbacks": 72,
    "dma": "unvalidated-provider-and-sync-errors-retained",
    "history_unchanged": true
  },
  "observation_limits": [
    "GDB breakpoints affect timing",
    "No callback-return instruction observation",
    "Cancellation branch not dynamically exercised; observed count 0 is not forced"
  ],
  "reproduction_code": "https://github.com/TTolsun/camera-hal-sdd-generator/blob/main/examples/libcamera/runtime/run_cam.py",
  "raw_evidence": "https://github.com/TTolsun/camera-hal-sdd-generator/tree/main/examples/libcamera/validation/issue211/runs/20261031-wsl-cam-3",
  "buffer_metadata": [
    [
      {
        "buffer_sequence": 0,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 434,
        "point": "buffer-metadata",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 434
      },
      {
        "buffer_sequence": 1,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 434,
        "point": "buffer-metadata",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 434
      },
      {
        "buffer_sequence": 2,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 434,
        "point": "buffer-metadata",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 434
      }
    ],
    [
      {
        "buffer_sequence": 0,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 449,
        "point": "buffer-metadata",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 449
      },
      {
        "buffer_sequence": 1,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 449,
        "point": "buffer-metadata",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 449
      },
      {
        "buffer_sequence": 2,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 449,
        "point": "buffer-metadata",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 449
      }
    ],
    [
      {
        "buffer_sequence": 0,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 464,
        "point": "buffer-metadata",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 464
      },
      {
        "buffer_sequence": 1,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 464,
        "point": "buffer-metadata",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 464
      },
      {
        "buffer_sequence": 2,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 464,
        "point": "buffer-metadata",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 464
      }
    ]
  ],
  "pretrial_kernel": "6.18.33.2-microsoft-standard-WSL2",
  "pretrial_udmabuf": false,
  "pretrial_dmabuf_heaps": false,
  "pretrial_provider_devices_present": false,
  "source_unmodified": true,
  "kernel_trial_authorized_by_user": true,
  "request_events": [
    [
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 434,
        "point": "callback-entry",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 437
      },
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 434,
        "point": "callback-entry",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 437
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 434,
        "point": "frame-processed",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 434
      },
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 434,
        "point": "callback-entry",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 437
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 434,
        "point": "frame-processed",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 434
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 434,
        "point": "frame-processed",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 434
      }
    ],
    [
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 449,
        "point": "callback-entry",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 452
      },
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 449,
        "point": "callback-entry",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 452
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 449,
        "point": "frame-processed",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 449
      },
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 449,
        "point": "callback-entry",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 452
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 449,
        "point": "frame-processed",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 449
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 449,
        "point": "frame-processed",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 449
      }
    ],
    [
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 464,
        "point": "callback-entry",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 467
      },
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 464,
        "point": "callback-entry",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 467
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 464,
        "point": "frame-processed",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 464
      },
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 464,
        "point": "callback-entry",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 467
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 464,
        "point": "frame-processed",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 464
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 464,
        "point": "frame-processed",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 464
      }
    ]
  ],
  "main_tid": [
    434,
    449,
    464
  ],
  "observation_points": {
    "callback-entry": "CameraSession::requestComplete entry",
    "frame-processed": "CameraSession::processRequest immediately before captureCount_++",
    "buffer-metadata": "CameraSession::processRequest after reading FrameMetadata"
  },
  "timeout_cleanup_events": [
    {
      "event": "provider-open",
      "provider": "/dev/udmabuf",
      "result": 3,
      "errno": 0
    },
    {
      "event": "allocate",
      "result": 5,
      "errno": 0,
      "backing_fd": 4,
      "dmabuf_fd": 5,
      "size": 4096
    },
    {
      "event": "mmap",
      "result": 0,
      "errno": 0
    },
    {
      "event": "sync-start",
      "result": 0,
      "errno": 0,
      "flags": 3,
      "retry": false
    },
    {
      "event": "sync-end",
      "result": 0,
      "errno": 0,
      "flags": 7,
      "retry": false
    },
    {
      "event": "munmap",
      "result": 0,
      "errno": 0
    },
    {
      "event": "close-dmabuf",
      "result": 0,
      "errno": 0
    },
    {
      "event": "close-backing",
      "result": 0,
      "errno": 0
    },
    {
      "event": "close-provider",
      "result": 0,
      "errno": 0
    }
  ]
}

MACHINE PROOFS AND HISTORICAL PUBLIC RECORDS
{"schema":1,"retained_pr69_pages":{"camera-requests.md":{"published_sha256":"8aafe33eef028effd72981c6a314b3262ea33b4fba9a9a6f7db201ad77afbac0","workspace_sha256":"8aafe33eef028effd72981c6a314b3262ea33b4fba9a9a6f7db201ad77afbac0"},"request-lifecycle.md":{"published_sha256":"ae9cf6081cbd2f183095c540ee97eccf7bd52407e8d1ba112b443f717b00fefa","workspace_sha256":"ae9cf6081cbd2f183095c540ee97eccf7bd52407e8d1ba112b443f717b00fefa"}},"public_base":"85b4cd8d6fd9e1778eac3f20cbd0df0e6b8b7cf3","upstream":{"official":"293d751a814e0d4c34e85ad457ccd9d5eefd1a61\trefs/heads/master","mirror":"293d751a814e0d4c34e85ad457ccd9d5eefd1a61\trefs/heads/upstream/master"},"renderer":{"model_calls":false,"profile":"publication.yaml","purpose":"Authenticate original visual fingerprints; export_site/prepare_catalog perform model-free receipt verification. All new inference uses separate generation/review configuration."},"human_review":"pending","complete_verified_record_index":[{"receipt_sha256":"95fdbbc684da0f12cb67d50b3f1fcbe0c0ad2dd830f9fe5adce37f823f19ae99","tag":"targeted-translation-correction","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"65213361cb62d256da23e4b2a9f054560dd0f5cd1b48c4840305ad5e246b3bd2"},{"receipt_sha256":"1f76c730bf989d92087469cd029ebfc0b722223af3393bbf86d73d7b905cf796","tag":"actual-run-review","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"7e0008619e979cd4dd9e7c7ced376115e32ed3daf568bdd8f17a21ff3b79bfc4"},{"receipt_sha256":"a5bd39fc92375c0f71ca03c6e48572b21a47a8c4b8ad7f7d92368ba33462d168","tag":"actual-run-review","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"83bcc8aeb1751785b8b3b88bf475af705fa63810cb47fe49d453ff8b085213e4"},{"receipt_sha256":"d40eb698881231eb732ba2692ffa5769e58bdd3c3d4c812ffe22c4819aed27e7","tag":"actual-run-review","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"dc7322720a7c96e103eaad127b5458d7fedd7f6e9869d8999ae44776379c10fc"},{"receipt_sha256":"07e13abd36b93cc73ed062df33828a673a1a6dc3b898046ddd0cb074310b2966","tag":"actual-run-review","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"10e3d32773874daa17c5bcf06039815493d8915b34f049966fa8a3d7da38c232"},{"receipt_sha256":"d2f468042f4b784084ad3ff9e86beb5a071b1d48f7173f81b4f93ee390e37db3","tag":"actual-run-review","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"d81f5173ddfddf220fb464c05db9e9bfa60e692b51a8f1afef292d2c8af03062"},{"receipt_sha256":"352b55576f30ed94ffe6b3ba5e4a67f2df0af0b580da7a11cd90fbc33f92db49","tag":"actual-run-review","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"a0df6f29822563c7c4a9d657c2245e0b2086e904fdff43957e95aa36af701b28"},{"receipt_sha256":"03d0e55e4df3ba8f74355c300e7e33cd844a26b63a60ea083d41167fc8c7933c","tag":"document-grounding","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"22d07a57b81e9db3c009953d93caa7820604f65efcd45c8cea4b7026c484cd89"},{"receipt_sha256":"c017c0126f198bcb9dbe3fcb305c6a2645767462b5cc03117653649f7ae2ae49","tag":"document-grounding","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"7f2199ed6ef1209a9af52c315f3bf12c502a181cffcdf08723f3daa4335e7df5"},{"receipt_sha256":"18eccc0dcc29a91d793a54e7532bbd69d631c3acdbe83950580b7370a0fc4fd3","tag":"document-grounding","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"826a8a95b165623b39fc14ba16b6794d3b1924b272a3f142efee318dac79fe30"},{"receipt_sha256":"83186aa386ff8d398dc1fddfb7dc5a1cb32fac49a347a49f82da90e50ad0f30b","tag":"document-grounding","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"e1cf3c1b4b93a2b8263a561f575292d1b5fcdbec34fc93403cd22a39b3f2f717"},{"receipt_sha256":"0a84ad723a56ae3e0b3b0a861b0e85ff8570cddea8b2aecc60b0fc79b4a51bd2","tag":"document-grounding","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"1a2b76af53a57f1bd585d02d9f46879d6b11bfeb4dfd2e09a68ded8d6b29da88"},{"receipt_sha256":"fda15cf0a3b9aaa9365f4390fbe2f4c40d681b7529d73fc88eb4de5593512c12","tag":"document-grounding","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"8bce277e34aada5de71f3467e01dee8ac8d11b220025efe6a30f17b5ae7841ea"},{"receipt_sha256":"7644b570900064c0137711a16c08240cc91b32e7c39b70f4b046116d2e3f83c8","tag":"document-grounding","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"fbce1b7dbf84605bfb10f102386603fee20d855e0ba1527e394a5a3dc8f63136"},{"receipt_sha256":"e8602fa05d4b6a6193314101d07586671c594130fd68ae194baee48c00a97dd9","tag":"document-grounding","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"14bf177699397f0a506fd2c52c466c73dc19bb9e0b8a9a8ba74945b1589e5981"},{"receipt_sha256":"46f11076df5ca5aca2cf95d1627bab49d8b982eed55dde66dfb018e5fd0b6295","tag":"targeted-runbook-edits","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"095dd12a49b5ac9a71d4f47ea7bc65c6f2b8fcab892111c0c7ee6d7b4f5e9a13"},{"receipt_sha256":"e1813e1cca47e717da7b75babaea202049d18bddb18a5618bb3f865272d39bde","tag":"runbook-revision","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"30ccb4c5404c0cb606c4125da66a343fd955ec80dcec4ce936cf3a277ab50bb0"},{"receipt_sha256":"fe13050b00b79522784e6fa54edf398e645ebb1ecaccd2393c274be2ad1094eb","tag":"runbook-revision","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"4ac0cee918cd933eb3e7b373319a0693799d39cfd4c1d12a46ff7a23b53617c0"},{"receipt_sha256":"2e43a23d4a052d1ec712f17b8c9ae5c2b10640305b01c48f28d48f4adf526582","tag":"official-cam-runbook","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"d80b1530da3f40845ac973df9159087c7321c88527de07ef3c0609876e281965"},{"receipt_sha256":"0b35f0c6cdc00d4b0bfd7509ece963ffe39f12b75682d8971f24c644fcb803ff","tag":"runbook-revision","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"5ec54567848e2a56e5b2994b5ac29073eebfd388c427573133a7f344a53e3e3e"},{"receipt_sha256":"0afb75c7c92b2c057fdd2f192835dbf26556b3ec419964f3ae61736b9d194810","tag":"official-cam-runbook","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"6df42beaa1f3b8a3fdfc5f2f43a83ca62f43adcd8f6a6135620efe4a878c8b2d"},{"receipt_sha256":"68a9d130608b6f6a6b7bbb047f53ff2ed36be78e0de3783694492a6536689458","tag":"runbook-revision","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"7c5501616ccac9e80bcb89084de4afe89e066fb8ce065d5ae179d11804ab8df1"},{"receipt_sha256":"056d28bb970e663a28da7de9af88c05b8877e1d92c4bd6360205ecd46ac63648","tag":"official-cam-runbook","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"513614c0313dea686364d5eb7696b0c0eb5b4c508304c7b94f123fca4d99c392"},{"receipt_sha256":"96a1963909ea459a053586f9674b63c42e6a57d61ecf30102ec6d4e5043f76eb","tag":"targeted-runbook-edits","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"a091952fbb1092f2837306d3e9f0230ff4955cf443e67375273ad4437dfa5520"},{"receipt_sha256":"8a1404a75e4bc00cac95c03df5200ce1422a2f129e4f53a6af85a063eee457c3","tag":"targeted-runbook-edits","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"c71aa7675faea01b81eeb9f00b686aee99a5cc1172ebfad3d3aa06aaf5de2e66"},{"receipt_sha256":"548d7c4bed61c0e060bbb928e2089e3400b340cb67c83b80e87e862433a434e2","tag":"targeted-runbook-edits","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"8ad15c95be4b33f11a47c937102bf8d21ea6e6e893cb786970ee58788a05bf63"},{"receipt_sha256":"f0cc7a266342fff5a3eb032826fb78c2416cd84c5e5815c19348542810af4a78","tag":"official-cam-runbook","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"868ac209871eb665b1dd44dd3e278fbae2955586b2cc25cdb2111a2ddf95419f"},{"receipt_sha256":"ee7042b967b276f268d809044adb6cbd7498eab49c5e9a206223c669bd13d510","tag":"release-notes-review","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"23afa2a34056781be4ed9bd8a164eb723e5bf4f3fdbdc8f67cf449d10cb3e078"},{"receipt_sha256":"c3596c36c1cfc32335111430f697a612582d6600e1cb8a66069693f7f97fb42d","tag":"publication-notes","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"e6c52126dabe1ab8f2a81d233cde535c0881890fc9b1ee7d7f5821e5fdd3e958"},{"receipt_sha256":"b43552e164c84e72a9400cc6f6f4afc3cfcf245669ebf5f96353189f6316dde3","tag":"document-grounding","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"cacd9205fb1fde3880a4036de484d0d81798fcc8b1e3cce449e84aa4573e9fe7"},{"receipt_sha256":"cbd104b98156fb831de11f790543795a4477cbf74655dbceedc501ec231772df","tag":"document-grounding","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"b34b0ab7859d7a013aebe60b1b39bd81773c03123dcaa61045857248ce55318e"},{"receipt_sha256":"5020913d990de51e0ce68c751aed3dc16a2d8a4b97441d1e8e8fb75bc91a11ed","tag":"document-grounding","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"c627fb69a8dacceee80d3a02cfa424de86a2a46b1e84842bdc5d9c8346640674"},{"receipt_sha256":"28bf9b12e6e4b7fd5b21fe876dfa84ecd0fa95a9ee05c268c5bc2657248fe50c","tag":"glossary-grounding","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"1a25f5da301f402a133da49ec44c91869779b68db275f0580a2131fd7ed3a086"},{"receipt_sha256":"a18376c9a8253dcb9fab4161f5429fd6230c9a4f32804a036533aed6b09d77cb","tag":"glossary-grounding","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"5b3037de9e9c069e3846ebbb155bab325fa330dc5eade12c333720b92f710c96"},{"receipt_sha256":"7a3b83015a7765b8b614bd778fe8c87c73a2c2ccad73a79987c704b0afbc620c","tag":"glossary-grounding","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"4b810270eac9526abbdf1421b203a41f9dc5438c203e49324cffeb8113cd0a98"},{"receipt_sha256":"796db9572fe83263a490d7c6571d36df4886bf2277ec0a47a1d567c810eb409e","tag":"glossary-grounding","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"752f47b1a3ecd7e4fb6ccceaa11578edecacb8e6cbfb1e7e43437a544adab0ca"},{"receipt_sha256":"e7731b13bd3352dbd8d213d0ba3158e440e8bb8b49aa0f6a98a20d0d1f6495ae","tag":"definition-revision","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"12a30f9ea9e188e786bcb5b2387e0735e563824b7ad8408c0b815c1294a81b5b"},{"receipt_sha256":"9f50329c68d1e595520f8666edf24ea3fcaaab24e9a7dcb3cba031dc097f72d3","tag":"nv12-definition-revision","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"7ac1d6f53228de1e98fc0d89e9bb5f9c5dfb171e965fa863caf6cbb31488492a"},{"receipt_sha256":"fb16df6d3df7290519ec2de4f9812100c1ea8c945c9a39d6b6d43c32a0cf9c3b","tag":"reader-glossary","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"bed099c68d2d8b116cac01da046314715190ac76bcdcf02e3b2621a23b5ea294"},{"receipt_sha256":"4c6911a9777045b90de51e85b4be1ef7c3390fe7ef8e10c3af3e4989018c4617","tag":"reader-glossary","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"235900570555d415281879190da16c79c0c50b98744cefd380e40720df5a55c5"},{"receipt_sha256":"8cf041a03f5603548f69069fcc7effdf5879fcb4efa98682585b067cb0fbccf9","tag":"glossary-grounding","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"2f50ca282d81b9b6726f799d300cfd83e718bf5794981e77bc3381befaf2eb01"},{"receipt_sha256":"128928792d68560b3a7e6060e25dc72ec308e2128af908d755045e2fa0f970e9","tag":"document-grounding","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"7e56596147966d241eddb328bd18e1d3fa197916b68016de755e9e1dec0734ec"},{"receipt_sha256":"016b11419c2728ab3988d27ceeaf95050cf5da2d5f3fde538171329f8d8fdb4b","tag":"availability","runner":"codex","model":"gpt-6.1-terra","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"32d42b15061c4b16f28a231e3bf0c1b07e654bbac7565662eb9f6ccc27f25b64"},{"receipt_sha256":"1dd5c594d652cba0547c0cd746d7fcbb7ef98b59bcf92b7ceeb5145b25eab5d0","tag":"availability","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"22f1ffd128e2c62f95616119dd366b3ccf7918c69676019194401e648d2c474a"},{"receipt_sha256":"9790a733888cf921b7746b518e68a7bc1453bcc11f7293790921de58e81a6771","tag":"official-cam-validation_outcome_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"b2ddb0018831ee57f42a4dd5d8408c4c3f3a02f1caea0299024e73ef0e028971"},{"receipt_sha256":"93ca1671b1aa63d043c314fd5b194c7d7d8a789f7fb54f1cd9444f7a03374fd2","tag":"official-cam-validation_completion_dispatch_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"39ce1dd9608a5a0ea233518076e069b92325790448d4414c3fe6cf9ebeaaa3fd"},{"receipt_sha256":"3c7ebcc21aa61b6ed594372fc400daaa0f6400387e220b097bd19bb414cf0b0a","tag":"official-cam-validation_completion_observed_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"df6806485f63f8ee9792ea9bcef67749d5eda8e15c66ec0f1d7ddd58e6c606ef"},{"receipt_sha256":"c8f2b8bbe48c7ea041553e8c3bdd3f7af6beb6096ada9658c437fbf713c3462c","tag":"official-cam-validation_boundary_prerequisites_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"ff52c4b2b51798474c35b7e359b9574e8f84e46f869d1cb8d3cfab604ee9cf74"},{"receipt_sha256":"38c96fb2e6cb61ea71d6c2fd72536295009b8934f6cb30872fcaf5e93f23185b","tag":"official-cam-validation_boundary_prerequisites_1","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"84ad58e41ddd4a5ffb1a6e78680b89e057287e2c5ad650446e5705e8febe9237"},{"receipt_sha256":"1d0df31f23be2d2e22974d14537bfe3068623ac37afaf796a3efb35285eb8921","tag":"official-cam-validation_boundary_failures_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"1d3ea2e24dbb7a3f2e876c167f8fc3c958dc895f0fd911323f9694df008e161a"},{"receipt_sha256":"79ea4bedb2f551cf91c3530c6dd81c87d956ff84334463cebbed25fa37abf17a","tag":"official-cam-validation_boundary_restored-scope_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"593a63f0234cc3ff8ecb3b8206d23aef474ed5d4d289dde3a255f726ae117ee6"},{"receipt_sha256":"54dc70d1aaafe5b1974e0268b79099a89c3de13dca6fce06825865a286f74785","tag":"official-cam-validation_boundary_failures_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"a629372347b28e32c3078de4197b6228a9534ff44e6d962c76f7215373bb2e10"},{"receipt_sha256":"c904ab9ad8d4dfaade55fdbf146083fcf04b2f6c67b24b7ce62398837b665ead","tag":"official-cam-validation_boundary_restored-scope_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"0ce1493788497d75ac6bc6d0c97a9674ba3d883bcbed52eb85a86b99b23dbdab"},{"receipt_sha256":"af3f1d07626d80b6ab376fa565eb96b67cc92b013d9f93275053ef6631ac1a0a","tag":"official-cam-validation_outcome_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"453b056585ca8f733ff311fce312e8342cd1e0e89b252215c99d581a509c8145"},{"receipt_sha256":"db34a4a49245a76457a6c1db1a27350782986a314a366ba9cba925079909d4c7","tag":"official-cam-validation_outcome_1","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"4846271c468aabb2edceb64dc86deb6e42cf218ab9d0f1e61e326e33a9f19b39"},{"receipt_sha256":"5753c1e4a36f34d181961c2ebbd87def1d850238b67ef72ae2471e4257e23e61","tag":"official-cam-validation_completion_dispatch_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"d7a8322ca718448b07f7b1c3b2e311ce9eccb1b5e6449573b4d9ddcd18dd14f6"},{"receipt_sha256":"03676be6d2c034579865a04604063921dacb3274a9d1299f30d01b5c05e141b1","tag":"official-cam-validation_completion_observed_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"91cca18838d457813e6c76ac3282fca90bcf41be00674b75244207adc7893aea"},{"receipt_sha256":"3516ec6d9923f865b1ffc4cecce9832688c9fda58a27dc6769c96dd0f2739564","tag":"official-cam-validation_boundary_prerequisites_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"daf65f1f6fd5ebd8bcbbd19c0c0396fa6845b3093c8dc4bf68a9187a8136aa01"},{"receipt_sha256":"d2c295f008cceaf15580eaec91bbc4cf198b9cc3dc77cc061bcd26c7f09b406f","tag":"official-cam-validation_boundary_prerequisites_1","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"725c65020af3e619083d7bb9cbef6d6db5087818d8ef03294b5ec6c6e897440b"},{"receipt_sha256":"8e56aed65454f1d50b3923af1d5ede92bbda7193ae91b315b24d7d141da43486","tag":"official-cam-validation_boundary_failures_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"9c23bc74e86d6e16029d31aefe3375ee5662fcedd3ca6ab2fcfbcdb40c69aa23"},{"receipt_sha256":"c2909721a303ef1d838ad09df8275383118f67bac7334c615630b4346b7d945f","tag":"official-cam-validation_boundary_failures_1","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"c1f2e20ee01a708181c6b807dff1ef0558a8b35be952303d5ee0d5b67fd4c325"},{"receipt_sha256":"97b3f791f60e5c154281f9dcc0720a01480d34aa43664fd4b213ebf0d6cb173c","tag":"official-cam-validation_boundary_failures_2","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"171aa9d939873356f643bfffc0fcc869821fdf63725da9565bb931f0f5ef4ec2"},{"receipt_sha256":"cf5fd0ee4a56d62907aff450ca9e847743279fc7cff442795b5f42b0e844f148","tag":"official-cam-validation_boundary_failures_3","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"a75ccbde9fd9b50999894786e5266ee670f44a30a7688c90fc5b1eb23594c692"},{"receipt_sha256":"f02dd9d110176604677d26c839bfbeb7792784a3c5c860ad5793a233a4663e1f","tag":"official-cam-validation_outcome_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"5dc2fbbcc17ca6fb764410d8f1dec05f18b202f99d1982409458a48cfa68aa5d"},{"receipt_sha256":"b71fc42c08d442fd7dfe7d788143f4719911e354923128595bb9851a02d6af13","tag":"official-cam-validation_completion_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"e5f17af8751b109e9cd143450cfafe3b8281bada32bba93e8af4f3523a82edf9"},{"receipt_sha256":"d56cae5694ea3c3ca251ee1376bfa336cc5e33ec83a1ba0d8f8179148775f3ad","tag":"official-cam-validation_completion_1","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"e5a47907eaa571aebecb097a85160e79ac5ab14053f2a889ab7f5fa5e77997f7"},{"receipt_sha256":"5607b73689204ad024916732aadd131cb5058e9ae874e184c55afe2e1e972646","tag":"official-cam-validation_completion_2","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"c2f32ca9efc4dd9100f9414a78cacf6b079ad149aea2740adf04a58f2c73c455"},{"receipt_sha256":"47d197450cdf67663475738dc5c2eec5774ab2e575ac2a10ddfe670d32b7473c","tag":"official-cam-validation_completion_3","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"bf77b2270610e45a04295b09a65ed7437f80120a50c86f0c3e61d1769ff9bba9"},{"receipt_sha256":"5a81d8d5884aaf566fadac6b68aa1e37b6e149482d035364bbf8bc43ac42baec","tag":"official-cam-validation_outcome_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"e9da4356dd640d7ad56437679fa7395116ea12355f2f1d7c961baf7aca728ad0"},{"receipt_sha256":"30c0a5b75f87e54cb7e406db981698f3b011453fefb940aad42192dea2328024","tag":"official-cam-validation_completion_dispatch_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"c772e163ddfc472004ffea8ae311b2fa58b27b6b329457074aed16bf74e939f7"},{"receipt_sha256":"c6cfcf8753afa0b11c77ca77c18cc234fbe561b7840f3df95abe48d25a7612f3","tag":"official-cam-validation_completion_observed_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"721dfdb0f0bb5eb2546bc81ce65c55a1f1179aab73ebf58b83ac559ade82dcde"},{"receipt_sha256":"0f8ec979189530ed18d7a48eb3317804b9f5472ca3ed77b108c4dca7d5a600b6","tag":"official-cam-validation_boundary_prerequisites_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"195b5aa71fb6689256c5580595750b9d3a9843b51f62106ab0b59e3ef18c0a56"},{"receipt_sha256":"bc99dbe51f2ca2a2d0ef691fff2aa05def73666584721374b2dc2a407613e5a8","tag":"official-cam-validation_boundary_prerequisites_1","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"2602077b37ea84661ee86ce9e953fec125b9d26b07de2ebc3531b0787882203f"},{"receipt_sha256":"b865d3a744a88f0127bb72ae30d697558af4e18ce052c6178c35c4d31bc71ba9","tag":"official-cam-validation_boundary_prerequisites_2","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"1c4f2e444d32879d2fa2400577438f92aaadf377835cae6bb0a627ae35fa1c09"},{"receipt_sha256":"fab1a1a6235f9a283ea2a22826e24b44820b38ec64df4885fdd3ede5c3fbb2f4","tag":"official-cam-validation_boundary_prerequisites_3","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"dafc6b521573d6d6fbf21e0f64aac06844467a0228f3fa9a3006bad6c25884ca"},{"receipt_sha256":"c08c1767ea118d64e63872487f6387ca4f9ae846aa477de53e47c3c853cc9746","tag":"official-cam-validation_outcome_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"5569d19f1ecc1858c4139fd6abd8aeae3ad61bc9f78d347f4eb101cb2af5d457"},{"receipt_sha256":"a5003bfa73c0a479539e41c03303975076335ff71a3c7634edc5304d4ebe7a3a","tag":"official-cam-validation_outcome_1","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"f53b983e77d87e9b0ec7ae720ca6541b829d71b100e897c62e8fd18d8fcd63fe"},{"receipt_sha256":"703282f16c2ecf3bbb2e963888c1781f2eb000bdb98b6cdab3838965fa138e0f","tag":"official-cam-validation_completion_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"a5c0c123f471f23f7670a67a787f0ff23ffe6e973c1318e3f0ee50ade5065a03"},{"receipt_sha256":"e4b9740e67dd1b491a722affd9698dbc71e227a6288bff6ec39d0a58bab95b2b","tag":"official-cam-validation_boundary_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"be2dbd867201acde131f2fac2e6c7ebde73e3cafa952e3842fafa540e0ed2c7e"},{"receipt_sha256":"1fdda49fe5e2e9ea3f16ad1381b5a6a92e2e93beeaa61c49e8dd57c101eb2300","tag":"official-cam-validation_boundary_1","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"7ba9e2c18e9612103cc30a6f8e35de91d3e7640a794689a6aa47f4b5365b5d9d"},{"receipt_sha256":"fe16872cb1a0433752eee572cf1a6e88469649bb7fcf0c4adb251c93977529c3","tag":"official-cam-validation_boundary_2","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"bd85dcbaa2b9bb00f6258f6a3001c206ab4e76b32f6b397b8deaed59a022b6fe"},{"receipt_sha256":"7b13b6c27f986377363f15559fb14e8a8f7b5cb68b62dce02523a0cdb77cbeda","tag":"official-cam-validation_boundary_3","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"f6e4445bfcb200a3a50a760559762b86b921bf3fbcab4ff2c789f8bfa2bdaf87"},{"receipt_sha256":"51ed061cbed05024fe73139cae02af6aa12fa681ad4c21c1e8044b9f44a6c536","tag":"translation_batch_0_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"dd25c7eccc755ccc27cae32d75d4fb89519706921ecaac02c3fea246351bdd36"},{"receipt_sha256":"a45773f6f68cdf32b2cccd012fafa18b66a1330cd8033d21663a7b1347051d09","tag":"translation_batch_0_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"8e65742fd116550094de5979c7333c87114ff94aa2745b33546cef44bf2c44d9"},{"receipt_sha256":"61ff06d4b93600e4b7dc538ee04de7db99b8ee29f4182d6c6d78c244a9e9a57a","tag":"translation_batch_0_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"4e4da45e8756b3b8bf37461008d7860f2305722bceac1f7c93f19dc392ebf73c"},{"receipt_sha256":"5ccc7bcf80bfd1558e0bbaf8afe6e0aac87c00d61b94bb54209d6ec0d6e47eb8","tag":"translation_batch_12_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"5668278e595a6513876f34f9ac323ce493a1b618a481e5090417410baaf2b656"},{"receipt_sha256":"a5c9fc51dae14cef5315b630e5b56249126eaeeb877a1f306a3500473e50fc6c","tag":"translation_batch_24_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"f4a2fe0fbbc770368e3776c6e191d1378596ada2db45dba8f892d75e7ca1beda"},{"receipt_sha256":"ba681e542a960d36eb857fd6811a2a8f03aed99c8975af2f9459d4d97f97ba8e","tag":"translation_batch_36_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"1d54de908df4d920156651324f39f1bc0ebae03da6acc4f60872a23660bc8cb4"},{"receipt_sha256":"60e2c191e78e316249deca62d0440f32d420789c9f2370c3420ab0122d472add","tag":"translation_batch_44_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"1d8a26c56b98ccd4ee2b41658b91a396f02d78a4b23a098339cceec59bd2f781"},{"receipt_sha256":"d6cbbb63afaee370e72f9280bb82c82bbbb60758a75dc3cac1f76d8b5b6c9d63","tag":"translation_batch_52_0","runner":"claude","model":"claude-haiku-5-5","selected_profile_arguments_verified":true,"completed_native_stdout_sha256":"bbd42af749efd5cbe82effbb3c404dfc36191d00c50b91aa0fb697e23d4f24f9"}],"selected_profiles":{"claude":{"kind":"cli","runner":"claude","model":"claude-haiku-5-5","args":["--effort","high","--setting-sources","project,local"],"max_input_chars":64000,"timeout_sec":600,"full_style_guides":true},"codex":{"kind":"cli","runner":"codex","model":"gpt-6.1-terra","args":["-c","model_reasoning_effort=\"high\""],"max_input_chars":64000,"timeout_sec":600,"full_style_guides":true}},"previous_release_source":"293d751a814e0d4c34e85ad457ccd9d5eefd1a61","pr69_published_readme":"# Claude comment follow-up for issue193\n\nPR68 retained an ordinary request-lifecycle profile without the three summaries requested in issue193 comment6533480897. Actual Claude generated three summaries and narrowed submission. The separate cross-document review then rejected an existing camera-requests statement equating return0 with successful capture queueing. Generator PR212 binds that one question to the queued invokeMethod implementation and rejects the observed success wording; selected Claude regenerated that one unit. Global defaults remain unchanged.\n\nAll five changed answer units were generated by actual Claude Code CLI claude-haiku-5-5 with --effort high. New translations use a separate profile. Separate fresh selected-Claude source entailment, required-question coverage and rendered bilingual review passed. Normal cross-document audit authenticates exact native receipts. Current full source review remains automatic, bounded to changed units; earlier broad editorial findings for ordinary documents remain open. No human approval, internal HAL or physical-device validation is claimed.\n\nOfficial public source293 is unchanged; the generator is pinned to the actual reviewed PR212 merge recorded in generator-merge.json. The new queued-connection excerpts match immutable Git source. All non-evidence facts, six scenario manuscripts, their fourteen Korean/English HTML pages including index, existing calls and full trace records are byte-identical to PR68. Historical publication and runtime records remain unchanged. The preceding four-unit source and bilingual passes, failed79-batch audit with its two contradictions, profiles and native records remain unchanged under previous-comment-stage/ in the ZIP. Current one-unit source and bilingual passes plus the final successful normal audit are separate reports. New profiles, raw requests/responses/native stdout, exact source snapshots and reproducible scripts are in cli-evidence.zip; every file has a SHA-256 index. Copied historical cache/native files are counted separately from new actual calls. The original static renderer agent identity is retained only for existing visual fingerprints; it executes no generation or review CLI. All new inference uses the three explicit selected-Claude profiles.\n\nTwo normal exports have identical manifests; local links, document health and route-table removal pass. Actual post-merge Pages and live HTTPS proofs will be recorded in generator issue193. Previous root run, README and receipt index are preserved here. This follow-up does not erase or promote previous negative assessments.\n","pr69_actual_review_profile":{"kind":"cli","runner":"claude","model":"claude-haiku-5-5","args":["--effort","high"],"max_input_chars":160000,"timeout_sec":600,"full_style_guides":true},"pr69_audit_metadata":{"schema":1,"source_commit":"293d751a814e0d4c34e85ad457ccd9d5eefd1a61","fresh_batches":0,"reused_batches":79,"human_review":"pending","assessment":"automatic model review; not human approval","comparison_scope":"Every target is compared with supplied sources and all primary claims. Secondary pairs are compared when in the same batch; this is not an exhaustive all-pairs proof.","status":"passed"},"pr69_source_review":{"schema":1,"status":"passed","source_commit":"293d751a814e0d4c34e85ad457ccd9d5eefd1a61","manuscript_sha256":"8aafe33eef028effd72981c6a314b3262ea33b4fba9a9a6f7db201ad77afbac0","run":"independent-rounds\\159ea6cab1b54eb9a7a2445f9ed89397","scope":"Fresh independent source entailment and required-question completeness of one changed unit only. Existing broad ordinary-document editorial findings are outside this bounded change and remain open.","rows":[{"topic":"request","part":"completion-signal","status":"passed","receipt":"independent-rounds\\159ea6cab1b54eb9a7a2445f9ed89397\\prompts\\calls\\a96ead6f0f694290a155fd22fb230c72\\001.receipt.json"}],"human_review":"pending","required_question_coverage":{"complete":true,"missing":[],"reason":"두 문장 안에서 구현 사실(invokeMethod(ConnectionTypeQueued) 호출 뒤 0 반환)과 API 설명(requestCompleted 신호로 완료가 별도로 알려짐)을 구분합니다. 0을 장치 캡처 큐잉 성공의 확인으로 설명하지 않습니다. queue-code의 반환 구문과 queue의 requestCompleted 설명이 두 주장을 뒷받침합니다. 이는 소스 계약에 대한 검토이며 실행 테스트로 검증한 것은 아닙니다."},"coverage_receipt":"independent-rounds\\159ea6cab1b54eb9a7a2445f9ed89397\\prompts\\calls\\a96ead6f0f694290a155fd22fb230c72\\002.receipt.json"}}
