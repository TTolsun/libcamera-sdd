issue211 CLI preflight
