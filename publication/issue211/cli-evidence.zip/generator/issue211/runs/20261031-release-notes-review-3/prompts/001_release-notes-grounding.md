<!-- system -->
Independently ground publication notes in supplied public data. No tools. Return JSON; automatic review is not human approval.

<!-- user -->
Check both corrected notes. Linked root run and receipts have exact package copies. Native receipt proof checks actual completed stdout, final args and request/response hashes. The renderer retains original visual identity only to authenticate saved artifacts; no inference in export. Separate profiles perform new inference.
NOTES
{"root-README.md": "# libcamera-sdd publication: issue211\n\n## Current release\n\n- Release notes: [publication/issue211/README.md](publication/issue211/README.md)\n- Run record: [run.json](publication/issue211/run.json)\n- Generation receipts: [generation-receipts.json](publication/issue211/generation-receipts.json)\n- Korean: https://ttolsun.github.io/libcamera-sdd/official-cam-validation.html\n- English: https://ttolsun.github.io/libcamera-sdd/en/official-cam-validation.html\n\nStatus: this package was prepared before deployment. The Pages deployment and the live output-hash proof are not yet recorded. They will be added to issue211 after the merge.\n\n- Source commit: 293d751a814e0d4c34e85ad457ccd9d5eefd1a61\n- Generator issue: https://github.com/TTolsun/camera-hal-sdd-generator/issues/211\n\nScope: observed on a WSL virtual camera (Virtual2) only. Hardware DMA, physical camera, production application, and internal HAL are not validated. Human review is pending.\n\n## Historical publications\n\n- [publication/issue193](publication/issue193/)\n- [publication/issue193-comment-followup](publication/issue193-comment-followup/)\n- [publication/source-excerpts](publication/source-excerpts/)\n- [publication/reader-ux](publication/reader-ux/)\n- [publication/reader-cleanup](publication/reader-cleanup/)\n- [publication/goal-162-163](publication/goal-162-163/)\n- [cli-runners](cli-runners/)\n", "README.md": "## Result\n\n- Status: `observed-wsl-virtual-only`. Camera: Virtual2, applied configuration `(0) 400x300-NV12/SMPTE170M`.\n- Trial kernel: `6.18.33.2-microsoft-standard-WSL2-issue211`.\n- Three independent final processes (pids 434, 449, 464) each completed 3 frames (buffer sequences 0, 1, 2), made 4 udmabuf allocations, had zero observed cancelled callbacks, and exited with code 0.\n- Observed TIDs: [434, 437], [449, 452], [464, 467]. These are the observed main-processing and callback roles in each process; other process threads may exist.\n\n## Callback and processing threads\n\n- Callback entry (`CameraSession::requestComplete`) ran on callback TIDs 437, 452, and 467.\n- Frame processing (`CameraSession::processRequest`, immediately before `captureCount_++`, `camera_session.cpp:535`) ran on main TIDs 434, 449, and 464. At this measured processing point, it was not observed on the callback thread.\n- Buffer metadata was read after `FrameMetadata` at `camera_session.cpp:503`.\n\n## udmabuf lifecycle (CPU read/write, not hardware DMA)\n\n1. Open `/dev/udmabuf`.\n2. Allocate a 4096-byte dmabuf (backing_fd 4, dmabuf_fd 5).\n3. `mmap`.\n4. `sync-start` (flags 3).\n5. CPU access: 4096 bytes, checksum 522240.\n6. `sync-end` (flags 7).\n7. `munmap`, then close dmabuf, backing, and provider. All return 0.\n\n## Environment during the trial\n\n- The default kernel `6.18.33.2-microsoft-standard-WSL2` is restored, and `.wslconfig` is absent after restore.\n- Kernel tag `linux-msft-wsl-6.18.33.2` (commit `c21a03b2943d147c280bdf32530d4fe6badfd6bd`). The compiler and config diff is preserved in full: GCC 13.2 to Ubuntu GCC 15.2, binutils 2.41 to 2.46, pahole 1.25 to 1.31.\n- Matching modules are not installed. Docker was stopped during the trial. The user authorized the kernel trial.\n- `/dev/udmabuf` is root-only. Permissions are unchanged. The unprivileged run failed with errno 13.\n\n## Limits\n\n- GDB breakpoints affect timing. The run does not prove callback return or performance.\n- No callback-return instruction was observed.\n- The cancellation branch was not exercised dynamically. The observed count of 0 was not forced.\n- Timeout probe (0.5 s) timed out with exit code 1. Cleanup returned 0 for `sync-end`, `munmap`, and all closes, and the process group was absent.\n- Negative probes: absent provider errno 2, unsupported ioctl errno 25, exit code 1.\n- Not validated: hardware DMA (`not-validated`), physical camera (`not-run`), production application (`not-run`), internal HAL (`not-run`). Human review is `pending`.\n\n## Generation\n\n- Writer and translation: native CLI `claude-haiku-5-5` with `--effort high --setting-sources project,local`.\n- New-document review: a separate Codex run, `gpt-6.1-terra` with `-c 'model_reasoning_effort=\"high\"'`.\n- The historical issue193/PR69 selected-Claude contract audit keeps its actual historical identity. It is not relabeled as Terra.\n- The renderer's original Codex visual identity is used for authentication only and invokes no model.\n- PR69 latest corrected source-identical request documents are preserved.\n- The official upstream is unchanged, so this is not a trivial rebuild. A new reader task closes the missing evidence for actual WSL allocator and callback behavior.\n\n## Evidence and files\n\n- Raw runs: https://github.com/TTolsun/camera-hal-sdd-generator/tree/main/examples/libcamera/validation/issue211/runs/20261031-wsl-cam-3\n- Runbook: https://github.com/TTolsun/camera-hal-sdd-generator/blob/main/examples/libcamera/runtime/OFFICIAL_CAM.md\n- Reproduction script: https://github.com/TTolsun/camera-hal-sdd-generator/blob/main/examples/libcamera/runtime/run_cam.py\n- Source commit `293d751a814e0d4c34e85ad457ccd9d5eefd1a61` is tracked clean and unmodified.\n- Package contents: `config/`, `manuscripts/`, `facts293.json.gz`, `english.json`, `profiles/`, `reviews/`, `build-validation.json`, `consistency-review.json`, `cli-evidence.zip`, `evidence-index.json`, `previous-release/`.\n- Pending: the postmerge Pages check and live output-hash proof, to be recorded in issue211.\n"}
MEASUREMENT
{
  "source_commit": "293d751a814e0d4c34e85ad457ccd9d5eefd1a61",
  "kernel": "6.18.33.2-microsoft-standard-WSL2-issue211",
  "results": [
    {
      "completed_frames": 3,
      "cancelled_callbacks": 0,
      "observed_tids": [
        434,
        437
      ],
      "successful_buffer_sequences": [
        0,
        1,
        2
      ],
      "pid": 434,
      "allocations": 4
    },
    {
      "completed_frames": 3,
      "cancelled_callbacks": 0,
      "observed_tids": [
        449,
        452
      ],
      "successful_buffer_sequences": [
        0,
        1,
        2
      ],
      "pid": 449,
      "allocations": 4
    },
    {
      "completed_frames": 3,
      "cancelled_callbacks": 0,
      "observed_tids": [
        464,
        467
      ],
      "successful_buffer_sequences": [
        0,
        1,
        2
      ],
      "pid": 464,
      "allocations": 4
    }
  ],
  "uid": 0,
  "gid": 0,
  "binaries": {
    "/home/baboess/.cache/issue211-runtime-D6sfkcnF/build/src/apps/cam/cam": "1ceed18da065a383e2f573ba49e9caea77033abd6830a7ec051e3681dabc79d2",
    "/home/baboess/.cache/issue211-runtime-D6sfkcnF/build/src/libcamera/libcamera.so": "2423e936a6ffde0fa533c76a4738f748f77b4535c881c12a616dfeec50a940eb",
    "/home/baboess/.cache/issue211-runtime-D6sfkcnF/build/src/libcamera/base/libcamera-base.so": "441f04294e61632d080f4bb55fb38ce787bb8af173a4b6d55d7c05f0f04fd18c",
    "/home/baboess/.cache/issue211-runtime-D6sfkcnF/dmabuf-probe-2": "531e499f094cca32f03e354afe2aa5a8d48b425916cbd7be2ad7e02306c58512"
  },
  "human_review": "pending",
  "physical_dma": "not-validated",
  "physical_camera": "not-run",
  "production_application": "not-run",
  "internal_hal": "not-run",
  "status": "observed-wsl-virtual-only",
  "schema": 1,
  "camera": "Virtual2",
  "applied_configuration": "(0) 400x300-NV12/SMPTE170M",
  "official_source_tracked_clean": true,
  "kernel_tag": "linux-msft-wsl-6.18.33.2",
  "kernel_tag_commit": "c21a03b2943d147c280bdf32530d4fe6badfd6bd",
  "kernel_sha256": "cf23bf492a00a5c7517e221b0d8f742ea3cffa9351823191a5ba5c476ba15460",
  "compiler_config_diff": "GCC 13.2 to Ubuntu GCC 15.2 capability changes, binutils 2.41 to 2.46, pahole 1.25 to 1.31; full diff preserved",
  "matching_modules_installed": false,
  "docker_during_trial": "stopped",
  "allocator": "udmabuf built-in, /dev/udmabuf root-only; permissions unchanged",
  "unprivileged_run": {
    "status": "failed",
    "errno": 13
  },
  "dma_probe_events": [
    {
      "event": "provider-open",
      "provider": "/dev/udmabuf",
      "result": 3,
      "errno": 0
    },
    {
      "event": "allocate",
      "result": 5,
      "errno": 0,
      "backing_fd": 4,
      "dmabuf_fd": 5,
      "size": 4096
    },
    {
      "event": "mmap",
      "result": 0,
      "errno": 0
    },
    {
      "event": "sync-start",
      "result": 0,
      "errno": 0,
      "flags": 3,
      "retry": false
    },
    {
      "event": "cpu-access",
      "result": 0,
      "errno": 0,
      "bytes": 4096,
      "checksum": 522240
    },
    {
      "event": "sync-end",
      "result": 0,
      "errno": 0,
      "flags": 7,
      "retry": false
    },
    {
      "event": "munmap",
      "result": 0,
      "errno": 0
    },
    {
      "event": "close-dmabuf",
      "result": 0,
      "errno": 0
    },
    {
      "event": "close-backing",
      "result": 0,
      "errno": 0
    },
    {
      "event": "close-provider",
      "result": 0,
      "errno": 0
    }
  ],
  "run_threads": [
    {
      "pid": 434,
      "callbacks": [
        437
      ],
      "processed": [
        434
      ]
    },
    {
      "pid": 449,
      "callbacks": [
        452
      ],
      "processed": [
        449
      ]
    },
    {
      "pid": 464,
      "callbacks": [
        467
      ],
      "processed": [
        464
      ]
    }
  ],
  "inferior_exit_codes": [
    0,
    0,
    0
  ],
  "processed_sequences": [
    [
      0,
      1,
      2
    ],
    [
      0,
      1,
      2
    ],
    [
      0,
      1,
      2
    ]
  ],
  "timeout_probe": {
    "seconds": 0.5,
    "timed_out": true,
    "exit_code": 1,
    "sync_end_return_code": 0,
    "munmap_return_code": 0,
    "close_return_codes": [
      0,
      0,
      0
    ],
    "process_group_absent": true
  },
  "negative_probes": {
    "absent_provider_errno": 2,
    "unsupported_ioctl_errno": 25,
    "exit_codes": [
      1,
      1
    ]
  },
  "supplemental_official_cam_strace": {
    "exit_code": 0,
    "callback_observation": false
  },
  "restored_kernel": "6.18.33.2-microsoft-standard-WSL2",
  "restored_wslconfig_exists": false,
  "old_cpu_probe": {
    "callbacks": 72,
    "dma": "unvalidated-provider-and-sync-errors-retained",
    "history_unchanged": true
  },
  "observation_limits": [
    "GDB breakpoints affect timing",
    "No callback-return instruction observation",
    "Cancellation branch not dynamically exercised; observed count 0 is not forced"
  ],
  "reproduction_code": "https://github.com/TTolsun/camera-hal-sdd-generator/blob/main/examples/libcamera/runtime/run_cam.py",
  "raw_evidence": "https://github.com/TTolsun/camera-hal-sdd-generator/tree/main/examples/libcamera/validation/issue211/runs/20261031-wsl-cam-3",
  "buffer_metadata": [
    [
      {
        "buffer_sequence": 0,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 434,
        "point": "buffer-metadata",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 434
      },
      {
        "buffer_sequence": 1,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 434,
        "point": "buffer-metadata",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 434
      },
      {
        "buffer_sequence": 2,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 434,
        "point": "buffer-metadata",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 434
      }
    ],
    [
      {
        "buffer_sequence": 0,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 449,
        "point": "buffer-metadata",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 449
      },
      {
        "buffer_sequence": 1,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 449,
        "point": "buffer-metadata",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 449
      },
      {
        "buffer_sequence": 2,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 449,
        "point": "buffer-metadata",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 449
      }
    ],
    [
      {
        "buffer_sequence": 0,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 464,
        "point": "buffer-metadata",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 464
      },
      {
        "buffer_sequence": 1,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 464,
        "point": "buffer-metadata",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 464
      },
      {
        "buffer_sequence": 2,
        "buffer_status": 0,
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:503",
        "pid": 464,
        "point": "buffer-metadata",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 464
      }
    ]
  ],
  "pretrial_kernel": "6.18.33.2-microsoft-standard-WSL2",
  "pretrial_udmabuf": false,
  "pretrial_dmabuf_heaps": false,
  "pretrial_provider_devices_present": false,
  "source_unmodified": true,
  "kernel_trial_authorized_by_user": true,
  "request_events": [
    [
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 434,
        "point": "callback-entry",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 437
      },
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 434,
        "point": "callback-entry",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 437
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 434,
        "point": "frame-processed",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 434
      },
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 434,
        "point": "callback-entry",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 437
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 434,
        "point": "frame-processed",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 434
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 434,
        "point": "frame-processed",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 434
      }
    ],
    [
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 449,
        "point": "callback-entry",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 452
      },
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 449,
        "point": "callback-entry",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 452
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 449,
        "point": "frame-processed",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 449
      },
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 449,
        "point": "callback-entry",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 452
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 449,
        "point": "frame-processed",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 449
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 449,
        "point": "frame-processed",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 449
      }
    ],
    [
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 464,
        "point": "callback-entry",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 467
      },
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 464,
        "point": "callback-entry",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 467
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 464,
        "point": "frame-processed",
        "request": "0x5555556794f0",
        "sequence": 0,
        "status": 1,
        "tid": 464
      },
      {
        "cookie": 0,
        "location": "CameraSession::requestComplete",
        "pid": 464,
        "point": "callback-entry",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 467
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 464,
        "point": "frame-processed",
        "request": "0x5555556793b0",
        "sequence": 1,
        "status": 1,
        "tid": 464
      },
      {
        "cookie": 0,
        "location": "/home/baboess/.cache/issue211-runtime-D6sfkcnF/source/src/apps/cam/camera_session.cpp:535",
        "pid": 464,
        "point": "frame-processed",
        "request": "0x555555679450",
        "sequence": 2,
        "status": 1,
        "tid": 464
      }
    ]
  ],
  "main_tid": [
    434,
    449,
    464
  ],
  "observation_points": {
    "callback-entry": "CameraSession::requestComplete entry",
    "frame-processed": "CameraSession::processRequest immediately before captureCount_++",
    "buffer-metadata": "CameraSession::processRequest after reading FrameMetadata"
  },
  "timeout_cleanup_events": [
    {
      "event": "provider-open",
      "provider": "/dev/udmabuf",
      "result": 3,
      "errno": 0
    },
    {
      "event": "allocate",
      "result": 5,
      "errno": 0,
      "backing_fd": 4,
      "dmabuf_fd": 5,
      "size": 4096
    },
    {
      "event": "mmap",
      "result": 0,
      "errno": 0
    },
    {
      "event": "sync-start",
      "result": 0,
      "errno": 0,
      "flags": 3,
      "retry": false
    },
    {
      "event": "sync-end",
      "result": 0,
      "errno": 0,
      "flags": 7,
      "retry": false
    },
    {
      "event": "munmap",
      "result": 0,
      "errno": 0
    },
    {
      "event": "close-dmabuf",
      "result": 0,
      "errno": 0
    },
    {
      "event": "close-backing",
      "result": 0,
      "errno": 0
    },
    {
      "event": "close-provider",
      "result": 0,
      "errno": 0
    }
  ]
}

VERIFIED MACHINE PROOFS (bounded representative records; complete index retained)
{"schema": 1, "retained_pr69_pages": {"camera-requests.md": {"published_sha256": "8aafe33eef028effd72981c6a314b3262ea33b4fba9a9a6f7db201ad77afbac0", "workspace_sha256": "8aafe33eef028effd72981c6a314b3262ea33b4fba9a9a6f7db201ad77afbac0"}, "request-lifecycle.md": {"published_sha256": "ae9cf6081cbd2f183095c540ee97eccf7bd52407e8d1ba112b443f717b00fefa", "workspace_sha256": "ae9cf6081cbd2f183095c540ee97eccf7bd52407e8d1ba112b443f717b00fefa"}}, "public_base": "85b4cd8d6fd9e1778eac3f20cbd0df0e6b8b7cf3", "upstream": {"official": "293d751a814e0d4c34e85ad457ccd9d5eefd1a61\trefs/heads/master", "mirror": "293d751a814e0d4c34e85ad457ccd9d5eefd1a61\trefs/heads/upstream/master"}, "renderer": {"model_calls": false, "profile": "publication.yaml", "purpose": "Authenticate original visual fingerprints; export_site/prepare_catalog perform model-free receipt verification. All new inference uses separate generation/review configuration."}, "human_review": "pending", "all_verified_count": 90, "verification_scope": "All selected records verified by load_record plus verify_cli_receipt, native stdout, exact selected args, request/response/prompt hashes. Not a semantic or human approval.", "representative_exact_receipts": [{"path": "build/issue211-publication/build/prompts/calls/28009113ff5949a6beb9f920b16c82eb/001.receipt.json", "receipt_sha256": "9790a733888cf921b7746b518e68a7bc1453bcc11f7293790921de58e81a6771", "model": "claude-haiku-5-5", "runner": "claude", "tag": "official-cam-validation_outcome_0", "completed_at": "2026-10-31T07:05:50.432731+00:00", "verification": {"runner": "claude", "model": "claude-haiku-5-5", "model_selection": "explicit", "producer": "cli/claude/claude-haiku-5-5", "stdout_sha256": "b2ddb0018831ee57f42a4dd5d8408c4c3f3a02f1caea0299024e73ef0e028971", "arguments_verified": true}, "selected_args": ["--model", "claude-haiku-5-5", "--effort", "high", "--setting-sources", "project,local"]}, {"path": "build/issue211-publication/build/translation-prompts/calls/05137ddd6a394d4daeed203f01db7c0a/001.receipt.json", "receipt_sha256": "51ed061cbed05024fe73139cae02af6aa12fa681ad4c21c1e8044b9f44a6c536", "model": "claude-haiku-5-5", "runner": "claude", "tag": "translation_batch_0_0", "completed_at": "2026-10-31T07:54:57.716748+00:00", "verification": {"runner": "claude", "model": "claude-haiku-5-5", "model_selection": "explicit", "producer": "cli/claude/claude-haiku-5-5", "stdout_sha256": "dd25c7eccc755ccc27cae32d75d4fb89519706921ecaac02c3fea246351bdd36", "arguments_verified": true}, "selected_args": ["--model", "claude-haiku-5-5", "--effort", "high", "--setting-sources", "project,local"]}, {"path": "examples/libcamera/validation/issue211/runs/20261031-bilingual-document-review-2/prompts/calls/65c06c36541742f29e5b47bb007ee2a8/001.receipt.json", "receipt_sha256": "128928792d68560b3a7e6060e25dc72ec308e2128af908d755045e2fa0f970e9", "model": "gpt-6.1-terra", "runner": "codex", "tag": "document-grounding", "completed_at": "2026-10-31T07:45:31.724417+00:00", "verification": {"runner": "codex", "model": "gpt-6.1-terra", "model_selection": "explicit", "producer": "cli/codex/gpt-6.1-terra", "stdout_sha256": "7e56596147966d241eddb328bd18e1d3fa197916b68016de755e9e1dec0734ec", "arguments_verified": true}, "selected_args": ["-m", "gpt-6.1-terra", "-c", "model_reasoning_effort=\"high\""]}, {"path": "examples/libcamera/validation/issue211/runs/20261031-release-notes-generation/prompts/calls/839f352852a6473a952a7b6de8468f63/001.receipt.json", "receipt_sha256": "c3596c36c1cfc32335111430f697a612582d6600e1cb8a66069693f7f97fb42d", "model": "claude-haiku-5-5", "runner": "claude", "tag": "publication-notes", "completed_at": "2026-10-31T07:51:22.877846+00:00", "verification": {"runner": "claude", "model": "claude-haiku-5-5", "model_selection": "explicit", "producer": "cli/claude/claude-haiku-5-5", "stdout_sha256": "e6c52126dabe1ab8f2a81d233cde535c0881890fc9b1ee7d7f5821e5fdd3e958", "arguments_verified": true}, "selected_args": ["--model", "claude-haiku-5-5", "--effort", "high", "--setting-sources", "project,local"]}]}
