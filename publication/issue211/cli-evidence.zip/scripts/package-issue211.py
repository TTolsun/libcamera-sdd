"""Package only public source inputs, native records and verified output metadata."""
from pathlib import Path
import gzip
import json
import shutil
import zipfile
import yaml

from sdd.runtime_evidence import sha256, require_success
from sdd.site_build import verify_site

root = Path(__file__).resolve().parent.parent
work = root/'build/issue211-publication'
repo = root/'build/libcamera-sdd-issue211'
validation = root/'examples/libcamera/validation/issue211'
runs = validation/'runs'
repeat = runs/'20261031-publication-repeat-build'
require_success(repeat)
if not json.loads((repeat/'repeat.json').read_text())['identical']:
    raise ValueError('Repeat build not identical')
site = repo/'docs'
checked = verify_site(site)
manifest = json.loads((site/'site-manifest.json').read_text(encoding='utf-8'))
if (site/'site-manifest.json').read_bytes() != (work/'export-final-2/site-manifest.json').read_bytes():
    raise ValueError('Published staging differs from reviewed final build')
package = repo/'publication/issue211'
package.mkdir(exist_ok=False)
(package/'previous-release').mkdir()
for name in ['README.md', 'run.json', 'generation-receipts.json']:
    shutil.copyfile(repo/name, package/'previous-release'/name)
for name in ['config', 'run/manuscripts']:
    shutil.copytree(work/name, package/('manuscripts' if name=='run/manuscripts' else name))
(package/'facts293.json.gz').write_bytes(gzip.compress((work/'run/facts/facts.json').read_bytes(),mtime=0))
for src,dst in [(work/'run/english.json','english.json'),(work/'site-intro.md','site-intro.md'),
                (work/'build/consistency-review.json','consistency-review.json'),
                (work/'generator-merge.json','generator-merge.json'),
                (work/'pr69-integration.json','pr69-integration.json'),
                (work/'release-grounding.json','native-call-verification.json')]:
    shutil.copyfile(src,package/dst)
(package/'profiles').mkdir()
for name in ['generation.yaml','publication.yaml','historical-contract-review.yaml','new-document-review.yaml']:
    shutil.copyfile(work/name,package/'profiles'/name)
for name in ['generation-profile.yaml','independent-review-profile.yaml']:
    shutil.copyfile(validation/name,package/'profiles'/name)
(package/'profiles/roles.json').write_text(json.dumps(dict(
    new_generation_translation='generation.yaml and generation-profile.yaml: actual selected Claude CLI with project,local settings',
    new_source_bilingual_review='new-document-review.yaml and independent-review-profile.yaml: actual independent Codex Terra/high CLI',
    publication='Model-free export; original visual-fingerprint agent identity only',
    historical_contract_review='Authenticates actual retained issue193/PR69 Haiku/high audit; no new inference and never relabeled Terra',
    global_defaults_changed=False),indent=2)+'\n',encoding='utf-8')
(package/'reviews').mkdir()
selected = {
    'korean-document':'20261031-korean-document-review-9',
    'bilingual-document':'20261031-bilingual-document-review-final',
    'bilingual-glossary':'20261031-glossary-bilingual-review',
    'runbook':'20261031-runbook-review-12',
    'release-notes':'20261031-release-notes-review-4',
}
for name,folder in selected.items():
    data=json.loads((runs/folder/'review.json').read_text(encoding='utf-8'))
    if data['review']['verdict']!='pass':raise ValueError(name+' did not pass')
    shutil.copyfile(runs/folder/'review.json',package/'reviews'/(name+'.json'))
shutil.copyfile(runs/'20261031-terra-final-runtime-review/review.json',package/'reviews/runtime.json')
for name in ['20261031-final-rendered-english-narrative.txt','20261031-final-rendered-evidence-inventory.json']:
    shutil.copyfile(runs/name,package/'reviews'/name)
shutil.copyfile(runs/'20261031-release-notes-correction/README.md',package/'README.md')
shutil.copyfile(runs/'20261031-release-notes-correction/root-README.md',repo/'README.md')

archive_entries={}
sources=[]
for name in ['prompts','translation-prompts','cli-checkpoints','generation-runs']:
    sources.extend((p,'workspace/build/'+p.relative_to(work/'build').as_posix())
                   for p in (work/'build'/name).rglob('*') if p.is_file())
sources.extend((p,'generator/issue211/'+p.relative_to(validation).as_posix())
               for p in validation.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
sources.extend((p,'generator/runtime/'+p.name) for p in (root/'examples/libcamera/runtime').iterdir() if p.is_file())
sources.append((Path(__file__),'scripts/package-issue211.py'))
with zipfile.ZipFile(package/'cli-evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for p,name in sorted(sources,key=lambda row:row[1]):
        # Isolated temporary CLI workspaces are deleted after native completion.
        if any(part.startswith('call-') for part in p.parts[:-1]):continue
        archive.write(p,name)
        archive_entries[name]=sha256(p)
(package/'archive-index.json').write_text(json.dumps(archive_entries,indent=2)+'\n',encoding='utf-8')
writer=yaml.safe_load((validation/'generation-profile.yaml').read_text(encoding='utf-8'))['agent']
reviewer=yaml.safe_load((validation/'independent-review-profile.yaml').read_text(encoding='utf-8'))['agent']
run=dict(schema=1,source_repository='https://gitlab.freedesktop.org/camera/libcamera.git',
    source_commit='293d751a814e0d4c34e85ad457ccd9d5eefd1a61',official_upstream_unchanged=True,
    generator_repository='https://github.com/TTolsun/camera-hal-sdd-generator',
    generator_behavior_commit='580df5156da7066a60e16ff9b656253b1c17f0c0',
    generator_pr='https://github.com/TTolsun/camera-hal-sdd-generator/pull/213',
    generator_ci='https://github.com/TTolsun/camera-hal-sdd-generator/actions/runs/41182193467',
    build_id=manifest['build_id'],facts_sha256=sha256(work/'run/facts/facts.json'),
    english_catalog_sha256=sha256(work/'run/english.json'),manifest_sha256=sha256(site/'site-manifest.json'),
    manifest_outputs=len(manifest['outputs']),profile=writer,independent_review_profile=reviewer,
    historical_review='Retained PR69/issue193 selected-Claude contract audit, exact original identity; not new Terra review',
    repeat_build_identical=True,validation=checked,evidence='publication/issue211/README.md',
    runtime_scope='observed-wsl-virtual-only',human_task_test='pending',internal_hal_validation='not-run',
    post_deployment='Predeployment record; actual Pages workflow and live HTTPS all-output hash proof are recorded after merge in generator issue211')
receipts=dict(schema=1,scope='New issue211 native calls plus preserved historical artifacts; exact full requests/responses/stdout and failed attempts in cli-evidence.zip',
    writer=writer,new_document_reviewer=reviewer,
    verified_call_index='publication/issue211/native-call-verification.json',
    complete_archive_index='publication/issue211/archive-index.json',
    historical_records='publication/issue193 and publication/issue193-comment-followup remain unchanged',
    human_review='pending')
for name,data in [('run.json',run),('generation-receipts.json',receipts)]:
    text=json.dumps(data,ensure_ascii=False,indent=2)+'\n'
    (repo/name).write_text(text,encoding='utf-8',newline='\n')
    (package/name).write_text(text,encoding='utf-8',newline='\n')
validation_data=dict(schema=1,local=checked,repeat_build_identical=True,manifest_sha256=run['manifest_sha256'],
    build_id=run['build_id'],manifest_outputs=len(manifest['outputs']),
    reviewed_english_html_sha256=json.loads((package/'reviews/20261031-final-rendered-evidence-inventory.json').read_text())['html_sha256']['en'],
    current_english_html_sha256=sha256(site/'en/official-cam-validation.html'),
    prior_public_base='85b4cd8d6fd9e1778eac3f20cbd0df0e6b8b7cf3',
    retained_pr69_documents={name:sha256(site/name) for name in ['camera-requests.md','request-lifecycle.md']},
    human_review='pending',physical_dma='not-validated',physical_camera='not-run',production_application='not-run',internal_hal='not-run')
if validation_data['reviewed_english_html_sha256']!=validation_data['current_english_html_sha256']:
    raise ValueError('Reviewed English HTML changed')
(package/'build-validation.json').write_text(json.dumps(validation_data,indent=2)+'\n',encoding='utf-8')
inputs={p.relative_to(package).as_posix():sha256(p) for p in sorted(package.rglob('*')) if p.is_file()}
(package/'evidence-index.json').write_text(json.dumps(dict(schema=1,scope='Every package file except this self-referential index; site files separately covered by the generator manifest',files=inputs,site_manifest=run['manifest_sha256'],site_outputs=manifest['outputs']),indent=2)+'\n',encoding='utf-8')
with (repo/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    f.write('\n# Preserve original issue211 native receipts, runtime and reviewed source bytes.\npublication/issue211/** -text -whitespace\n')
print(json.dumps(dict(build_id=run['build_id'],package_files=len(inputs),archive_files=len(archive_entries),zip_bytes=(package/'cli-evidence.zip').stat().st_size)))
