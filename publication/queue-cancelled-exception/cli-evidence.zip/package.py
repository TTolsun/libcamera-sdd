from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
from sdd.document_metadata import split_frontmatter
from sdd.site_build import verify_site
root=Path(__file__).resolve().parent;repo=root.parents[1];work=root/'workspace';public=repo/'build/issue194/publication';pkg=public/'publication/queue-cancelled-exception';pkg.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
m=json.loads((public/'docs/site-manifest.json').read_bytes());assert (root/'first-manifest.json').read_bytes()==(public/'docs/site-manifest.json').read_bytes()
checks=verify_site(public/'docs');old=repo/'build/callback-observation/workspace'
baseline=json.loads((root/'baseline/hashes.json').read_bytes()); changed=[n for n,h in baseline.items() if sha(work/'manuscripts'/n)!=h]
assert changed==['pipeline-requests.md'],changed
for n in ('request-lifecycle.md','approvals.json'):
 if (root/'baseline'/n).exists():assert (root/'baseline'/n).read_bytes()==(work/'manuscripts'/n).read_bytes()
review=json.loads((root/'independent-grounding.json').read_bytes());assert review['manuscript_sha256']==sha(work/'manuscripts/pipeline-requests.md');assert all(x['status']=='supported' for x in review['results'])
audit=json.loads((work/'build/consistency-review.json').read_bytes());assert audit['status']=='passed';assert len(audit['unresolved'])==1 and audit['unresolved'][0]['claim_id']=='scenarios/queue_request.md/paragraph/28',audit['unresolved']
meta,body=split_frontmatter((work/'manuscripts/pipeline-requests.md').read_text(encoding='utf-8'))
answer=next(a for a in meta['generated_design']['answers']['queue'] if a.get('part_id')=='device-submit');assert '취소' in answer['text'] and 'queueRequestDevice' in answer['text'] and 'ret' in answer['text']
shutil.copytree(work/'config',pkg/'config',dirs_exist_ok=True)
(pkg/'manuscripts').mkdir(exist_ok=True)
for n in ('pipeline-requests.md','approvals.json'):
 if (work/'manuscripts'/n).exists():shutil.copy2(work/'manuscripts'/n,pkg/'manuscripts'/n)
for n in ('english.json','site-intro.md'):shutil.copy2(work/n,pkg/n)
for n in ('sdd.yaml','sdd.review.yaml','sdd.render.yaml'):shutil.copy2(work/n,pkg/'profiles'/n) if (pkg/'profiles').exists() else ((pkg/'profiles').mkdir(),shutil.copy2(work/n,pkg/'profiles'/n))
for n in ('preflight.json','independent-grounding.json','source-window-review.json','browser-validation.json','prior-answer-rejection.json','finding-resolution.json','retranslation-request.json','approval-state.json'):shutil.copy2(root/n,pkg/n)
shutil.copy2(work/'build/facts-verification.json',pkg/'facts-verification.json')
shutil.copy2(root/'baseline/consistency-review.json',pkg/'previous-consistency-review.json')
shutil.copy2(root/'baseline/pipeline-requests.md',pkg/'previous-pipeline-requests.md')
write(pkg/'facts-reference.json',dict(schema=1,facts_sha256=sha(work/'facts/facts.json'),previous_archive='../callback-observation/structural-facts.zip',previous_record='../callback-observation/structural-facts.json',source_commit=meta['source_commit'],retained_byte_identical=True))
files=[p for p in (work/'build').rglob('*') if p.is_file()]+[p for p in (root/'preflight').rglob('*') if p.is_file()]+[p for p in root.glob('*.log') if not p.name.startswith(('server','package'))]+list(root.glob('*.py'))+[root/'claude-help.txt']+[p for a in ('first-attempt','second-attempt','third-attempt') for p in (root/a).rglob('*') if p.is_file()]
index={};new=[];historical=0
with zipfile.ZipFile(pkg/'cli-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files):
  rel=p.relative_to(root).as_posix();assert not any(s in p.name.lower() for s in ('credentials','auth.json','.env'))
  z.write(p,rel);index[rel]=dict(sha256=sha(p),bytes=p.stat().st_size)
  if p.name.endswith('.receipt.json'):
   r=json.loads(p.read_bytes());assert r['model'] in ('claude-haiku-5-5','gpt-6.1-terra')
   args=r['provider']['arguments']
   if r['model']=='claude-haiku-5-5':
    assert args[args.index('--effort')+1]=='high';assert set(r['provider']['provider']['modelUsage'])=={'claude-haiku-5-5'}
   else:assert 'model_reasoning_effort="high"' in args
   previous=old/p.relative_to(work) if p.is_relative_to(work) else None
   if previous and previous.exists() and sha(previous)==sha(p):historical+=1
   else:new.append(dict(path=rel,sha256=sha(p),tag=r['tag'],model=r['model'],runner=r['provider']['runner']))
write(pkg/'cli-evidence-index.json',dict(schema=1,archive_sha256=sha(pkg/'cli-evidence.zip'),files=index))
write(pkg/'new-receipts.json',dict(schema=1,receipts=new,retained_historical_receipts=historical,human_review='pending',callback_runtime_validation='not-run'))
write(pkg/'manuscript-preservation.json',dict(schema=1,changed=changed,unchanged=len(baseline)-len(changed),approvals=json.loads((root/'approval-state.json').read_bytes()),callback_plan='request-lifecycle.md byte-identical',previous_hashes=baseline))
generator=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();source=meta['source_commit']
run=dict(schema=1,source_repository='https://gitlab.freedesktop.org/camera/libcamera.git',source_commit=source,generator_repository='https://github.com/TTolsun/camera-hal-sdd-generator',generator_behavior_commit=generator,generator_prs=[205,206],build_id=m['build_id'],facts_sha256=sha(work/'facts/facts.json'),english_catalog_sha256=sha(work/'english.json'),manifest_sha256=sha(public/'docs/site-manifest.json'),manifest_outputs=len(m['outputs']),profile=dict(kind='cli',runner='claude',model='claude-haiku-5-5',args=['--effort','high','--setting-sources','project,local']),independent_review_profile=dict(kind='cli',runner='codex',model='gpt-6.1-terra',args=['-c','model_reasoning_effort="high"']),structural_extraction=dict(fresh=False,reason='Official upstream unchanged; previous fresh Meson/Ninja/libclang facts retained; current evidence recollected.',previous_release='publication/callback-observation/structural-facts.json'),validation=checks,repeat_build_identical=True,automatic_unresolved=len(audit['unresolved']),human_review='pending',callback_runtime_validation='not-run',internal_hal_validation='not-run',evidence='publication/queue-cancelled-exception/README.md',post_deployment='Predeployment report; actual Pages and public hash checks are recorded in the release PR after merge.')

if not (pkg/'previous-run.json').exists():shutil.copy2(public/'run.json',pkg/'previous-run.json')
write(public/'run.json',run);write(pkg/'build-validation.json',dict(build_id=m['build_id'],manifest_sha256=run['manifest_sha256'],repeat_identical=True,**checks))
(pkg/'.gitattributes').write_text('** -text whitespace=cr-at-eol\nmanuscripts/** -whitespace\nprevious-pipeline-requests.md -whitespace\n',encoding='utf-8')
(pkg/'README.md').write_text(f'''# Cancellation precondition for device submission

The Korean and English Pipeline request guide now explicitly states that doQueueRequest calls
queueRequestDevice and assigns ret only when the request is not already cancelled. The preceding
paragraph retains the cancelled request's completeRequest call and early return. Nonzero ret
handling and the device implementer's parameter/buffer obligation remain source-bound.

Generator [PR205](https://github.com/TTolsun/camera-hal-sdd-generator/pull/205) and [PR206](https://github.com/TTolsun/camera-hal-sdd-generator/pull/206), commit `{generator}`.
Official libcamera HEAD is still `{source}`. Existing fresh Meson/Ninja/libclang structural facts
are retained and source excerpts recollected; no new structural extraction or hardware execution
is claimed. [Source windows](source-window-review.json) distinguish the bounded review from
unreviewed source/runtime scope.

The [previous automatic report](previous-consistency-review.json) preserves both original
ambiguous findings, one Korean and its English translation. The current manifest-owned
[report](../../docs/contract-consistency.json) has zero contradictions. The original Korean/English ambiguity pair is now assessed compatible,
and one different insufficient-evidence finding for a next-step navigation link remains.
Its exact verdict is preserved in [finding resolution](finding-resolution.json); ordinary link checks
verify that the target exists, without manually changing the model assessment. Verdicts were produced by independent Codex CLI, not edited.
This is automatic source review, not human approval or an exhaustive proof of runtime behavior.

New prose and changed English strings use independent Claude Code 2.1.314, exact
`claude-haiku-5-5`, `--effort high --setting-sources project,local`. [Preflight](preflight.json)
records actual provider modelUsage and high support. Source grounding and bilingual consistency
use independent Codex `gpt-6.1-terra`, `-c model_reasoning_effort="high"`.
[Profiles](profiles/), [new receipts](new-receipts.json), [native evidence](cli-evidence.zip),
and its [hash index](cli-evidence-index.json) preserve exact per-run settings and execution results.
Historical receipts are identified separately and are not fresh inference. Global defaults
were not changed. No alternate model, CLI, direct API, saved answer or manual manuscript
substituted for new generation. A sandboxed preflight stalled and was stopped; the exact same
CLI/model/effort succeeded outside the restricted sandbox. Initial local pytest temp-directory
access failed; a writable workspace temp directory passed 212 focused tests.
The first draft exceeded the prose growth limit and independent grounding rejected its omitted no-fence early-return condition. It was preserved and regenerated through the same Haiku CLI with the existing focused writing mode and a complete question. Earlier output and generation records remain preserved.

Only pipeline-requests.md changed among the previous manuscripts. Full bilingual review also
found an existing English paragraph expanding waiting requests to all pending requests. The same
Haiku CLI retranslated it as all waiting requests; its Korean original was unchanged.
The full audit rejected a generated claim that the cancelRequest body was unconfirmed. A corrected
call-only question and separate submission/failure units regenerated through the same Haiku CLI
remove that claim. Rejected artifacts and all verdicts remain in the evidence archive. The effective human approval state is unchanged: no approval ledger exists in either original
or current input, and both have no accepted pages or findings. See [approval state](approval-state.json).
request-lifecycle.md, including its unexecuted callback investigation plan, is byte-identical;
see [preservation](manuscript-preservation.json). No accept command was executed.
[Independent grounding](independent-grounding.json) reviews all generated pipeline statements.
The original historical figure identity remains solely for verification; no new inference
uses its historical render profile. New review uses its separate explicit profile.

[Build checks](build-validation.json): build `{m['build_id']}`, {len(m['outputs'])} owned outputs,
zero broken internal links; two ordinary generator exports produced an identical manifest.
[Browser checks](browser-validation.json) verify both languages and mobile reading.
Generated HTML was not manually edited. Actual application callback execution and internal
Camera HAL validation remain not-run. Existing human approval state is unchanged.
Post-merge Pages workflow and public manifest/all-output hash checks are recorded in the release PR.
''',encoding='utf-8',newline='\n')
readme=public/'README.md';lines=readme.read_text(encoding='utf-8').splitlines();lines[2]=f'Current release: [device-submission cancellation exception](publication/queue-cancelled-exception/README.md), generator [PR205](https://github.com/TTolsun/camera-hal-sdd-generator/pull/205) and [PR206](https://github.com/TTolsun/camera-hal-sdd-generator/pull/206), build `{m["build_id"]}`, official public libcamera `{source}`. [Korean and English site](https://ttolsun.github.io/libcamera-sdd/). Actual callback execution remains unverified; existing generation records and human approval state are preserved.';readme.write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(**run,new_receipts=len(new),retained_historical_receipts=historical,archive_bytes=(pkg/'cli-evidence.zip').stat().st_size),ensure_ascii=False))
