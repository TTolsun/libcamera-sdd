from pathlib import Path
from collections import defaultdict
from types import SimpleNamespace
import hashlib, json
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.llm import Agent
from sdd.document_metadata import split_frontmatter
from sdd.design_request import _design_units
from sdd.grounding import review

root=Path(__file__).resolve().parent
cfg=load(root/'workspace/sdd.review.yaml')
assert cfg.agent.runner=='codex' and cfg.agent.model=='gpt-6.1-terra'
assert cfg.agent.args==['-c','model_reasoning_effort="high"']
model=KnowledgeModel.load(cfg.facts_path)
section=next(s for s in cfg.sections() if s['id']=='pipeline-requests')
path=cfg.sdd_dir/'pipeline-requests.md'
raw=path.read_bytes()
meta,_=split_frontmatter(raw.decode('utf-8'))
assert meta['source_commit']==model.meta['source_commit']
answers=meta['generated_design']['answers']
groups=defaultdict(list)
for unit in _design_units(section,{}):
    basis=unit.get('answer_contract',{}).get('basis','execution-check' if unit.get('_statement_kind') else 'description')
    groups[unit['id'],basis].append(unit)
agent=Agent(cfg.agent,dump_dir=cfg.build_dir/'independent-grounding')
rows=[]
total=0
for (tid,basis),units in groups.items():
    parts={u['_part_id'] for u in units}
    statements=[s for s in answers[tid] if s.get('part_id') in parts]
    assert statements
    ids=list(dict.fromkeys(s['id'] for u in units for s in u['sources']))
    records={sid:model.evidence[f"{section['id']}/{tid}/{sid}"] for sid in ids}
    topic=dict(question='\n'.join(u['question'] for u in units),answer_contract=dict(
        basis='investigation' if basis=='execution-check' else basis))
    status='supported'
    finding=None
    try:
        review(SimpleNamespace(cfg=cfg,agent=agent),topic,statements,
               {sid:r['text'] for sid,r in records.items()},'cancelled_exception_'+tid+'_'+basis,
               source_files={sid:r['file'] for sid,r in records.items()},
               source_scopes={sid:r['selector']['scope'] for sid,r in records.items() if r['selector'].get('scope')},
               context_records=records)
    except ValueError as exc:
        # Keep the negative source-entailment verdict for the explicitly
        # unexecuted plan. It is not a passed factual/runtime verification.
        # Every behavior statement still fails this review on rejection.
        if basis!='execution-check' or not str(exc).startswith('모델 근거 대조 실패'):
            raise
        assert len(statements)==1 and statements[0]['kind']=='limitation'
        assert '아직 실행하지 않은 조사 계획' in statements[0]['text'] and '검증 전' in statements[0]['text']
        status='insufficient-evidence-unverified-plan'
        finding=str(exc)
    total+=len(statements)
    rows.append(dict(topic=tid,basis=basis,parts=sorted(parts),statements=len(statements),status=status,
                     finding=finding,receipt=str(agent.last_receipt.relative_to(root))))
    print(tid+'/'+basis+': '+status+' ('+str(len(statements))+')',flush=True)
assert total==sum(map(len,answers.values()))
report=dict(schema=1,source_commit=model.meta['source_commit'],manuscript_sha256=hashlib.sha256(raw).hexdigest(),
            profile=dict(kind=cfg.agent.kind,runner=cfg.agent.runner,model=cfg.agent.model,args=cfg.agent.args),
            scope='All generated pipeline request statements grouped by original topic and answer basis; full associated source contexts retained.',
            results=rows,statement_count=total,status='completed',
            human_review='pending',callback_runtime_validation='not-run',internal_hal_validation='not-run')
(root/'independent-grounding.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

