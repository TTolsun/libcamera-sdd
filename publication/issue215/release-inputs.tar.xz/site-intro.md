# libcamera 설계 문서

**기능·강점·연동 조건을 판단하려면 For Vendor에서, 처음 구조를 배우거나 다른 팀의 코드를 수정하려면 For Developer에서 시작하세요.**

## 어디서 시작할까요?

<div class="reader-start">
<section>
<h3 id="for-vendor">For Vendor</h3>
<p>기능과 지원 조건을 확인하고 연동·구현 범위를 정합니다.</p>
<a href="vendor-overview.md">제품 개요부터 읽기 →</a>
</section>
<section>
<h3 id="for-developer">For Developer</h3>
<p>전체 구조를 익히고 요청 처리 흐름을 따라갑니다.</p>
<a href="overview.md">시스템 개요부터 읽기 →</a>
</section>
</div>

<!-- sdd:overview-visual -->

왼쪽 메뉴는 **독자 → 수행할 작업 → 문서** 순서입니다. For Vendor에서는 도입 판단·연동 구현·장치별 기능 구현을, For Developer에서는 구조 이해·동작 추적과 문제 진단·코드 탐색을 선택하세요.

## Vendor가 먼저 확인할 내용

1. [libcamera 제품 개요](vendor-overview.md)에서 해결하는 문제, 제공 기능과 공통 설계의 강점을 확인합니다.
2. [연동 가이드](vendor-integration.md)에서 연동 순서와 제공 측·구현자의 책임을 정합니다.
3. [지원 범위와 검증](vendor-assurance.md)에서 구성 제약과 성능 근거의 범위를 확인합니다.

이 안내는 공개 libcamera 예제입니다. 사내 HAL의 기능이나 회사 제품의 성능·지원 범위를 나타내지 않습니다.

## 처음 읽는 개발자의 순서

1. [시스템 개요](overview.md#탐색과-파이프라인-선택)에서 `src/libcamera/camera_manager.cpp`의 CameraManager 진입점과 카메라 탐색을 확인합니다. 근거를 펼치면 읽을 파일과 함수가 나옵니다.
2. [요청 제출과 완료](overview.md#요청-제출과-완료)에서 요청이 어디로 이동하고 어떤 신호로 끝나는지 따라갑니다. 낯선 용어는 [용어집](glossary.md)에서 확인합니다.
3. [요청 처리와 문제 진단](request-lifecycle.md)에서 증상에 맞는 코드로 이동합니다. 수정 전에는 [상태와 자원](overview.md#캡처-세션의-상태와-자원), [동기화 책임](overview.md#스레드-경계와-동기화)을 확인합니다.

For Developer는 신입·타팀 개발자를 위한 경로입니다. 클래스 전체를 먼저 외울 필요 없이, 한 요청을 따라간 뒤 작업에 필요한 상세 문서로 이동하세요.

## 지금 필요한 문서

| 하려는 일 | 시작할 문서 |
|---|---|
| 이 프로젝트가 무엇을 받아 무엇을 내놓는지 이해합니다. | [이 프로젝트가 하는 일](team-overview.md) |
| 하드웨어 지원의 구현 범위와 책임을 정합니다. | [libcamera 제품 개요](vendor-overview.md) |
| 카메라를 직접 실행해 보고 설계 이유를 읽습니다. | [실행해 보고 설계 이유 읽기](onboarding.md) |
| 요청을 연동하거나 완료 지연을 진단합니다. | [요청 처리와 문제 진단](request-lifecycle.md) |
| 구성 실패의 원인을 좁힙니다. | [구성 실패를 좁히는 순서](request-lifecycle.md#구성-실패를-좁히는-순서) |
| 파이프라인의 구성·완료·정지를 구현합니다. | [Pipeline Handler](pipeline-handler.md) |
| 모듈 선택과 알고리즘 인터페이스를 수정합니다. | [IPA 관리와 구현 진입점](ipa.md) |
| 처음 구조를 배우고 수정할 코드를 찾습니다. | [시스템 개요](overview.md) |
| 객체 수명과 상태 전이를 확인합니다. | [카메라와 요청 모델](camera-model.md) |

하드웨어 지원을 추가하거나 파이프라인·알고리즘을 수정한다면 **[libcamera 제품 개요](vendor-overview.md)**부터 읽으세요. 구현할 경계와 계약을 확인한 뒤 작업별 상세 문서로 이동할 수 있습니다.

## 기준 설명 찾기

요청·버퍼의 소유권과 재사용 규칙은 **카메라와 요청 모델**, 장치 큐와 완료 순서의 구현 규칙은 **Pipeline Handler**에서 관리합니다. 진단 문서는 이 계약을 연결하여 증상별 확인 순서를 안내합니다.

알고리즘을 따라가려면 [IPU3 LSC의 설정과 프레임 처리](ipu3-lsc-flow.md)를 여세요. 카메라별 튜닝과 커널 지원 조건은 [RKISP1 카메라별 왜곡 보정](rkisp1-dewarp.md)에서 확인합니다.

약어가 낯설면 각 문서 첫머리의 용어 설명이나 [용어집](glossary.md)을 확인하세요.

## 문서를 읽는 방법

1. 페이지 첫 문장과 이동 안내에서 지금 확인할 항목을 고릅니다.
2. 문단 근거의 **발췌**를 누르면 이 문서 안의 원문이 펼쳐집니다. **전체 소스**는 해당 커밋의 코드 저장소로 이동합니다.
3. 실행 확인 항목은 대상 기기의 검증 계획에 옮깁니다.

그림을 누르면 확대와 요소 검색을 사용할 수 있습니다. 관계 그림과 정적 호출 추적은 실제 실행 순서를 보장하지 않습니다. 전체 클래스는 [구성 요소 색인](component-index.md), 주요 호출과 추적 경계는 [핵심 시나리오](scenarios/index.md)에 있습니다.

??? note "검증 범위와 문서 상태"
    "자동 검사 통과"는 인용한 코드 위치와 문장 형식을 기계로 확인했다는 뜻이며, 사람의 내용 승인이 아닙니다. 문서 상단에 검토 상태를, 아래 생성 근거에 분석 커밋과 자동 검사 결과를 표시합니다. 코드 발췌와 대조한 설명도 내용이 맞는지 사람이 검토해야 합니다.

    이 사이트는 공개 libcamera의 정적 분석 결과입니다. 실제 기기의 촬영·성능·오류 복구와 사내 HAL은 검증하지 않았습니다. 설계 선택의 이유와 성능 예산은 코드에 근거가 있을 때만 설명할 수 있습니다.

    [모델 비교 기록](https://github.com/TTolsun/camera-hal-sdd-generator/blob/main/docs/libcamera/records/model-comparison.md)의 4B·9B 초안은 내용 오류가 남아 채택하지 않았습니다.

??? note "생성과 배포"
    [생성기](https://github.com/TTolsun/camera-hal-sdd-generator)가 추출·검증·화면 구성을 담당하고, [공개 문서 저장소](https://github.com/TTolsun/libcamera-sdd)가 공개 입력의 이력과 산출물을 보관합니다. 공개 환경에는 정기 예약을 설치하지 않습니다.

    원래 라이브러리 사용법은 [libcamera 공식 문서](https://docs.libcamera.org/master/)에서 확인하세요.
