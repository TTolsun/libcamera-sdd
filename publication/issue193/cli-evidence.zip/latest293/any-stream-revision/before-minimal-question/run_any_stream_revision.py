from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,sys,json
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.generate import Generator
from sdd.llm import Agent
from sdd.impact import ImpactReport
w=Path(__file__).resolve().parent;c=load(w/'any-stream-revision-generation.yaml');m=KnowledgeModel.load(c.facts_path);sys.stdout.reconfigure(encoding='utf-8');root=w.parents[2]
impact=ImpactReport(base=m.meta['source_commit'],head=m.meta['source_commit'],sections={'request-diagnosis':['Current selected-Claude review rejected any-stream versus all-stream scope in validation-effects']});impact.save(w/'any-stream-revision/impact.json');Generator(c,m,Agent(c.agent,c.build_dir/'prompts')).run(['request-diagnosis'],impact);print('Isolated native pipeline handler generation passed',flush=True)
def run(name,log,args=[]):
 with (w/'any-stream-revision'/log).open('wb') as f:p=subprocess.run([sys.executable,str(w/name),*args],cwd=root,stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0,name+' failed; original outputs preserved';print(name,'EXIT0',flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:
 for f in [pool.submit(run,'review_any_stream_source.py','source.log',['request-diagnosis']),pool.submit(run,'translate_any_stream_revision.py','translation.log')]:f.result()
for name in ('source-review.json','translation-summary.json'):assert json.loads((w/'any-stream-revision'/name).read_bytes())['status']=='passed'
run('review_any_stream_bilingual.py','bilingual.log',['request-diagnosis']);assert json.loads((w/'any-stream-revision/bilingual-review.json').read_bytes())['status']=='passed'
print('Isolated native generation, translation, separate source and bilingual gates passed; original ongoing audit inputs remain unchanged. Integration still required.',flush=True)
