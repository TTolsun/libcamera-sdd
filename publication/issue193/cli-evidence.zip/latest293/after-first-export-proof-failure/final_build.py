from pathlib import Path
import json,hashlib,shutil,yaml,sys,subprocess
from sdd.config import load
from sdd.facts.model import KnowledgeModel
from sdd.consistency import enforce as consistency_enforce
from sdd.document_health import enforce as health_enforce,checkpoint
from sdd.export_site import export_site
from sdd.site_build import verify_site
sys.stdout.reconfigure(encoding='utf-8')
w=Path(__file__).resolve().parent
merges=json.loads((w/'generator-merges.json').read_bytes());assert merges['status']=='merged'
generator_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w.parents[2],text=True).strip();assert generator_commit==merges['final_commit'],'Final export requires the pinned merged generator commit'
glossary_review=json.loads((w/'glossary-tid-review.json').read_bytes());assert glossary_review['status']=='passed'
c=load(w/'publication.yaml');m=KnowledgeModel.load(c.facts_path)
consistency_enforce(c,m)
health=health_enforce(c,m);assert not health['findings']
# Establish the reviewed migration baseline only after all current checks pass.
baseline_archive=w/'before-final-build';baseline_archive.mkdir(exist_ok=True)
if (c.build_dir/'document-baseline.json').exists() and not (baseline_archive/'document-baseline.json').exists():shutil.copyfile(c.build_dir/'document-baseline.json',baseline_archive/'document-baseline.json')
checkpoint(c,health)
for profile in ('publication.yaml','generation.yaml','translation.yaml','independent-review.yaml'):
 p=w/profile;d=yaml.safe_load(p.read_text(encoding='utf-8'))
 for name in list(d['documentation'].get('pages',{})):
  if name.startswith('scenarios/'):
   d['documentation']['pages'][name].pop('max_growth_ratio',None)
   if not d['documentation']['pages'][name]:del d['documentation']['pages'][name]
 p.write_text(yaml.safe_dump(d,allow_unicode=True,sort_keys=False),encoding='utf-8',newline='\n')
c=load(w/'publication.yaml');health=health_enforce(c,m);assert not health['findings'];consistency_enforce(c,m)
out=export_site(c,w/'site');first=(out/'site-manifest.json').read_bytes();validation=verify_site(out)
# The second normal export runs to public/docs after every local proof and the remote-head guard.
# Its complete manifest must equal this first export before the build is marked passed.
terms=json.loads((out/'en/assets/glossary.json').read_bytes());english_tid=next(t for t in terms if t['id']=='term-tid')
korean_tid=next(t for t in yaml.safe_load((w/'config/glossary.yaml').read_text(encoding='utf-8'))['terms'] if t['term']=='TID')
assert hashlib.sha256(english_tid['definition'].encode()).hexdigest()==glossary_review['english_definition_sha256']
assert hashlib.sha256(korean_tid['definition'].encode()).hexdigest()==glossary_review['korean_definition_sha256']
assert glossary_review['source_commit']==m.meta['source_commit'] and glossary_review['source_sha256']==m.evidence['request-lifecycle/journey/thread-id']['sha256']
manifest=json.loads(first)
report=dict(schema=1,status='awaiting-repeat-export',source_commit=m.meta['source_commit'],generator_commit=generator_commit,build_id=manifest['build_id'],validation=validation,manifest_outputs=len(manifest['outputs']),manifest_sha256=hashlib.sha256(first).hexdigest(),repeat_build_identical=False,health_findings=health['findings'],scenario_growth_overrides_removed=True,human_review='pending',internal_hal_validation='not-run')
(w/'build-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
