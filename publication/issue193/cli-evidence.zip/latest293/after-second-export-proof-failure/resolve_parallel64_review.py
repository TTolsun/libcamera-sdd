from pathlib import Path
import json,hashlib,re,sys
from sdd.translation import _validate_text
sys.stdout.reconfigure(encoding='utf-8');w=Path(__file__).resolve().parent;old=json.loads((w/'parallel64-translation-review.json').read_bytes());fixed=json.loads((w/'parallel64-revised-bilingual.json').read_bytes());assert fixed['status']=='passed';cat=json.loads((w/'run/english.json').read_bytes());src=json.loads((w/'independent-repaired-documents.json').read_bytes());bi=json.loads((w/'bilingual-repaired-documents.json').read_bytes());build=json.loads((w/'build-validation.json').read_bytes());overlay=json.loads((w/'facts-overlay-verification.json').read_bytes());assert src['status']==bi['status']==build['status']==overlay['status']=='passed'
cam=next(p for p in src['pages'] if p['page']=='camera-model.md');cambi=next(p for p in bi['pages'] if p['page']=='camera-model.md');assert cam['status']==cambi['status']=='passed';revised={p['id']:p for p in fixed['pairs']};judgments={r['id']:r for r in old['reviews']};rows=[]
metadata_ids={'19','20','21','22','23','29','30','35'}
for p in old['pairs']:
 idx=p['id'];key=p['key'];r=judgments[idx]
 if idx=='1':
  assert key not in cat['strings'],'Rejected old Camera::configure unit still published'
  rows.append(dict(id=idx,resolution='superseded-source-correction',source_page='camera-model.md',source_review=src['run'],bilingual_review=bi['run'],scope='Old Korean and English condition removed through actual selected native regeneration; source-reviewed current explanation distinguishes null stream/Fatal termination from an actual returned error.'))
  continue
 assert key in cat['strings'];value=cat['strings'][key];_validate_text(key,value);sha=hashlib.sha256(value.encode()).hexdigest()
 if idx in revised:
  assert sha==revised[idx]['current_value_sha256'];assert next(x for x in fixed['reviews'] if x['id']==idx)['supported']
  rows.append(dict(id=idx,resolution='fresh-native-translation-and-independent-review',value_sha256=sha,review=fixed['run']))
 elif r['source_supported'] and r['preserves_supported_meaning']:
  assert sha==p['current_value_sha256'];rows.append(dict(id=idx,resolution='retained-independent-compatible-source-review',value_sha256=sha,receipt=r['receipt']))
 else:
  assert idx in metadata_ids and not r['source_supported'] and r['preserves_supported_meaning']
  assert re.search('근거 수준|근거 파일|소스 발췌|시작하는 발췌',key),'Unclassified API rejection cannot be treated as metadata'
  assert sha==p['current_value_sha256']
  rows.append(dict(id=idx,resolution='rendering-metadata-domain',value_sha256=sha,language_review=r['receipt'],native_source_verdict='Original insufficient-input finding retained unchanged; no API entailment approval claimed.',deterministic_checks=['Normal current model/evidence collector and immutable source/hash validation','Normal source-compatible manuscript/export gates','All-placeholder preservation and zero-link-error/repeat-manifest checks'],scope='Location/count/file/history labels are renderer/provenance metadata, not additional source-runtime API assertions. Original analysis labels and prior model records remain historical; no new execution or device result is claimed.'))
report=dict(schema=1,status='passed',source_commit=cat['source_commit'],catalog_sha256=hashlib.sha256((w/'run/english.json').read_bytes()).hexdigest(),manifest_sha256=build['manifest_sha256'],original_negative_review=old['run'],rows=rows,metadata_source_review_not_claimed=sorted(metadata_ids),human_review='pending',internal_hal_validation='not-run',scope='Resolve every concurrent public64 comparison item with its appropriate evidence domain; original negative/insufficient-input verdicts are preserved, not rewritten as successful CLI reviews.')
(w/'parallel64-integration-resolution.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Resolved',len(rows),'concurrent release comparison items with separate source and metadata domains',flush=True)
