<!-- system -->
Return only OK. Do not use tools.

<!-- user -->
Verify this model invocation completes.
